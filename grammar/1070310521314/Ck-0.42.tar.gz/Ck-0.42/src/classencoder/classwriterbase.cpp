/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "classwriterbase.hpp"

namespace ClassEncoder
{
using namespace std;

//! Default constructor
/*!
 * Empty
 */
ClassWriterBase::ClassWriterBase()
{
}

//! Default destructor
/*!
 * Empty
 */
ClassWriterBase::~ClassWriterBase()
{
}

//! Write an array to the stream
/*!
 * Writes an array of bytes to the class stream as u1 units.
 * \param stream The class stream
 * \param data A pointer to the data that should be written
 * \param length The length of the data to be written in bytes
 */
void ClassWriterBase::writeu1Array( ofstream &stream, const char* data, unsigned int length ) const
{
    stream.write( data, length );
}

//! Write an u1 value to the stream
/*!
 * This function is provided for completeness as there is no conversien necessary.
 * \param stream The class stream
 * \param num The u1 value to write to the stream
 */
void ClassWriterBase::writeu1( ofstream &stream, const u1 &num ) const
{
    stream.write( (const char *) &num, 1 );
}

//! Write an u2 value to the stream
/*!
 * Converts the number to big endian and writes it to the class stream.
 * \param stream The class stream
 * \param num The u2 value to write to the stream
 */
void ClassWriterBase::writeu2( ofstream &stream, const u2 &num ) const
{
    u2 bigNum = u2ToBigEndian( num );
    stream.write( (const char*)&bigNum, 2 );
}

//! Write an u4 value to the stream
/*!
 * Converts the number to big endian and writes it to the class stream.
 * \param stream The class stream
 * \param num The u4 value to write to the stream
 */
void ClassWriterBase::writeu4( ofstream &stream, const u4 &num ) const
{
    u4 bigNum = u4ToBigEndian( num );
    stream.write( (const char*)&bigNum, 4 );
}


//! Convert an u2 value to big endian
/*!
 * \param num The number to convert.
 */
u2 ClassWriterBase::u2ToBigEndian( u2 num ) const
{
    return ( num >> 8 ) + (( num & 0xFF ) <<8 );
}

//! Convert an u4 value to big endian
/*!
 * \param num The number to convert.
 */
u4 ClassWriterBase::u4ToBigEndian( u4 num ) const
{
    return (( num & 0xFF ) << 24 ) +
        (( num >> 8 & 0xFF ) << 16 ) +
        (( num >> 16 & 0xFF ) << 8 ) +
        ( num >> 24 );
}

} // end namespace
