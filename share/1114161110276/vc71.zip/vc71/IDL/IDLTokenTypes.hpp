#ifndef INC_IDLTokenTypes_hpp_
#define INC_IDLTokenTypes_hpp_

/* $ANTLR 2.7.5 (20050128): "idl.g" -> "IDLTokenTypes.hpp"$ */

#ifndef CUSTOM_API
# define CUSTOM_API
#endif

#ifdef __cplusplus
struct CUSTOM_API IDLTokenTypes {
#endif
	enum {
		EOF_ = 1,
		SEMI = 4,
		LITERAL_module = 5,
		LCURLY = 6,
		RCURLY = 7,
		LITERAL_interface = 8,
		COLON = 9,
		COMMA = 10,
		SCOPEOP = 11,
		LITERAL_const = 12,
		ASSIGN = 13,
		OR = 14,
		XOR = 15,
		AND = 16,
		LSHIFT = 17,
		RSHIFT = 18,
		PLUS = 19,
		MINUS = 20,
		STAR = 21,
		DIV = 22,
		MOD = 23,
		TILDE = 24,
		LPAREN = 25,
		RPAREN = 26,
		LITERAL_TRUE = 27,
		LITERAL_FALSE = 28,
		LITERAL_typedef = 29,
		LITERAL_native = 30,
		LITERAL_octet = 31,
		LITERAL_any = 32,
		LITERAL_unsigned = 33,
		LITERAL_short = 34,
		LITERAL_long = 35,
		LITERAL_char = 36,
		LITERAL_float = 37,
		LITERAL_double = 38,
		LITERAL_boolean = 39,
		LITERAL_struct = 40,
		LITERAL_union = 41,
		LITERAL_switch = 42,
		LITERAL_case = 43,
		LITERAL_default = 44,
		LITERAL_enum = 45,
		LITERAL_sequence = 46,
		LT_ = 47,
		GT = 48,
		LITERAL_string = 49,
		LBRACK = 50,
		RBRACK = 51,
		LITERAL_readonly = 52,
		LITERAL_attribute = 53,
		LITERAL_exception = 54,
		LITERAL_oneway = 55,
		LITERAL_void = 56,
		LITERAL_in = 57,
		LITERAL_out = 58,
		LITERAL_inout = 59,
		LITERAL_raises = 60,
		LITERAL_context = 61,
		INT = 62,
		OCTAL = 63,
		HEX = 64,
		STRING_LITERAL = 65,
		CHAR_LITERAL = 66,
		FLOAT = 67,
		IDENT = 68,
		QUESTION = 69,
		DOT = 70,
		NOT = 71,
		WS_ = 72,
		PREPROC_DIRECTIVE = 73,
		SL_COMMENT = 74,
		ML_COMMENT = 75,
		ESC = 76,
		VOCAB = 77,
		DIGIT = 78,
		OCTDIGIT = 79,
		HEXDIGIT = 80,
		NULL_TREE_LOOKAHEAD = 3
	};
#ifdef __cplusplus
};
#endif
#endif /*INC_IDLTokenTypes_hpp_*/
