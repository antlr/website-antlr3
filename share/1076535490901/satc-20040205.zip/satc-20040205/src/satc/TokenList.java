/*
 * Created on 30.11.2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package satc;

import javax.swing.text.Document;
import javax.swing.text.Element;

import antlr.Token;
import antlr.TokenStream;
import antlr.TokenStreamException;

/**
 * @author bogdan
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TokenList implements TokenStream {

	/* (non-Javadoc)
	 * @see antlr.TokenStream#nextToken()
	 */
	//TODO throw exception?
	public Token nextToken() throws TokenStreamException {
		ListToken t = crtToken;
		if (t != null) {
			crtToken = (ListToken) t.getHiddenAfter();
//System.out.println("crt token = " + t);	
			return t;
		}
		else return new ListToken( antlr.ANTLRTokenTypes.EOF, "<EOF>");
	}
	
	public Token previousToken() throws TokenStreamException {
		ListToken t = crtToken;
		if (t != null) {
			crtToken = (ListToken) t.getHiddenBefore();
//System.out.println("crt token = " + crtToken);	
		}
		return t;
	}

	private Document doc;
	ListToken crtToken;
	/**
	 * 
	 */
	public void print() throws TokenStreamException {
		ListToken t = crtToken;
		for (t = (ListToken)nextToken(); t != null; t = (ListToken)nextToken()) {
			System.out.print(t.getText());
			if (t.getType() == antlr.ANTLRTokenTypes.EOF)
				System.out.print("<<EOF>>");
		}
	}

	/**
	 * @param doc
	 */
	public void reset(Document doc) {
		this.doc = doc;
		Element line = doc.getDefaultRootElement().getElement(0);
		crtToken = (ListToken) line.getAttributes().getAttribute("firstToken");
	}

	/**
	 * @param tok
	 */
	public void reset( ListToken tok) {
		crtToken = tok;
	}
}
