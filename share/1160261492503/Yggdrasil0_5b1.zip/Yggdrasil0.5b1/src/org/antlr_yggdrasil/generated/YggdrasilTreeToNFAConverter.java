// $ANTLR 2.7.6 (2005-12-22): "YggdrasilBuilder.g" -> "YggdrasilTreeToNFAConverter.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.generated;
import org.antlr_yggdrasil.tool.*;
import org.antlr_yggdrasil.tool.Grammar;
import java.util.*;
import org.antlr_yggdrasil.analysis.*;
import org.antlr_yggdrasil.misc.*;
import org.antlr.stringtemplate.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** Build an NFA from a tree representing an ANTLR grammar. */
public class YggdrasilTreeToNFAConverter extends antlr.TreeParser       implements YggdrasilTreeToNFAConverterTokenTypes
 {

/** Factory used to create nodes and submachines */
protected NFAFactory factory = null;

/** Which NFA object are we filling in? */
protected NFA nfa = null;

/** Which grammar are we converting an NFA for? */
protected Grammar grammar = null;

protected String currentRuleName = null;

public YggdrasilTreeToNFAConverter(Grammar g, NFA nfa, NFAFactory factory) {
	this();
	this.grammar = g;
	this.nfa = nfa;
	this.factory = factory;
}

/* These shouldn't be here, but ... */
protected StringTemplateGroup templates;
protected StringTemplateGroup userTemplates;

public void setTemplates(StringTemplateGroup t, StringTemplateGroup u) {
	templates = t;
	userTemplates = u;
}

protected String getUname(String nm) {
	String firstChar = nm.substring(0,1).toUpperCase();
	String uname = firstChar + nm.substring(1);

	return uname;
}

protected void init() {
    // define all the rule begin/end NFAStates to solve forward reference issues
    Collection rules = grammar.getRules();
    for (Iterator itr = rules.iterator(); itr.hasNext();) {
		Rule r = (Rule) itr.next();
        String ruleName = r.name;
        NFAState ruleBeginState = factory.newState();
        ruleBeginState.setDescription("rule "+ruleName+" start");
		ruleBeginState.setEnclosingRuleName(ruleName);
        grammar.setRuleStartState(ruleName, ruleBeginState);
        NFAState ruleEndState = factory.newState();
        ruleEndState.setDescription("rule "+ruleName+" end");
        ruleEndState.setAcceptState(true);
		ruleEndState.setEnclosingRuleName(ruleName);
        grammar.setRuleStopState(ruleName, ruleEndState);
    }
}

protected void addFollowTransition(String ruleName, NFAState following) {
     //System.out.println("adding follow link to rule "+ruleName);
     // find last link in FOLLOW chain emanating from rule
     NFAState end = grammar.getRuleStopState(ruleName);
     while ( end.transition(1)!=null ) {
         end = (NFAState)end.transition(1).target;
     }
     if ( end.transition(0)!=null ) {
         // already points to a following node
         // gotta add another node to keep edges to a max of 2
         NFAState n = factory.newState();
         Transition e = new Transition(Label.EPSILON, n);
         end.addTransition(e);
         end = n;
     }
     Transition followEdge = new Transition(Label.EPSILON, following);
     end.addTransition(followEdge);
}

protected void finish() {
    List rules = new LinkedList();
    rules.addAll(grammar.getRules());
    int numEntryPoints = factory.build_EOFStates(rules);
    if ( numEntryPoints==0 ) {
        ErrorManager.grammarError(ErrorManager.MSG_NO_GRAMMAR_START_RULE,
                                  grammar,
                                  null,
                                  grammar.getName());
    }
}

    public void reportError(RecognitionException ex) {
		Token token = null;
		if ( ex instanceof MismatchedTokenException ) {
			token = ((MismatchedTokenException)ex).token;
		}
		else if ( ex instanceof NoViableAltException ) {
			token = ((NoViableAltException)ex).token;
		}
        ErrorManager.syntaxError(
            ErrorManager.MSG_SYNTAX_ERROR,
            token,
            "buildnfa: "+ex.toString(),
            ex);
    }
public YggdrasilTreeToNFAConverter() {
	tokenNames = _tokenNames;
}

	public final void file(AST _t) throws RecognitionException {
		
		GrammarAST file_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			_loop3:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_header)) {
					fileheader(_t);
					_t = _retTree;
				}
				else {
					break _loop3;
				}
				
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				typeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			grammar(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void fileheader(AST _t) throws RecognitionException {
		
		GrammarAST fileheader_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t7 = _t;
			GrammarAST tmp1_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_header);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp2_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp3_AST_in = (GrammarAST)_t;
			match(_t,LCURLY);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case TOKENS:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t7;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void typeDecls(AST _t) throws RecognitionException {
		
		GrammarAST typeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t38 = _t;
			GrammarAST tmp4_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop40:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LCURLY||_t.getType()==LITERAL_atomic)) {
					attributeTypeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop40;
				}
				
			} while (true);
			}
			_t = __t38;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void optionsSpec(AST _t) throws RecognitionException {
		
		GrammarAST optionsSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t13 = _t;
			GrammarAST tmp5_AST_in = (GrammarAST)_t;
			match(_t,OPTIONS);
			_t = _t.getFirstChild();
			{
			int _cnt15=0;
			_loop15:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN)) {
					option(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt15>=1 ) { break _loop15; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt15++;
			} while (true);
			}
			_t = __t13;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammar(AST _t) throws RecognitionException {
		
		GrammarAST grammar_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			init();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LEXER_GRAMMAR:
			{
				AST __t67 = _t;
				GrammarAST tmp6_AST_in = (GrammarAST)_t;
				match(_t,LEXER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t67;
				_t = _t.getNextSibling();
				break;
			}
			case PARSER_GRAMMAR:
			{
				AST __t68 = _t;
				GrammarAST tmp7_AST_in = (GrammarAST)_t;
				match(_t,PARSER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t68;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_GRAMMAR:
			{
				AST __t69 = _t;
				GrammarAST tmp8_AST_in = (GrammarAST)_t;
				match(_t,TREE_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t69;
				_t = _t.getNextSibling();
				break;
			}
			case COMBINED_GRAMMAR:
			{
				AST __t70 = _t;
				GrammarAST tmp9_AST_in = (GrammarAST)_t;
				match(_t,COMBINED_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t70;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			finish();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokensSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokensSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t20 = _t;
			GrammarAST tmp10_AST_in = (GrammarAST)_t;
			match(_t,TOKENS);
			_t = _t.getFirstChild();
			{
			int _cnt22=0;
			_loop22:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN||_t.getType()==TOKEN_REF)) {
					tokenSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt22>=1 ) { break _loop22; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt22++;
			} while (true);
			}
			_t = __t20;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void action(AST _t) throws RecognitionException {
		
		GrammarAST action_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t122 = _t;
			GrammarAST tmp11_AST_in = (GrammarAST)_t;
			match(_t,RCURLY);
			_t = _t.getFirstChild();
			bareTemplate(_t);
			_t = _retTree;
			_t = __t122;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void option(AST _t) throws RecognitionException {
		
		GrammarAST option_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t17 = _t;
			GrammarAST tmp12_AST_in = (GrammarAST)_t;
			match(_t,ASSIGN);
			_t = _t.getFirstChild();
			GrammarAST tmp13_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			optionValue(_t);
			_t = _retTree;
			_t = __t17;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void optionValue(AST _t) throws RecognitionException {
		
		GrammarAST optionValue_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp14_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp15_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case KEYWORD:
			{
				GrammarAST tmp16_AST_in = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				break;
			}
			case INT:
			{
				GrammarAST tmp17_AST_in = (GrammarAST)_t;
				match(_t,INT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokenSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokenSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				GrammarAST tmp18_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp19_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp20_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN:
				case TOKEN_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN:
			{
				AST __t25 = _t;
				GrammarAST tmp21_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getFirstChild();
				GrammarAST tmp22_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp23_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp24_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case KEYWORD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t25;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t28 = _t;
			GrammarAST tmp25_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop30:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==SEMI||_t.getType()==LITERAL_public||_t.getType()==LITERAL_import)) {
					grammarAttributeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop30;
				}
				
			} while (true);
			}
			_t = __t28;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecl(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_public:
				{
					GrammarAST tmp26_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_public);
					_t = _t.getNextSibling();
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				attributeVarDecl(_t);
				_t = _retTree;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp27_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_import);
				_t = _t.getNextSibling();
				GrammarAST tmp28_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeVarDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeVarDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t48 = _t;
			GrammarAST tmp29_AST_in = (GrammarAST)_t;
			match(_t,SEMI);
			_t = _t.getFirstChild();
			GrammarAST tmp30_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp31_AST_in = (GrammarAST)_t;
				match(_t,OPEN_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				GrammarAST tmp32_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				_loop51:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						GrammarAST tmp33_AST_in = (GrammarAST)_t;
						match(_t,ID);
						_t = _t.getNextSibling();
					}
					else {
						break _loop51;
					}
					
				} while (true);
				}
				GrammarAST tmp34_AST_in = (GrammarAST)_t;
				match(_t,CLOSE_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp35_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			_t = __t48;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ruleAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST ruleAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t34 = _t;
			GrammarAST tmp36_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop36:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SEMI:
				{
					attributeVarDecl(_t);
					_t = _retTree;
					break;
				}
				case ID:
				case LITERAL_new:
				case LITERAL_using:
				{
					attributeUseDecl(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					break _loop36;
				}
				}
			} while (true);
			}
			_t = __t34;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeUseDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeUseDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp37_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp38_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getNextSibling();
				{
				GrammarAST tmp39_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ID:
				case SEMI:
				case DOT_TEXT:
				case LITERAL_new:
				case LITERAL_using:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop64:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop64;
					}
					
				} while (true);
				}
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp40_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_new);
				_t = _t.getNextSibling();
				GrammarAST tmp41_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp42_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_using);
				_t = _t.getNextSibling();
				GrammarAST tmp43_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeTypeDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeTypeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_atomic:
			{
				AST __t42 = _t;
				GrammarAST tmp44_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_atomic);
				_t = _t.getFirstChild();
				GrammarAST tmp45_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_native);
				_t = _t.getNextSibling();
				GrammarAST tmp46_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				_t = __t42;
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				AST __t43 = _t;
				GrammarAST tmp47_AST_in = (GrammarAST)_t;
				match(_t,LCURLY);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_native:
				{
					GrammarAST tmp48_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_native);
					_t = _t.getNextSibling();
					break;
				}
				case ID:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				GrammarAST tmp49_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp50_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				_loop46:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI)) {
						attributeVarDecl(_t);
						_t = _retTree;
					}
					else {
						break _loop46;
					}
					
				} while (true);
				}
				_t = __t43;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void idQualifier(AST _t) throws RecognitionException {
		
		GrammarAST idQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp51_AST_in = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case ID:
			case SYN_SEMPRED:
			case BANGEDUP:
			case SEMI:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arrayQualifier(AST _t) throws RecognitionException {
		
		GrammarAST arrayQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t55 = _t;
			GrammarAST tmp52_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp53_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp54_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case DOT_TEXT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop59:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop59;
					}
					
				} while (true);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t55;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarSpec(AST _t) throws RecognitionException {
		
		GrammarAST grammarSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST cmt = null;
		
		try {      // for error handling
			GrammarAST tmp55_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOC_COMMENT:
			{
				cmt = (GrammarAST)_t;
				match(_t,DOC_COMMENT);
				_t = _t.getNextSibling();
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case TOKENS:
			case RULE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			rules(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		GrammarAST rules_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt78=0;
			_loop78:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					rule(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt78>=1 ) { break _loop78; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt78++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		GrammarAST rule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		
		StateCluster g=null;
		StateCluster b = null;
		String r=null;
		
		
		try {      // for error handling
			AST __t80 = _t;
			GrammarAST tmp56_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			r=id.getText();
			currentRuleName = r; factory.setCurrentRuleName(r);
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			AST __t85 = _t;
			GrammarAST tmp57_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			b=block(_t);
			_t = _retTree;
			GrammarAST tmp58_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t85;
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp59_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			
			/* 11/28/2005: removed to treat Tokens rule like any other
			if ( r.equals(Grammar.ARTIFICIAL_TOKENS_RULENAME) ) {
			NFAState ruleState = factory.build_ArtificialMatchTokensRuleNFA();
			if ( grammar.getNumberOfAltsForDecisionNFA(ruleState)>1 ) {
				                ruleState.setDecisionASTNode(#BLOCK); // always track ast node
			int d = grammar.assignDecisionNumber( ruleState );
			grammar.setDecisionNFA( d, ruleState );
			grammar.setDecisionBlockAST(d, #BLOCK);
			}
			// hook rule start state for Tokens to its manually-created start
			NFAState start = grammar.getRuleStartState(r);
					        start.addTransition(new Transition(Label.EPSILON, ruleState));
			}
			else */
			{
							if ( Character.isLowerCase(r.charAt(0)) ||
								 grammar.type==Grammar.LEXER )
							{
								// attach start node to block for this rule
								NFAState start = grammar.getRuleStartState(r);
								start.setAssociatedASTNode(id);
								start.addTransition(new Transition(Label.EPSILON, b.left));
			
								// track decision if > 1 alts
								if ( grammar.getNumberOfAltsForDecisionNFA(b.left)>1 ) {
									b.left.setDescription(grammar.grammarTreeToString((GrammarAST) rule_AST_in));
									b.left.setDecisionASTNode((GrammarAST) tmp57_AST_in);
									int d = grammar.assignDecisionNumber( b.left );
									grammar.setDecisionNFA( d, b.left );
				grammar.setDecisionBlockAST(d, tmp57_AST_in);
								}
			
								// hook to end of rule node
								NFAState end = grammar.getRuleStopState(r);
								b.right.addTransition(new Transition(Label.EPSILON,end));
							}
			}
			
			_t = __t80;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void modifier(AST _t) throws RecognitionException {
		
		GrammarAST modifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_protected:
			{
				GrammarAST tmp60_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_protected);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_public:
			{
				GrammarAST tmp61_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_public);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_private:
			{
				GrammarAST tmp62_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_private);
				_t = _t.getNextSibling();
				break;
			}
			case FRAGMENT:
			{
				GrammarAST tmp63_AST_in = (GrammarAST)_t;
				match(_t,FRAGMENT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  block(AST _t) throws RecognitionException {
		StateCluster g = null;
		
		GrammarAST block_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StateCluster a = null;
		List alts = new LinkedList();
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt95=0;
			_loop95:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					a=alternative(_t);
					_t = _retTree;
					alts.add(a);
				}
				else {
					if ( _cnt95>=1 ) { break _loop95; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt95++;
			} while (true);
			}
			
			g = factory.build_AlternativeBlock(alts);
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void exceptionGroup(AST _t) throws RecognitionException {
		
		GrammarAST exceptionGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt102=0;
			_loop102:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_exception)) {
					exceptionSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt102>=1 ) { break _loop102; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt102++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void constructorRule(AST _t) throws RecognitionException {
		
		GrammarAST constructorRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t88 = _t;
			GrammarAST tmp64_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_COLON);
			_t = _t.getFirstChild();
			GrammarAST tmp65_AST_in = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			{
			int _cnt90=0;
			_loop90:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_0.member(_t.getType()))) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt90>=1 ) { break _loop90; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt90++;
			} while (true);
			}
			_t = __t88;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeItem(AST _t) throws RecognitionException {
		
		GrammarAST attributeItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			attributeElement(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  alternative(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST alternative_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StateCluster e = null;
		
		
		try {      // for error handling
			AST __t97 = _t;
			GrammarAST tmp66_AST_in = (GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt99=0;
			_loop99:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_1.member(_t.getType()))) {
					e=element(_t);
					_t = _retTree;
					g = factory.build_AB(g,e);
				}
				else {
					if ( _cnt99>=1 ) { break _loop99; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt99++;
			} while (true);
			}
			GrammarAST tmp67_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t97;
			_t = _t.getNextSibling();
			
			if (g==null) { // if alt was a list of actions or whatever
			g = factory.build_Epsilon();
			}
			else {
				factory.optimizeAlternative(g);
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final StateCluster  element(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST element_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST p = null;
		GrammarAST spred = null;
		StringTemplate pred = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			case CHAR_RANGE:
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case NOT:
			case WILDCARD:
			{
				g=elementItem(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case BANGEDUP:
			{
				g=ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				g=treeMatcher(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp68_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case RANGE:
				case CHAR_RANGE:
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case NOT:
				case WILDCARD:
				{
					g=elementItem(_t);
					_t = _retTree;
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				{
					g=baseebnf(_t);
					_t = _retTree;
					break;
				}
				case TREE_BEGIN:
				{
					g=treeMatcher(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeElement(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				attributeElement(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t120 = _t;
				GrammarAST tmp69_AST_in = (GrammarAST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t120;
				_t = _t.getNextSibling();
				break;
			}
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case SEMPRED:
			{
				p = _t==ASTNULL ? null : (GrammarAST)_t;
				pred=sempred(_t);
				_t = _retTree;
				g = factory.build_SemanticPredicate(p, pred);
				break;
			}
			case SYN_SEMPRED:
			{
				spred = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				g = factory.build_SemanticPredicate(spred);
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp70_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				g = factory.build_Epsilon();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void exceptionSpec(AST _t) throws RecognitionException {
		
		GrammarAST exceptionSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t104 = _t;
			GrammarAST tmp71_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_exception);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RBRACKET:
			{
				arg_decl(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop107:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_catch)) {
					exceptionHandler(_t);
					_t = _retTree;
				}
				else {
					break _loop107;
				}
				
			} while (true);
			}
			_t = __t104;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arg_decl(AST _t) throws RecognitionException {
		
		GrammarAST arg_decl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t109 = _t;
			GrammarAST tmp72_AST_in = (GrammarAST)_t;
			match(_t,RBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp73_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp74_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case COLON:
			{
				GrammarAST tmp75_AST_in = (GrammarAST)_t;
				match(_t,COLON);
				_t = _t.getNextSibling();
				{
				int _cnt113=0;
				_loop113:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt113>=1 ) { break _loop113; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt113++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t109;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionHandler(AST _t) throws RecognitionException {
		
		GrammarAST exceptionHandler_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t115 = _t;
			GrammarAST tmp76_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_catch);
			_t = _t.getFirstChild();
			arg_decl(_t);
			_t = _retTree;
			action(_t);
			_t = _retTree;
			_t = __t115;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void assignment(AST _t) throws RecognitionException {
		
		GrammarAST assignment_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t151 = _t;
			GrammarAST tmp77_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				break;
			}
			case TOKEN_REF:
			{
				GrammarAST tmp78_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp79_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t151;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  elementItem(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST elementItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST n = null;
		GrammarAST c = null;
		GrammarAST ast1 = null;
		GrammarAST t = null;
		GrammarAST ast3 = null;
		GrammarAST a = null;
		GrammarAST b = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case WILDCARD:
			{
				g=atom(_t);
				_t = _retTree;
				break;
			}
			case NOT:
			{
				AST __t160 = _t;
				n = _t==ASTNULL ? null :(GrammarAST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case KEYWORD:
				{
					AST __t162 = _t;
					c = _t==ASTNULL ? null :(GrammarAST)_t;
					match(_t,KEYWORD);
					_t = _t.getFirstChild();
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast1 = _t==ASTNULL ? null : (GrammarAST)_t;
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t162;
					_t = _t.getNextSibling();
					
						            int ttype=0;
								if ( grammar.type==Grammar.LEXER ) {
								ttype = Grammar.getCharValueFromGrammarCharLiteral(c.getText());
								}
								else {
								ttype = grammar.getTokenType(c.getText());
							}
					IntSet notAtom = grammar.complement(ttype);
					if ( notAtom.isNil() ) {
					ErrorManager.grammarError(ErrorManager.MSG_EMPTY_COMPLEMENT,
										  			              grammar,
													              c.token,
														          c.getText());
					}
						            g=factory.build_Set(notAtom);
						
					break;
				}
				case TOKEN_REF:
				{
					AST __t164 = _t;
					t = _t==ASTNULL ? null :(GrammarAST)_t;
					match(_t,TOKEN_REF);
					_t = _t.getFirstChild();
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast3 = _t==ASTNULL ? null : (GrammarAST)_t;
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t164;
					_t = _t.getNextSibling();
					
						           int ttype = grammar.getTokenType(t.getText());
					IntSet notAtom = grammar.complement(ttype);
					if ( notAtom.isNil() ) {
					ErrorManager.grammarError(ErrorManager.MSG_EMPTY_COMPLEMENT,
									  			              grammar,
												              t.token,
													          t.getText());
					}
						           g=factory.build_Set(notAtom);
						
					break;
				}
				case SET:
				{
					g=set(_t);
					_t = _retTree;
					
						           GrammarAST stNode = (GrammarAST)n.getFirstChild();
					IntSet notSet = grammar.complement(stNode.getSetValue());
					stNode.setSetValue(notSet);
					if ( notSet.isNil() ) {
					ErrorManager.grammarError(ErrorManager.MSG_EMPTY_COMPLEMENT,
									  			              grammar,
												              n.token);
					}
						           g=factory.build_Set(notSet);
						
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				n.followingNFAState = g.right;
				_t = __t160;
				_t = _t.getNextSibling();
				break;
			}
			case RANGE:
			{
				AST __t166 = _t;
				GrammarAST tmp80_AST_in = (GrammarAST)_t;
				match(_t,RANGE);
				_t = _t.getFirstChild();
				a = _t==ASTNULL ? null : (GrammarAST)_t;
				atom(_t);
				_t = _retTree;
				b = _t==ASTNULL ? null : (GrammarAST)_t;
				atom(_t);
				_t = _retTree;
				_t = __t166;
				_t = _t.getNextSibling();
				g = factory.build_Range(grammar.getTokenType(a.getText()),
				grammar.getTokenType(b.getText()));
				break;
			}
			case CHAR_RANGE:
			{
				AST __t167 = _t;
				GrammarAST tmp81_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t167;
				_t = _t.getNextSibling();
				
				if ( grammar.type==Grammar.LEXER ) {
					g = factory.build_CharRange(c1.getText(), c2.getText());
				}
				
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void ast_suffix(AST _t) throws RecognitionException {
		
		GrammarAST ast_suffix_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case CARET:
			{
				GrammarAST tmp82_AST_in = (GrammarAST)_t;
				match(_t,CARET);
				_t = _t.getNextSibling();
				break;
			}
			case BANG:
			{
				GrammarAST tmp83_AST_in = (GrammarAST)_t;
				match(_t,BANG);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  ebnf(AST _t) throws RecognitionException {
		StateCluster g = null;
		
		GrammarAST ebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANGEDUP:
			{
				AST __t173 = _t;
				GrammarAST tmp84_AST_in = (GrammarAST)_t;
				match(_t,BANGEDUP);
				_t = _t.getFirstChild();
				g=baseebnf(_t);
				_t = _retTree;
				_t = __t173;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				g=baseebnf(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final StateCluster  treeMatcher(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST treeMatcher_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StateCluster e=null;
		
		
		try {      // for error handling
			AST __t183 = _t;
			GrammarAST tmp85_AST_in = (GrammarAST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			GrammarAST el=(GrammarAST)_t;
			g=element(_t);
			_t = _retTree;
			
			StateCluster down = factory.build_Atom(Label.DOWN);
			// TODO set following states for imaginary nodes?
			//el.followingNFAState = down.right;
					   g = factory.build_AB(g,down);
					
			{
			_loop185:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_1.member(_t.getType()))) {
					el=(GrammarAST)_t;
					e=element(_t);
					_t = _retTree;
					g = factory.build_AB(g,e);
				}
				else {
					break _loop185;
				}
				
			} while (true);
			}
			
			StateCluster up = factory.build_Atom(Label.UP);
			//el.followingNFAState = up.right;
					   g = factory.build_AB(g,up);
					   // tree roots point at right edge of DOWN for LOOK computation later
					   treeMatcher_AST_in.NFATreeDownState = down.left;
					
			_t = __t183;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void attrLabel(AST _t) throws RecognitionException {
		
		GrammarAST attrLabel_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LABEL_ATTRIBUTE:
			{
				a = (GrammarAST)_t;
				match(_t,LABEL_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			case ASSIGN_ATTRIBUTE:
			{
				GrammarAST tmp86_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case RANGE:
			case CHAR_RANGE:
			case SET:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop157:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop157;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  baseebnf(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST baseebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST blk = null;
		GrammarAST eob = null;
		GrammarAST blk2 = null;
		GrammarAST eob3 = null;
		
		StateCluster b = null;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				AST __t175 = _t;
				GrammarAST tmp87_AST_in = (GrammarAST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				GrammarAST tmp88_AST_in = (GrammarAST)_t;
				match(_t,EOB);
				_t = _t.getNextSibling();
				_t = __t175;
				_t = _t.getNextSibling();
				
				// track decision if > 1 alts
				if ( grammar.getNumberOfAltsForDecisionNFA(b.left)>1 ) {
				b.left.setDescription(grammar.grammarTreeToString((GrammarAST) tmp87_AST_in));
				b.left.setDecisionASTNode((GrammarAST) tmp87_AST_in);
				int d = grammar.assignDecisionNumber( b.left );
				grammar.setDecisionNFA( d, b.left );
				grammar.setDecisionBlockAST(d, tmp87_AST_in);
				}
				g = b;
				
				break;
			}
			case OPTIONAL:
			{
				AST __t176 = _t;
				GrammarAST tmp89_AST_in = (GrammarAST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				AST __t177 = _t;
				blk = _t==ASTNULL ? null :(GrammarAST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				GrammarAST tmp90_AST_in = (GrammarAST)_t;
				match(_t,EOB);
				_t = _t.getNextSibling();
				_t = __t177;
				_t = _t.getNextSibling();
				_t = __t176;
				_t = _t.getNextSibling();
				
				g = factory.build_Aoptional(b);
					g.left.setDescription(grammar.grammarTreeToString(baseebnf_AST_in,false));
				// there is always at least one alt even if block has just 1 alt
				int d = grammar.assignDecisionNumber( g.left );
						grammar.setDecisionNFA(d, g.left);
				grammar.setDecisionBlockAST(d, (GrammarAST) blk);
				g.left.setDecisionASTNode(baseebnf_AST_in);
					
				break;
			}
			case CLOSURE:
			{
				AST __t178 = _t;
				GrammarAST tmp91_AST_in = (GrammarAST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				AST __t179 = _t;
				GrammarAST tmp92_AST_in = (GrammarAST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				eob = (GrammarAST)_t;
				match(_t,EOB);
				_t = _t.getNextSibling();
				_t = __t179;
				_t = _t.getNextSibling();
				_t = __t178;
				_t = _t.getNextSibling();
				
				g = factory.build_Astar(b);
						// track the loop back / exit decision point
					b.right.setDescription("()* loopback of "+grammar.grammarTreeToString(baseebnf_AST_in,false));
				int d = grammar.assignDecisionNumber( b.right );
						grammar.setDecisionNFA(d, b.right);
				grammar.setDecisionBlockAST(d, tmp92_AST_in);
				b.right.setDecisionASTNode(eob);
				// make block entry state also have same decision for interpreting grammar
				NFAState altBlockState = (NFAState)g.left.transition(0).target;
				altBlockState.setDecisionASTNode(baseebnf_AST_in);
				altBlockState.setDecisionNumber(d);
				g.left.setDecisionNumber(d); // this is the bypass decision (2 alts)
				g.left.setDecisionASTNode(baseebnf_AST_in);
					
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t180 = _t;
				GrammarAST tmp93_AST_in = (GrammarAST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				AST __t181 = _t;
				blk2 = _t==ASTNULL ? null :(GrammarAST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				eob3 = (GrammarAST)_t;
				match(_t,EOB);
				_t = _t.getNextSibling();
				_t = __t181;
				_t = _t.getNextSibling();
				_t = __t180;
				_t = _t.getNextSibling();
				
				g = factory.build_Aplus(b);
				// don't make a decision on left edge, can reuse loop end decision
						// track the loop back / exit decision point
					b.right.setDescription("()+ loopback of "+grammar.grammarTreeToString(baseebnf_AST_in,false));
				int d = grammar.assignDecisionNumber( b.right );
						grammar.setDecisionNFA(d, b.right);
					grammar.setDecisionBlockAST(d, blk2);
				b.right.setDecisionASTNode(eob3);
				// make block entry state also have same decision for interpreting grammar
				NFAState altBlockState = (NFAState)g.left.transition(0).target;
				altBlockState.setDecisionASTNode(baseebnf_AST_in);
				altBlockState.setDecisionNumber(d);
				
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void attributeElement(AST _t) throws RecognitionException {
		
		GrammarAST attributeElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp94_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				attributeGroup(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp95_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			{
				attributeStatements(_t);
				_t = _retTree;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp96_AST_in = (GrammarAST)_t;
				match(_t,CURRENT_TREE);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp97_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp98_AST_in = (GrammarAST)_t;
				match(_t,LPAREN);
				_t = _t.getNextSibling();
				{
				_loop215:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_tokenSet_0.member(_t.getType()))) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop215;
					}
					
				} while (true);
				}
				GrammarAST tmp99_AST_in = (GrammarAST)_t;
				match(_t,RPAREN);
				_t = _t.getNextSibling();
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				treeConstructor(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  sempred(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST sempred_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
			StringTemplate pred = null;
		
		
		try {      // for error handling
			AST __t124 = _t;
			s = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			pred=template(_t);
			_t = _retTree;
				code = templates.getInstanceOf("validateSemanticPredicate");
					        code.setAttribute("pred", pred.toString());
					
			_t = __t124;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return code;
	}
	
	public final void bareTemplate(AST _t) throws RecognitionException {
		
		GrammarAST bareTemplate_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp100_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp101_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				{
				int _cnt149=0;
				_loop149:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt149>=1 ) { break _loop149; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt149++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  template(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST template_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
		GrammarAST i = null;
		GrammarAST v = null;
		StringTemplate attr = null;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				code = new StringTemplate(userTemplates, s.getText());
				break;
			}
			case ID:
			{
				i = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				code = userTemplates.getInstanceOf(i.getText());
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop131:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ID)) {
					AST __t130 = _t;
					v = _t==ASTNULL ? null :(GrammarAST)_t;
					match(_t,ID);
					_t = _t.getFirstChild();
					attr=attributeTemplate(_t);
					_t = _retTree;
					code.setAttribute(v.getText(), attr);
					_t = __t130;
					_t = _t.getNextSibling();
				}
				else {
					break _loop131;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return code;
	}
	
	public final void predicateConstructor(AST _t) throws RecognitionException {
		
		GrammarAST predicateConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t126 = _t;
			GrammarAST tmp102_AST_in = (GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			bareTemplate(_t);
			_t = _retTree;
			_t = __t126;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  attributeTemplate(AST _t) throws RecognitionException {
		StringTemplate index = null; ;
		
		GrammarAST attributeTemplate_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
			StringTemplate tail = null;
			String name = null;
		
		
		try {      // for error handling
			a = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
				name = a.getText().substring(1);
					index = templates.getInstanceOf("qualifiedAttribute");
				
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				tail=arrayQualifierTemplate(_t,name);
				_t = _retTree;
				break;
			}
			case 3:
			case DOT_TEXT:
			{
					tail = templates.getInstanceOf("Attribute");
							tail.setAttribute("name", getUname(name));
							index.setAttribute("index", tail);
						
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop135:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					tail=idQualifierTemplate(_t);
					_t = _retTree;
					index.setAttribute("index", tail);
				}
				else {
					break _loop135;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return index;
	}
	
	public final StringTemplate  arrayQualifierTemplate(AST _t,
		String name
	) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST arrayQualifierTemplate_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
		StringTemplate index = null;
		
		try {      // for error handling
			AST __t139 = _t;
			GrammarAST tmp103_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
				code = templates.getInstanceOf("TableEntry");
						code.setAttribute("name", getUname(name));
					
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				code.setAttribute("contents", s);
				break;
			}
			case ID:
			{
				index=qualifiedIdTemplate(_t);
				_t = _retTree;
				code.setAttribute("contents", index);
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t139;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  idQualifierTemplate(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST idQualifierTemplate_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST d = null;
			StringTemplate tail = null;
			StringTemplate index = null;
			String name = null;
		
		
		try {      // for error handling
			d = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			name = d.getText().substring(1);
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				code=arrayQualifierTemplate(_t,name);
				_t = _retTree;
				break;
			}
			case 3:
			case DOT_TEXT:
			{
					code = templates.getInstanceOf("Attribute");
								code.setAttribute("name", getUname(name));
							
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  qualifiedIdTemplate(AST _t) throws RecognitionException {
		StringTemplate index = null; ;
		
		GrammarAST qualifiedIdTemplate_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST i = null;
		StringTemplate tail = null;
		
		try {      // for error handling
			i = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
				index = templates.getInstanceOf("qualifiedAttribute");
				
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				tail=arrayQualifierTemplate(_t,i.getText());
				_t = _retTree;
				index.setAttribute("index", tail);
				break;
			}
			case 3:
			case DOT_TEXT:
			{
				index.setAttribute("index", i.getText());
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop144:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					tail=idQualifierTemplate(_t);
					_t = _retTree;
					index.setAttribute("index", tail);
				}
				else {
					break _loop144;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return index;
	}
	
	public final void attribute(AST _t) throws RecognitionException {
		
		GrammarAST attribute_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp104_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop171:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop171;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final StateCluster  atom(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST atom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST r = null;
		GrammarAST rarg = null;
		GrammarAST as1 = null;
		GrammarAST t = null;
		GrammarAST c = null;
		GrammarAST s = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				AST __t187 = _t;
				r = _t==ASTNULL ? null :(GrammarAST)_t;
				match(_t,RULE_REF);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ARG_ACTION:
				{
					rarg = (GrammarAST)_t;
					match(_t,ARG_ACTION);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case BANG:
				case CARET:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					as1 = _t==ASTNULL ? null : (GrammarAST)_t;
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				_t = __t187;
				_t = _t.getNextSibling();
				
				NFAState start = grammar.getRuleStartState(r.getText());
				if ( start!=null ) {
				int ruleIndex = grammar.getRuleIndex(r.getText());
				g = factory.build_RuleRef(ruleIndex, start);
				r.followingNFAState = g.right;
				if ( g.left.transition(0) instanceof RuleClosureTransition
					 && grammar.type!=Grammar.LEXER )
				{
				addFollowTransition(r.getText(), g.right);
				}
				// else rule ref got inlined to a set
				}
				
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				
				if ( grammar.type==Grammar.LEXER ) {
				NFAState start = grammar.getRuleStartState(t.getText());
				if ( start!=null ) {
				int ruleIndex = grammar.getRuleIndex(t.getText());
				g = factory.build_RuleRef(ruleIndex, start);
				// don't add FOLLOW transitions in the lexer;
				// only exact context should be used.
				}
				}
				else {
				int tokenType = grammar.getTokenType(t.getText());
				g = factory.build_Atom(tokenType);
				t.followingNFAState = g.right;
				}
				
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				
					if ( grammar.type==Grammar.LEXER ) {
						g = factory.build_KeywordAtom(c.getText());
					}
					else {
				int tokenType = grammar.getTokenType(c.getText());
				g = factory.build_Atom(tokenType);
				c.followingNFAState = g.right;
					}
					
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				
					if ( grammar.type==Grammar.LEXER ) {
						g = factory.build_StringLiteralAtom(s.getText());
					}
					else {
				int tokenType = grammar.getTokenType(s.getText());
				g = factory.build_Atom(tokenType);
				s.followingNFAState = g.right;
					}
					
				break;
			}
			case WILDCARD:
			{
				GrammarAST tmp105_AST_in = (GrammarAST)_t;
				match(_t,WILDCARD);
				_t = _t.getNextSibling();
				g = factory.build_Wildcard();
				break;
			}
			case SET:
			{
				g=set(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final StateCluster  set(AST _t) throws RecognitionException {
		StateCluster g=null;
		
		GrammarAST set_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
		
			IntSet elements=new IntervalSet();
			set_AST_in.setSetValue(elements); // track set for use by code gen
		
		
		try {      // for error handling
			AST __t191 = _t;
			s = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,SET);
			_t = _t.getFirstChild();
			{
			int _cnt193=0;
			_loop193:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_2.member(_t.getType()))) {
					setElement(_t,elements);
					_t = _retTree;
				}
				else {
					if ( _cnt193>=1 ) { break _loop193; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt193++;
			} while (true);
			}
			_t = __t191;
			_t = _t.getNextSibling();
			
				g = factory.build_Set(elements);
				        s.followingNFAState = g.right;
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return g;
	}
	
	public final void setElement(AST _t,
		IntSet elements
	) throws RecognitionException {
		
		GrammarAST setElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		GrammarAST t = null;
		GrammarAST s = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		int ttype;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				
					if ( grammar.type==Grammar.LEXER ) {
					ttype = Grammar.getCharValueFromGrammarCharLiteral(c.getText());
					}
					else {
					ttype = grammar.getTokenType(c.getText());
				}
				if ( elements.member(ttype) ) {
							ErrorManager.grammarError(ErrorManager.MSG_DUPLICATE_SET_ENTRY,
													  grammar,
													  c.token,
													  c.getText());
				}
				elements.add(ttype);
				
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				
				ttype = grammar.getTokenType(t.getText());
				if ( elements.member(ttype) ) {
							ErrorManager.grammarError(ErrorManager.MSG_DUPLICATE_SET_ENTRY,
													  grammar,
													  t.token,
													  t.getText());
				}
				elements.add(ttype);
				
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				
				ttype = grammar.getTokenType(s.getText());
				if ( elements.member(ttype) ) {
							ErrorManager.grammarError(ErrorManager.MSG_DUPLICATE_SET_ENTRY,
													  grammar,
													  s.token,
													  s.getText());
				}
				elements.add(ttype);
				
				break;
			}
			case CHAR_RANGE:
			{
				AST __t195 = _t;
				GrammarAST tmp106_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t195;
				_t = _t.getNextSibling();
				
					if ( grammar.type==Grammar.LEXER ) {
					        int a = Grammar.getCharValueFromGrammarCharLiteral(c1.getText());
					    int b = Grammar.getCharValueFromGrammarCharLiteral(c2.getText());
						elements.addAll(IntervalSet.of(a,b));
					}
					
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeGroup(AST _t) throws RecognitionException {
		
		GrammarAST attributeGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t197 = _t;
			GrammarAST tmp107_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_GROUP);
			_t = _t.getFirstChild();
			{
			_loop199:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeItem(_t);
					_t = _retTree;
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp108_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					break _loop199;
				}
				}
			} while (true);
			}
			_t = __t197;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeBlock(AST _t) throws RecognitionException {
		
		GrammarAST attributeBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				{
				_loop202:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_tokenSet_0.member(_t.getType()))) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop202;
					}
					
				} while (true);
				}
				break;
			}
			case SEMPRED:
			{
				predicateConstructor(_t);
				_t = _retTree;
				{
				_loop204:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_tokenSet_0.member(_t.getType()))) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop204;
					}
					
				} while (true);
				}
				{
				GrammarAST tmp109_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getNextSibling();
				attributeBlock(_t);
				_t = _retTree;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeStatements(AST _t) throws RecognitionException {
		
		GrammarAST attributeStatements_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t207 = _t;
			GrammarAST tmp110_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			attributeBlock(_t);
			_t = _retTree;
			_t = __t207;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void treeConstructor(AST _t) throws RecognitionException {
		
		GrammarAST treeConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t217 = _t;
			GrammarAST tmp111_AST_in = (GrammarAST)_t;
			match(_t,TREE_CONSTRUCTOR);
			_t = _t.getFirstChild();
			attributeItem(_t);
			_t = _retTree;
			{
			int _cnt219=0;
			_loop219:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_0.member(_t.getType()))) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt219>=1 ) { break _loop219; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt219++;
			} while (true);
			}
			_t = __t217;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF",
		"ARG_ACTION"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2199023255936L, 27664L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 648538280375613824L, 1175057L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 648535938527526912L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	}
	
