using System;
using System.IO;
using System.Text;
using System.Collections;

using antlr;	
using antlr.collections;

namespace DDW.CSharp
{

	#region IVisitor 
	/// <summary>
	/// Visitor interface to walk ast.
	/// </summary>
	public interface IVisitor
	{
		void Visit(AST node);
	}
	#endregion 
	#region CSharpAST 
	/// <summary>
	/// The base class for all custom ASTs.
	/// </summary>
	public  class CSharpAST : antlr.BaseAST
	{	
		private int ttype = Token.INVALID_TYPE;
		protected string p_text;
		
		#region Constructor 
		/// <summary>
		/// Construct blank AST node using a token
		/// </summary>
		#endregion 
		public						CSharpAST()			{}
		public						CSharpAST(Token tok)
		{
			initialize(tok);
		}
 		#region UserData 
		/// <summary>
		/// Gets or sets the user-definable data for the current object.
		/// </summary>
		#endregion 
		public virtual IDictionary 	UserData			
		{
			get{ return null; }
			set{ }
		}
 		#region Accept 
		/// <summary>
		/// Visitor pattern callback.
		/// </summary>
		/// <param name="v">Visiting object</param>
		#endregion 
		public virtual void 		Accept(IVisitor v)	
		{
			v.Visit(this);
		}
 		#region Text 
		/// <summary>
		/// Gets or sets the text of the node.
		/// </summary>
		#endregion 
//		public override string		Text				
//		{
//			get{return p_text;}	
//			set{p_text = value;}	
//		}
 		#region Type 
		/// <summary>
		/// Gets or sets the Type of the node (TODO: make this enum)
		/// </summary>
		#endregion 
		public override int			Type				
		{
			get{return ttype;}	
			set{ttype = value;}	
		}
		#region Various Java methods 
		public override void		initialize(int t, String txt)	
		{
			setType(t);
			setText(txt);
		}

		public override void		initialize(AST t)				
		{
			p_text = t.getText();
			Type = t.Type;
		}

		public override void		initialize(Token tok)			
		{
			p_text = tok.getText();
			Type = tok.Type;
		}
		public override String		getText()						
		{
			return p_text;
		}
		public			int			getType()						
		{
			return ttype;
		}
		public override void		setText(String text_)			
		{
			p_text = text_;
		}

		public override void		setType(int ttype_)				
		{
			ttype = ttype_;
		}
		#endregion 
		public override String		ToString()						
		{
			return p_text +" (" + this.GetType().Name+")";
		}
	}
	#endregion 

	#region NamespaceNode 
	public class				NamespaceNode : CSharpAST
	{
	}
	#endregion 
	#region UsingNode 
	public class				UsingNode : CSharpAST
	{
	}
	#endregion 

	#region Types 
	public class				Types : CSharpAST
	{
	}
	#endregion 
    	#region InterfaceNode 
	public class						InterfaceNode : TypeNode
	{
	}
		#endregion 
		#region ClassNode 
	public class						ClassNode : TypeNode
	{
	}
	#endregion 
		#region EnumNode 
	public class						EnumNode : TypeNode
	{
	}
	#endregion 
		#region StructNode 
	public class						StructNode : TypeNode
	{
	}
	#endregion 
		#region DelegateNode 
	public class						DelegateNode : TypeNode
	{
	}
	#endregion 

	#region Members 
	public class				Members : CSharpAST
	{
	}
	#endregion 
	#region TypeMemberNode 
	/// <summary>
	/// Abstract base class for member types (Field, Method, Prop..)
	/// </summary>
	public abstract class TypeMemberNode : CSharpAST		
	{
		public AttributeNode[]			Attributes		
		{
			get
			{	// return by searching nodes
				return new AttributeNode[]{};
			}
			set
			{	// set nodes
			}
		}
		public CustomAttributeNode[]	CustomAttributes
		{
			get
			{	
				return new CustomAttributeNode[]{};
			}
			set
			{	// set nodes
			}
		}
		public CommentNode[]			Comments		
		{
			get
			{	
				return new CommentNode[]{};
			}
			set
			{	// set nodes
			}
		}
		public string					Name			
		{
			get
			{	
				return "";
			}
			set
			{	// set nodes
			}
		}
		public LinePragma				LinePragma		
		{
			get
			{	
				return new LinePragma();
			}
			set
			{	// set nodes
			}
		}
	}
	#endregion 
		#region ConstantNode 
	public class						ConstantNode : TypeMemberNode
	{
	}
		#endregion 
		#region FieldNode 
	public class						FieldNode : TypeMemberNode
	{
	}
		#endregion 
		#region MethodNode 
	public class						MethodNode : TypeMemberNode
	{
	}
		#endregion 
		#region PropertyNode 
	public class						PropertyNode : TypeMemberNode
	{
	}
		#endregion 
		#region EventNode 
	public class						EventNode : TypeMemberNode
	{
	}
		#endregion 
		#region IndexerNode 
	public class						IndexerNode : TypeMemberNode
	{
	}
		#endregion 
		#region OperatorNode 
	public class						OperatorNode : TypeMemberNode
	{
	}
		#endregion 
		#region ConstructorNode 
	public class						ConstructorNode : TypeMemberNode
	{
	}
		#endregion 
		#region DestructorNode 
	public class						DestructorNode : TypeMemberNode
	{
	}
		#endregion 
		#region TypeNode 
	public abstract class				TypeNode : TypeMemberNode
	{
	}
		#endregion 
		#region AccessorNode 
	public class						AccessorNode : TypeMemberNode
	{
	}
		#endregion 
	#region BaseTypes 
	public class				BaseTypes : CSharpAST
	{
	}
	#endregion 

	#region TypeRef 
	public class						TypeRef : CSharpAST
	{
	}
	#endregion 
	#region Ident 
	public class						Ident : CSharpAST
	{
	}
	#endregion 
	#region QualIdent 
	public class						QualIdent : CSharpAST
	{
	}
	#endregion 
	#region Args 
	public class						Args : CSharpAST
	{
	}
	#endregion 
	#region Arg 
	public class						Arg : CSharpAST
	{
	}
	#endregion 
	#region ArgDirection 
	public class						ArgDirection : CSharpAST
	{
	}
	#endregion 
	#region Op 
	public class						Op : CSharpAST
	{	
//
	}
	#endregion 

	#region	Statements 
	public class				Statements : CSharpAST
	{
	}
	#endregion 
	#region	Statement 
	public class				Statement : CSharpAST
	{
	}
	#endregion 
		#region	LabeledStmt 
	public class				LabeledStmt : Statement
	{
		// Label
		// Statement
	}
	#endregion 
		#region	ExprStmt 
	public class				ExprStmt : Statement
	{
		// Label
		// Statement
	}
	#endregion 
	#region	AssignStmt 
	public class				AssignStmt : Statement
	{
		// Label
		// Statement
	}
	#endregion 
		#region	VariableDeclStmt 
	public class				VariableDeclStmt : Statement
	{
		// Init
		// Name
		// Type
		// IsConstant
	}
	#endregion 
		#region	ConditionStmt 
	public class				ConditionStmt : Statement
	{
	}
	#endregion 
			#region	SwitchSection 
	public class				SwitchSection : Statements
	{
		// Expr
		// Label eg: case default
		// Statements
	}
	#endregion 
			#region	TrueSection 
	public class				TrueSection : SwitchSection
	{
		// Expr - always TRUE
		// Label - always CASE
		// Statements
	}
	#endregion 
			#region	FalseSection 
	public class				FalseSection : SwitchSection
	{
		// Expr - always FALSE
		// Label - always CASE
		// Statements
	}
	#endregion 
		#region	IterationStmt 
	public class				IterationStmt : Statement
	{
		// InitStatement
		// IncrementStatement
		// TestExpression
		// Statements
		// TestFirst (bool)
	}
	#endregion 
			#region	InitStmt 
	public class				InitStmt : Statement
	{
		// Statements
	}
	#endregion 
			#region	IncStmt 
	public class				IncStmt : Statement
	{
		// Statements
	}
	#endregion 
			#region	TestExpr 
	public class				TestExpr : Expression
	{
		// Expression
	}
	#endregion 
		#region	GotoStmt 
	public class				GotoStmt : Statement
	{
	}
	#endregion 
		#region	ReturnStmt 
	public class				ReturnStmt : Statement
	{
	}
	#endregion 
		#region	BreakStmt 
	public class				BreakStmt : Statement
	{
	}
	#endregion 
		#region	ContinueStmt 
	public class				ContinueStmt : Statement
	{
	}
	#endregion 
		#region	ThrowStmt 
	public class				ThrowStmt : Statement
	{
	}
	#endregion 
		#region	CheckedStmt 
	public class				CheckedStmt : Statement
	{
	}
	#endregion 
		#region	UncheckedStmt 
	public class				UncheckedStmt : Statement
	{
	}
	#endregion 
		#region	LockStmt 
	public class				LockStmt : Statement
	{
	}
	#endregion 
		#region	UsingStmt 
	public class				UsingStmt : Statement
	{
	}
	#endregion 
		#region	TryCatchFinallyStmt 
	public class				TryCatchFinallyStmt : Statement
	{
	}
	#endregion 
			#region	TryStmt 
	public class				TryStmt : Statement
	{
	}
	#endregion 
			#region	CatchClause 
	public class				CatchClause : Statement
	{
	}
	#endregion 
			#region	FinallyStmt 
	public class				FinallyStmt : Statement
	{
	}
	#endregion 
	
	#region	Expressions 
	public class				Expressions : CSharpAST
	{
	}
	#endregion 
	#region	Expression 
	public class				Expression : CSharpAST
	{
	}
	#endregion 
		#region	SubExpression 
	public class				SubExpression : Expression
	{
	}
	#endregion 
		#region	CastExpr 
	public class				CastExpr : Expression
	{
	}
	#endregion 
		#region	ThisRefExpr 
	public class				ThisRefExpr : Expression
	{
	}
	#endregion 
		#region	BaseRefExpr 
	public class				BaseRefExpr : Expression
	{
	}
	#endregion 
		#region	MemberAccessExpr 
	public class				MemberAccessExpr : Expression
	{
	}
	#endregion 
		#region	UnaryExpr 
	public class				UnaryExpr : Expression
	{
	}
	#endregion 
		#region	InvokeExpr 
	public class				InvokeExpr : Expression
	{
	}
	#endregion 
		#region	IndexerExpr 
	public class				IndexerExpr : Expression
	{
	}
	#endregion 
		#region	ObjectCreateExpr 
	public class				ObjectCreateExpr : Expression
	{
	}
	#endregion 
		#region	TypeOfExpr 
	public class				TypeOfExpr : Expression
	{
	}
	#endregion 
		#region	PostfixExpr 
	public class				PostfixExpr : Expression
	{
	}
	#endregion 
		#region	CheckedExpr 
	public class				CheckedExpr : Expression
	{
	}
	#endregion 
		#region	UncheckedExpr 
	public class				UncheckedExpr : Expression
	{
	}
	#endregion 

		#region	PrimitiveExpr 
	public class				PrimitiveExpr : Expression
	{
	}
	#endregion 
		#region	ArrayCreateExpr 
	public class				ArrayCreateExpr : Expression
	{
	}
	#endregion 
		#region	ArrayRankExpr 
	public class				ArrayRankExpr : Expression
	{
	}
	#endregion 
	#region	ArrayInitExpr 
	public class				ArrayInitExpr : Expression
	{
	}
	#endregion 

	#region	Literal 
	public class				Literal : CSharpAST
	{
		protected bool isParsed = false;
	}
	#endregion 
		#region	BooleanLiteral 
	public class				BooleanLiteral : Literal
	{	
		private bool p_value;
		public bool Value
		{
			get
			{
				if(isParsed) return p_value;
				if(this.p_text.ToUpper() == "TRUE") 
					p_value = true;
				else
					p_value = false;
				isParsed = true;
				return p_value;
			}
			set
			{
				isParsed = true;
				p_value = value;
			}
		}
	}
	#endregion 
		#region	IntegerLiteral 
	public class				IntegerLiteral : Literal
	{	
		private int p_value;
		public int Value
		{
			get
			{
				if(isParsed) return p_value;
				p_value = Int32.Parse(p_text);
				isParsed = true;
				return p_value;
			}
			set
			{
				isParsed = true;
				p_value = value;
			}
		}
	}
	#endregion 
		#region	RealLiteral 
	public class				RealLiteral : Literal
	{	
		private double p_value;
		public double Value
		{
			get
			{
				if(isParsed) return p_value;
				p_value = Double.Parse(p_text);
				isParsed = true;
				return p_value;
			}
			set
			{
				isParsed = true;
				p_value = value;
			}
		}
	}
	#endregion 
		#region	CharLiteral 
	public class				CharLiteral : Literal
	{	
		private char p_value;
		public char Value
		{
			get
			{
				if(isParsed) return p_value;
				p_value = Char.Parse(p_text);
				isParsed = true;
				return p_value;
			}
			set
			{
				isParsed = true;
				p_value = value;
			}
		}
	}
	#endregion 
		#region	StringLiteral 
	public class				StringLiteral : Literal
	{	
		private string p_value;
		public string Value
		{
			get
			{
				if(isParsed) return p_value;
				p_value = p_text;
				isParsed = true;
				return p_value;
			}
			set
			{
				isParsed = true;
				p_value = value;
			}
		}
	}
	#endregion 	
		#region	NullLiteral 
	public class				NullLiteral : Literal
	{	
		public string Value
		{
			get
			{
				return null;
			}
			set
			{
			}
		}
	}
	#endregion 

	#region Attributes 
	public class AttributeNode : CSharpAST
	{	
		private string		p_name;
//		private string		p_arguments;
//		private string		p_comment;
//		private string		p_linePragma;

		#region Constructor 
		/// <summary>
		/// Construct blank AST node using a token
		/// </summary>
		#endregion 
		public string				Name
		{
			get{return p_name;}
			set{p_name = value;}
		}
	}
	#endregion 
	#region GlobalAttributeNode 
	public class GlobalAttributeNode : CSharpAST
	{	
		private string		p_name;
//		private string		p_arguments;
//		private string		p_comment;
//		private string		p_linePragma;

		#region Constructor 
		/// <summary>
		/// Construct blank AST node using a token
		/// </summary>
		#endregion 
		public string				Name
		{
			get{return p_name;}
			set{p_name = value;}
		}
	}
	#endregion 
	#region CustomAttributeNode 
	public class						CustomAttributeNode : CSharpAST
	{
	}
	#endregion 
	#region ModifierAttributes 
	public class ModifierAttributes : CSharpAST
	{	
	}
	#endregion 

	#region CommentNode 
	public class						CommentNode : CSharpAST
	{
	}
	#endregion 
	#region LinePragma 
	public class						LinePragma : CSharpAST
	{
	}
	#endregion 
}	


