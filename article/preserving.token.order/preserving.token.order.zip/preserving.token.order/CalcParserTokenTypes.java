// $ANTLR 2.7.3-20030430: "calc.g" -> "CalcLexer.java"$

public interface CalcParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int ID = 4;
	int EQUALS = 5;
	int SEMI = 6;
	int LITERAL_print = 7;
	int PLUS = 8;
	int STAR = 9;
	int INT = 10;
	int WS = 11;
	int LPAREN = 12;
	int RPAREN = 13;
}
