package org.antlr_yggdrasil.runtime.test;

import org.antlr_yggdrasil.runtime.Carrier;
import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.ReferenceCarrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.DefaultPayload;
import org.antlr_yggdrasil.runtime.DefaultCarrier;

public class ReferenceCarrierTest extends TestCase {
	ReferenceCarrier ref = null;
	Carrier carrier = null;
	
	public static void main(String[] args) {
		junit.textui.TestRunner.run(ReferenceCarrierTest.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		ref = new ReferenceCarrier();
		carrier = new DefaultCarrier();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		ref = null;
	}

	public void testGetAttributes() {
		Payload p = new DefaultPayload();
		carrier.setAttributes(p);
		ref.setCarrier(carrier);
		
		assertTrue(carrier.getAttributes() == p);
		assertTrue(ref.getAttributes() == p);
	}

	public void testCopy() {
		assertTrue(ref.copy() == null);
		
		carrier.setNextSibling(new DefaultCarrier());
		carrier.setFirstChild(new DefaultCarrier());
		
		ref.setCarrier(carrier);
		
		Carrier test = ref.copy();
		assertTrue(carrier.equals(test));
	}

	public void testGetText() {
		Payload p = new DefaultPayload();
		carrier.setAttributes(p);
		
		ref.setCarrier(carrier);
		p.setText("payload");
		assertTrue(ref.getText().equals("payload"));
		
		ref.setText("reference");
		assertTrue(p.getText().equals("reference"));
		assertTrue(carrier.getText().equals("reference"));
		assertTrue(ref.getText().equals("reference"));
	}

	public void testGetType() {
		Payload p = new DefaultPayload();
		carrier.setAttributes(p);
		
		ref.setCarrier(carrier);
		p.setType(6);
		assertFalse(ref.getType() == 6);
		
		ref.setType(7);
		assertTrue(p.getType() == 7);
		assertTrue(carrier.getType() == 7);
		assertTrue(ref.getType() == 7);
	}

	public void testSetRef() {
	}

	public void testGetRef() {
	}

}
