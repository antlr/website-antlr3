package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */

import edu.usfca.syndiag.*;
import java.awt.event.*;
import java.io.*;
import java.util.StringTokenizer;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import java.awt.*;
import javax.swing.*;

public class Main {

    static boolean isBlind = false;
    static boolean toWrap = false;
    static String saveToFileName;
    static String inputFileName;

    public static void main(String[] args) throws Exception {

	parseArgs(args);

        InputStream inStr;
	if ( inputFileName == null ) 
	{ inStr = System.in; }
        else 
	{ inStr = new FileInputStream(inputFileName); }

  SwingForm swing = new SwingForm();
	swing.createForm();
	swing.load(inStr);
	
	if (saveToFileName != null) { 
		swing.saveAsFile(swing.ast, saveToFileName);
	}

	if ( isBlind ) { System.exit(0); }

    }

    public static void print(GrammarAST t) {
        System.out.println(toString(t));
    }

    public static String toString(GrammarAST t) {
        String s = null;
        try {
            s = new ANTLRTreePrinter().toString((AST)t);
        }
        catch (Exception e) {
            System.err.println("Problems printing tree: "+t);
            e.printStackTrace(System.err);
        }
        return s;
    }

    public static void parseArgs(String[] args) {

	for (int i=0; i<args.length; i++) {
	   if (args[i].equals("-wrap")) { toWrap = true; }
	   else if(args[i].equals("-save")) { saveToFileName=args[++i]; }
	   else if(args[i].equals("-blind")) { isBlind = true; }
	   else if(args[i].equals("-help")) { printUsage(); }
	   else if(args[i].equals("--help")) { printUsage(); }
	   else if(args[i].equals("-?")) { printUsage(); }
	   else { inputFileName = args[i]; }

	}
	
    }

    public static void printUsage() {
	System.out.println("Usage: java edu.usfca.syndiag.Main [-wrap] [-save image.ext] [-blind] [input.g]");
	System.exit(0);
    }

}
