/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

/**
 * @author Owner
 *
 */
public class DefaultPayloadFactory implements PayloadFactory {
	Class defaultClass = PayloadToken.class;
	Class types[] = null;
	int nTypes = 0;

	/**
	 * 
	 */
	public DefaultPayloadFactory() {
	}
	
	public DefaultPayloadFactory(int size) {
		types = new Class[size];
	}
	
	public DefaultPayloadFactory(int size, Class c) {
		if (size > 0)
			types = new Class[size];
		
		defaultClass = c;
	}

	
	public Payload createNew(int type) {
		return createNew (type, "");
	}
	
	public Payload createNew(Payload type, Payload text) {
		return null;
	}
	
	public Payload createNew(String type, Payload text) {
		return null;
	}
	
	public Payload createNew(Payload type, String text) {
		return null;
	}
	
	public Payload createNew(String type, String text) {
		return null;
	}
	
	/**
	 * @params int, String
	 */
	public Payload createNew(int type, String text) {
		Payload retval = null;
		if (types == null) {
			if (defaultClass != null) {
				try {
					retval = (Payload) defaultClass.newInstance();
					retval.setType(type);
					retval.setText(text);
				}
				catch (InstantiationException e) {
					;// TODO: throw exception here
				}
				catch (IllegalAccessException ia) {
					; //TODO:  throw exception here
				}			
			}
			else
				retval = new PayloadToken(type, text);
		}
		return retval;
	}

	/* (non-Javadoc)
	 * @see antlr.CarrierFactory#setDefault(java.lang.Class)
	 */
	public void setDefault(Class c) {
		defaultClass = c;
	}

	/* (non-Javadoc)
	 * @see antlr.CarrierFactory#set(java.lang.Class, int)
	 */
	public void set(Class c, int type) {
		if (types == null)
			;		// TODO: throw exception here
		
		if (type > nTypes)
			;	// TODO: throw exception here
			
		types[type] = c;
	}

}
