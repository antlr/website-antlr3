/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include <iostream>
#include "method_info.hpp"
#include "code_attribute.hpp"
#include "constantpool.hpp"

namespace ClassEncoder
{
using namespace std;

//!  Default constructor.
/*!
 * \param constantPool Pointer to the constant pool for the class this method belongs to.
 * \name The function name.
 */
method_info::method_info( ConstantPool *constantPool, const string &name )
{
    ConstantPoolEntries = constantPool;
    CodeAttribute = new code_attribute( ConstantPoolEntries );

    access_flags = 0;
    FunctionName = name;
    ReturnType = "V"; // void

    if( name == "<init>" ) // special hidden parameter
    {
        CodeAttribute->addLocal(); // this
    }
}

//! Default destructor.
/*!
 *  Destroys the object
 */
method_info::~method_info()
{
    if( CodeAttribute )
        delete CodeAttribute;
}

//! Write the method to the class stream.
/*!
 * \param stream The class stream to write to.
 */
void method_info::write( ofstream &stream )
{
//     u2 access_flags;
    writeu2( stream, access_flags );
//        u2 name_index;
    writeu2( stream, name_index );
//        u2 descriptor_index;
    writeu2( stream, descriptor_index );

//        u2 attributes_count;
    writeu2( stream, 1 );
//        attribute_info attributes[attributes_count];
    CodeAttribute->write( stream );
}

//! Sets the availability of this function.
/*!
 * Available flags are:
 * - ACC_PUBLIC
 * - ACC_PRIVATE
 * - ACC_PROTECTED
 * - ACC_STATIC
 * - ACC_FINAL
 * - ACC_SYNCHRONIZED
 * - ACC_SUPER
 * - ACC_NATIVE
 * - ACC_INTERFACE
 * - ACC_ABSTRACT
 * - ACC_STRICT
 * \flags The availability mode (or a combination of these or'ed together)
 */
void method_info::setAccess( u2 flags )
{
    // TODO: check that the flags are valid
    access_flags = flags;
}

//! Add class type parameter.
/*!
 * \param objectType Full java typename of parameter.
 * \param addLocal Should the variable automatically be declared a local variable.
 */
void method_info::addParameter( const string &objectType, bool addLocal )
{
    Parameters.push_back( objectType );
    if( addLocal )
        CodeAttribute->addLocal();
}

//! Set the return type of this function.
/*!
 * All functions return void until implemented
 *\param Full java typename of return type
 */
void method_info::setReturnType( const string &type )
{
    ReturnType = type;
}

//! Add a local variable
/*!
 * This function is a convinience function forwarding the call to the code attribute.
 * \return The variable index.
 * \see code_attribute::addLocal
 * \todo add throw when over max locals (u2)
 */
unsigned int method_info::addLocal()
{
    return CodeAttribute->addLocal();
}

//! Build method descriptor.
/*!
 * Builds the methoddescriptor for this class based on the parameters and return types.
 * Rules:
 * ( ParameterDescriptor*   ) ReturnDescriptor
 * ParameterDescriptor = CZFDBSIJ for basic types, Lobject; for objects [ in front for arrays
 * ReturnDescriptor = same as above, V for void
 * \return The complete method-descriptor for these class.
 */
string method_info::buildMethodDescriptor()
{
    string result = "(";
    for( vector<string>::const_iterator it = Parameters.begin();
             it != Parameters.end(); it++ )
    {
        result += (*it);
    }
    result += ")";
    result += ReturnType;
    return result;
}

//! Get the pointer to the ByteCode object for this method.
/*!
 * \return The pointer to the ByteCode object for this class.
 */
ByteCode *method_info::code()
{
    return CodeAttribute->code();
}


//! This function finishes writing for this class.
/*!
 * Any function calls after you have called finished will not have any impact.
 * This function makes sure all it's properties are written into the constant_pool
 * it is important that this is done before writing.
 * \todo: make class do this? Add Valid boolean.
 */
void method_info::finish()
{
    name_index = ConstantPoolEntries->add( new Utf8_info( FunctionName ) );
    descriptor_index = ConstantPoolEntries->add( new Utf8_info( buildMethodDescriptor() ) );
}

} // end namespace
