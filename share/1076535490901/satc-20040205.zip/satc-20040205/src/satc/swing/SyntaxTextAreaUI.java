/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */
 
package satc.swing;

import javax.swing.JComponent;
import javax.swing.text.EditorKit;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.View;

import satc.SyntaxFactory;



/**
 *  Provides the look and feel for a syntax aware text component.
 */
public class SyntaxTextAreaUI extends javax.swing.plaf.basic.BasicTextAreaUI {
    
    //TODO: create a proxy ?
    public SyntaxTextAreaUI() {
        editorKit = SyntaxFactory.createEditorKit("PlainText");
    }

    public SyntaxTextAreaUI( String syntaxName) {
        editorKit = SyntaxFactory.createEditorKit( syntaxName);
    }
     
    /**
     *  Creates a syntax aware view for a text element.
     */
    public View create( Element elem) {
        return editorKit.createView( elem);
    }
    
    /**
     * Fetches the EditorKit for the UI.
     */
    public EditorKit getEditorKit( JTextComponent tc) {
            return editorKit;
    }

    public void installUI( JComponent c) {
        super.installUI( c);
        JTextComponent text = (JTextComponent) c;
        if( text.getDocument() == null) {
            text.setDocument( getEditorKit( text).createDefaultDocument());
        } else {
            ((SyntaxEditorKit) getEditorKit( text)).installEditorKit( text.getDocument()); 
        }       
    }

    private SyntaxEditorKit editorKit;
    
    private void p( String s) { System.out.println( s); }
    
}

