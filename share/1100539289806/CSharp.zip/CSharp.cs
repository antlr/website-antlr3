using System;

using CommonAST				= antlr.CommonAST;
using AST					= antlr.collections.AST;
using DumpASTVisitor		= antlr.DumpASTVisitor;
using CharBuffer			= antlr.CharBuffer;
using RecognitionException	= antlr.RecognitionException;
using TokenStreamException	= antlr.TokenStreamException;
using System.IO;

namespace DDW.CSharp
{
	class CSharp 
	{
		public static void Main(string[] args) 
		{
			if(args.Length == 0)
			{
				Console.WriteLine("Append a C# filename, or drag C# file onto this program to parse it.\n\nPress enter to continue...");				
				Console.Read();
				return;
			}
			try 
			{	
				string fileName = args[0];
				Console.WriteLine("Parsing " + fileName);
				Console.WriteLine(fileName);
				FileStream s = new FileStream(args[0], FileMode.Open, FileAccess.Read);
				CSharpLexer lexer = new CSharpLexer(s);
				lexer.setFilename(fileName);
				CSharpParser parser = new CSharpParser(lexer);
				parser.setFilename(fileName);

				// Parse the input expression
				parser.compilation_unit();
				s.Close();
				AST t = parser.getAST();
				if(t!=null)
				{
					Console.WriteLine(t.ToStringTree());
					//Console.Out.WriteLine("\n\n");
					//CSharpTreeWalker walker = new CSharpTreeWalker();
					//string st = walker.compilation_unit(t);
					//Console.Out.WriteLine("Text is "+st);
				}
				else
				{
					Console.WriteLine("Tree is empty");
				}

			}
			catch(Exception e) 
			{
				Console.Error.WriteLine("exception: "+e);
			}
			Console.WriteLine("\n\nPress enter to continue...");
			Console.Read();
		}  
	}
}