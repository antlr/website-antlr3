Minimum requirements:
- Visual Studio .Net 2003

Known problems:

During compilation compiler throws 190 warnings and one error:
PreservingFileWriter.java(29,19): error VJS1223: Cannot find method 'getParentFile()' in 'java.io.File'
This error can be avoided by changing PreservingFileWriter.java file, line 29 from:

File parentdir = target_file.getParentFile();
if( parentdir != null )
{
  if (!parentdir.exists())
    throw new IOException("destination directory of '"+file+"' doesn't exist");
  if (!parentdir.canWrite())
    throw new IOException("destination directory of '"+file+"' isn't writeable");
}

to:

String parentdirname = target_file.getParent();
if( parentdirname != null )
{
  File parentdir = new File(parentdirname);
  if (!parentdir.exists())
    throw new IOException("destination directory of '"+file+"' doesn't exist");
  if (!parentdir.canWrite())
    throw new IOException("destination directory of '"+file+"' isn't writeable");
}

or by applying "Java 1.1" patch