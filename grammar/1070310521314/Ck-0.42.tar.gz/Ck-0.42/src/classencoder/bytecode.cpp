/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "bytecode.hpp"
#include "constantpool.hpp"

#include <iostream>

namespace ClassEncoder
{
using namespace std;

/*
  byte  // 1-byte signed 2's complement integer
  short  // 2-byte signed 2's complement integer
  int  // 4-byte signed 2's complement integer
  long  // 8-byte signed 2's complement integer
  float  // 4-byte IEEE 754 single-precision float
  double  // 8-byte IEEE 754 double-precision float
  char  // 2-byte unsigned Unicode character

 */

//! Constructor
/*!
 * Init of object.
 */
ByteCode::ByteCode( ConstantPool *pool )
{
    ConstantPoolEntries = pool;
    StackSize = 0;
    MaxStackSize = 0;
}

//! Destructor
/*!
 * Emptry
 */
ByteCode::~ByteCode()
{
}

//! Write bytecode to stream
/*!
 * \param stream The class stream to write to.
 */
void ByteCode::write( ofstream &stream ) const
{
    for( vector<u1>::const_iterator it = Code.begin(); it != Code.end(); ++it )
    {
        writeu1( stream, *it );
    }
}

//! Internal push function to monitor run time stack size
/*!
 * This function must be called each time an emit function is called that pushes something to the stack.
 * \param num The number of elements to push (not bytes)
 */
void ByteCode::push( int num )
{
    if( num == 0 ) return;
    StackSize += num;
    if( StackSize > MaxStackSize ) MaxStackSize = StackSize;
}

//! Internal pop function to monitor run time stack size
/*!
 * This function must be called each time an emit function is called that pops something to the stack.
 * \param num The number of elements to pop (not bytes)
 */
void ByteCode::pop( int num )
{
    if( num == 0 ) return;
        StackSize -= num;
}

// PUSH CONSTANTS ONTO THE STACK
/** \name pushtostack
 *  Push constants onto the stack
 */
//@{

//! Push integer between 0 and 5 to the stack.
/*!
 * \param number Number to push.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iconst( int number )
{
    u2 pos = Code.size();
    switch( number )
    {
        case 0:
            Code.push_back( jvm_iconst_0 );
            break;
        case 1:
            Code.push_back( jvm_iconst_1 );
            break;
        case 2:
            Code.push_back( jvm_iconst_2 );
            break;
        case 3:
            Code.push_back( jvm_iconst_3 );
            break;
        case 4:
            Code.push_back( jvm_iconst_4 );
            break;
        case 5:
            Code.push_back( jvm_iconst_5 );
            break;
        default:
            cerr << "Warning: ByteCode::emit_iconst( int ) number above 5 given. Using sipush!\n";
            return emit_sipush( number );
            break;
    }
    push();
    return pos;
}

//! Push an unsigned byte onto the stack.
/*!
 * \param num Number to push.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_bipush( u1 num )
{
    u2 pos = Code.size();
    Code.push_back( jvm_bipush );
    Code.push_back( num );
    push();
    return pos;
}

//! Push an unsigned two-byte value onto the stack.
/*!
 * \param num Number to push.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_sipush( u2 num )
{
    u2 pos = Code.size();
    Code.push_back( jvm_sipush );
    Code.push_back( (u1)(num >> 8) );
    Code.push_back( (u1)num );
    push( );
    return pos;
}

//! push single-word constant onto stack
/*!
 * \param index One byte index in the constant pool of the entry to be pushed.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ldc( u1 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_ldc );
    Code.push_back( index );
    return pos;
}

//! push single-word constant onto stack (wide index)
/*!
 * \param index Two byte index in the constant pool of the entry to be pushed.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ldc2( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_ldc_w );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    return pos;
}
//@}


// LOADING LOCALS ON THE STACK
/** \name localtostack
 *  Loading locals onto the stack
 */
//@{


//! Load integer from local variable
/*!
 * \param vindex The value of the local variable at vindex in the current Java frame is pushed onto the operand stack.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iload( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_iload_0 );
            break;
        case 1:
            Code.push_back( jvm_iload_1 );
            break;
        case 2:
            Code.push_back( jvm_iload_2 );
            break;
        case 3:
            Code.push_back( jvm_iload_3 );
            break;
        default:
            Code.push_back( jvm_iload );
            Code.push_back( vindex );
    }
    push();
    return pos;
}

//! Load long integer from local variable
/*!
 * \param vindex The value of the local variable at vindex in the current Java frame is pushed onto the operand stack.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lload( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_lload_0 );
            break;
        case 1:
            Code.push_back( jvm_lload_1 );
            break;
        case 2:
            Code.push_back( jvm_lload_2 );
            break;
        case 3:
            Code.push_back( jvm_lload_3 );
            break;
        default:
            Code.push_back( jvm_lload );
            Code.push_back( vindex );
    }
    push( 2 );
    return pos;
}

//! Load single float from local variable
/*!
 * \param vindex The value of the local variable at vindex in the current Java frame is pushed onto the operand stack.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fload( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_fload_0 );
            break;
        case 1:
            Code.push_back( jvm_fload_1 );
            break;
        case 2:
            Code.push_back( jvm_fload_2 );
            break;
        case 3:
            Code.push_back( jvm_fload_3 );
            break;
        default:
            Code.push_back( jvm_fload );
            Code.push_back( vindex );
    }
    push( 1 );
    return pos;
}

//! Load double float from local variable
/*!
 * \param vindex The value of the local variable at vindex in the current Java frame is pushed onto the operand stack.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dload( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_dload_0 );
            break;
        case 1:
            Code.push_back( jvm_dload_1 );
            break;
        case 2:
            Code.push_back( jvm_dload_2 );
            break;
        case 3:
            Code.push_back( jvm_dload_3 );
            break;
        default:
            Code.push_back( jvm_dload );
            Code.push_back( vindex );
    }
    push( 2 );
    return pos;
}

//! Load object reference from local variable.
/*!
 * \param vindex The value of the local variable at vindex in the current Java frame is pushed onto the operand stack.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_aload( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_aload_0 );
            break;
        case 1:
            Code.push_back( jvm_aload_1 );
            break;
        case 2:
            Code.push_back( jvm_aload_2 );
            break;
        case 3:
            Code.push_back( jvm_aload_3 );
            break;
        default:
            Code.push_back( jvm_aload );
            Code.push_back( vindex );
    }
    push( 1 );
    return pos;
}
//@}

// STORING STACK TO LOCALS
/** \name storetostack
 *  Store stack values into locals.
 */
//@{


//! Store integer into local variable
/*!
 * \param vindex Top integer stack item is pushed to the integer variable at vindex.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_istore( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_istore_0 );
            break;
        case 1:
            Code.push_back( jvm_istore_1 );
            break;
        case 2:
            Code.push_back( jvm_istore_2 );
            break;
        case 3:
            Code.push_back( jvm_istore_3 );
            break;
        default:
            Code.push_back( jvm_istore );
            Code.push_back( vindex );
    }
    pop( 1 );
    return pos;
}

//! Store long integer into local variable
/*!
 * \param vindex Top long integer stack item is pushed to the long integer variable at vindex.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lstore( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_lstore_0 );
            break;
        case 1:
            Code.push_back( jvm_lstore_1 );
            break;
        case 2:
            Code.push_back( jvm_lstore_2 );
            break;
        case 3:
            Code.push_back( jvm_lstore_3 );
            break;
        default:
            Code.push_back( jvm_lstore );
            Code.push_back( vindex );
    }
    pop( 2 );
    return pos;
}

//! Store float into local variable
/*!
 * \param vindex Top float stack item is pushed to the float variable at vindex.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fstore( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_fstore_0 );
            break;
        case 1:
            Code.push_back( jvm_fstore_1 );
            break;
        case 2:
            Code.push_back( jvm_fstore_2 );
            break;
        case 3:
            Code.push_back( jvm_fstore_3 );
            break;
        default:
            Code.push_back( jvm_fstore );
            Code.push_back( vindex );
    }
    pop( 1 );
    return pos;

}

//! Store double float into local variable
/*!
 * \param vindex Top double float stack item is pushed to the double float variable at vindex.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dstore( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_dstore_0 );
            break;
        case 1:
            Code.push_back( jvm_dstore_1 );
            break;
        case 2:
            Code.push_back( jvm_dstore_2 );
            break;
        case 3:
            Code.push_back( jvm_dstore_3 );
            break;
        default:
            Code.push_back( jvm_dstore );
            Code.push_back( vindex );
    }
    pop( 2 );
    return pos;
}

//! Store double float into local variable
/*!
 * \param vindex Top double float stack item is pushed to the double float variable at vindex.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_astore( u1 vindex )
{
    u2 pos = Code.size();
    switch( vindex )
    {
        case 0:
            Code.push_back( jvm_astore_0 );
            break;
        case 1:
            Code.push_back( jvm_astore_1 );
            break;
        case 2:
            Code.push_back( jvm_astore_2 );
            break;
        case 3:
            Code.push_back( jvm_astore_3 );
            break;
        default:
            Code.push_back( jvm_astore );
            Code.push_back( vindex );
    }
    pop( 1 );
    return pos;
}

//! Increment local variable by constant
/*!
 * \param vindex Index of local integer variable to increment.
 * \param value The local variable is incremented with this value.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iinc( u1 vindex, u1 value )
{
    u2 pos = Code.size();
    Code.push_back( jvm_iinc );
    Code.push_back( vindex );
    Code.push_back( value );
    return pos;
}
//@}


// ARRAY FUNCTIONS
/** \name arrayfunctions
 *  Stack instructions
 */
//@{
unsigned int ByteCode::emit_newarray( _basic_data_types type )
{
    u2 pos = Code.size();
    Code.push_back( jvm_newarray );
    Code.push_back( type );
    pop( 1 );
    return pos;
}

//! Allocate new multi-dimensional array
/*!
 * the index is used to construct an index into the constant pool of the current class.
 * The item at that index is resolved. The resulting entry must be an array class of one
 * or more dimensions.
 * \param index Two byte index in the constant pool of the entry to be pushed.
 * \param dimensions the number of dimensions to create.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_multianewarray( u2 index, u1 dimensions )
{
    u2 pos = Code.size();
    Code.push_back( jvm_multianewarray );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    Code.push_back( dimensions );
    return pos;
}

//! Allocate new multi-dimensional array
/*!
 * Convenience function for getting static fields. This function creates the needed entries in the static pool for you.
 * \param
 */
unsigned int ByteCode::emit_multianewarray( const string classType, u1 dimensions )
{
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( classType ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    return emit_multianewarray( classref, dimensions );
}

//! Store into integer array
unsigned int ByteCode::emit_iastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_iastore );
    return pos;
}

//! Store into long integer array
unsigned int ByteCode::emit_lastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_lastore );
    return pos;
}

//! Store into single float array
unsigned int ByteCode::emit_fastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_fastore );
    return pos;
}

//! Store into double float array
unsigned int ByteCode::emit_dastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_dastore );
    return pos;
}

//! Store into object reference array
unsigned int ByteCode::emit_aastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_aastore );
    return pos;
}

//! Store into signed byte array
unsigned int ByteCode::emit_bastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_bastore );
    return pos;
}

//! Store into character array
unsigned int ByteCode::emit_castore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_castore );
    return pos;
}

//! Store into short array
unsigned int ByteCode::emit_sastore()
{
    u2 pos = Code.size();
    Code.push_back( jvm_sastore );
    return pos;
}

//! Load integer from array
unsigned int ByteCode::emit_iaload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_iaload );
    return pos;
}
//! Load long integer from array
unsigned int ByteCode::emit_laload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_laload );
    return pos;
}

//! Load single float from array
unsigned int ByteCode::emit_faload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_faload );
    return pos;
}

//! Load double float from array
unsigned int ByteCode::emit_daload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_daload );
    return pos;
}

//! Load object reference from array
unsigned int ByteCode::emit_aaload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_aaload );
    return pos;
}

//! Load signed byte from array
unsigned int ByteCode::emit_baload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_baload );
    return pos;
}

//! Load character from array
unsigned int ByteCode::emit_caload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_caload );
    return pos;
}

//! Load short from array
unsigned int ByteCode::emit_saload()
{
    u2 pos = Code.size();
    Code.push_back( jvm_saload );
    return pos;
}

//@}

// STACK INSTRUCTIONS
/** \name stackinstructions
 *  Stack instructions
 */
//@{

//! Pop top stack word
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_pop()
{
    u2 pos = Code.size();
    pop();
    Code.push_back( jvm_pop );
    return pos;
}

//! Pop top two stack word
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_pop2()
{
    u2 pos = Code.size();
    pop( 2 );
    Code.push_back( jvm_pop2 );
    return pos;

}

//! Duplicate top stack word
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dup()
{
    u2 pos = Code.size();
    push();
    Code.push_back( jvm_dup );
    return pos;
}

//! Duplicate top two stack word
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dup2()
{
    u2 pos = Code.size();
    push( 2 );
    Code.push_back( jvm_dup2 );
    return pos;
}

//! Duplicate top stack word and put it two down.
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dup_x1()
{
    u2 pos = Code.size();
    Code.push_back( jvm_dup_x1 );
    push( 1 );
    return pos;
}

//! Duplicate top stack word and put it three down.
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dup_x2()
{
    u2 pos = Code.size();
    Code.push_back( jvm_dup_x2 );
    push( 1 );
    return pos;
}

//! Swap top two stack words
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_swap()
{
    u2 pos = Code.size();
    Code.push_back( jvm_swap );
    return pos;
}
//@}


// ARITHMETIC INSTRUCTIONS

//! Internal arithmetic helper function.
/*!
 * Since all arithmetic instructions take no parameters this helper function avoids duplicating code.
 * \param code Opcode for the arithmetic function to perform.
 * \param popVal Number of items this function pops from the stack (in total)
 * \return The instruction position.
 */
unsigned int ByteCode::emit_arithmetic( _opcode code, unsigned int popVal )
{
    u2 pos = Code.size();
    Code.push_back( code );
    pop( popVal );
    return pos;
}


/** \name arithmetic
 *  Arithmetic instructions
 */
//@{


//! Integer add
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iadd() // add
{
    return emit_arithmetic( jvm_iadd );
}

//! Long integer add
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ladd()
{
    return emit_arithmetic( jvm_ladd, 2 );
}

//! Float add
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fadd()
{
    return emit_arithmetic( jvm_fadd, 1 );
}

//! Double float add
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dadd()
{
    return emit_arithmetic( jvm_dadd, 2 );
}

//! Integer subtract
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_isub() // sub
{
    return emit_arithmetic( jvm_isub );
}

//! Long Integer subtract
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lsub()
{
    return emit_arithmetic( jvm_lsub, 2 );
}

//! Float subtract
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fsub()
{
    return emit_arithmetic( jvm_fsub, 1 );
}

//! Double Float subtract
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dsub()
{
    return emit_arithmetic( jvm_dsub, 2 );
}

//! Integer multiplication
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_imul() // mul
{
    return emit_arithmetic( jvm_imul );
}

//! Long Integer multiplication
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lmul()
{
    return emit_arithmetic( jvm_lmul, 2 );
}

//! Float multiplication
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fmul()
{
    return emit_arithmetic( jvm_dmul, 1 );
}

//! Double Float multiplication
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dmul()
{
    return emit_arithmetic( jvm_dmul, 2 );
}

//! Integer division
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_idiv()// div
{
    return emit_arithmetic( jvm_idiv );
}

//! Long Integer division
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ldiv()
{
    return emit_arithmetic( jvm_ldiv, 2 );
}

//! Float division
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fdiv()
{
    return emit_arithmetic( jvm_fdiv, 1 );
}

//! Double Float division
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ddiv()
{
    return emit_arithmetic( jvm_ddiv, 2 );
}

//! Integer remainder
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_irem() // mod
{
    return emit_arithmetic( jvm_irem );
}

//! Long Integer remainder
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lrem()
{
    return emit_arithmetic( jvm_lrem, 2 );
}

//! Float remainder
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_frem()
{
    return emit_arithmetic( jvm_frem, 1 );
}

//! Double Float remainder
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_drem()
{
    return emit_arithmetic( jvm_drem, 2 );
}

//! Integer negate
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ineg()
{
    return emit_arithmetic( jvm_ineg, 0 );
}

//! Long Integer negate
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_lneg()
{
    return emit_arithmetic( jvm_lneg, 0 );
}

//! Float negate
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_fneg()
{
    return emit_arithmetic( jvm_fneg, 0 );
}

//! Double Float negate
/*!
 * \return The instruction position.
 */
unsigned int ByteCode::emit_dneg()
{
    return emit_arithmetic( jvm_dneg, 0 );
}
//@}

// LOGICAL INSTRUCTIONS

/** \name logical
 *  Transfer control in the program.
 */
//@{

//! Integer logical and
/*!
 * Performs logical and on the two top integer stack values. Result on stack top.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iand()
{
    u2 pos = Code.size();
    Code.push_back( jvm_iand );
    pop( 2 );
    return pos;
}

//! Integer logical or
/*!
 * Performs logical or on the two top integer stack values. Result on stack top.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ior()
{
    u2 pos = Code.size();
    Code.push_back( jvm_ior );
    pop( 2 );
    return pos;
}

//! Integer logical xor
/*!
 * Performs logical xor on the two top integer stack values. Result on stack top.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ixor()
{
    u2 pos = Code.size();
    Code.push_back( jvm_ixor );
    pop( 2 );
    return pos;
}

//@}

// CONVERSION OPERATIONS

// CONTROL TRANSFER
//! Internal control transfer helper function.
/*!
 * Since all control instructions take the same parameters this helper function avoids duplicating code.
 * \param code Opcode for the control transfer function to perform.
 * \param jump Position in the bytecode to resume execution after jump.
 * \param popVal Number of items this function pops from the stack (in total)
 * \return The instruction position.
 */
unsigned int ByteCode::emit_transfer( _opcode code, u2 jump, unsigned int popVal )
{
    u2 pos = Code.size();
    Code.push_back( code );
    // push high bits
    Code.push_back( (u1)(jump >> 8) );
        // push low bits
    Code.push_back( (u1)jump );
    pop( popVal );
    return pos;
}

/** \name controltransfer
 *  Transfer control in the program.
 */
//@{

//! Patch jump to jump to a new position.
/*!
 * Patches the given jump to jump to the new position given. This can be useful when the position to jump to is not known at the time the jump is created.
 * \param instrAddr The position of the jump instruction to patch.
 * \param jump The new position this jump should jump to.
 * \return The instruction position.
 */
void ByteCode::patch( unsigned int instrAddr, u2 jump )
{
    Code[instrAddr + 1] = (u1)(jump >> 8);
    Code[instrAddr + 2] = (u1)(jump);
}

//! Branch if equal
/*!
 * Jumps if top integer on stack is zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifeq( u2 jump )
{
    return emit_transfer( jvm_ifeq, jump );
}

//! Branch if null
/*!
 * Jumps if top reference on stack is null.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifnull( u2 jump )
{
    return emit_transfer( jvm_ifnull, jump );
}

//! Branch if less than
/*!
 * Jumps if top integer on stack is less than zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_iflt( u2 jump ) // less than
{
    return emit_transfer( jvm_iflt, jump );
}

//! Branch if less or equal
/*!
 * Jumps if top integer on stack is less or equal to zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifle( u2 jump ) // less or equal
{
    return emit_transfer( jvm_ifle, jump );
}

//! Branch if not equal
/*!
 * Jumps if top integer on stack is not equal to zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifne( u2 jump ) // not equal
{
    return emit_transfer( jvm_ifne, jump );
}

//! Branch if not null.
/*!
 * Jumps if top reference on stack is not null.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifnonnull( u2 jump )
{
    return emit_transfer( jvm_ifnonnull, jump );
}

//! Branch if greater than
/*!
 * Jumps if top integer on stack is greater than zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifgt( u2 jump ) // greater than
{
    return emit_transfer( jvm_ifgt, jump );
}

//! Branch if greater or equal.
/*!
 * Jumps if top integer on stack is greater than or equal to zero.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_ifge( u2 jump ) // greater or equal
{
    return emit_transfer( jvm_ifge, jump );
}

//! Branch if integers equal
/*!
 * Jumps if top two integers on stack are equal.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmpeq( u2 jump ) // top two stack integers equal
{
    return emit_transfer( jvm_if_icmpeq, jump, 2 );
}

//! Branch if integers not equal
/*!
 * Jumps if top two integers on stack are not equal.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmpne( u2 jump ) // top two stack integers not equal
{
    return emit_transfer( jvm_if_icmpne, jump, 2 );
}

//! Branch if integer less than
/*!
 * Jumps if first value on stack is less than the top value.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmplt( u2 jump ) // integer stack 2 less than stack 1
{
    return emit_transfer( jvm_if_icmplt, jump, 2 );
}

//! Branch if integer greater than
/*!
 * Jumps if first value on stack is greater than the top value.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmpgt( u2 jump ) // integer stack 2 greater than stack 1
{
    return emit_transfer( jvm_if_icmpgt, jump, 2 );
}

//! Branch if integer less or equal
/*!
 * Jumps if first value on stack is less than or equal to the top value.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmple( u2 jump ) // stack2 less or equal stack 1
{
    return emit_transfer( jvm_if_icmple, jump, 2 );
}

//! Branch if integer greater or equal
/*!
 * Jumps if first value on stack is greater than or equal to the top value.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_if_icmpge( u2 jump ) // stack 2 greater or equal stack 1
{
    return emit_transfer( jvm_if_icmpge, jump, 2 );
}

//! Branch
/*!
 * Unconditional jump.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_goto( u2 jump )
{
    return emit_transfer( jvm_goto, jump, 0 );
}

//! Jump subroutine
/*!
 * Pushes ret value to stack and jumps.
 * \param jump Position to resume execution after jump.
 * \return The instruction position.
 * \sa emit_ret
 */
unsigned int ByteCode::emit_jsr( u2 jump ) // jump subroutine (ret on stack)
{
    u2 pos = Code.size();
    Code.push_back( jvm_jsr );
    Code.push_back( (u1)(jump >> 8) );
    Code.push_back( (u1)jump );
    push( );
    return pos;
}

//! Return from subroutine
/*!
 * \param vindex Local variable vindex in the current Java frame must contain a return address.
 * \return The instruction position.
 * \sa emit_jsr
 */
unsigned int ByteCode::emit_ret( u1 vindex )
{
    u2 pos = Code.size();
    Code.push_back( jvm_ret );
    Code.push_back( vindex );
    return pos;
}
//@}


// MANIPULATING OBJECT FIELDS
/** \name manipulateobjectfields
 *  Manipulate object fields
 */
//@{

//! Get static field from class
/*!
 * \param index Index to a valid entry in the constant pool. The constant pool item will be a field reference to a static field of a class.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_getstatic( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_getstatic );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    push();
    return pos;
}

//! Get static field from class
/*!
 * Convenience function for getting static fields. This function creates the needed entries in the static pool for you.
 *
 * \param className Name of class where the object can be found.
 * \param fieldName The name of the wanted field.
 * \param fieldType The type of the wanted object. Note that this must be a fully qualified java name.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_getstatic( const string &className, const string &fieldName, const string &fieldType )
{
    unsigned int desc_index = ConstantPoolEntries->add( new Utf8_info( fieldType ) );
    unsigned int name_index = ConstantPoolEntries->add( new Utf8_info( fieldName ) );
    unsigned int name_and_type_index = ConstantPoolEntries->add( new NameAndType_info(
                                                                     name_index,
                                                                     desc_index )
                                                                 );
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( className ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    unsigned int fieldref = ConstantPoolEntries->add( new Fieldref_info( classref, name_and_type_index ) );

    return emit_getstatic( fieldref );
}
//@}


// METHOD INVOCATION
/** \name manipulateobjectfields
 *  Manipulate object fields
 */
//@{

//! Invoke instance method
/*!
 * This is the normal method dispatch in Java.
 * The operand stack must contain a reference to an object and some number of arguments
 * \param index Index must point to a valid entry in the constant pool.
 * The item at that index in the constant pool contains the complete method signature.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokevirtual( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_invokevirtual );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    return pos;
}

//! Invoke instance method, dispatching based on compile-time type
/*!
 * The operand stack must contain a reference to an object and some number of arguments
 * \param index Index must point to a valid entry in the constant pool.
 * The item at that index in the constant pool contains the complete method signature.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokespecial( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_invokespecial );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    return pos;
}

//! Invoke a class (static) method
/*!
 * The operand stack must contain the required number of arguments for the function.
 * \param index Index must point to a valid entry in the constant pool.
 * The item at that index in the constant pool contains the complete method signature and class.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokestatic( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_invokestatic );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    push(); // TODO.. this is only true if function returns
    return pos;
}

//! Invoke an interface method
/*!
 * The operand stack must contain the required number of arguments for the function.
 * \param index Index must point to valid entry in the constant pool.
 * \param nargs The number of arguments of the called function.
 * The item at that index in the constant pool contains the complete method signature and class.
 */
unsigned int ByteCode::emit_invokeinterface( u2 index, u1 nargs )
{
    u2 pos = Code.size();
    Code.push_back( jvm_invokeinterface );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    Code.push_back( nargs );
    Code.push_back( (u1)0 );
    return pos;
}

//! Invoke instance method, dispatching based on compile-time type
/*!
 * Convenience function for invoking a special function.
 * This function creates the needed entries in the static pool for you.
 *
 * \param object The object type to invoke the function on.
 * \param function The name of the function to invoke.
 * \param footprint The method signature of the class.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokespecial( const string &object, const string &function, const string &footprint )
{
    // methodref
      // classref
         //"java/lang/Object"
      // name_and_type_index
        // name_index "<init>"
        // descriptor_index "()V"
    unsigned int desc_index = ConstantPoolEntries->add( new Utf8_info( footprint ) );
    unsigned int name_index = ConstantPoolEntries->add( new Utf8_info( function ) );
    unsigned int name_and_type_index = ConstantPoolEntries->add( new NameAndType_info(
                                                                     name_index,
                                                                     desc_index )
                                                                 );
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( object ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    unsigned int methodref = ConstantPoolEntries->add( new Methodref_info( classref, name_and_type_index ) );

    return emit_invokespecial( methodref );
}

//! Invoke a class (static) method
/*!
 * Convenience function for invoking a static function.
 * This function creates the needed entries in the static pool for you.
 *
 * \param classType The class of the static method.
 * \param function The name of the function to invoke.
 * \param footprint The method signature of the class.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokestatic( const string &classType,
                                          const string &function, const string &footprint )
{
    unsigned int desc_index = ConstantPoolEntries->add( new Utf8_info( footprint ) );
    unsigned int name_index = ConstantPoolEntries->add( new Utf8_info( function ) );
    unsigned int name_and_type_index = ConstantPoolEntries->add( new NameAndType_info(
                                                                     name_index,
                                                                     desc_index )
                                                                 );
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( classType ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    unsigned int methodref = ConstantPoolEntries->add( new Methodref_info( classref, name_and_type_index ) );

    return emit_invokestatic( methodref );

}

//! Invoke instance method.
/*!
 * Convenience function for invoking normal class function.
 * This function creates the needed entries in the static pool for you.
 *
 * \param classType The class of the object to invoke the method on.
 * \param function The name of the function to invoke.
 * \param footprint The method signature of the class.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokevirtual( const string &classType,
                                          const string &function, const string &footprint )
{
    unsigned int desc_index = ConstantPoolEntries->add( new Utf8_info( footprint ) );
    unsigned int name_index = ConstantPoolEntries->add( new Utf8_info( function ) );
    unsigned int name_and_type_index = ConstantPoolEntries->add( new NameAndType_info(
                                                                     name_index,
                                                                     desc_index )
                                                                 );
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( classType ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    unsigned int methodref = ConstantPoolEntries->add( new Methodref_info( classref, name_and_type_index ) );

    return emit_invokevirtual( methodref );
}

//! Invoke interface method.
/*!
 * Convenience function for invoking interface methods
 * This function creates the needed entries in the static pool for you.
 *
 * \param objectType The class of the object to invoke the method on.
 * \param function The name of the function to invoke.
 * \param footprint The method signature of the class.
 * \param nargs The number of arguments you have pushed on the stack for this function counting the
 * object reference as a parameter.
 * \return The instruction position.
 */
unsigned int ByteCode::emit_invokeinterface( const string &objectType, const string &function,
                                             const string &footprint, u1 nargs )
{
    unsigned int desc_index = ConstantPoolEntries->add( new Utf8_info( footprint ) );
    unsigned int name_index = ConstantPoolEntries->add( new Utf8_info( function ) );
    unsigned int name_and_type_index = ConstantPoolEntries->add( new NameAndType_info(
                                                                     name_index,
                                                                     desc_index )
                                                                 );
    unsigned int classString = ConstantPoolEntries->add( new Utf8_info( objectType ) );
    unsigned int classref = ConstantPoolEntries->add( new Class_info( classString ) );
    unsigned int methodref = ConstantPoolEntries->add(
        new InterfaceMethodref_info( classref, name_and_type_index ) );

    return emit_invokeinterface( methodref, nargs );
}
//@}

    // MISC OBJECT FUNCTIONS
/** \name miscobjectfunc
 *  Manipulate object fields
 */
//@{
//! Allocate an object on the heap
/*!
 * \param index Index to a class item in the constant pool. This item must be a class name that can be
 * resolved to a class pointer. A new instance of that class is created and a reference to it pushed on
 * the stack.
 */
unsigned int ByteCode::emit_new( u2 index )
{
    u2 pos = Code.size();
    Code.push_back( jvm_new );
    Code.push_back( (u1)(index >> 8) );
    Code.push_back( (u1)index );
    push();
    return pos;
}
//! Allocate an object on the heap
/*!
 * \param classType The type of the object want to create. An index in the constant pool
 * will be created for you.
 */
unsigned int ByteCode::emit_new( const std::string &classType )
{
    u2 classString = ConstantPoolEntries->add( new Utf8_info( classType ) );
    u2 classref = ConstantPoolEntries->add( new Class_info( classString ) );
    return emit_new( classref );
}

//@}

// FUNCTION RETURN
/** \name manipulateobjectfields
 *  Manipulate object fields
 */
//@{

//! Return integer from function
/*!
 * Returns the top integer value on the stack.
 */
unsigned int ByteCode::emit_ireturn()
{
    u2 pos = Code.size();
    Code.push_back( jvm_ireturn );
    return pos;
}

//! Return long integer from function
/*!
 * Returns the top long integer value on the stack.
 */
unsigned int ByteCode::emit_lreturn()
{
    u2 pos = Code.size();
    Code.push_back( jvm_lreturn );
    return pos;
}

//! Return float from function
/*!
 * Returns the top float value on the stack.
 */
unsigned int ByteCode::emit_freturn()
{
    u2 pos = Code.size();
    Code.push_back( jvm_freturn );
    return pos;
}

//! Return double float from function
/*!
 * Returns the top double float value on the stack.
 */
unsigned int ByteCode::emit_dreturn()
{
    u2 pos = Code.size();
    Code.push_back( jvm_dreturn );
    return pos;
}

//! Return from function
unsigned int ByteCode::emit_return()
{
    u2 pos = Code.size();
    Code.push_back( jvm_return );
    return pos;
}
//@}

} // end namespace
