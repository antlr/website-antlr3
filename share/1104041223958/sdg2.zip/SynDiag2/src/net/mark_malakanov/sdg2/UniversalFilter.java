package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */
import java.io.File;
import java.util.HashMap;

public class UniversalFilter 
          extends javax.swing.filechooser.FileFilter {

    HashMap extentions;
    String description, separator;
    
    public UniversalFilter() {
      extentions = new HashMap();
      description = ""; 
      separator = "";
    }

    public UniversalFilter(String[] extentions, String description) {
      this();
      for (int i=0; i<extentions.length; i++) {
        this.extentions.put(extentions[i],description);
      }
      this.description = description;	
    }

    public UniversalFilter(String extention, String description) {
      this();
      add(extention, description);	
    }

    public void add(String extention, String description) {
      extentions.put(extention, description);
      	
      this.description = this.description + separator 
	+ description + " (*."+extention +")"; 

      separator = "; ";
    }

    public boolean accept(File f) {
      boolean accept = f.isDirectory();
  
      if( ! accept) {
        String suffix = getSuffix(f);
  
        if(suffix != null) 
	 accept = ( extentions.get( suffix ) != null );
      }
      return accept;
    }

    public String getDescription() {
      return description;
    }

    private String getSuffix(File f) {
      String s = f.getPath(), suffix = null;
      int i = s.lastIndexOf('.');
  
      if(i > 0 && i < s.length() - 1)
        suffix = s.substring(i+1).toLowerCase();
  
      return suffix;
    }
  }
