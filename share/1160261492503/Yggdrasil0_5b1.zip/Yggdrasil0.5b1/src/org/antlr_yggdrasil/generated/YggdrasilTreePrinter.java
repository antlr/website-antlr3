// $ANTLR 2.7.6 (2005-12-22): "YggdrasilPrint.g" -> "YggdrasilTreePrinter.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
	package org.antlr_yggdrasil.generated;
	import org.antlr_yggdrasil.tool.*;
	import java.util.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** Print out a grammar (no pretty printing).
 *
 *  Terence Parr
 *  University of San Francisco
 *  August 19, 2003
 */
public class YggdrasilTreePrinter extends antlr.TreeParser       implements YggdrasilTreePrinterTokenTypes
 {

	protected Grammar grammar;
	protected boolean showActions;
    protected StringBuffer buf = new StringBuffer(300);

    public void out(String s) {
        buf.append(s);
    }

    public void reportError(RecognitionException ex) {
		Token token = null;
		if ( ex instanceof MismatchedTokenException ) {
			token = ((MismatchedTokenException)ex).token;
		}
		else if ( ex instanceof NoViableAltException ) {
			token = ((NoViableAltException)ex).token;
		}
        ErrorManager.syntaxError(
            ErrorManager.MSG_SYNTAX_ERROR,
            token,
            "YggdrasilPrint: "+ex.toString(),
            ex);
    }

	/** Normalize a grammar print out by removing all double spaces
	 *  and trailing/beginning stuff.  FOr example, convert
	 *
	 *  ( A  |  B  |  C )*
	 *
	 *  to
	 *
	 *  ( A | B | C )*
	 */
	public static String normalize(String g) {
	    StringTokenizer st = new StringTokenizer(g, " ", false);
		StringBuffer buf = new StringBuffer();
		while ( st.hasMoreTokens() ) {
			String w = st.nextToken();
			buf.append(w);
			buf.append(" ");
		}
		return buf.toString().trim();
	}
public YggdrasilTreePrinter() {
	tokenNames = _tokenNames;
}

/** Call this to figure out how to print */
	public final String  toString(AST _t,
		Grammar g, boolean showActions
	) throws RecognitionException {
		String s=null;
		
		GrammarAST toString_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		grammar = g;
		this.showActions = showActions;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_header:
			{
				fileheader(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				grammar(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			{
				rule(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				alternative(_t);
				_t = _retTree;
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case SEMPRED:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				elementPrint(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				GrammarAST tmp1_AST_in = (GrammarAST)_t;
				match(_t,EOR);
				_t = _t.getNextSibling();
				s="EOR";
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			return normalize(buf.toString());
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return s;
	}
	
	public final void fileheader(AST _t) throws RecognitionException {
		
		GrammarAST fileheader_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t9 = _t;
			GrammarAST tmp2_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_header);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp3_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp4_AST_in = (GrammarAST)_t;
			match(_t,LCURLY);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case TOKENS:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t9;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t15 = _t;
			GrammarAST tmp5_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop17:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==SEMI||_t.getType()==LITERAL_public||_t.getType()==LITERAL_import)) {
					grammarAttributeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop17;
				}
				
			} while (true);
			}
			_t = __t15;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void optionsSpec(AST _t) throws RecognitionException {
		
		GrammarAST optionsSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t65 = _t;
			GrammarAST tmp6_AST_in = (GrammarAST)_t;
			match(_t,OPTIONS);
			_t = _t.getFirstChild();
			out(" options {");
			{
			int _cnt67=0;
			_loop67:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN)) {
					option(_t);
					_t = _retTree;
					out("; ");
				}
				else {
					if ( _cnt67>=1 ) { break _loop67; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt67++;
			} while (true);
			}
			out("} ");
			_t = __t65;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammar(AST _t) throws RecognitionException {
		
		GrammarAST grammar_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LEXER_GRAMMAR:
			{
				AST __t54 = _t;
				GrammarAST tmp7_AST_in = (GrammarAST)_t;
				match(_t,LEXER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t,"lexer " );
				_t = _retTree;
				_t = __t54;
				_t = _t.getNextSibling();
				break;
			}
			case PARSER_GRAMMAR:
			{
				AST __t55 = _t;
				GrammarAST tmp8_AST_in = (GrammarAST)_t;
				match(_t,PARSER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t,"parser ");
				_t = _retTree;
				_t = __t55;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_GRAMMAR:
			{
				AST __t56 = _t;
				GrammarAST tmp9_AST_in = (GrammarAST)_t;
				match(_t,TREE_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t,"tree ");
				_t = _retTree;
				_t = __t56;
				_t = _t.getNextSibling();
				break;
			}
			case COMBINED_GRAMMAR:
			{
				AST __t57 = _t;
				GrammarAST tmp10_AST_in = (GrammarAST)_t;
				match(_t,COMBINED_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t,"");
				_t = _retTree;
				_t = __t57;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		GrammarAST rule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST b = null;
		
		try {      // for error handling
			AST __t83 = _t;
			GrammarAST tmp11_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			out(id.getText());
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			out(" : ");
			b = _t==ASTNULL ? null : (GrammarAST)_t;
			block(_t,false);
			_t = _retTree;
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp12_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			out(";\n");
			_t = __t83;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		GrammarAST alternative_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t105 = _t;
			GrammarAST tmp13_AST_in = (GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt107=0;
			_loop107:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt107>=1 ) { break _loop107; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt107++;
			} while (true);
			}
			GrammarAST tmp14_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t105;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void elementPrint(AST _t) throws RecognitionException {
		
		GrammarAST elementPrint_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST aa = null;
		GrammarAST l = null;
		GrammarAST spred = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case WILDCARD:
			{
				atom(_t);
				_t = _retTree;
				break;
			}
			case NOT:
			{
				AST __t152 = _t;
				GrammarAST tmp15_AST_in = (GrammarAST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				out("~");
				atom(_t);
				_t = _retTree;
				_t = __t152;
				_t = _t.getNextSibling();
				break;
			}
			case RANGE:
			{
				AST __t153 = _t;
				GrammarAST tmp16_AST_in = (GrammarAST)_t;
				match(_t,RANGE);
				_t = _t.getFirstChild();
				atom(_t);
				_t = _retTree;
				out("..");
				atom(_t);
				_t = _retTree;
				_t = __t153;
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t154 = _t;
				GrammarAST tmp17_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				atom(_t);
				_t = _retTree;
				out("..");
				atom(_t);
				_t = _retTree;
				_t = __t154;
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				{
					aa = (GrammarAST)_t;
					match(_t,ASSIGN_ATTRIBUTE);
					_t = _t.getNextSibling();
					out(aa.getText()+"=");
					break;
				}
				case LABEL_ATTRIBUTE:
				{
					l = (GrammarAST)_t;
					match(_t,LABEL_ATTRIBUTE);
					_t = _t.getNextSibling();
					out(l.getText()+"=");
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case SET:
				case STRING_LITERAL:
				case DOT_TEXT:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop159:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop159;
					}
					
				} while (true);
				}
				atom(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case BANGEDUP:
			{
				ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				treeMatcher(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t160 = _t;
				GrammarAST tmp18_AST_in = (GrammarAST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t,true);
				_t = _retTree;
				_t = __t160;
				_t = _t.getNextSibling();
				out("=>");
				break;
			}
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				break;
			}
			case SYN_SEMPRED:
			{
				spred = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				
					  String name = spred.getText();
					  GrammarAST predAST=grammar.getSyntacticPredicate(name);
					  block(predAST, true);
					  out("=>");
					
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp19_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void file(AST _t) throws RecognitionException {
		
		GrammarAST file_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			_loop5:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_header)) {
					fileheader(_t);
					_t = _retTree;
				}
				else {
					break _loop5;
				}
				
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				typeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			grammar(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void typeDecls(AST _t) throws RecognitionException {
		
		GrammarAST typeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t25 = _t;
			GrammarAST tmp20_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop27:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LCURLY||_t.getType()==LITERAL_atomic)) {
					attributeTypeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop27;
				}
				
			} while (true);
			}
			_t = __t25;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokensSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokensSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t72 = _t;
			GrammarAST tmp21_AST_in = (GrammarAST)_t;
			match(_t,TOKENS);
			_t = _t.getFirstChild();
			{
			int _cnt74=0;
			_loop74:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN||_t.getType()==TOKEN_REF)) {
					tokenSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt74>=1 ) { break _loop74; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt74++;
			} while (true);
			}
			_t = __t72;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void action(AST _t) throws RecognitionException {
		
		GrammarAST action_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t135 = _t;
			GrammarAST tmp22_AST_in = (GrammarAST)_t;
			match(_t,RCURLY);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t135;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecl(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_public:
				{
					GrammarAST tmp23_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_public);
					_t = _t.getNextSibling();
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				attributeVarDecl(_t);
				_t = _retTree;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp24_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_import);
				_t = _t.getNextSibling();
				GrammarAST tmp25_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeVarDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeVarDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t35 = _t;
			GrammarAST tmp26_AST_in = (GrammarAST)_t;
			match(_t,SEMI);
			_t = _t.getFirstChild();
			GrammarAST tmp27_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp28_AST_in = (GrammarAST)_t;
				match(_t,OPEN_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				{
				int _cnt38=0;
				_loop38:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						GrammarAST tmp29_AST_in = (GrammarAST)_t;
						match(_t,ID);
						_t = _t.getNextSibling();
					}
					else {
						if ( _cnt38>=1 ) { break _loop38; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt38++;
				} while (true);
				}
				GrammarAST tmp30_AST_in = (GrammarAST)_t;
				match(_t,CLOSE_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp31_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			_t = __t35;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ruleAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST ruleAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t21 = _t;
			GrammarAST tmp32_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop23:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SEMI:
				{
					attributeVarDecl(_t);
					_t = _retTree;
					break;
				}
				case ID:
				case LITERAL_new:
				case LITERAL_using:
				{
					attributeUseDecl(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					break _loop23;
				}
				}
			} while (true);
			}
			_t = __t21;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeUseDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeUseDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp33_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp34_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getNextSibling();
				{
				GrammarAST tmp35_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ID:
				case SEMI:
				case DOT_TEXT:
				case LITERAL_new:
				case LITERAL_using:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop51:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop51;
					}
					
				} while (true);
				}
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp36_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_new);
				_t = _t.getNextSibling();
				GrammarAST tmp37_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp38_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_using);
				_t = _t.getNextSibling();
				GrammarAST tmp39_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeTypeDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeTypeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_atomic:
			{
				AST __t29 = _t;
				GrammarAST tmp40_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_atomic);
				_t = _t.getFirstChild();
				GrammarAST tmp41_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_native);
				_t = _t.getNextSibling();
				GrammarAST tmp42_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				_t = __t29;
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				AST __t30 = _t;
				GrammarAST tmp43_AST_in = (GrammarAST)_t;
				match(_t,LCURLY);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_native:
				{
					GrammarAST tmp44_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_native);
					_t = _t.getNextSibling();
					break;
				}
				case ID:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				GrammarAST tmp45_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp46_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				_loop33:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI)) {
						attributeVarDecl(_t);
						_t = _retTree;
					}
					else {
						break _loop33;
					}
					
				} while (true);
				}
				_t = __t30;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void idQualifier(AST _t) throws RecognitionException {
		
		GrammarAST idQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp47_AST_in = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case ID:
			case SYN_SEMPRED:
			case BANGEDUP:
			case SEMI:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arrayQualifier(AST _t) throws RecognitionException {
		
		GrammarAST arrayQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t42 = _t;
			GrammarAST tmp48_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp49_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp50_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case DOT_TEXT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop46:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop46;
					}
					
				} while (true);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t42;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarSpec(AST _t,
		String gtype
	) throws RecognitionException {
		
		GrammarAST grammarSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST cmt = null;
		
		try {      // for error handling
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			out(gtype+"grammar "+id.getText());
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOC_COMMENT:
			{
				cmt = (GrammarAST)_t;
				match(_t,DOC_COMMENT);
				_t = _t.getNextSibling();
				out(cmt.getText()+"\n");
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case RCURLY:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case TOKENS:
			case RULE:
			case RCURLY:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			out(";\n");
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			case RCURLY:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			rules(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		GrammarAST rules_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt81=0;
			_loop81:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case RULE:
				{
					rule(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_COLON:
				{
					constructorRule(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					if ( _cnt81>=1 ) { break _loop81; } else {throw new NoViableAltException(_t);}
				}
				}
				_cnt81++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void option(AST _t) throws RecognitionException {
		
		GrammarAST option_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		
		try {      // for error handling
			AST __t69 = _t;
			GrammarAST tmp51_AST_in = (GrammarAST)_t;
			match(_t,ASSIGN);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			out(id.getText()+"=");
			optionValue(_t);
			_t = _retTree;
			_t = __t69;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void optionValue(AST _t) throws RecognitionException {
		
		GrammarAST optionValue_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST s = null;
		GrammarAST c = null;
		GrammarAST i = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				id = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				out(id.getText());
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				out(s.getText());
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				out(c.getText());
				break;
			}
			case INT:
			{
				i = (GrammarAST)_t;
				match(_t,INT);
				_t = _t.getNextSibling();
				out(i.getText());
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokenSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokenSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				GrammarAST tmp52_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp53_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp54_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN:
				case TOKEN_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN:
			{
				AST __t77 = _t;
				GrammarAST tmp55_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getFirstChild();
				GrammarAST tmp56_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp57_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp58_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case KEYWORD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				GrammarAST tmp59_AST_in = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t77;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void constructorRule(AST _t) throws RecognitionException {
		
		GrammarAST constructorRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t90 = _t;
			GrammarAST tmp60_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_COLON);
			_t = _t.getFirstChild();
			GrammarAST tmp61_AST_in = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			{
			int _cnt92=0;
			_loop92:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt92>=1 ) { break _loop92; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt92++;
			} while (true);
			}
			_t = __t90;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void modifier(AST _t) throws RecognitionException {
		
		GrammarAST modifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		out(modifier_AST_in.getText()); out(" ");
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_protected:
			{
				GrammarAST tmp62_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_protected);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_public:
			{
				GrammarAST tmp63_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_public);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_private:
			{
				GrammarAST tmp64_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_private);
				_t = _t.getNextSibling();
				break;
			}
			case FRAGMENT:
			{
				GrammarAST tmp65_AST_in = (GrammarAST)_t;
				match(_t,FRAGMENT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void block(AST _t,
		boolean forceParens
	) throws RecognitionException {
		
		GrammarAST block_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		int numAlts = countAltsForBlock(block_AST_in);
		
		
		try {      // for error handling
			AST __t95 = _t;
			GrammarAST tmp66_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			if ( forceParens||numAlts>1 ) out(" (");
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				out(" : ");
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			alternative(_t);
			_t = _retTree;
			{
			_loop98:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					out(" | ");
					alternative(_t);
					_t = _retTree;
				}
				else {
					break _loop98;
				}
				
			} while (true);
			}
			GrammarAST tmp67_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			if ( forceParens||numAlts>1 ) out(")");
			_t = __t95;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionGroup(AST _t) throws RecognitionException {
		
		GrammarAST exceptionGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt110=0;
			_loop110:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_exception)) {
					exceptionSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt110>=1 ) { break _loop110; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt110++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeItem(AST _t) throws RecognitionException {
		
		GrammarAST attributeItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			attributeElement(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final int  countAltsForBlock(AST _t) throws RecognitionException {
		int n=0;
		
		GrammarAST countAltsForBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t100 = _t;
			GrammarAST tmp68_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				GrammarAST tmp69_AST_in = (GrammarAST)_t;
				match(_t,OPTIONS);
				_t = _t.getNextSibling();
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt103=0;
			_loop103:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					GrammarAST tmp70_AST_in = (GrammarAST)_t;
					match(_t,ALT);
					_t = _t.getNextSibling();
					n++;
				}
				else {
					if ( _cnt103>=1 ) { break _loop103; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt103++;
			} while (true);
			}
			GrammarAST tmp71_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t100;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return n;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		GrammarAST element_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST l = null;
		GrammarAST spred = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case WILDCARD:
			{
				atom(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case NOT:
			{
				AST __t126 = _t;
				GrammarAST tmp72_AST_in = (GrammarAST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				out("~");
				atom(_t);
				_t = _retTree;
				_t = __t126;
				_t = _t.getNextSibling();
				break;
			}
			case RANGE:
			{
				AST __t127 = _t;
				GrammarAST tmp73_AST_in = (GrammarAST)_t;
				match(_t,RANGE);
				_t = _t.getFirstChild();
				atom(_t);
				_t = _retTree;
				out("..");
				atom(_t);
				_t = _retTree;
				_t = __t127;
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t128 = _t;
				GrammarAST tmp74_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				atom(_t);
				_t = _retTree;
				out("..");
				atom(_t);
				_t = _retTree;
				_t = __t128;
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				l = _t==ASTNULL ? null : (GrammarAST)_t;
				attrLabel(_t);
				_t = _retTree;
				out(l.getText()+"=");
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					atom(_t);
					_t = _retTree;
					break;
				}
				case NOT:
				{
					AST __t131 = _t;
					GrammarAST tmp75_AST_in = (GrammarAST)_t;
					match(_t,NOT);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					_t = __t131;
					_t = _t.getNextSibling();
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				{
					baseebnf(_t);
					_t = _retTree;
					break;
				}
				case TREE_BEGIN:
				{
					treeMatcher(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeElement(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				attributeElement(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case BANGEDUP:
			{
				ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				treeMatcher(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp76_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case SYNPRED:
			{
				AST __t133 = _t;
				GrammarAST tmp77_AST_in = (GrammarAST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t,true);
				_t = _retTree;
				_t = __t133;
				_t = _t.getNextSibling();
				out("=>");
				break;
			}
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				break;
			}
			case SYN_SEMPRED:
			{
				spred = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				
					  String name = spred.getText();
					  GrammarAST predAST=grammar.getSyntacticPredicate(name);
					  block(predAST, true);
					  out("=>");
					
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp78_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionSpec(AST _t) throws RecognitionException {
		
		GrammarAST exceptionSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t112 = _t;
			GrammarAST tmp79_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_exception);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RBRACKET:
			{
				arg_decl(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop115:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_catch)) {
					exceptionHandler(_t);
					_t = _retTree;
				}
				else {
					break _loop115;
				}
				
			} while (true);
			}
			_t = __t112;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arg_decl(AST _t) throws RecognitionException {
		
		GrammarAST arg_decl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t117 = _t;
			GrammarAST tmp80_AST_in = (GrammarAST)_t;
			match(_t,RBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp81_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp82_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case COLON:
			{
				GrammarAST tmp83_AST_in = (GrammarAST)_t;
				match(_t,COLON);
				_t = _t.getNextSibling();
				{
				int _cnt121=0;
				_loop121:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt121>=1 ) { break _loop121; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt121++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t117;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionHandler(AST _t) throws RecognitionException {
		
		GrammarAST exceptionHandler_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t123 = _t;
			GrammarAST tmp84_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_catch);
			_t = _t.getFirstChild();
			arg_decl(_t);
			_t = _retTree;
			action(_t);
			_t = _retTree;
			_t = __t123;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void assignment(AST _t) throws RecognitionException {
		
		GrammarAST assignment_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t144 = _t;
			GrammarAST tmp85_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				break;
			}
			case TOKEN_REF:
			{
				GrammarAST tmp86_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp87_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t144;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t) throws RecognitionException {
		
		GrammarAST atom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST rarg = null;
		GrammarAST targ = null;
		out(" ");
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case WILDCARD:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case RULE_REF:
				{
					AST __t173 = _t;
					GrammarAST tmp88_AST_in = (GrammarAST)_t;
					match(_t,RULE_REF);
					_t = _t.getFirstChild();
					out(atom_AST_in.toString());
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case ARG_ACTION:
					{
						rarg = (GrammarAST)_t;
						match(_t,ARG_ACTION);
						_t = _t.getNextSibling();
						out("["+rarg.toString()+"]");
						break;
					}
					case 3:
					case BANG:
					case CARET:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t173;
					_t = _t.getNextSibling();
					break;
				}
				case TOKEN_REF:
				{
					AST __t176 = _t;
					GrammarAST tmp89_AST_in = (GrammarAST)_t;
					match(_t,TOKEN_REF);
					_t = _t.getFirstChild();
					out(atom_AST_in.toString());
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case ARG_ACTION:
					{
						targ = (GrammarAST)_t;
						match(_t,ARG_ACTION);
						_t = _t.getNextSibling();
						out("["+targ.toString()+"]");
						break;
					}
					case 3:
					case BANG:
					case CARET:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t176;
					_t = _t.getNextSibling();
					break;
				}
				case KEYWORD:
				{
					AST __t179 = _t;
					GrammarAST tmp90_AST_in = (GrammarAST)_t;
					match(_t,KEYWORD);
					_t = _t.getFirstChild();
					out(atom_AST_in.toString());
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t179;
					_t = _t.getNextSibling();
					break;
				}
				case STRING_LITERAL:
				{
					AST __t181 = _t;
					GrammarAST tmp91_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getFirstChild();
					out(atom_AST_in.toString());
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t181;
					_t = _t.getNextSibling();
					break;
				}
				case WILDCARD:
				{
					AST __t183 = _t;
					GrammarAST tmp92_AST_in = (GrammarAST)_t;
					match(_t,WILDCARD);
					_t = _t.getFirstChild();
					out(atom_AST_in.toString());
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BANG:
					case CARET:
					{
						ast_suffix(_t);
						_t = _retTree;
						break;
					}
					case 3:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t183;
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				out(" ");
				break;
			}
			case SET:
			{
				set(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ast_suffix(AST _t) throws RecognitionException {
		
		GrammarAST ast_suffix_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case CARET:
			{
				GrammarAST tmp93_AST_in = (GrammarAST)_t;
				match(_t,CARET);
				_t = _t.getNextSibling();
				out("^");
				break;
			}
			case BANG:
			{
				GrammarAST tmp94_AST_in = (GrammarAST)_t;
				match(_t,BANG);
				_t = _t.getNextSibling();
				out("!");
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attrLabel(AST _t) throws RecognitionException {
		
		GrammarAST attrLabel_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LABEL_ATTRIBUTE:
			{
				a = (GrammarAST)_t;
				match(_t,LABEL_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			case ASSIGN_ATTRIBUTE:
			{
				GrammarAST tmp95_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SET:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop150:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop150;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void baseebnf(AST _t) throws RecognitionException {
		
		GrammarAST baseebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				block(_t,true);
				_t = _retTree;
				out(" ");
				break;
			}
			case OPTIONAL:
			{
				AST __t164 = _t;
				GrammarAST tmp96_AST_in = (GrammarAST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				block(_t,true);
				_t = _retTree;
				_t = __t164;
				_t = _t.getNextSibling();
				out("? ");
				break;
			}
			case CLOSURE:
			{
				AST __t165 = _t;
				GrammarAST tmp97_AST_in = (GrammarAST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				block(_t,true);
				_t = _retTree;
				_t = __t165;
				_t = _t.getNextSibling();
				out("* ");
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t166 = _t;
				GrammarAST tmp98_AST_in = (GrammarAST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				block(_t,true);
				_t = _retTree;
				_t = __t166;
				_t = _t.getNextSibling();
				out("+ ");
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void treeMatcher(AST _t) throws RecognitionException {
		
		GrammarAST treeMatcher_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t168 = _t;
			GrammarAST tmp99_AST_in = (GrammarAST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			out(" ^(");
			element(_t);
			_t = _retTree;
			{
			_loop170:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					break _loop170;
				}
				
			} while (true);
			}
			out(") ");
			_t = __t168;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeElement(AST _t) throws RecognitionException {
		
		GrammarAST attributeElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp100_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				attributeGroup(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp101_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			{
				attributeStatements(_t);
				_t = _retTree;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp102_AST_in = (GrammarAST)_t;
				match(_t,CURRENT_TREE);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp103_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp104_AST_in = (GrammarAST)_t;
				match(_t,LPAREN);
				_t = _t.getNextSibling();
				{
				_loop217:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop217;
					}
					
				} while (true);
				}
				GrammarAST tmp105_AST_in = (GrammarAST)_t;
				match(_t,RPAREN);
				_t = _t.getNextSibling();
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				treeConstructor(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		GrammarAST ebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANGEDUP:
			{
				AST __t162 = _t;
				GrammarAST tmp106_AST_in = (GrammarAST)_t;
				match(_t,BANGEDUP);
				_t = _t.getFirstChild();
				baseebnf(_t);
				_t = _retTree;
				_t = __t162;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				baseebnf(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void sempred(AST _t) throws RecognitionException {
		
		GrammarAST sempred_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t137 = _t;
			GrammarAST tmp107_AST_in = (GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t137;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void template(AST _t) throws RecognitionException {
		
		GrammarAST template_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp108_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp109_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				{
				int _cnt142=0;
				_loop142:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt142>=1 ) { break _loop142; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt142++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attribute(AST _t) throws RecognitionException {
		
		GrammarAST attribute_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp110_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop188:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop188;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void set(AST _t) throws RecognitionException {
		
		GrammarAST set_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t191 = _t;
			GrammarAST tmp111_AST_in = (GrammarAST)_t;
			match(_t,SET);
			_t = _t.getFirstChild();
			out("(");
			setElement(_t);
			_t = _retTree;
			{
			_loop193:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==CHAR_RANGE||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF)) {
					out("|");
					setElement(_t);
					_t = _retTree;
				}
				else {
					break _loop193;
				}
				
			} while (true);
			}
			out(")");
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANG:
			case CARET:
			{
				ast_suffix(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t191;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void setElement(AST _t) throws RecognitionException {
		
		GrammarAST setElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case KEYWORD:
				{
					GrammarAST tmp112_AST_in = (GrammarAST)_t;
					match(_t,KEYWORD);
					_t = _t.getNextSibling();
					out(setElement_AST_in.toString());
					break;
				}
				case TOKEN_REF:
				{
					GrammarAST tmp113_AST_in = (GrammarAST)_t;
					match(_t,TOKEN_REF);
					_t = _t.getNextSibling();
					out(setElement_AST_in.toString());
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp114_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					out(setElement_AST_in.toString());
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case CHAR_RANGE:
			{
				AST __t197 = _t;
				GrammarAST tmp115_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t197;
				_t = _t.getNextSibling();
				out(c1.getText()+
					     ".."+
					     c2.getText());
					
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeGroup(AST _t) throws RecognitionException {
		
		GrammarAST attributeGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t199 = _t;
			GrammarAST tmp116_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_GROUP);
			_t = _t.getFirstChild();
			{
			_loop201:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeItem(_t);
					_t = _retTree;
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp117_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					break _loop201;
				}
				}
			} while (true);
			}
			_t = __t199;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeBlock(AST _t) throws RecognitionException {
		
		GrammarAST attributeBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				{
				_loop204:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop204;
					}
					
				} while (true);
				}
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				{
				_loop206:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop206;
					}
					
				} while (true);
				}
				{
				GrammarAST tmp118_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getNextSibling();
				attributeBlock(_t);
				_t = _retTree;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeStatements(AST _t) throws RecognitionException {
		
		GrammarAST attributeStatements_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t209 = _t;
			GrammarAST tmp119_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			attributeBlock(_t);
			_t = _retTree;
			_t = __t209;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void treeConstructor(AST _t) throws RecognitionException {
		
		GrammarAST treeConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t219 = _t;
			GrammarAST tmp120_AST_in = (GrammarAST)_t;
			match(_t,TREE_CONSTRUCTOR);
			_t = _t.getFirstChild();
			attributeItem(_t);
			_t = _retTree;
			{
			int _cnt221=0;
			_loop221:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt221>=1 ) { break _loop221; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt221++;
			} while (true);
			}
			_t = __t219;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF",
		"ARG_ACTION"
	};
	
	}
	
