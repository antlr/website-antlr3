/* $ANTLR 2.7.5 (20050128): "treewalk.g" -> "LangParser.cpp"$ */
#include "LangParser.hpp"
#include <antlr/NoViableAltException.hpp>
#include <antlr/SemanticException.hpp>
#include <antlr/ASTFactory.hpp>
#line 9 "treewalk.g"

#include <iostream>

#line 11 "LangParser.cpp"
LangParser::LangParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,k)
{
}

LangParser::LangParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,1)
{
}

LangParser::LangParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,k)
{
}

LangParser::LangParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,1)
{
}

LangParser::LangParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(state,1)
{
}

void LangParser::block() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST block_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		RefMyAST tmp4_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
		tmp4_AST = astFactory->create(LT(1));
		astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp4_AST));
		match(LCURLY);
		{ // ( ... )*
		for (;;) {
			if ((_tokenSet_0.member(LA(1)))) {
				statement();
				astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else {
				goto _loop3;
			}
			
		}
		_loop3:;
		} // ( ... )*
		match(RCURLY);
		block_AST = RefMyAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_1);
	}
	returnAST = block_AST;
}

void LangParser::statement() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST statement_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	RefMyAST b_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		switch ( LA(1)) {
		case ID:
		case INT:
		{
			expr();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			match(SEMI);
			statement_AST = RefMyAST(currentAST.root);
			break;
		}
		case LITERAL_if:
		{
			RefMyAST tmp7_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
			tmp7_AST = astFactory->create(LT(1));
			astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp7_AST));
			match(LITERAL_if);
			match(LPAREN);
			expr();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			match(RPAREN);
			statement();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			{
			if ((LA(1) == LITERAL_else)) {
				match(LITERAL_else);
				statement();
				astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else if ((_tokenSet_1.member(LA(1)))) {
			}
			else {
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			
			}
			statement_AST = RefMyAST(currentAST.root);
			break;
		}
		case LITERAL_while:
		{
			RefMyAST tmp11_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
			tmp11_AST = astFactory->create(LT(1));
			astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp11_AST));
			match(LITERAL_while);
			match(LPAREN);
			expr();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			match(RPAREN);
			statement();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			statement_AST = RefMyAST(currentAST.root);
			break;
		}
		case LCURLY:
		{
			block();
			b_AST = returnAST;
			statement_AST = RefMyAST(currentAST.root);
#line 31 "treewalk.g"
			statement_AST = b_AST;
#line 137 "LangParser.cpp"
			currentAST.root = statement_AST;
			if ( statement_AST!=RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) &&
				statement_AST->getFirstChild() != RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
				  currentAST.child = statement_AST->getFirstChild();
			else
				currentAST.child = statement_AST;
			currentAST.advanceChildToEnd();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_1);
	}
	returnAST = statement_AST;
}

void LangParser::expr() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST expr_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		assignExpr();
		astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		expr_AST = RefMyAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_2);
	}
	returnAST = expr_AST;
}

void LangParser::assignExpr() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST assignExpr_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		aexpr();
		astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		{
		if ((LA(1) == ASSIGN)) {
			RefMyAST tmp14_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
			tmp14_AST = astFactory->create(LT(1));
			astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp14_AST));
			match(ASSIGN);
			assignExpr();
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		}
		else if ((LA(1) == SEMI || LA(1) == RPAREN)) {
		}
		else {
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		
		}
		assignExpr_AST = RefMyAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_2);
	}
	returnAST = assignExpr_AST;
}

void LangParser::aexpr() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST aexpr_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		mexpr();
		astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == PLUS)) {
				RefMyAST tmp15_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
				tmp15_AST = astFactory->create(LT(1));
				astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp15_AST));
				match(PLUS);
				mexpr();
				astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else {
				goto _loop11;
			}
			
		}
		_loop11:;
		} // ( ... )*
		aexpr_AST = RefMyAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
	returnAST = aexpr_AST;
}

void LangParser::mexpr() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST mexpr_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		atom();
		astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == STAR)) {
				RefMyAST tmp16_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
				tmp16_AST = astFactory->create(LT(1));
				astFactory->makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp16_AST));
				match(STAR);
				atom();
				astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else {
				goto _loop14;
			}
			
		}
		_loop14:;
		} // ( ... )*
		mexpr_AST = RefMyAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_4);
	}
	returnAST = mexpr_AST;
}

void LangParser::atom() {
	returnAST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	RefMyAST atom_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		if ((LA(1) == ID)) {
			RefMyAST tmp17_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
			tmp17_AST = astFactory->create(LT(1));
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp17_AST));
			match(ID);
			atom_AST = RefMyAST(currentAST.root);
		}
		else if ((LA(1) == INT)) {
			RefMyAST tmp18_AST = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
			tmp18_AST = astFactory->create(LT(1));
			astFactory->addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp18_AST));
			match(INT);
			atom_AST = RefMyAST(currentAST.root);
		}
		else {
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
	returnAST = atom_AST;
}

void LangParser::initializeASTFactory( ANTLR_USE_NAMESPACE(antlr)ASTFactory& factory )
{
	factory.setMaxNodeType(20);
}
const char* LangParser::tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"LCURLY",
	"RCURLY",
	"SEMI",
	"\"if\"",
	"LPAREN",
	"RPAREN",
	"\"else\"",
	"\"while\"",
	"ASSIGN",
	"PLUS",
	"STAR",
	"ID",
	"INT",
	"WS_",
	"COMMA",
	"ESC",
	"DIGIT",
	0
};

const unsigned long LangParser::_tokenSet_0_data_[] = { 100496UL, 0UL, 0UL, 0UL };
// LCURLY "if" "while" ID INT 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long LangParser::_tokenSet_1_data_[] = { 101552UL, 0UL, 0UL, 0UL };
// LCURLY RCURLY "if" "else" "while" ID INT 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_1(_tokenSet_1_data_,4);
const unsigned long LangParser::_tokenSet_2_data_[] = { 576UL, 0UL, 0UL, 0UL };
// SEMI RPAREN 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_2(_tokenSet_2_data_,4);
const unsigned long LangParser::_tokenSet_3_data_[] = { 4672UL, 0UL, 0UL, 0UL };
// SEMI RPAREN ASSIGN 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_3(_tokenSet_3_data_,4);
const unsigned long LangParser::_tokenSet_4_data_[] = { 12864UL, 0UL, 0UL, 0UL };
// SEMI RPAREN ASSIGN PLUS 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_4(_tokenSet_4_data_,4);
const unsigned long LangParser::_tokenSet_5_data_[] = { 29248UL, 0UL, 0UL, 0UL };
// SEMI RPAREN ASSIGN PLUS STAR 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangParser::_tokenSet_5(_tokenSet_5_data_,4);


