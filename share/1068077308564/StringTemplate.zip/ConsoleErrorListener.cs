using System;

namespace Antlr.StringTemplate {
	/// <summary>
	/// An error listener that sends all of it's output to the console.
	/// </summary>
	public class ConsoleErrorListener : IStringTemplateErrorListener {
		public ConsoleErrorListener() {
		}

		public void Error(String s, Exception e) {
			Console.Error.WriteLine(s);

			if ( e != null ) {
				Console.Error.WriteLine(e.StackTrace);
			}
		}

		public void Warning(String s) {
			Console.WriteLine(s);
		}

		public void Debug(String s) {
			Console.WriteLine(s);
		}
	}
}
