/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef CONSTANTPOOL_HPP
#define CONSTANTPOOL_HPP

#include <string>
#include <fstream>
#include <vector>

#include "defs.hpp"
#include "classwriterbase.hpp"

namespace ClassEncoder
{
class cp_info;

//! Object representing the object pool
/*!
 * This class represents a constant pool of a class file. You can add entries to it and make it write itself to a class stream.
 *
 * \todo Currently generating classes needing entries in the constant pool create them and enters them via the add function. This means that redundant multiple entries in the constant pool are unavoidable. A nice addition to this class would be to add createXXX_info functions that check if the needed entry is already in the pool before creating it.
 */
class ConstantPool
{
public:
    ConstantPool();
    ~ConstantPool();

    //! get the number of items in the constant pool
    unsigned int count() const { return ConstantPoolCount; }
    unsigned int add( cp_info *entry );
    void write( std::ofstream &stream ) const;

private:
    std::vector<cp_info*> Entries;
    unsigned int ConstantPoolCount;
};

//! Base class for all constant pool entries
/*!
 * \sa _constant_tags
 */
class cp_info : public ClassWriterBase
{
public:
    //! empty destructor
    virtual ~cp_info() {}
    virtual void write( std::ofstream &stream ) const;

protected:
    //! Default constructor only available to subclasses
    cp_info() {}

protected:
    u1 tag;
};

//! Constant pool Class_info entry
/*!
 * Represents a class_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#1221
 */
class Class_info : public cp_info
{
public:
    //! Constructor
    /*!
     * \param index Index in the constant pool to a Utf8_info class containing the information.
     */
    Class_info( u2 index ) { name_index = index; tag = CONSTANT_Class;}
    //! Destructor
    virtual ~Class_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 name_index;
};

//! Constant pool Methodref_info entry
/*!
 * Represents a methodref_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#42041
 */
class Methodref_info : public cp_info
{
public:
    //! Constructor
    /*!
     * \param classi Index in the constant pool to a Class_info object.
     * \param nameati Index in the constant pool to a NameAndType_info object.
     */
    Methodref_info( u2 classi, u2 nameati )
	{ class_index = classi; name_and_type_index = nameati; tag = CONSTANT_Methodref; }
    //! Destructor
    virtual ~Methodref_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 class_index;
    u2 name_and_type_index;
};

//! Constant pool InterfaceMethodref_info entry
/*!
 * Represents a methodref_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#42041
 */
class InterfaceMethodref_info : public cp_info
{
public:
    //! Constructor
    /*!
     * \param classi Index in the constant pool to a Class_info object.
     * \param nameati Index in the constant pool to a NameAndType_info object.
     */
    InterfaceMethodref_info( u2 classi, u2 nameati )
	{ class_index = classi; name_and_type_index = nameati; tag = CONSTANT_InterfaceMethodref; }
    //! Destructor
    virtual ~InterfaceMethodref_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 class_index;
    u2 name_and_type_index;
};

//! Constant pool Fieldref_info
/*!
 * Represents a Fieldref_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#42041
 */
class Fieldref_info : public cp_info
{
public:
    //! constructor
    /*!
     * \param classi Index in the constant pool to a Class_info object.
     * \param nameati Index in the constant pool to a NameAndType_info object.
     */
    Fieldref_info( u2 classi, u2 nameati )
	{ class_index = classi; name_and_type_index = nameati; tag = CONSTANT_Fieldref; }
    //! Destructor
    virtual ~Fieldref_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 class_index;
    u2 name_and_type_index;
};


//! Constant pool NameAndType_info entry
/*!
 * Represents a NameAndType_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#1327
 */
class NameAndType_info : public cp_info
{
public:
    //! constructor
    /*!
     * \param namei Index in the constant pool to a Utf8_info object describing the name.
     * \param desci Index in the constant pool to a Utf8_info object describing the type.
     */
    NameAndType_info( u2 namei, u2 desci)
	{ name_index = namei; descriptor_index = desci; tag = CONSTANT_NameAndType; }
    //! Destructor
    virtual ~NameAndType_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 name_index; // method name (utf8)
    u2 descriptor_index; // method parameters (utf8)
};


//! Constant pool String_info entry
/*!
 * Not currently used.
 */
class String_info : public cp_info
{
public:
    String_info() { tag = CONSTANT_String; }
    //! Destructor
    virtual ~String_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 string_index;
};

//! Constant pool Integer_info entry
/*!
 * Not currently used.
 */
class Integer_info : public cp_info
{
public:
    Integer_info() { tag = CONSTANT_Integer; }
    //! Destructor
    virtual ~Integer_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u4 bytes;
};

//! Constant pool Float_info entry
/*!
 * Not currently used.
 */
class Float_info : public cp_info
{
public:
    Float_info() { tag = CONSTANT_Float; }
    //! Destructor
    virtual ~Float_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u4 bytes;
};

//! Constant pool Long_info entry
/*!
 * Not currently used.
 */
class Long_info : public cp_info
{
public:
    Long_info() { tag = CONSTANT_Long; }
    //! Destructor
    virtual ~Long_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u4 high_bytes;
    u4 low_bytes;
};

//! Constant pool Double_info entry
/*!
 * Not currently used.
 */
class Double_info : public cp_info
{
public:
    Double_info() { tag = CONSTANT_Double; }
    //! Destructor
    virtual ~Double_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u4 high_bytes;
    u4 low_bytes;
};

//! Constant pool Utf8_info entry
/*!
 * Represents a Fieldref_info entry as defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#7963
 */
class Utf8_info : public cp_info
{
public:
    //! constructor
    /*!
     * \param data The string data this object should contain.
     */
    Utf8_info( const std::string &data ) { bytes = data; length = bytes.length(); tag = CONSTANT_Utf8; }
    //! Destructor
    virtual ~Utf8_info() {}
    virtual void write( std::ofstream &stream ) const;

private:
    u2 length;
    std::string bytes; // encode with u1
};

} // end namespace
#endif // CONSTANTPOOL_HPP
