import java.util.Vector;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;

public class Function{
	public Vector params;
	public CommonTree tree;
	public String name;
	public String return_type;
	
	public Function(String n, String r, Vector my_params, CommonTree my_tree){
		name=n;
		return_type=r;
		params=my_params;
		tree=my_tree;
	}
}

