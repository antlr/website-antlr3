/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.logging.Logger;

/**
 *  This class reads the syntax modes from a property file and registers 
 *  them. 
 */
public class SettingsReader {

    private static ResourceBundle settings;
    static Properties syntaxMap;
    private static String sep = System.getProperty( "file.separator");
    private static String SETTINGS_PATH = "settings" + sep;
    private static String SETTINGS = "settings" + sep + "settings.properties";
    private static String path = null; 

    public SettingsReader() {
		SettingsReader.load();
    }

    /**
     *  Reads the syntax modes from a property file and creates a 
     *  SyntaxInfo structure for each of them. The SyntaxInfo structures
     *  are then registered with <code>Syntax</code> class.
     */
    public static void load() {
        try {
            URL url = Class.forName("satc.SettingsReader").getClassLoader().getResource( SETTINGS);
            settings = new PropertyResourceBundle( new FileInputStream( new File( url.getPath())));
            path = (new File( url.getPath())).getParent() + sep;
			log.config("path = " + path);
            String kits = settings.getString( "InstalledEditors" );
            StringTokenizer st = new StringTokenizer( kits, "," );
            while( st.hasMoreTokens() ) {
                String syntaxName = st.nextToken();
                // At the first, we have to read ALL info about kit
                String contentType = settings.getString( syntaxName + ".contentType" );
                String extList = settings.getString( syntaxName + ".extensionList" );
				log.config("extensionList = " + extList);
                String filterTitle = settings.getString( syntaxName + ".fileFilterTitle" );

                // Finally, convert the list of extensions to, ehm, List :-)
                java.util.List l = new ArrayList( 5 );
                StringTokenizer extST = new StringTokenizer( extList, "," );
                while( extST.hasMoreTokens() ) l.add( extST.nextToken() );            

                // Actually create the KitInfo from provided informations
                SyntaxInfo ki = new SyntaxInfo( syntaxName, contentType, l, filterTitle);
                Syntax.register( ki);
            }
        }
        catch( Exception e) {
           e.printStackTrace();
        }
    }
    
    public static Properties getProperties( String syntaxMode) {    
        if( syntaxMap == null) {
            syntaxMap = new Properties();
        }
        if( syntaxMap.containsKey( syntaxMode)) {
            return (Properties) syntaxMap.get( syntaxMode);
        }
        return loadProperties( syntaxMode);
    }
    
    
    //TODO: return a default value
    private static Properties loadProperties( String syntaxMode) {
//      URL url = ClassLoader.getSystemResource( SETTINGS_PATH + syntaxMode + ".properties");
        Properties prop = new Properties();
        try {
			log.config("Path = " + path + ", syntax mode = " + syntaxMode);
          	prop.load( new java.io.FileInputStream( path + syntaxMode + ".properties"));
            syntaxMap.put( syntaxMode, prop);
        } catch( Exception e) {
            e.printStackTrace();
        }
        return prop;
    }
    
	private static Logger log = Logger.getLogger("satc.SettingsReader");
	
}


