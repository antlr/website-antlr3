package net.mark_malakanov.sdg2;

import antlr.*;

import antlr.collections.*;

import antlr.debug.misc.*;

import edu.usfca.syndiag.*;

/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/SdgBody.java,v 1.4 2005/01/29 21:43:38 Mark Exp $
 *
 * Modification Log
 * $Log: SdgBody.java,v $
 * Revision 1.4  2005/01/29 21:43:38  Mark
 * optimized memory usage
 *
 * Revision 1.3  2005/01/03 13:16:48  Mark
 * minor
 *
 * Revision 1.2  2004/12/30 01:53:28  Mark
 * resizing of width added
 *
 * Revision 1.1  2004/12/29 20:38:32  Mark
 * SdgBody separated with GUI. Multifile output command line params added.
 *
 */

//import antlr.ANTLRLexer;
//import antlr.ANTLRParser;
import edu.usfca.syndiag.ANTLRLexer;
import edu.usfca.syndiag.ANTLRParser;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import java.io.*;

import java.util.StringTokenizer;

import javax.imageio.ImageIO;

import javax.swing.*;


public class SdgBody {
    ASTFactory astFactory;
    AST initialGrammarTree;
    AST grammarTree;
    int diagramWidth;
    int diagramAltWidth;
    String diagramStyle = "Canonical";

    public SdgBody() {
    }

    public void calcLayout(int dw, int daw) {
        try {
            diagramWidth = dw;
            diagramAltWidth = daw;

            grammarTree = astFactory.dupList(initialGrammarTree);

            if (initialGrammarTree == grammarTree) {
                grammarTree = null;
            }

            if (grammarTree.equalsTree(initialGrammarTree)) {
                grammarTree = grammarTree;
            }

            // walk the tree caculate the dimension of each item
            SetDimension sd = new SetDimension();

            if (diagramWidth > 0) {
                AdjustDimension ad = new AdjustDimension();
                ad.setWidth(diagramWidth);
                ad.setAltWidth(diagramAltWidth);
                ad.grammar(grammarTree);
            }

            // caculate the dimension for the new tree
            sd.grammar(grammarTree);

            // caculate and set the location for the new tree
            SetLocation sl = new SetLocation();
            sl.grammar(grammarTree);
        } catch (RecognitionException e) {
            throw new RuntimeException(e);
        }
    }

    public void load(InputStream inStr)
        throws java.io.IOException, antlr.RecognitionException, 
            antlr.TokenStreamException {
        ANTLRLexer lexer = new ANTLRLexer(inStr);
        ANTLRParser parser = new ANTLRParser(lexer);
        parser.setASTNodeClass("edu.usfca.syndiag.GrammarAST");
        parser.grammar();
        initialGrammarTree = parser.getAST();
        astFactory = parser.getASTFactory();

        //System.out.println(grammarTree.toStringList());
        // print((GrammarAST)grammarTree);
        calcLayout(diagramWidth, diagramAltWidth);
    }

    public void saveAsFile(AST ast, String fileName)
        throws java.io.IOException {

        int width = ((GrammarAST) ast).getWidth() + 170;
        int height = ((GrammarAST) ast).getHeight() + 50;

        String fmt = "png";
        fmt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();

        if (fmt.equalsIgnoreCase("svg")) {
            DrawDemo svgPanel = new DrawDemo();
            svgPanel.setAST(ast);
            svgPanel.paintSvg(fileName);
            return;
        } 
        
        // if format not SVG
        BufferedImage image = new BufferedImage(width, height,
                BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D g = image.createGraphics();

        DrawDemo canvas;
        canvas = new DrawDemo();
        canvas.init();
        canvas.setAST(ast);
        canvas.setBackground(Color.white);
        canvas.setForeground(Color.black);
        canvas.setBounds(0, 0, width, height);
        canvas.setDiagramStyle(diagramStyle);

        g.setBackground(Color.white);
        g.setPaint(Color.gray);
        g.clearRect(0, 0, width, height);

        AffineTransform aT = g.getTransform();
        int dX = ((GrammarAST) ast).getX();
        int dY = ((GrammarAST) ast).getY();
        aT.translate(-dX + 20, -dY + 20);
        g.setTransform(aT);

        canvas.paint(g);
        g.dispose();

        System.err.println("save " + fileName);
        
        ImageIO.write(image, fmt, new File(fileName));
        image.flush();
        
        image = null; //free memory
        System.gc();
        //image = new BufferedImage(0, 0, BufferedImage.TYPE_BYTE_BINARY );
        //image = null;
        
    }

    public void saveAsHTMLandFiles(String dirName, String htmlName, String ext,
        String htmlTitle, String htmlHeader, String imgBorder,
        ProgressMonitor pm) throws java.io.IOException, InterruptedException {
        GrammarAST gast = (GrammarAST) grammarTree;
        GrammarAST[] rules = gast.getChildrenAsArray();
        GrammarAST rule;

        File dir = new File(dirName);
        dir.mkdir();

        if (!htmlName.toLowerCase().endsWith(".html")) {
            htmlName = htmlName + ".html";
        }

        PrintWriter w = new PrintWriter(new BufferedOutputStream(
                    new FileOutputStream(htmlName)));

        HtmlSyntaxDiagramGenerator hsdg = new HtmlSyntaxDiagramGenerator(w,
                dirName, ext, htmlTitle, htmlHeader, imgBorder);

        Draw draw = new Draw();
        draw.setDiagGen(hsdg);

        if (pm != null) {
            pm.setMaximum(rules.length);
        }

        for (int i = 0; i < rules.length; i++) {
            rule = (GrammarAST) rules[i];

            String fn = rule.getFirstChild().getText();
            String fullName = dirName + "/" + fn + "." + ext;

            if (pm != null) {
                pm.setProgress(i);
                pm.setNote(fullName);
                Thread.currentThread().yield();
                Thread.currentThread().sleep(50);

                if (pm.isCanceled()) {
                    break;
                }
            }

            try {
                draw.grammar(rule);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            saveAsFile(rule, fullName);

            if (pm != null) {
                pm.setProgress(i + 1);
                pm.setNote(fullName);
                Thread.currentThread().yield();
                Thread.currentThread().sleep(50);

                if (pm.isCanceled()) {
                    break;
                }
            }
        }

        w.println("</BODY>");
        w.println("</HTML>");
        w.flush();
        w.close();

        if (pm != null) {
            pm.close();
        }
    }

    public void saveAsFiles(String dirName, String ext)
        throws java.io.IOException {
        GrammarAST gast = (GrammarAST) grammarTree;
        GrammarAST[] rules = gast.getChildrenAsArray();
        GrammarAST rule;

        for (int i = 0; i < rules.length; i++) {
            rule = (GrammarAST) rules[i];

            String fn = rule.getFirstChild().getText();
            saveAsFile(rule, fn + "." + ext);
        }
    }

    /**
     * Saves HTML binder file and multiple image files for each rule in separate
     * directory. Uses separate thread to do it in background.
     */
    public void saveAsHTMLandFilesInBkg(String dirName, String htmlName,
        String ext, String htmlTitle, String htmlHeader, String imgBorder,
        ProgressMonitor pm) throws java.io.IOException, InterruptedException {
        HTMLandFilesBackGroundSaver t = new HTMLandFilesBackGroundSaver(this,
                dirName, htmlName, ext, htmlTitle, htmlHeader, imgBorder);
        t.setProgressMonitor(pm);
        t.start();

        //} catch ( Exception x ) {
        //throw new RuntimeException( x );
        //}
    }
}
