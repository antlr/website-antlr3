using System;

namespace StringTemplateTest {
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1 {
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
			if ( args.Length == 0 ) {
				Console.Error.WriteLine("Please pass in a test to run; must be class with runTests() method");
			}

			String className = args[0];
			TestSuite test = null;

			try {
				try {
					Type c = Type.GetType(className);
					test = (TestSuite)Activator.CreateInstance(c, null);
				}
				catch (Exception e) {
					Console.WriteLine("Cannot load class: " + className);
					Console.WriteLine(e.StackTrace);
					return;
				}

				test.runTests();
			}
			catch (FailedAssertionException fae) {
				Console.WriteLine("FAILED "+test.testName+":");
				Console.WriteLine(fae.StackTrace);
			}
			catch (Exception e) {
				Console.WriteLine("Exception during test "+test.testName);
				Console.WriteLine(e.StackTrace);
			}

			Console.WriteLine("successes: "+test.getSuccesses());
			Console.WriteLine("failures: "+test.getFailures());		
		}
	}
}
