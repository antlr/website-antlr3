package net.mark_malakanov.sdg2;

/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/HTMLandFilesBackGroundSaver.java,v 1.2 2005/01/03 13:16:48 Mark Exp $
 *
 * Modification Log
 * $Log: HTMLandFilesBackGroundSaver.java,v $
 * Revision 1.2  2005/01/03 13:16:48  Mark
 * minor
 *
 * Revision 1.1  2004/12/29 20:38:32  Mark
 * SdgBody separated with GUI. Multifile output command line params added.
 *
 */
import javax.swing.ProgressMonitor;


public class HTMLandFilesBackGroundSaver extends Thread {
    SdgBody sdgBody;
    String dirName;
    String htmlName;
    String ext;
    String htmlTitle;
    String htmlHeader;
    String imgBorder;
    ProgressMonitor prgMon;

    public HTMLandFilesBackGroundSaver(SdgBody sdgBody, String dirName,
        String htmlName, String ext, String htmlTitle, String htmlHeader,
        String imgBorder) {
        super("Save in backgorund:" + htmlTitle);
        this.sdgBody = sdgBody;
        this.dirName = dirName;
        this.htmlName = htmlName;
        this.ext = ext;
        this.htmlTitle = htmlTitle;
        this.htmlHeader = htmlHeader;
        this.imgBorder = imgBorder;
    }

    public void setProgressMonitor(ProgressMonitor pm) {
        prgMon = pm;
    }

    public void run() {
        try {
            sdgBody.saveAsHTMLandFiles(dirName, htmlName, ext, htmlTitle,
                htmlHeader, imgBorder, prgMon);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
