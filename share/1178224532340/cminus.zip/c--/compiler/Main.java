import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import org.antlr.stringtemplate.*;
import org.antlr.stringtemplate.language.*;

import java.util.HashMap;
import java.util.Vector;
import java.util.Map;
import java.io.*;

public class Main {
	
	static public CommonTreeNodeStream nodes;

    static SymbolTable symbols = new SymbolTable();

    static Boolean single_error_fatal=false;
    static Boolean error_occurred=false;
	
	static public void print_err(String s){
        if(nodes!=null){
            s="line "+Integer.toString(((CommonTree)nodes.get(nodes.index())).getLine())+":"+Integer.toString(((CommonTree)nodes.get(nodes.index())).getCharPositionInLine())+" "+s;
        }
		System.err.println("*** "+s);
		//FIXME: Error function returns line and char of next node, not the node that causes the error. ANTLR should add a function soon with correct noded.
        if(single_error_fatal){
            System.exit(-1);
        }else{
            error_occurred=true;
        }
	}

    static public void check_err(){
        if(error_occurred) System.exit(-1);
    }
	
    public static void main(String[] args) throws Exception{

        //Read Input
        File f = new File(args[0]); 
        FileInputStream fis = new FileInputStream(f); 
        ANTLRInputStream input = new ANTLRInputStream(fis);

        //Lexer
        CMinusLexer lexer = new CMinusLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        
        //Parser and AST construction
        CMinusParser parser = new CMinusParser(tokens);
        CMinusParser.program_return result = parser.program();
        CommonTree t = (CommonTree)result.getTree();
        check_err();

        //Function Identification
        nodes=new CommonTreeNodeStream(t);
        FunctionID f_walker = new FunctionID(nodes);
        f_walker.program();
        
        //Error Checking
        nodes=new CommonTreeNodeStream(t);
        Validator v_walker = new Validator(nodes);
        v_walker.program();

        check_err();

        single_error_fatal=true;

        //Compiler
        nodes=new CommonTreeNodeStream(t);
        FileReader template_file = new FileReader("LLVM.stg");
        StringTemplateGroup templates = new StringTemplateGroup(template_file,DefaultTemplateLexer.class);
        template_file.close();
        Compiler c_walker = new Compiler(nodes);
        c_walker.setTemplateLib(templates);
        c_walker.mtemplates=templates;
        Compiler.program_return r = c_walker.program();
        StringTemplate output = (StringTemplate)r.getTemplate();
        System.out.println(output.toString());

    }
}
