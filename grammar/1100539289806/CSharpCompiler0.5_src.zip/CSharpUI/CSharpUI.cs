using System;

using CommonAST				= antlr.CommonAST;
using AST					= antlr.collections.AST;
using DumpASTVisitor		= antlr.DumpASTVisitor;
using CharBuffer			= antlr.CharBuffer;
using RecognitionException	= antlr.RecognitionException;
using TokenStreamException	= antlr.TokenStreamException;
using antlr.debug;

using System.IO;
using System.Text;
using System.CodeDom;
using System.Reflection;
using System.Windows.Forms;

using DDW.CSharp.Parse;
using DDW.CSharp.Dom;
using DDW.CSharp.Walk;
using DDW.CSharp.Gen;

namespace DDW.CSharpUI
{
	class CSharp 
	{
		private static CSharpViewer ctv;
		private static CSharpAST antlrTree = null;
		private static bool console  = false;
		private static bool showtree = false;
		private static bool walktree = false;
		private static bool gencode  = false;

		[STAThread]
		public static void Main(string[] args) 
		{
			if(args.Length == 0)
			{
				showtree = true;
			}
			if(args.Length > 1)
			{
				for(int i = 0; i < args.Length; i++)
				{
					if(args[i]		== "showtree") 
						showtree = true;
					else if(args[i] == "console") 
						console = true;
					else if(args[i] == "walktree")
						walktree = true;
					else if(args[i] == "gencode")
						gencode = true;
				}
			}
//			try 
//			{	
				if(args.Length > 0)
				{
					string filename = args[0];
					IGraph ig = GetGraph(filename);
				
					if(console)
					{
						if(antlrTree != null)
							Console.WriteLine(antlrTree.ToStringTree());
					}
					if(walktree && ig != null)
					{
						PropertyWalkerTest wt = new PropertyWalkerTest();
						PropertyWalker.Walk(ig, wt);
						StreamWriter sr = File.CreateText(@"test\graph.out");
						sr.WriteLine(wt);
						sr.Close();
					}
					if(gencode && ig != null)
					{
						StreamWriter sr = File.CreateText(@"test\gen.out");
						CSharpGen csg = new CSharpGen(sr);
						csg.Parse(ig);
						csg.Close();
						sr.Close();
					}
					if(showtree)
					{
						App.AddGraph(ig, filename);
						if(!App.IsHandleCreated)
							Application.Run(App);
					}
				}
				else
				{
					Application.Run(App);
				}
//			}
//			catch(Exception e) 
//			{
//				Console.WriteLine("exception: "+e);
//			}
		}
		private static CSharpAST GetAST(string filename)
		{
			CSharpParser parser = null;
			if (File.Exists(filename)) 
			{
				Console.WriteLine("Parsing " + filename);
				FileStream s = new FileStream(filename, FileMode.Open, FileAccess.Read);
				CSharpLexer lexer = new CSharpLexer(s);
				lexer.setFilename(filename);
				parser = new CSharpParser(lexer);
				parser.setFilename(filename);
				//parser.setASTFactory(new LineNumberFactory() );

				// Parse the input expression
				DateTime tStart = DateTime.Now;
				parser.compilation_unit();
				TimeSpan compTime = DateTime.Now - tStart;
				Console.WriteLine(compTime.ToString());
				App.StatsText = "Time to parse (lex, parse & attrib): " + compTime.ToString();
				s.Close();
			}
			if(parser != null)
			{
				antlrTree = (CSharpAST)(parser.getAST());
				antlrTree.FileName = filename;
			}
			return antlrTree;
		}

		public static IGraph GetGraph(string filename)
		{
			GetAST(filename);
			if(antlrTree!=null)
				return antlrTree.GetGraph();
			else
				return null;
		}
		public static string AntlrText
		{
			get
			{
				return antlrTree.ToStringTree();
			}
		}
  
			public static CSharpViewer App
		{
			get
			{
				if(ctv == null) ctv = new CSharpViewer();
				return ctv;
			}
			set
			{
				ctv = value;
			}
		}
			 
	}
}