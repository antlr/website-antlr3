/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc.swing;

import java.util.ArrayList;
import java.util.logging.Logger;

import javax.swing.JTree;
import javax.swing.text.Document;
import javax.swing.tree.TreePath;

import satc.MultiStateLexer;
import satc.TokenList;
import satc.antlr.DocAST;
import satc.antlr.DocParser;
import antlr.CommonAST;
import antlr.Parser;


/**
 *  This class listens for changes in the document and updates the AST.
 */
public class ParserDocumentListener  {

    /**
     * Enables/disables the listener.
     */
    public void setEnabled( boolean b) {
        isEnabled = b;
    }

    /**
     * Returns true if the listener is enabled.
     */
    public boolean isEnabled() {
        return isEnabled;
    }
    
    /**
     *  Updates the AST.
     */
    public void updateTree( Document doc) { 
		log.finest("-->updateTree(): "); 
   	 
		tokenList = (TokenList) doc.getProperty("tokenList");
		tokenList.reset( doc);                       
		
        parser = (DocParser) doc.getProperty("parser");
		log.fine("parser = " + parser);        
        if( parser == null) return;
        
        try {
            parser.getInputState().reset();
			tokenList.reset(doc); 
			log.fine("parser.start()...");
			((DocParser)parser).errorFound = false;
            parser.getClass().getMethod( "start", null).invoke( parser, null);
			log.fine("parser.errorFound = " + ((DocParser)parser).errorFound);

			if (((DocParser)parser).errorFound) return;

	        astTree = (JTree) doc.getProperty("AST");
	        
	        CommonAST astRoot = (CommonAST) parser.getAST();
	        
			JTreeASTModel treeModel;
   	    	if( astRoot != null) {
/*				if (astTree.getModel() instanceof JTreeASTModel) {
					treeModel = (JTreeASTModel) astTree.getModel();
					treeModel.valueForPathChanged( new TreePath(treeModel.getRoot()), astRoot);
				}
				else {
*/					treeModel = new JTreeASTModel( astRoot); 
					astTree.setModel( treeModel);
//				}
				
				astTree.collapsePath( new TreePath(astTree.getModel().getRoot()));
				ArrayList newNodes = ((DocParser)parser).newNodes;
				if (newNodes != null) {
					log.fine("=== start new nodes ===");
					for (int i = 0; i < newNodes.size(); i++) {
						log.fine("" + newNodes.get(i));
					}					
					log.fine("=== end new nodes ===");
/*					for (int i = 0; i < ((DocParser)parser).newNodes.size(); i++) {
						astTree.expandPath( treeModel.getTreePath((DocAST) newNodes.get(i)));
					}
*/					int row;
					TreePath path;
					if (newNodes.size() > 0) {
						path = treeModel.getTreePath((DocAST) newNodes.get(0));
						astTree.expandPath( path);
						row = astTree.getRowForPath( path);
						for( int i = 0; i < 5; i++) {
							astTree.expandRow( row + i);
						}
						astTree.scrollRowToVisible(row+12);
					}
					if (newNodes.size() > 1) {
						path = treeModel.getTreePath((DocAST) newNodes.get( newNodes.size()-1));
						astTree.expandPath( path);
						row = astTree.getRowForPath( path);
						for( int i = 0; i < 5; i++) {
							astTree.expandRow( row + i);
						}
						astTree.scrollRowToVisible(row+12);
					}
				}
        	}
        	
        	else {
			log.fine("astRoot == null");
			}
        } catch( Exception e) {
			log.fine("--------------");
			log.fine("Parsing error!");
			log.fine("--------------");
//            e.printStackTrace();
        }
        
		log.finest("<--updateTree()");    	 
    }
    


    private MultiStateLexer lexer = null;
	private TokenList tokenList = null;
    private Parser parser = null;    
    private JTree astTree;
    private boolean isEnabled;

	private static Logger log = Logger.getLogger("satc.swing.ParserDocumentListener");

}
