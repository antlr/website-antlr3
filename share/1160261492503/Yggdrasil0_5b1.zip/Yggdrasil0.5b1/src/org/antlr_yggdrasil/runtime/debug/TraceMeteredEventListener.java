package org.antlr_yggdrasil.runtime.debug;

import java.util.Vector;

import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.TreeCodeBlock;

/** Print out (most of) the events... Useful for debugging, testing... */
public class TraceMeteredEventListener extends BlankMeteredEventListener implements TreeInstrumentation {
	public void enterRule(String ruleName) { System.out.println("enterRule "+ruleName); }
	public void exitRule(String ruleName) { System.out.println("exitRule "+ruleName); }
	public void enterSubRule(int decisionNumber) { System.out.println("enterSubRule"); }
	public void exitSubRule(int decisionNumber) { System.out.println("exitSubRule"); }
	public void location(int line, int pos) {System.out.println("location "+line+":"+pos);}
	public void consumeToken(Payload t) { 
		System.out.println("[ " + t.getType() + ", " + t.getText() + " ]");
	}

	// Tree parsing stuff

	public void consumeNode(int ID, String text, int type) {
		System.out.println("consumeNode "+ID+" "+text+" "+type);
	}

	public void LT(int i, int ID, String text, int type) {
		System.out.println("LT "+i+" "+ID+" "+text+" "+type);
	}


	// AST stuff
	protected String decode(int code) {
		boolean isList = (code & TreeCodeBlock.LIST) == TreeCodeBlock.LIST;
		boolean hasCarrier = (code & TreeCodeBlock.NO_CARRIER) == TreeCodeBlock.NO_CARRIER;
		String retval = null;
		
		switch (code) {
		case TreeCodeBlock.RIGHT:
			retval = "RIGHT";
			break;
			
		case TreeCodeBlock.DOWN:
			retval = "DOWN";
			break;
			
		case TreeCodeBlock.ROOT:
			retval = "ROOT";
			break;
			
		case TreeCodeBlock.RIGHTLIST:
			retval = "RIGHTLIST";
			break;
			
		case TreeCodeBlock.UP:
			retval = "UP";
			break;
		}
		
		return retval;
	}
	
	public void addPayload(int code, Payload item) {
		System.out.println("addPayload " + decode(code) + " [" + item.getType() + ", " + item.getText());
	}

	public void addCarrier(int code, Carrier item) {
		System.out.println("addCarrier " + decode(code) + " [" + item.getType() + ", " + item.getText());
	}

	public void add(Vector item) {
		System.out.println("add");
	}

	public void processFromMark() {}

	public void processList(Vector v, int direction) {
		System.out.println("processList " + decode(direction));
	}

	public void setNextDown(boolean nextIsDown) {
		System.out.println("setNextDown " + nextIsDown);
	}
}

