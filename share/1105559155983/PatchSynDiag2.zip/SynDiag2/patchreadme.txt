
This zip file contains a patch for the Syntax Diagram Generator 2 (for ANTLR)

The patch allows the HTML save box to appear without generating exceptions.
(Due to non-standard libraries not being present.)

--------------------------------

Instructions

1) Download and unzip the "ANTLR Syntax Diagram Generator 2" from the
   antlr.org website "Share" section.

2) Unzip this zip file over the top of the SynDiag2 directory.

--------------------------------

Addition feature

I have also added a simplified form for invoking the program:

java GViz [-wrap] [-save image.ext] [-blind] [input.g]

-wrap 		wraps wide rules

-save		saves whole diagram into image file. 
		Format must be supported. PNG and JPG are.

-blind		saves without showing GUI.

input.g		The grammar file. Currently ANTLR only supported.

---------------------------------

See main readme file for more information on the program.

Charles.Crichton@comlab.ox.ac.uk
12 January 2005