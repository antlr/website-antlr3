/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import antlr.*;
import satc.MultiStateLexer;

/**
*  Abstract implementation of the LexerCallback interface.
*/
public abstract class AbstractLexerCallback implements MultiStateLexer.LexerCallback {

    private boolean enabled;

    /**
    *  The action to be performed for each new token.
    */
    public abstract void action( Token tok);

    /**
    *  Returns true if this action is currently enabled.
    */
    public boolean isEnabled() {
        return enabled;
    }

    /**
    *  Enables/disables this action.
    */
    public void setEnabled( boolean en) {
        enabled = en;
    }
}
