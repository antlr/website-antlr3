using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using DDW.CSharp;
using DDW.CSharp.Dom;
using DDW.CSharp.Walk;
using DDW.CSharp.Gen;


namespace DDW.CSharpUI
{
	public class CSharpViewer : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TreeView Tree;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RichTextBox richTextBoxAntlrTree;
		private System.Windows.Forms.TabPage tabPageSource;
		private System.Windows.Forms.TabPage tabPageAntlrTree;
		private System.Windows.Forms.TabPage tabPageCSharpDom;
		private System.Windows.Forms.TabPage tabPageRegen;
		private System.Windows.Forms.RichTextBox richTextBoxSource;
		private System.Windows.Forms.TabControl tabControlCode;
		private System.Windows.Forms.RichTextBox richTextBoxCSharpDom;
		private System.Windows.Forms.RichTextBox richTextBoxRegen;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.TabPage tabStats;
		private System.Windows.Forms.RichTextBox richTextBoxStats;
		private System.ComponentModel.IContainer components;

		public CSharpViewer()
		{
			InitializeComponent();			
			Bitmap iconStrip = new Bitmap(GetType(), "CodeIcons.bmp");
				//Images.GetBitmap("CodeIcons.bmp");
			Tree.ImageList = new ImageList();
			Tree.ImageList.ImageSize = new Size(18, 20);
			Tree.ImageList.Images.AddStrip(iconStrip);
			Tree.ImageIndex = 0;			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		public string SourceText
		{
			get
			{
				return richTextBoxSource.Text;
			}
			set
			{
				richTextBoxSource.Text = value;
			}
		}
		public string AntlrText
		{
			get
			{
				return richTextBoxAntlrTree.Text;
			}
			set
			{
				richTextBoxAntlrTree.Text = value;
			}
		}
		public string CSDomText
		{
			get
			{
				return richTextBoxCSharpDom.Text;
			}
			set
			{
				richTextBoxCSharpDom.Text = value;
			}
		}
		public string RegenText
		{
			get
			{
				return richTextBoxRegen.Text;
			}
			set
			{
				richTextBoxRegen.Text = value;
			}
		}
		public string StatsText
		{
			get
			{
				return richTextBoxStats.Text;
			}
			set
			{
				richTextBoxStats.Text = value;
			}
		}
		public void AddGraph(IGraph ig, string filename)
		{
			this.Tree.Nodes.Clear();
			this.Tree.Nodes.Add(new IGraphNode(ig));

			StringBuilder source = new StringBuilder();
			StreamReader sr = File.OpenText(filename);
			source.Append(sr.ReadToEnd());
			sr.Close();
			this.SourceText = source.ToString();

			this.AntlrText =	CSharp.AntlrText;

			PropertyWalkerTest wt = new PropertyWalkerTest();
			PropertyWalker.Walk(ig, wt);
			this.CSDomText = wt.ToString();

			StringBuilder sb = new StringBuilder();
			StringWriter stw = new StringWriter(sb);
			CSharpGen csg = new CSharpGen(stw);
			csg.Parse(ig);
			this.RegenText = stw.ToString();
			csg.Close();
			stw.Close();
		}
		public void AddFile(string filename)
		{
			IGraph ig = CSharp.GetGraph(filename);
			AddGraph(ig, filename);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CSharpViewer));
			this.Tree = new System.Windows.Forms.TreeView();
			this.richTextBoxAntlrTree = new System.Windows.Forms.RichTextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.tabControlCode = new System.Windows.Forms.TabControl();
			this.tabPageSource = new System.Windows.Forms.TabPage();
			this.richTextBoxSource = new System.Windows.Forms.RichTextBox();
			this.tabPageAntlrTree = new System.Windows.Forms.TabPage();
			this.tabPageCSharpDom = new System.Windows.Forms.TabPage();
			this.richTextBoxCSharpDom = new System.Windows.Forms.RichTextBox();
			this.tabPageRegen = new System.Windows.Forms.TabPage();
			this.richTextBoxRegen = new System.Windows.Forms.RichTextBox();
			this.tabStats = new System.Windows.Forms.TabPage();
			this.richTextBoxStats = new System.Windows.Forms.RichTextBox();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.tabControlCode.SuspendLayout();
			this.tabPageSource.SuspendLayout();
			this.tabPageAntlrTree.SuspendLayout();
			this.tabPageCSharpDom.SuspendLayout();
			this.tabPageRegen.SuspendLayout();
			this.tabStats.SuspendLayout();
			this.SuspendLayout();
			// 
			// Tree
			// 
			this.Tree.Dock = System.Windows.Forms.DockStyle.Left;
			this.Tree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Tree.ImageIndex = -1;
			this.Tree.Indent = 18;
			this.Tree.ItemHeight = 20;
			this.Tree.Name = "Tree";
			this.Tree.SelectedImageIndex = -1;
			this.Tree.Size = new System.Drawing.Size(392, 729);
			this.Tree.TabIndex = 0;
			this.Tree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Tree_AfterSelect);
			// 
			// richTextBoxAntlrTree
			// 
			this.richTextBoxAntlrTree.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxAntlrTree.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBoxAntlrTree.Name = "richTextBoxAntlrTree";
			this.richTextBoxAntlrTree.Size = new System.Drawing.Size(792, 703);
			this.richTextBoxAntlrTree.TabIndex = 2;
			this.richTextBoxAntlrTree.Text = "Antlr Tree";
			this.richTextBoxAntlrTree.WordWrap = false;
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.panel3,
																				 this.splitter1,
																				 this.Tree});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1200, 729);
			this.panel1.TabIndex = 3;
			// 
			// panel3
			// 
			this.panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.tabControlCode});
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(400, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(800, 729);
			this.panel3.TabIndex = 4;
			// 
			// tabControlCode
			// 
			this.tabControlCode.Controls.AddRange(new System.Windows.Forms.Control[] {
																						 this.tabPageSource,
																						 this.tabPageAntlrTree,
																						 this.tabPageCSharpDom,
																						 this.tabPageRegen,
																						 this.tabStats});
			this.tabControlCode.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControlCode.Name = "tabControlCode";
			this.tabControlCode.SelectedIndex = 0;
			this.tabControlCode.Size = new System.Drawing.Size(800, 729);
			this.tabControlCode.TabIndex = 3;
			// 
			// tabPageSource
			// 
			this.tabPageSource.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.richTextBoxSource});
			this.tabPageSource.Location = new System.Drawing.Point(4, 22);
			this.tabPageSource.Name = "tabPageSource";
			this.tabPageSource.Size = new System.Drawing.Size(792, 703);
			this.tabPageSource.TabIndex = 0;
			this.tabPageSource.Text = "Source";
			// 
			// richTextBoxSource
			// 
			this.richTextBoxSource.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxSource.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBoxSource.HideSelection = false;
			this.richTextBoxSource.Name = "richTextBoxSource";
			this.richTextBoxSource.Size = new System.Drawing.Size(792, 703);
			this.richTextBoxSource.TabIndex = 3;
			this.richTextBoxSource.Text = "Source";
			this.richTextBoxSource.WordWrap = false;
			this.richTextBoxSource.TextChanged += new System.EventHandler(this.richTextBoxSource_TextChanged);
			// 
			// tabPageAntlrTree
			// 
			this.tabPageAntlrTree.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.richTextBoxAntlrTree});
			this.tabPageAntlrTree.Location = new System.Drawing.Point(4, 22);
			this.tabPageAntlrTree.Name = "tabPageAntlrTree";
			this.tabPageAntlrTree.Size = new System.Drawing.Size(792, 703);
			this.tabPageAntlrTree.TabIndex = 1;
			this.tabPageAntlrTree.Text = "Antlr Tree";
			// 
			// tabPageCSharpDom
			// 
			this.tabPageCSharpDom.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.richTextBoxCSharpDom});
			this.tabPageCSharpDom.Location = new System.Drawing.Point(4, 22);
			this.tabPageCSharpDom.Name = "tabPageCSharpDom";
			this.tabPageCSharpDom.Size = new System.Drawing.Size(792, 703);
			this.tabPageCSharpDom.TabIndex = 2;
			this.tabPageCSharpDom.Text = "CSharp Dom";
			// 
			// richTextBoxCSharpDom
			// 
			this.richTextBoxCSharpDom.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxCSharpDom.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBoxCSharpDom.Name = "richTextBoxCSharpDom";
			this.richTextBoxCSharpDom.Size = new System.Drawing.Size(792, 703);
			this.richTextBoxCSharpDom.TabIndex = 4;
			this.richTextBoxCSharpDom.Text = "CSharp Dom";
			this.richTextBoxCSharpDom.WordWrap = false;
			// 
			// tabPageRegen
			// 
			this.tabPageRegen.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.richTextBoxRegen});
			this.tabPageRegen.Location = new System.Drawing.Point(4, 22);
			this.tabPageRegen.Name = "tabPageRegen";
			this.tabPageRegen.Size = new System.Drawing.Size(792, 703);
			this.tabPageRegen.TabIndex = 3;
			this.tabPageRegen.Text = "Regenerated Code";
			// 
			// richTextBoxRegen
			// 
			this.richTextBoxRegen.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxRegen.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBoxRegen.HideSelection = false;
			this.richTextBoxRegen.Name = "richTextBoxRegen";
			this.richTextBoxRegen.Size = new System.Drawing.Size(792, 703);
			this.richTextBoxRegen.TabIndex = 5;
			this.richTextBoxRegen.Text = "Regenerated Code";
			this.richTextBoxRegen.WordWrap = false;
			// 
			// tabStats
			// 
			this.tabStats.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.richTextBoxStats});
			this.tabStats.Location = new System.Drawing.Point(4, 22);
			this.tabStats.Name = "tabStats";
			this.tabStats.Size = new System.Drawing.Size(792, 703);
			this.tabStats.TabIndex = 4;
			this.tabStats.Text = "Stats";
			// 
			// richTextBoxStats
			// 
			this.richTextBoxStats.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxStats.Name = "richTextBoxStats";
			this.richTextBoxStats.Size = new System.Drawing.Size(792, 703);
			this.richTextBoxStats.TabIndex = 0;
			this.richTextBoxStats.Text = "Stats";
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(392, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(8, 729);
			this.splitter1.TabIndex = 3;
			this.splitter1.TabStop = false;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem4});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem5});
			this.menuItem1.Text = "&File";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "&Open";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "&Edit";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem6,
																					  this.menuItem7});
			this.menuItem3.Text = "&View";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "Expand All";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.Text = "Collapse All";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem8});
			this.menuItem4.Text = "&Help";
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 0;
			this.menuItem8.Shortcut = System.Windows.Forms.Shortcut.F1;
			this.menuItem8.Text = "C# Dom";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// CSharpViewer
			// 
			this.AllowDrop = true;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1200, 729);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel1});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "CSharpViewer";
			this.Text = "CSharpViewer";
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.tabControlCode.ResumeLayout(false);
			this.tabPageSource.ResumeLayout(false);
			this.tabPageAntlrTree.ResumeLayout(false);
			this.tabPageCSharpDom.ResumeLayout(false);
			this.tabPageRegen.ResumeLayout(false);
			this.tabStats.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			// File Open		
			OpenFileDialog openFileDialog1 = new OpenFileDialog();

			openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
			openFileDialog1.Filter = "C# files (*.cs;*.in)|*.cs;*.in|All files (*.*)|*.*" ;
			openFileDialog1.FilterIndex = 1;
			openFileDialog1.RestoreDirectory = false;
			openFileDialog1.Multiselect = false;

			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				string file = openFileDialog1.FileName;
				AddFile(file);
			}
		}
		protected override void OnDragEnter(DragEventArgs e)					
		{
			base.OnDragEnter(e);
			if (e.Data.GetDataPresent(DataFormats.FileDrop) ) 
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}
		protected override void OnDragDrop(DragEventArgs e)						
		{
			base.OnDragDrop(e);
			// Handle FileDrop data.
			if(e.Data.GetDataPresent(DataFormats.FileDrop) )
			{
				string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
				// only open first file for now...
				if(files.Length > 0 && files[0] != "")
					AddFile(files[0]);
			}

		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			Tree.ExpandAll();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			Tree.CollapseAll();
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			if(File.Exists(@"CSharpDom.chm"))
				Help.ShowHelp(this, "CSharpDom.chm", null);
			else
				Console.WriteLine("file doesn't exist");
		}

		private void richTextBoxSource_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void Tree_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if(!(e.Node is IGraphNode)) return;
			LinePragma lp = ((IGraphNode)e.Node).Graph.LinePragma;
			if(lp == null) return;
			int col = lp.Column;
			int line = lp.Line;
			
			if(line == 0) return;
			string src = richTextBoxRegen.Text;
			int endIndex = 0;
			int startIndex = 0;
			int nextStartChar = 0;
			for(int i = 1; i <= lp.EndLine; i++)
			{
				if(line == i) 
					startIndex = nextStartChar;
				if(nextStartChar > 0) 
					endIndex = nextStartChar;
				nextStartChar = src.IndexOf("\n", endIndex + 1);
			}
			startIndex += lp.Column;
			endIndex += lp.EndColumn;
			int len = endIndex - startIndex;;
			if(len < 1) len = 1;
			richTextBoxRegen.Select(startIndex, len);
			richTextBoxRegen.ScrollToCaret();
		}
	}
}
