package org.antlr.java.crossref;
 

import java.io.IOException;

/** Represents the definition of a method within the
 *  package/class hierarchy.  
 */
public class MethodScope extends Scope {
	/**
	 * Field JUSTNAME
	 */
	public final static int JUSTNAME = 1;
	/**
	 * Field MUSTMATCHALL
	 */
	public final static int MUSTMATCHALL = 2;
	/**
	 * Field AMBIGUOUSOK
	 */
	public final static int AMBIGUOUSOK = 3;
	
	/**
	 * How should a method be matched? 
     * JUSTNAME - by name
     * MUSTMATCHALL - name and parameters must exactly match
     * AMBIGUOUSOK - If a parameter is unknown, then match will succeed
	 */
	public static final int methodMatch = AMBIGUOUSOK;
	
    /**
     * Field parameterScope
     */
    protected ParameterScope parameterScope = null;

    /**
     * Field returnType
     */
    protected ClassScope returnType = null;
    
    /**
     * JNI string represting returnType and parameters
     * @see Signature
     */
    protected String signature;

    /**
     * Constructor for MethodScope
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public MethodScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /**
     * Method setParameterScope
     * @param s ParameterScope
     */
    public void setParameterScope(ParameterScope s) {
        parameterScope = s;
    }
	/**
	 * @return ParameterScope
	 */
	public ParameterScope getParameterScope() {
		return parameterScope;
	}

    /**
     * Method setReturnType
     * @param t ClassScope
     */
    public void setReturnType(ClassScope t) {
        returnType = t;
    }

    /**
     * Method getReturnType
     * @return ClassScope
     */
    public ClassScope getReturnType() {
        return returnType;
    }
	/**
	 * return this, I am a Method!
	 * @return Scope
	 */
	public Scope getNearestClassOrMethodScope(){
		return this;
	}

    /**
     * Method dump
     */
    public void dump() {
        tab();
        if ( returnType!=null ) {
            System.out.print("MethodScope:dump " + returnType.getFullyQualifiedName()+" ");
        }
        else {
            System.out.print("MethodScope:dump " + "void ");
        }
        System.out.print(getName()+"(");
        if ( parameterScope!=null ) {
            parameterScope.dump();
        }
        System.out.println(")");
    }

	/** XML dump()
	 * 
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException 
	{
		StringBuffer string = new StringBuffer();
		string.append("Method name=\"" + getName() + "\"");
		if(returnType != null)
			string.append(" returnType=\"" + returnType.getFullyQualifiedName() +"\"");
		if(signature != null)
			string.append(" signature=\"" + signature +"\"");
		

		xmlWriter.xmlOpen(string.toString());			
		if(loc != null)
			loc.xmlSerialize(xmlWriter); 
			
		if ( parameterScope!=null ) 
			parameterScope.xmlSerialize(xmlWriter);

		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
		if(codeBlocks != null)
			xmlSerializeCodeBlocks(xmlWriter);

		  				
		xmlWriter.xmlClose("Method");
			
	}

	/**
	 * @return String
	 */
	public String getSignature() {
		return signature;
	}

	/**
	 * @param signature
	 */
	public void setSignature(String signature) {
		this.signature = signature;
	}
	/**
	 * @param signature
	 * @return boolean
	 */
	public boolean matchSignature(String signature) {
		boolean result = false;
		if(methodMatch == JUSTNAME)
			result = true;
		else if (this.signature.equals(signature))
			result = true;
		else if(methodMatch == AMBIGUOUSOK)
			result = matchParams(signature, false);
		else if(methodMatch == MUSTMATCHALL)
			result = matchParams(signature, true);
			

		return result;
	}

	/** Textually, validate parameters.
	 *  Bug: need to consider superClasses.
	 * 
	 * @param signature2
	 * @param strict
	 * @return boolean
	 */
	private boolean matchParams(String signature2, boolean strict) {
		String params1 = this.signature;
		String params2 = signature2;
		boolean ret = true;
		char char1 = params1.charAt(0);
		char char2 = params2.charAt(0);
		while(char1 != ')' && char2 != ')')
		{
			if(!matchchar(char1, char2, strict))
				return false;
			if(char1 == 'L')
				params1 = params1.substring(params1.indexOf(';')+ 1);
			else
				params1 = params1.substring(1);
			if(char2 == 'L')
				params2 = params2.substring(params2.indexOf(';')+1);
			else
				params2 = params2.substring(1);
			char1 = params1.charAt(0);
			char2 = params2.charAt(0);
		}	
		if(char1 != ')' || char2 != ')')
			ret = false;
		return ret;
	}

	/** 
	 * @param char1
	 * @param char2
	 * @param strict
	 * @return boolean
	 */
	private boolean matchchar(char char1, char char2, boolean strict) {
		boolean ret = false;
		
		if(char1 == char2)
			ret = true;
		else if(!strict)
		{
			if(char1 == Signature.UNKNOWN || char2 == Signature.UNKNOWN)
				ret = true;
		}
			
		return ret;
	}

	/**
	 * Method addScope
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScope(org.antlr.java.crossref.Scope)
	 */
	public void addScope(Scope s) {
		return;		
	}

	/**
	 * Method addScopeMember
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScopeMember(org.antlr.java.crossref.Scope)
	 */
	public void addScopeMember(Scope s) {
		return;		
	}
	

}
