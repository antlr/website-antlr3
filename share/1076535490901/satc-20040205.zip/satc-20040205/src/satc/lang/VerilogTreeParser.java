// $ANTLR : "VerilogTreeParser.g" -> "VerilogTreeParser.java"$

package satc.lang; 

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;


public class VerilogTreeParser extends antlr.TreeParser       implements VerilogTreeParserTokenTypes
 {
public VerilogTreeParser() {
	tokenNames = _tokenNames;
}

	public final void start(AST _t) throws RecognitionException {
		
		AST start_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST start_AST = null;
		
		try {      // for error handling
			AST __t351 = _t;
			AST tmp1_AST = null;
			AST tmp1_AST_in = null;
			tmp1_AST = astFactory.create((AST)_t);
			tmp1_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp1_AST);
			ASTPair __currentAST351 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,START);
			_t = _t.getFirstChild();
			{
			_loop353:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_module:
				case NIL:
				case NIL2:
				{
					unit(_t);
					_t = _retTree;
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case NIL3:
				{
					directive(_t);
					_t = _retTree;
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
				{
					break _loop353;
				}
				}
			} while (true);
			}
			currentAST = __currentAST351;
			_t = __t351;
			_t = _t.getNextSibling();
			start_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = start_AST;
		_retTree = _t;
	}
	
	public final void unit(AST _t) throws RecognitionException {
		
		AST unit_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST unit_AST = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_module:
			{
				module(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			case NIL:
			{
				macromodule(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			case NIL2:
			{
				udp(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = unit_AST;
		_retTree = _t;
	}
	
	public final void directive(AST _t) throws RecognitionException {
		
		AST directive_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST directive_AST = null;
		
		try {      // for error handling
			AST tmp2_AST = null;
			AST tmp2_AST_in = null;
			tmp2_AST = astFactory.create((AST)_t);
			tmp2_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp2_AST);
			match(_t,NIL3);
			_t = _t.getNextSibling();
			directive_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = directive_AST;
		_retTree = _t;
	}
	
	public final void module(AST _t) throws RecognitionException {
		
		AST module_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST module_AST = null;
		
		try {      // for error handling
			AST __t356 = _t;
			AST tmp3_AST = null;
			AST tmp3_AST_in = null;
			tmp3_AST = astFactory.create((AST)_t);
			tmp3_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp3_AST);
			ASTPair __currentAST356 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,LITERAL_module);
			_t = _t.getFirstChild();
			AST tmp4_AST = null;
			AST tmp4_AST_in = null;
			tmp4_AST = astFactory.create((AST)_t);
			tmp4_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp4_AST);
			match(_t,ID);
			_t = _t.getNextSibling();
			portList(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop358:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_tokenSet_0.member(_t.getType()))) {
					element(_t);
					_t = _retTree;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop358;
				}
				
			} while (true);
			}
			currentAST = __currentAST356;
			_t = __t356;
			_t = _t.getNextSibling();
			module_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = module_AST;
		_retTree = _t;
	}
	
	public final void macromodule(AST _t) throws RecognitionException {
		
		AST macromodule_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST macromodule_AST = null;
		
		try {      // for error handling
			AST tmp5_AST = null;
			AST tmp5_AST_in = null;
			tmp5_AST = astFactory.create((AST)_t);
			tmp5_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp5_AST);
			match(_t,NIL);
			_t = _t.getNextSibling();
			macromodule_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = macromodule_AST;
		_retTree = _t;
	}
	
	public final void udp(AST _t) throws RecognitionException {
		
		AST udp_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST udp_AST = null;
		
		try {      // for error handling
			AST tmp6_AST = null;
			AST tmp6_AST_in = null;
			tmp6_AST = astFactory.create((AST)_t);
			tmp6_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp6_AST);
			match(_t,NIL2);
			_t = _t.getNextSibling();
			udp_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = udp_AST;
		_retTree = _t;
	}
	
	public final void portList(AST _t) throws RecognitionException {
		
		AST portList_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST portList_AST = null;
		
		try {      // for error handling
			AST __t360 = _t;
			AST tmp7_AST = null;
			AST tmp7_AST_in = null;
			tmp7_AST = astFactory.create((AST)_t);
			tmp7_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp7_AST);
			ASTPair __currentAST360 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,PORT_LIST);
			_t = _t.getFirstChild();
			{
			_loop362:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==IDENTIFIER||_t.getType()==ESCAPED_IDENTIFIER)) {
					identifier(_t);
					_t = _retTree;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop362;
				}
				
			} while (true);
			}
			currentAST = __currentAST360;
			_t = __t360;
			_t = _t.getNextSibling();
			portList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = portList_AST;
		_retTree = _t;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		AST element_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST element_AST = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_parameter:
			{
				parameterDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_input:
			{
				inputDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_output:
			{
				outputDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_inout:
			{
				inoutDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL6:
			{
				netDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL7:
			{
				regDeclaration(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL4:
			{
				continuousAssign(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL5:
			{
				alwaysStatement(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = element_AST;
		_retTree = _t;
	}
	
	public final void identifier(AST _t) throws RecognitionException {
		
		AST identifier_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST identifier_AST = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case IDENTIFIER:
			{
				AST tmp8_AST = null;
				AST tmp8_AST_in = null;
				tmp8_AST = astFactory.create((AST)_t);
				tmp8_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp8_AST);
				match(_t,IDENTIFIER);
				_t = _t.getNextSibling();
				identifier_AST = (AST)currentAST.root;
				break;
			}
			case ESCAPED_IDENTIFIER:
			{
				AST tmp9_AST = null;
				AST tmp9_AST_in = null;
				tmp9_AST = astFactory.create((AST)_t);
				tmp9_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp9_AST);
				match(_t,ESCAPED_IDENTIFIER);
				_t = _t.getNextSibling();
				identifier_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = identifier_AST;
		_retTree = _t;
	}
	
	public final void parameterDeclaration(AST _t) throws RecognitionException {
		
		AST parameterDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterDeclaration_AST = null;
		
		try {      // for error handling
			AST __t365 = _t;
			AST tmp10_AST = null;
			AST tmp10_AST_in = null;
			tmp10_AST = astFactory.create((AST)_t);
			tmp10_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp10_AST);
			ASTPair __currentAST365 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,LITERAL_parameter);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			{
				range(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case ASSIGN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			parameterAssignmentList(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST365;
			_t = __t365;
			_t = _t.getNextSibling();
			parameterDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = parameterDeclaration_AST;
		_retTree = _t;
	}
	
	public final void inputDeclaration(AST _t) throws RecognitionException {
		
		AST inputDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inputDeclaration_AST = null;
		
		try {      // for error handling
			AST __t373 = _t;
			AST tmp11_AST = null;
			AST tmp11_AST_in = null;
			tmp11_AST = astFactory.create((AST)_t);
			tmp11_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp11_AST);
			ASTPair __currentAST373 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,LITERAL_input);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			{
				range(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			inputList(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST373;
			_t = __t373;
			_t = _t.getNextSibling();
			inputDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = inputDeclaration_AST;
		_retTree = _t;
	}
	
	public final void outputDeclaration(AST _t) throws RecognitionException {
		
		AST outputDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST outputDeclaration_AST = null;
		
		try {      // for error handling
			AST __t376 = _t;
			AST tmp12_AST = null;
			AST tmp12_AST_in = null;
			tmp12_AST = astFactory.create((AST)_t);
			tmp12_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp12_AST);
			ASTPair __currentAST376 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,LITERAL_output);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			{
				range(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			outputList(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST376;
			_t = __t376;
			_t = _t.getNextSibling();
			outputDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = outputDeclaration_AST;
		_retTree = _t;
	}
	
	public final void inoutDeclaration(AST _t) throws RecognitionException {
		
		AST inoutDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inoutDeclaration_AST = null;
		
		try {      // for error handling
			AST __t379 = _t;
			AST tmp13_AST = null;
			AST tmp13_AST_in = null;
			tmp13_AST = astFactory.create((AST)_t);
			tmp13_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp13_AST);
			ASTPair __currentAST379 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,LITERAL_inout);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			{
				range(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			inoutList(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST379;
			_t = __t379;
			_t = _t.getNextSibling();
			inoutDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = inoutDeclaration_AST;
		_retTree = _t;
	}
	
	public final void netDeclaration(AST _t) throws RecognitionException {
		
		AST netDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST netDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp14_AST = null;
			AST tmp14_AST_in = null;
			tmp14_AST = astFactory.create((AST)_t);
			tmp14_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp14_AST);
			match(_t,NIL6);
			_t = _t.getNextSibling();
			netDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = netDeclaration_AST;
		_retTree = _t;
	}
	
	public final void regDeclaration(AST _t) throws RecognitionException {
		
		AST regDeclaration_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST regDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp15_AST = null;
			AST tmp15_AST_in = null;
			tmp15_AST = astFactory.create((AST)_t);
			tmp15_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp15_AST);
			match(_t,NIL7);
			_t = _t.getNextSibling();
			regDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = regDeclaration_AST;
		_retTree = _t;
	}
	
	public final void continuousAssign(AST _t) throws RecognitionException {
		
		AST continuousAssign_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST continuousAssign_AST = null;
		
		try {      // for error handling
			AST tmp16_AST = null;
			AST tmp16_AST_in = null;
			tmp16_AST = astFactory.create((AST)_t);
			tmp16_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp16_AST);
			match(_t,NIL4);
			_t = _t.getNextSibling();
			continuousAssign_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = continuousAssign_AST;
		_retTree = _t;
	}
	
	public final void alwaysStatement(AST _t) throws RecognitionException {
		
		AST alwaysStatement_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alwaysStatement_AST = null;
		
		try {      // for error handling
			AST tmp17_AST = null;
			AST tmp17_AST_in = null;
			tmp17_AST = astFactory.create((AST)_t);
			tmp17_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp17_AST);
			match(_t,NIL5);
			_t = _t.getNextSibling();
			alwaysStatement_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = alwaysStatement_AST;
		_retTree = _t;
	}
	
	public final void range(AST _t) throws RecognitionException {
		
		AST range_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST range_AST = null;
		
		try {      // for error handling
			AST __t392 = _t;
			AST tmp18_AST = null;
			AST tmp18_AST_in = null;
			tmp18_AST = astFactory.create((AST)_t);
			tmp18_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp18_AST);
			ASTPair __currentAST392 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,RANGE);
			_t = _t.getFirstChild();
			simpleExpression(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			simpleExpression(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST392;
			_t = __t392;
			_t = _t.getNextSibling();
			range_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = range_AST;
		_retTree = _t;
	}
	
	public final void parameterAssignmentList(AST _t) throws RecognitionException {
		
		AST parameterAssignmentList_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterAssignmentList_AST = null;
		
		try {      // for error handling
			{
			int _cnt369=0;
			_loop369:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN)) {
					parameterAssignment(_t);
					_t = _retTree;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt369>=1 ) { break _loop369; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt369++;
			} while (true);
			}
			parameterAssignmentList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = parameterAssignmentList_AST;
		_retTree = _t;
	}
	
	public final void parameterAssignment(AST _t) throws RecognitionException {
		
		AST parameterAssignment_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterAssignment_AST = null;
		
		try {      // for error handling
			AST __t371 = _t;
			AST tmp19_AST = null;
			AST tmp19_AST_in = null;
			tmp19_AST = astFactory.create((AST)_t);
			tmp19_AST_in = (AST)_t;
			astFactory.addASTChild(currentAST, tmp19_AST);
			ASTPair __currentAST371 = currentAST.copy();
			currentAST.root = currentAST.child;
			currentAST.child = null;
			match(_t,ASSIGN);
			_t = _t.getFirstChild();
			identifier(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			expression(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			currentAST = __currentAST371;
			_t = __t371;
			_t = _t.getNextSibling();
			parameterAssignment_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = parameterAssignment_AST;
		_retTree = _t;
	}
	
	public final void expression(AST _t) throws RecognitionException {
		
		AST expression_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expression_AST = null;
		
		try {      // for error handling
			identifier(_t);
			_t = _retTree;
			astFactory.addASTChild(currentAST, returnAST);
			expression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = expression_AST;
		_retTree = _t;
	}
	
	public final void inputList(AST _t) throws RecognitionException {
		
		AST inputList_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inputList_AST = null;
		AST id1_AST = null;
		AST id1 = null;
		AST id2_AST = null;
		AST id2 = null;
		
		try {      // for error handling
			id1 = _t==ASTNULL ? null : (AST)_t;
			identifier(_t);
			_t = _retTree;
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop383:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==IDENTIFIER||_t.getType()==ESCAPED_IDENTIFIER)) {
					id2 = _t==ASTNULL ? null : (AST)_t;
					identifier(_t);
					_t = _retTree;
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop383;
				}
				
			} while (true);
			}
			inputList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = inputList_AST;
		_retTree = _t;
	}
	
	public final void outputList(AST _t) throws RecognitionException {
		
		AST outputList_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST outputList_AST = null;
		AST id1_AST = null;
		AST id1 = null;
		AST id2_AST = null;
		AST id2 = null;
		
		try {      // for error handling
			id1 = _t==ASTNULL ? null : (AST)_t;
			identifier(_t);
			_t = _retTree;
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop386:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==IDENTIFIER||_t.getType()==ESCAPED_IDENTIFIER)) {
					id2 = _t==ASTNULL ? null : (AST)_t;
					identifier(_t);
					_t = _retTree;
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop386;
				}
				
			} while (true);
			}
			outputList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = outputList_AST;
		_retTree = _t;
	}
	
	public final void inoutList(AST _t) throws RecognitionException {
		
		AST inoutList_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inoutList_AST = null;
		AST id1_AST = null;
		AST id1 = null;
		AST id2_AST = null;
		AST id2 = null;
		
		try {      // for error handling
			id1 = _t==ASTNULL ? null : (AST)_t;
			identifier(_t);
			_t = _retTree;
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop389:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==IDENTIFIER||_t.getType()==ESCAPED_IDENTIFIER)) {
					id2 = _t==ASTNULL ? null : (AST)_t;
					identifier(_t);
					_t = _retTree;
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop389;
				}
				
			} while (true);
			}
			inoutList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = inoutList_AST;
		_retTree = _t;
	}
	
	public final void simpleExpression(AST _t) throws RecognitionException {
		
		AST simpleExpression_AST_in = (AST)_t;
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simpleExpression_AST = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SL:
			{
				AST __t394 = _t;
				AST tmp20_AST = null;
				AST tmp20_AST_in = null;
				tmp20_AST = astFactory.create((AST)_t);
				tmp20_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp20_AST);
				ASTPair __currentAST394 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,SL);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST394;
				_t = __t394;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case SR:
			{
				AST __t395 = _t;
				AST tmp21_AST = null;
				AST tmp21_AST_in = null;
				tmp21_AST = astFactory.create((AST)_t);
				tmp21_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp21_AST);
				ASTPair __currentAST395 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,SR);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST395;
				_t = __t395;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case PLUS:
			{
				AST __t396 = _t;
				AST tmp22_AST = null;
				AST tmp22_AST_in = null;
				tmp22_AST = astFactory.create((AST)_t);
				tmp22_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp22_AST);
				ASTPair __currentAST396 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,PLUS);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST396;
				_t = __t396;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case MINUS:
			{
				AST __t397 = _t;
				AST tmp23_AST = null;
				AST tmp23_AST_in = null;
				tmp23_AST = astFactory.create((AST)_t);
				tmp23_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp23_AST);
				ASTPair __currentAST397 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,MINUS);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST397;
				_t = __t397;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case STAR:
			{
				AST __t398 = _t;
				AST tmp24_AST = null;
				AST tmp24_AST_in = null;
				tmp24_AST = astFactory.create((AST)_t);
				tmp24_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp24_AST);
				ASTPair __currentAST398 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,STAR);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST398;
				_t = __t398;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case DIV:
			{
				AST __t399 = _t;
				AST tmp25_AST = null;
				AST tmp25_AST_in = null;
				tmp25_AST = astFactory.create((AST)_t);
				tmp25_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp25_AST);
				ASTPair __currentAST399 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,DIV);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST399;
				_t = __t399;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case MOD:
			{
				AST __t400 = _t;
				AST tmp26_AST = null;
				AST tmp26_AST_in = null;
				tmp26_AST = astFactory.create((AST)_t);
				tmp26_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp26_AST);
				ASTPair __currentAST400 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,MOD);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST400;
				_t = __t400;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case UNARY_PLUS:
			{
				AST __t401 = _t;
				AST tmp27_AST = null;
				AST tmp27_AST_in = null;
				tmp27_AST = astFactory.create((AST)_t);
				tmp27_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp27_AST);
				ASTPair __currentAST401 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,UNARY_PLUS);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST401;
				_t = __t401;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case UNARY_MINUS:
			{
				AST __t402 = _t;
				AST tmp28_AST = null;
				AST tmp28_AST_in = null;
				tmp28_AST = astFactory.create((AST)_t);
				tmp28_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp28_AST);
				ASTPair __currentAST402 = currentAST.copy();
				currentAST.root = currentAST.child;
				currentAST.child = null;
				match(_t,UNARY_MINUS);
				_t = _t.getFirstChild();
				simpleExpression(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				currentAST = __currentAST402;
				_t = __t402;
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				identifier(_t);
				_t = _retTree;
				astFactory.addASTChild(currentAST, returnAST);
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			case NUMBER:
			{
				AST tmp29_AST = null;
				AST tmp29_AST_in = null;
				tmp29_AST = astFactory.create((AST)_t);
				tmp29_AST_in = (AST)_t;
				astFactory.addASTChild(currentAST, tmp29_AST);
				match(_t,NUMBER);
				_t = _t.getNextSibling();
				simpleExpression_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		returnAST = simpleExpression_AST;
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"START",
		"\"module\"",
		"ID",
		"PORT_LIST",
		"\"parameter\"",
		"ASSIGN",
		"\"input\"",
		"\"output\"",
		"\"inout\"",
		"RANGE",
		"SL",
		"SR",
		"PLUS",
		"MINUS",
		"STAR",
		"DIV",
		"MOD",
		"UNARY_PLUS",
		"UNARY_MINUS",
		"NUMBER",
		"IDENTIFIER",
		"ESCAPED_IDENTIFIER",
		"NIL6",
		"NIL7",
		"NIL4",
		"NIL5",
		"NIL3",
		"NIL",
		"NIL2"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 1006640384L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	}
	
