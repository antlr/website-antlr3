/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

public class DefaultCarrier extends Carrier {
	Carrier right = null;
	Carrier down = null;
	int type = -1;
	Payload attributes;

	public DefaultCarrier() {		
	}
	
	public DefaultCarrier(Payload pay) {
		attributes = pay;
		type = pay.getType();
	}
	
	/* (non-Javadoc)
	 * @see antlr.Carrier#getAttributes()
	 */
	public Payload getAttributes() {
		return attributes;
	}
	
	public String getText() {
		if (attributes != null) {
			return attributes.getText();
		}
		return null;
	}
	
	public int getType() {
		return type;
	}
	
	public boolean hasSiblings() {
		return right != null;
	}
	
	public boolean hasChildren() {
		return down != null;
	}

	/* (non-Javadoc)
	 * @see antlr.Carrier#setAttributes(antlr.Payload)
	 */
	public void setAttributes(Payload pay) {
		attributes = pay;
		type = pay.getType();
	}
	
	public void setText(String text) {
		if (attributes == null) {
			// TODO:  Throw exception here
		}
		
		attributes.setText(text);
	}

	public void setType(int type_) {
		if (attributes == null) {
			// TODO:  Throw exception here
		}
		
		attributes.setType(type_);
		type = type_;
	}

	public Carrier getFirstChild() {
		return down;
	}
	
	public Carrier getLastSibling() {
		Carrier retval = this;
		Carrier next = retval.getNextSibling();
		while (next != null) {
			retval = next;
			next = retval.getNextSibling();
		}
		
		return retval;
	}
	
	public Carrier getNextSibling() {
		return right;
	}
	
	public void setFirstChild(Carrier c) {
		down = c;
	}
	
	public void setNextSibling(Carrier c) {
		right = c;
	}
	
	public Object clone() {
		Carrier replicant = null;
		if (attributes == null)
			replicant = new DefaultCarrier();
		else
			replicant = attributes.wrap();
		
		return (Object) replicant;
	}
	
	public Carrier copy() {
		Carrier retval = (Carrier) clone();
		if (down != null)
			retval.setFirstChild(down.copy());
		
		if (right != null)
			retval.setNextSibling(right.copy());
		
		return retval;
	}
	
	public boolean equals(Object o) {
		if (o == null)
			return false;
		
		DefaultCarrier d = (DefaultCarrier) o;
		
		if (right == null) {
			if (d.right != null)
				return false;
		}
		else if (!right.equals(d.right))
			return false;
		
		if (down == null) {
			if (d.down != null)
				return false;
		}
		else if (!down.equals(d.down))
			return false;
		
		if (type != d.type)
			return false;
		
		if (attributes == null) {
			if (d.attributes != null)
				return false;
		}
		else if (!attributes.equals(d.attributes))
			return false;
		
		return true;
	}
	
	public Carrier wrap() {
		Carrier retval = null;
		if (attributes != null)
			retval = attributes.wrap();
		else
			retval = new ReferenceCarrier(this);
		
		return retval;
	}
	
	public String toString() {
		return toString(0);
	}
	
	protected String tabs(int offset) {
		String ret = "";
		
		for (int i=0; i<offset; i++)
			ret += "\t";
		
		return ret;
	}
	
	protected String toString(int indent) {
		String retval = "";
		Carrier child = getFirstChild();
		if (child == null) {
			retval = tabs(indent);
			retval += getText() + "\n";
			return retval;
		}
		
		retval = tabs(indent) + "(\t" + getText() + "\n";
		while (child != null) {
			retval += child.toString(indent+1);
			child = child.getNextSibling();
		}
		retval += tabs(indent) + ")\n";
		
		return retval;
	}
}