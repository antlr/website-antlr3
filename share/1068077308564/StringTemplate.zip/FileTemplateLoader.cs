using System;
using System.IO;

namespace Antlr.StringTemplate {
	/// <summary>
	/// Summary description for FileTemplateLoader.
	/// </summary>
	public class FileTemplateLoader : IStringTemplateLoader {
		private String rootDir;

		public FileTemplateLoader() : this(null) {
		}

		public FileTemplateLoader(String rootDir) {
			if (rootDir == null) {
				this.rootDir = AppDomain.CurrentDomain.BaseDirectory;
			}
			else {
				this.rootDir = rootDir;
			}
		}

		/// <summary>
		/// Convert a filename relativePath/name.st to relativePath/name.
		/// </summary>
		/// <param name="relativePath">Relative template path.</param>
		/// <returns>The template name.</returns>
		public String DeriveTemplateNameFromLocation(String location) {
			return Path.ChangeExtension(location, null);
		}

		/// <summary>
		/// Derive a template path from a name.
		/// </summary>
		/// <param name="templateName">Template name.</param>
		/// <returns>The template path.</returns>
		public String DeriveLocationFromTemplateName(String templateName) {
			return templateName + ".st";
		}

		public String LoadTemplate(String name, String location) {
			TextReader br = null;
			String templateSource = null;
			String templatePath = Path.Combine(this.rootDir, location);

			try {
				br = File.OpenText(templatePath);
				templateSource = br.ReadToEnd();

				if ( templateSource == null || templateSource.Length == 0 ) {
					throw new Exception("No text in template '" + name + "'");
				}

				// strip newlines etc.. from front/back since filesystem
				// may add newlines etc...
				templateSource = templateSource.Trim();
				br.Close();
				br = null;
			}
			catch (IOException) {
				if ( br != null ) {
					try {
						br.Close();
					}
					catch (IOException e) {
						throw new Exception("Cannot close template file: " + location, e);
					}
				}
			}

			return templateSource;
		}

		public String Base { 
			get {
				return this.rootDir;
			}
			set {
				DirectoryInfo di = new DirectoryInfo(value);
				this.rootDir = di.FullName;
			}
		}
	}
}
