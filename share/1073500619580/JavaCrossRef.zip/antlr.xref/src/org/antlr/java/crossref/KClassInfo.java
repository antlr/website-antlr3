package org.antlr.java.crossref;

import java.util.Vector;

/**
* A class for storing information about a class.  
* This information can be read in by a KClassFileReader, or written out by
* a KClassFileWriter.
*
* @see KFieldInfo
* @see KMethodInfo
* @see KAttributeInfo
* @see KClassFileReader
* @see KClassFileWriter
*/
public class KClassInfo extends KCommonInfo {
	private String superName = "java.lang.Object", sourceFile;
	private KConstPool cp;
	// Vector of Strings
	private Vector interfaces = new Vector();
	// Vector of FieldInfo
	private Vector fields = new Vector();
	// Vector of MethodInfo
	private Vector methods = new Vector();
	private KInnerClassInfo[] innerClasses;

	/**
	* Set the constant pool.  The ClassInfo class itself does not actually use 
	* the ConstPool for anything. This method is useful if the ClassInfo is 
	* being read in by a ClassFileReader and there are attributes that the 
	* Reader does not understand, which reference entries in the constant 
	* pool.  The best example of such an attribute is method bytecodes.
	* In a future release, ClassFileReaders will understand bytecodes, 
	* and so this method will become less important.  
	*
	* <p>The new ConstPool is not immutable.  It may be passed to a 
	* ClassFileWriter, which will add entries as needed.
	*
	* @see KConstPool
	*/
	public void setConstPool(KConstPool cp) {
		this.cp = cp;
	}

	/**
	* Get the constant pool.  The ClassInfo class itself does not use the
	* constant pool for anthing. The constant pool is useful if the ClassInfo is 
	* being written out by a ClassFileWriter and there are attributes that the 
	* Writer does not understand, which reference entries in the constant 
	* pool.  The best example of such an attribute is method bytecodes.
	* The Writer will use the ConstPool returned by this method in preference
	* to creating its own ConstPool.  Letting the Writer create its own 
	* ConstPool is probably not a good idea, for the reasons describe above.
	* In a future release, ClassFileWriters will understand bytecodes, and so
	* this method will become less important.
	*
	* @see KConstPool
	*/
	public KConstPool getConstPool() {
		return cp;
	}

	/**
	* Set the name of the super class.  The name should be of the form "java.lang.String".
	*/
	public void setSuperClassName(String name) {
		superName = name;
	}

	/**
	* Get the name of the super class.  The name is of the form "java.lang.String".
	*/
	public String getSuperClassName() {
		return superName;
	}

	/**
	* Add an interface that the class implements.
	*/
	public void addInterface(String interfaceName) {
		interfaces.addElement(interfaceName);
	}

	/**
	* Get the interfaces that this class implements.
	*/
	public String[] getInterfaces() {
		String[] list = new String[interfaces.size()];
		interfaces.copyInto(list);
		return list;
	}

	/**
	* Add a field to this class.  The FieldInfo should be need not be
	* entirely filled out before being added.
	* 
	* @see KFieldInfo
	*/
	public void addField(KFieldInfo fieldInfo) {
		fields.addElement(fieldInfo);
	}

	/**
	* Get the fields of this class.
	*
	* @see KFieldInfo
	*/
	public KFieldInfo[] getFields() {
		KFieldInfo[] list = new KFieldInfo[fields.size()];
		fields.copyInto(list);
		return list;
	}

	/**
	* Add a method to this class.  The KMethodInfo should be need not be
	* entirely filled out before being added.
	* 
	* @see KMethodInfo
	*/
	public void addMethod(KMethodInfo methodInfo) {
		methods.addElement(methodInfo);
	}

	/**
	* Get the methods of this class.
	*
	* @see KMethodInfo
	*/
	public KMethodInfo[] getMethods() {
		KMethodInfo[] list = new KMethodInfo[methods.size()];
		methods.copyInto(list);
		return list;
	}
	
	/**
	* Specify the source file for this class, if it is known.
	*/
	public void setSourceFile(String sourceFile) {
		this.sourceFile = sourceFile;
	}

	/**
	* Get the source file for this class.  If the file is not known, this
	* may return null.
	*/
	public String getSourceFile() {
		return sourceFile;
	}

	/**
	* Set the inner class information of this class.  Using inner classes is 
	* a bit tricky. The array should include elements for every inner class 
	* of this class, and every class that contains this class. For example:
	*
	*<pre>class Foo {
	*    class Bar {
	*        class Quux {
	*            class Squish {
	*            }
	*        }
	*    }
	*    class Baz {
	*    }
	*}</pre>
	*
	* If this ClassInfo is for Foo.Bar, then the inner classes array should be 
	* {FooInfo, BarInfo, QuuxInfo}. The order is important: outer classes 
	* <strong>must</strong> come before their inner classes. Note that the 
	* current class must have an entry in the array. Squish and Baz may be
	* included in the array, but they're not necessary.
	*
	* @see KInnerClassInfo
	*/
	public void setInnerClasses(KInnerClassInfo[] innerClasses) {
		this.innerClasses = innerClasses;
	}

	/**
	* Get the inner class information of this class.
	*
	* @see #setInnerClasses(KInnerClassInfo[])
	*/
	public KInnerClassInfo[] getInnerClasses() {
		return innerClasses;
	}
}
