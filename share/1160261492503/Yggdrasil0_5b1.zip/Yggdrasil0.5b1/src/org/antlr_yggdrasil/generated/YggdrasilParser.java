// $ANTLR 2.7.6 (2005-12-22): "Yggdrasil.g" -> "YggdrasilParser.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.generated;
import org.antlr_yggdrasil.tool.*;
import org.antlr_yggdrasil.tool.Grammar;
import java.util.*;
import java.io.*;
import org.antlr_yggdrasil.analysis.*;
import org.antlr_yggdrasil.misc.*;
import antlr.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

/** Read in an ANTLR grammar and build an AST.  Try not to do
 *  any actions, just build the tree.
 *
 *  The phases are:
 *
 *		antlr.g (this file)
 *		assign.types.g
 *		define.g
 *		buildnfa.g
 *		antlr.print.g (optional)
 *		codegen.g
 *
 *  Terence Parr
 *  University of San Francisco
 *  2005
 */
public class YggdrasilParser extends antlr.LLkParser       implements YggdrasilTokenTypes
 {

	org.antlr_yggdrasil.tool.Grammar grammar = null;
	protected int gtype = 0;
	protected String currentRuleName = null;
	protected GrammarAST currentBlockAST = null;

	/* this next stuff supports construction of the Tokens artificial rule.
	   I hate having some partial functionality here, I like doing everything
	   in future tree passes, but the Tokens rule is sensitive to filter mode.
	   And if it adds syn preds, future tree passes will need to process the
	   fragments defined in Tokens; a cyclic dependency.
	   As of 1-17-06 then, Tokens is created for lexer grammars in the
	   antlr grammar parser itself.

	   This grammar is also sensitive to the backtrack grammar option that
	   tells ANTLR to automatically backtrack when it can't compute a DFA.

	   7-2-06 I moved all option processing to antlr.g from define.g as I
	   need backtrack option etc... for blocks.  Got messy.
	*/
	protected List lexerRuleNames = new ArrayList();
	public List getLexerRuleNames() { return lexerRuleNames; }

	public void setGrammar(org.antlr_yggdrasil.tool.Grammar g, int type) {
		grammar = g;
		gtype = type;
	}

	protected GrammarAST setToBlockWithSet(GrammarAST b) {
		GrammarAST alt = (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(ALT,"ALT")).add(b).add((GrammarAST)astFactory.create(EOA,"<end-of-alt>")));
		prefixWithSynPred(alt);
		return (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(BLOCK,"BLOCK")).add(alt).add((GrammarAST)astFactory.create(EOB,"<end-of-block>")));
	}

	protected GrammarAST createBlockFromDupAlt(GrammarAST alt) {
		GrammarAST nalt = (GrammarAST)astFactory.dupTree(alt);
		GrammarAST blk = (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(BLOCK,"BLOCK")).add(nalt).add((GrammarAST)astFactory.create(EOB,"<end-of-block>")));
		return blk;
	}

	/** Rewrite alt to have a synpred as first element;
	 *  (xxx)=>xxx
	 *  but only if they didn't specify one manually.
	 */
	protected void prefixWithSynPred(GrammarAST alt) {
		// if they want backtracking and it's not a lexer rule in combined grammar
		String autoBacktrack = (String)currentBlockAST.getOption("backtrack");
		if ( autoBacktrack==null ) {
			autoBacktrack = (String)grammar.getOption("backtrack");
		}
		if ( autoBacktrack!=null&&autoBacktrack.equals("true") &&
			 !(gtype==COMBINED_GRAMMAR &&
			 Character.isUpperCase(currentRuleName.charAt(0))) &&
			 alt.getFirstChild().getType()!=SYN_SEMPRED )
		{
			// duplicate alt and make a synpred block around that dup'd alt
			GrammarAST synpredBlockAST = createBlockFromDupAlt(alt);

			// Create a SYN_SEMPRED node as if user had typed this in
			// Effectively we replace (xxx)=>xxx with {synpredxxx}? xxx
			GrammarAST synpredAST = createSynSemPredFromBlock(synpredBlockAST);

			// insert SYN_SEMPRED as first element of alt
			synpredAST.getLastSibling().setNextSibling(alt.getFirstChild());
			alt.setFirstChild(synpredAST);
		}
	}

	protected GrammarAST createSynSemPredFromBlock(GrammarAST synpredBlockAST) {
		// add grammar fragment to a list so we can make fake rules for them
		// later.
		String predName = grammar.defineSyntacticPredicate(synpredBlockAST,currentRuleName);
		// convert (alpha)=> into {synpredN}? where N is some pred count
		// during code gen we convert to function call with templates
		String synpredinvoke = predName;
		GrammarAST p = (GrammarAST)astFactory.create(SYN_SEMPRED,synpredinvoke);
		p.setEnclosingRule(currentRuleName);
		// track how many decisions have synpreds
		grammar.blocksWithSynPreds.add(currentBlockAST);
		return p;
	}

	public GrammarAST createSimpleRuleAST(String name,
										  GrammarAST block,
										  boolean fragment)
   {
   		GrammarAST modifier = null;
   		if ( fragment ) {
   			modifier = (GrammarAST)astFactory.create(FRAGMENT,"fragment");
   		}
   		GrammarAST EORAST = (GrammarAST)astFactory.create(EOR,"<end-of-rule>");
   		GrammarAST EOBAST = block.getLastChild();
		EORAST.setLine(EOBAST.getLine());
		EORAST.setColumn(EOBAST.getColumn());
		GrammarAST ruleAST =
		   (GrammarAST)astFactory.make( (new ASTArray(5)).add((GrammarAST)astFactory.create(RULE,"rule")).add((GrammarAST)astFactory.create(ID,name)).add(modifier).add(block).add(EORAST));
		ruleAST.setLine(block.getLine());
		ruleAST.setColumn(block.getColumn());
		return ruleAST;
	}

    public void reportError(RecognitionException ex) {
		Token token = null;
		try {
			token = LT(1);
		}
		catch (TokenStreamException tse) {
			ErrorManager.internalError("can't get token???", tse);
		}
		ErrorManager.syntaxError(
			ErrorManager.MSG_SYNTAX_ERROR,
			token,
			"antlr: "+ex.toString(),
			ex);
    }

    public void cleanup(GrammarAST root) {
		if ( gtype==LEXER_GRAMMAR ) {
			String filter = (String)grammar.getOption("filter");
			GrammarAST tokensRuleAST =
			    grammar.addArtificialMatchTokensRule(
			    	root,
			    	lexerRuleNames,
			    	filter!=null&&filter.equals("true"));
		}
    }

protected YggdrasilParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public YggdrasilParser(TokenBuffer tokenBuf) {
  this(tokenBuf,3);
}

protected YggdrasilParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public YggdrasilParser(TokenStream lexer) {
  this(lexer,3);
}

public YggdrasilParser(ParserSharedInputState state) {
  super(state,3);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void file(
		org.antlr_yggdrasil.tool.Grammar g
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST file_AST = null;
		
		try {      // for error handling
			{
			_loop3:
			do {
				if ((LA(1)==LITERAL_header||LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					fileheader();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop3;
				}
				
			} while (true);
			}
			{
			switch ( LA(1)) {
			case ATTRIBUTE_STMT:
			{
				typeDecls();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case OPTIONS:
			case PARSER:
			case DOC_COMMENT:
			case LITERAL_lexer:
			case LITERAL_tree:
			case LITERAL_grammar:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				optionsSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PARSER:
			case DOC_COMMENT:
			case LITERAL_lexer:
			case LITERAL_tree:
			case LITERAL_grammar:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			grammar(g);
			astFactory.addASTChild(currentAST, returnAST);
			file_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = file_AST;
	}
	
	public final void fileheader() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST fileheader_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_header:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			GrammarAST tmp1_AST = null;
			tmp1_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp1_AST);
			match(LITERAL_header);
			{
			GrammarAST tmp2_AST = null;
			tmp2_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp2_AST);
			match(LCURLY);
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				optionsSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case TOKENS:
			case LCURLY:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case TOKENS:
			{
				tokensSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LCURLY:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LCURLY:
			{
				action();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(RCURLY);
			}
			fileheader_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = fileheader_AST;
	}
	
	public final void typeDecls() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST typeDecls_AST = null;
		
		try {      // for error handling
			GrammarAST tmp4_AST = null;
			tmp4_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp4_AST);
			match(ATTRIBUTE_STMT);
			{
			_loop30:
			do {
				if ((LA(1)==LITERAL_native||LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					attributeTypeDecl();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop30;
				}
				
			} while (true);
			}
			match(RCURLY);
			typeDecls_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = typeDecls_AST;
	}
	
	public final Map  optionsSpec() throws RecognitionException, TokenStreamException {
		Map opts=new HashMap();
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST optionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp6_AST = null;
			tmp6_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp6_AST);
			match(OPTIONS);
			{
			int _cnt52=0;
			_loop52:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					option(opts);
					astFactory.addASTChild(currentAST, returnAST);
					match(SEMI);
				}
				else {
					if ( _cnt52>=1 ) { break _loop52; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt52++;
			} while (true);
			}
			match(RCURLY);
			optionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = optionsSpec_AST;
		return opts;
	}
	
	public final void grammar(
		org.antlr_yggdrasil.tool.Grammar g
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST grammar_AST = null;
		Token  cmt = null;
		GrammarAST cmt_AST = null;
		GrammarAST gr_AST = null;
		GrammarAST gid_AST = null;
		GrammarAST gattr_AST = null;
		GrammarAST ts_AST = null;
		GrammarAST a_AST = null;
		GrammarAST r_AST = null;
		
			this.grammar = g;
			GrammarAST opt=null;
			Token optionsStartToken = null;
			Map opts;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case DOC_COMMENT:
			{
				cmt = LT(1);
				cmt_AST = (GrammarAST)astFactory.create(cmt);
				match(DOC_COMMENT);
				break;
			}
			case PARSER:
			case LITERAL_lexer:
			case LITERAL_tree:
			case LITERAL_grammar:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			grammarType();
			gr_AST = (GrammarAST)returnAST;
			id();
			gid_AST = (GrammarAST)returnAST;
			GrammarAST tmp9_AST = null;
			tmp9_AST = (GrammarAST)astFactory.create(LT(1));
			match(SEMI);
			{
			switch ( LA(1)) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls();
				gattr_AST = (GrammarAST)returnAST;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case FRAGMENT:
			case DOC_COMMENT:
			case LCURLY:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				if ( inputState.guessing==0 ) {
					optionsStartToken=LT(1);
				}
				opts=optionsSpec();
				if ( inputState.guessing==0 ) {
					grammar.setOptions(opts, optionsStartToken);
				}
				if ( inputState.guessing==0 ) {
					opt=(GrammarAST)returnAST;
				}
				break;
			}
			case TOKENS:
			case FRAGMENT:
			case DOC_COMMENT:
			case LCURLY:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case TOKENS:
			{
				tokensSpec();
				ts_AST = (GrammarAST)returnAST;
				break;
			}
			case FRAGMENT:
			case DOC_COMMENT:
			case LCURLY:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LCURLY:
			{
				action();
				a_AST = (GrammarAST)returnAST;
				break;
			}
			case FRAGMENT:
			case DOC_COMMENT:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			rules();
			r_AST = (GrammarAST)returnAST;
			GrammarAST tmp10_AST = null;
			tmp10_AST = (GrammarAST)astFactory.create(LT(1));
			match(Token.EOF_TYPE);
			if ( inputState.guessing==0 ) {
				grammar_AST = (GrammarAST)currentAST.root;
				
				grammar_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add(null).add((GrammarAST)astFactory.make( (new ASTArray(9)).add(gr_AST).add(gid_AST).add(cmt_AST).add(gattr_AST).add(opt).add(ts_AST).add(null).add(a_AST).add(r_AST))));
				cleanup((GrammarAST) grammar_AST);
				
				currentAST.root = grammar_AST;
				currentAST.child = grammar_AST!=null &&grammar_AST.getFirstChild()!=null ?
					grammar_AST.getFirstChild() : grammar_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = grammar_AST;
	}
	
	public final void grammarType() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST grammarType_AST = null;
		Token  gr = null;
		GrammarAST gr_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_lexer:
			{
				match(LITERAL_lexer);
				if ( inputState.guessing==0 ) {
					gtype=LEXER_GRAMMAR;
				}
				break;
			}
			case PARSER:
			{
				match(PARSER);
				if ( inputState.guessing==0 ) {
					gtype=PARSER_GRAMMAR;
				}
				break;
			}
			case LITERAL_tree:
			{
				match(LITERAL_tree);
				if ( inputState.guessing==0 ) {
					gtype=TREE_GRAMMAR;
				}
				break;
			}
			case LITERAL_grammar:
			{
				if ( inputState.guessing==0 ) {
					gtype=COMBINED_GRAMMAR;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			gr = LT(1);
			gr_AST = (GrammarAST)astFactory.create(gr);
			astFactory.addASTChild(currentAST, gr_AST);
			match(LITERAL_grammar);
			if ( inputState.guessing==0 ) {
				gr_AST.setType(gtype);
			}
			grammarType_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = grammarType_AST;
	}
	
	public final void id() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST id_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				GrammarAST tmp14_AST = null;
				tmp14_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp14_AST);
				match(TOKEN_REF);
				if ( inputState.guessing==0 ) {
					id_AST = (GrammarAST)currentAST.root;
					id_AST.setType(ID);
				}
				id_AST = (GrammarAST)currentAST.root;
				break;
			}
			case RULE_REF:
			{
				GrammarAST tmp15_AST = null;
				tmp15_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp15_AST);
				match(RULE_REF);
				if ( inputState.guessing==0 ) {
					id_AST = (GrammarAST)currentAST.root;
					id_AST.setType(ID);
				}
				id_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = id_AST;
	}
	
	public final void grammarAttributeDecls() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST grammarAttributeDecls_AST = null;
		
		try {      // for error handling
			GrammarAST tmp16_AST = null;
			tmp16_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp16_AST);
			match(ATTRIBUTE_STMT);
			{
			_loop22:
			do {
				if ((_tokenSet_6.member(LA(1)))) {
					grammarAttributeDecl();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop22;
				}
				
			} while (true);
			}
			match(RCURLY);
			grammarAttributeDecls_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = grammarAttributeDecls_AST;
	}
	
	public final void tokensSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST tokensSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp18_AST = null;
			tmp18_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp18_AST);
			match(TOKENS);
			{
			int _cnt57=0;
			_loop57:
			do {
				if ((LA(1)==TOKEN_REF)) {
					tokenSpec();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt57>=1 ) { break _loop57; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt57++;
			} while (true);
			}
			match(RCURLY);
			tokensSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = tokensSpec_AST;
	}
	
	public final void action() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST action_AST = null;
		
		try {      // for error handling
			match(LCURLY);
			{
			switch ( LA(1)) {
			case STRING_LITERAL:
			{
				GrammarAST tmp21_AST = null;
				tmp21_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp21_AST);
				match(STRING_LITERAL);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case COLON:
			{
				match(COLON);
				{
				int _cnt124=0;
				_loop124:
				do {
					if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
						assignment();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						if ( _cnt124>=1 ) { break _loop124; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt124++;
				} while (true);
				}
				break;
			}
			case RCURLY:
			case SEMPRED:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case RCURLY:
			{
				GrammarAST tmp23_AST = null;
				tmp23_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp23_AST);
				match(RCURLY);
				break;
			}
			case SEMPRED:
			{
				GrammarAST tmp24_AST = null;
				tmp24_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp24_AST);
				match(SEMPRED);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			action_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		returnAST = action_AST;
	}
	
	public final void rules() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rules_AST = null;
		
		try {      // for error handling
			{
			int _cnt63=0;
			_loop63:
			do {
				if ((_tokenSet_10.member(LA(1))) && (_tokenSet_11.member(LA(2)))) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==RULE_REF) && (LA(2)==ATTRIBUTE_COLON)) {
					constructorRule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt63>=1 ) { break _loop63; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt63++;
			} while (true);
			}
			rules_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = rules_AST;
	}
	
	public final void grammarAttributeDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST grammarAttributeDecl_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_public:
			case TOKEN_REF:
			case RULE_REF:
			{
				{
				switch ( LA(1)) {
				case LITERAL_public:
				{
					GrammarAST tmp25_AST = null;
					tmp25_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp25_AST);
					match(LITERAL_public);
					break;
				}
				case TOKEN_REF:
				case RULE_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				attributeVarDecl();
				astFactory.addASTChild(currentAST, returnAST);
				grammarAttributeDecl_AST = (GrammarAST)currentAST.root;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp26_AST = null;
				tmp26_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp26_AST);
				match(LITERAL_import);
				GrammarAST tmp27_AST = null;
				tmp27_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp27_AST);
				match(STRING_LITERAL);
				grammarAttributeDecl_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		returnAST = grammarAttributeDecl_AST;
	}
	
	public final void attributeVarDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeVarDecl_AST = null;
		
		try {      // for error handling
			id();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp28_AST = null;
				tmp28_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp28_AST);
				match(OPEN_ELEMENT_OPTION);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop38:
				do {
					if ((LA(1)==COMMA)) {
						match(COMMA);
						id();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop38;
					}
					
				} while (true);
				}
				GrammarAST tmp30_AST = null;
				tmp30_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp30_AST);
				match(CLOSE_ELEMENT_OPTION);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			id();
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp31_AST = null;
			tmp31_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp31_AST);
			match(SEMI);
			attributeVarDecl_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeVarDecl_AST;
	}
	
	public final void ruleAttributeDecls() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ruleAttributeDecls_AST = null;
		
		try {      // for error handling
			GrammarAST tmp32_AST = null;
			tmp32_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp32_AST);
			match(ATTRIBUTE_STMT);
			{
			_loop27:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==OPEN_ELEMENT_OPTION||LA(2)==TOKEN_REF||LA(2)==RULE_REF) && (LA(3)==SEMI||LA(3)==TOKEN_REF||LA(3)==RULE_REF)) {
					attributeVarDecl();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((_tokenSet_14.member(LA(1))) && (LA(2)==ASSIGN||LA(2)==TOKEN_REF||LA(2)==RULE_REF) && (LA(3)==SEMI||LA(3)==TOKEN_REF||LA(3)==RULE_REF)) {
					attributeUseDecl();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop27;
				}
				
			} while (true);
			}
			match(RCURLY);
			ruleAttributeDecls_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_15);
			} else {
			  throw ex;
			}
		}
		returnAST = ruleAttributeDecls_AST;
	}
	
	public final void attributeUseDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeUseDecl_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				GrammarAST tmp34_AST = null;
				tmp34_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp34_AST);
				match(ASSIGN);
				{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop49:
				do {
					if ((LA(1)==DOT_TEXT||LA(1)==LBRACKET)) {
						idQualifier();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop49;
					}
					
				} while (true);
				}
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp35_AST = null;
				tmp35_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp35_AST);
				match(LITERAL_new);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp36_AST = null;
				tmp36_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp36_AST);
				match(LITERAL_using);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			attributeUseDecl_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_16);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeUseDecl_AST;
	}
	
	public final void attributeTypeDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeTypeDecl_AST = null;
		
		try {      // for error handling
			if ((LA(1)==LITERAL_native||LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF)) {
				{
				switch ( LA(1)) {
				case LITERAL_native:
				{
					GrammarAST tmp38_AST = null;
					tmp38_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp38_AST);
					match(LITERAL_native);
					break;
				}
				case TOKEN_REF:
				case RULE_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				id();
				astFactory.addASTChild(currentAST, returnAST);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				GrammarAST tmp39_AST = null;
				tmp39_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp39_AST);
				match(LCURLY);
				{
				_loop34:
				do {
					if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
						attributeVarDecl();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop34;
					}
					
				} while (true);
				}
				match(RCURLY);
				attributeTypeDecl_AST = (GrammarAST)currentAST.root;
			}
			else if ((LA(1)==LITERAL_native) && (LA(2)==LITERAL_atomic)) {
				GrammarAST tmp41_AST = null;
				tmp41_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp41_AST);
				match(LITERAL_native);
				GrammarAST tmp42_AST = null;
				tmp42_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp42_AST);
				match(LITERAL_atomic);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				attributeTypeDecl_AST = (GrammarAST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_17);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeTypeDecl_AST;
	}
	
	public final void idQualifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST idQualifier_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case DOT_TEXT:
			{
				GrammarAST tmp43_AST = null;
				tmp43_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp43_AST);
				match(DOT_TEXT);
				idQualifier_AST = (GrammarAST)currentAST.root;
				break;
			}
			case LBRACKET:
			{
				arrayItem();
				astFactory.addASTChild(currentAST, returnAST);
				idQualifier_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_18);
			} else {
			  throw ex;
			}
		}
		returnAST = idQualifier_AST;
	}
	
	public final void arrayItem() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST arrayItem_AST = null;
		
		try {      // for error handling
			{
			GrammarAST tmp44_AST = null;
			tmp44_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp44_AST);
			match(LBRACKET);
			{
			switch ( LA(1)) {
			case STRING_LITERAL:
			{
				GrammarAST tmp45_AST = null;
				tmp45_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp45_AST);
				match(STRING_LITERAL);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop44:
				do {
					if ((LA(1)==DOT_TEXT||LA(1)==LBRACKET)) {
						idQualifier();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(RBRACKET);
			}
			arrayItem_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_18);
			} else {
			  throw ex;
			}
		}
		returnAST = arrayItem_AST;
	}
	
	public final void option(
		Map opts
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST option_AST = null;
		GrammarAST o_AST = null;
		
		Object value=null;
		
		
		try {      // for error handling
			id();
			o_AST = (GrammarAST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp47_AST = null;
			tmp47_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp47_AST);
			match(ASSIGN);
			value=optionValue();
			astFactory.addASTChild(currentAST, returnAST);
			if ( inputState.guessing==0 ) {
				
					opts.put(o_AST.getText(), value);
					
			}
			option_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = option_AST;
	}
	
	public final Object  optionValue() throws RecognitionException, TokenStreamException {
		Object value=null;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST optionValue_AST = null;
		GrammarAST x_AST = null;
		Token  s = null;
		GrammarAST s_AST = null;
		Token  c = null;
		GrammarAST c_AST = null;
		Token  i = null;
		GrammarAST i_AST = null;
		Token  ss = null;
		GrammarAST ss_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				x_AST = (GrammarAST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					value = x_AST.getText();
				}
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				s = LT(1);
				s_AST = (GrammarAST)astFactory.create(s);
				astFactory.addASTChild(currentAST, s_AST);
				match(STRING_LITERAL);
				if ( inputState.guessing==0 ) {
					String vs = s_AST.getText();
					value=vs.substring(1,vs.length()-1);
				}
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case KEYWORD:
			{
				c = LT(1);
				c_AST = (GrammarAST)astFactory.create(c);
				astFactory.addASTChild(currentAST, c_AST);
				match(KEYWORD);
				if ( inputState.guessing==0 ) {
					String vs = c_AST.getText();
					value=vs.substring(1,vs.length()-1);
				}
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case INT:
			{
				i = LT(1);
				i_AST = (GrammarAST)astFactory.create(i);
				astFactory.addASTChild(currentAST, i_AST);
				match(INT);
				if ( inputState.guessing==0 ) {
					value = new Integer(i_AST.getText());
				}
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STAR:
			{
				ss = LT(1);
				ss_AST = (GrammarAST)astFactory.create(ss);
				astFactory.addASTChild(currentAST, ss_AST);
				match(STAR);
				if ( inputState.guessing==0 ) {
					ss_AST.setType(STRING_LITERAL); value = "*";
				}
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = optionValue_AST;
		return value;
	}
	
	public final void tokenSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST tokenSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp48_AST = null;
			tmp48_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp48_AST);
			match(TOKEN_REF);
			{
			switch ( LA(1)) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp49_AST = null;
				tmp49_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp49_AST);
				match(OPEN_ELEMENT_OPTION);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				match(CLOSE_ELEMENT_OPTION);
				break;
			}
			case SEMI:
			case ASSIGN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ASSIGN:
			{
				GrammarAST tmp51_AST = null;
				tmp51_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp51_AST);
				match(ASSIGN);
				GrammarAST tmp52_AST = null;
				tmp52_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp52_AST);
				match(KEYWORD);
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			tokenSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_20);
			} else {
			  throw ex;
			}
		}
		returnAST = tokenSpec_AST;
	}
	
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rule_AST = null;
		Token  d = null;
		GrammarAST d_AST = null;
		Token  p1 = null;
		GrammarAST p1_AST = null;
		Token  p2 = null;
		GrammarAST p2_AST = null;
		Token  p3 = null;
		GrammarAST p3_AST = null;
		Token  p4 = null;
		GrammarAST p4_AST = null;
		GrammarAST ruleName_AST = null;
		GrammarAST ra_AST = null;
		GrammarAST act_AST = null;
		Token  colon = null;
		GrammarAST colon_AST = null;
		GrammarAST s_AST = null;
		GrammarAST b_AST = null;
		Token  semi = null;
		GrammarAST semi_AST = null;
		GrammarAST ex_AST = null;
		
		GrammarAST modifier=null, blk=null, blkRoot=null, eob=null;
		int start = ((TokenWithIndex)LT(1)).getIndex();
		int startLine = LT(1).getLine();
		GrammarAST opt = null;
		Map opts = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case DOC_COMMENT:
			{
				d = LT(1);
				d_AST = (GrammarAST)astFactory.create(d);
				match(DOC_COMMENT);
				break;
			}
			case FRAGMENT:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_protected:
			{
				p1 = LT(1);
				p1_AST = (GrammarAST)astFactory.create(p1);
				match(LITERAL_protected);
				if ( inputState.guessing==0 ) {
					modifier=p1_AST;
				}
				break;
			}
			case LITERAL_public:
			{
				p2 = LT(1);
				p2_AST = (GrammarAST)astFactory.create(p2);
				match(LITERAL_public);
				if ( inputState.guessing==0 ) {
					modifier=p2_AST;
				}
				break;
			}
			case LITERAL_private:
			{
				p3 = LT(1);
				p3_AST = (GrammarAST)astFactory.create(p3);
				match(LITERAL_private);
				if ( inputState.guessing==0 ) {
					modifier=p3_AST;
				}
				break;
			}
			case FRAGMENT:
			{
				p4 = LT(1);
				p4_AST = (GrammarAST)astFactory.create(p4);
				match(FRAGMENT);
				if ( inputState.guessing==0 ) {
					modifier=p4_AST;
				}
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			id();
			ruleName_AST = (GrammarAST)returnAST;
			if ( inputState.guessing==0 ) {
					currentRuleName=ruleName_AST.getText();
						if ( gtype==LEXER_GRAMMAR && p4_AST==null ) {
						lexerRuleNames.add(currentRuleName);
						}
					
			}
			{
			switch ( LA(1)) {
			case BANG:
			{
				GrammarAST tmp54_AST = null;
				tmp54_AST = (GrammarAST)astFactory.create(LT(1));
				match(BANG);
				break;
			}
			case OPTIONS:
			case LCURLY:
			case ATTRIBUTE_STMT:
			case COLON:
			case LITERAL_throws:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_throws:
			{
				throwsSpec();
				break;
			}
			case OPTIONS:
			case LCURLY:
			case ATTRIBUTE_STMT:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				opts=optionsSpec();
				if ( inputState.guessing==0 ) {
					opt=(GrammarAST)returnAST;
				}
				break;
			}
			case LCURLY:
			case ATTRIBUTE_STMT:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls();
				ra_AST = (GrammarAST)returnAST;
				break;
			}
			case LCURLY:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LCURLY:
			{
				action();
				act_AST = (GrammarAST)returnAST;
				break;
			}
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			colon = LT(1);
			colon_AST = (GrammarAST)astFactory.create(colon);
			match(COLON);
			if ( inputState.guessing==0 ) {
				
						blkRoot = (GrammarAST)astFactory.create(BLOCK,"BLOCK");
						blkRoot.setLine(colon.getLine());
						blkRoot.setColumn(colon.getColumn());
						eob = (GrammarAST)astFactory.create(EOB,"<end-of-block>");
					
			}
			{
			boolean synPredMatched74 = false;
			if (((LA(1)==STRING_LITERAL||LA(1)==KEYWORD||LA(1)==TOKEN_REF) && (LA(2)==RANGE||LA(2)==OR) && (LA(3)==STRING_LITERAL||LA(3)==KEYWORD||LA(3)==TOKEN_REF))) {
				int _m74 = mark();
				synPredMatched74 = true;
				inputState.guessing++;
				try {
					{
					setNoParens();
					match(SEMI);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched74 = false;
				}
				rewind(_m74);
inputState.guessing--;
			}
			if ( synPredMatched74 ) {
				setNoParens();
				s_AST = (GrammarAST)returnAST;
				if ( inputState.guessing==0 ) {
					
								blk = (GrammarAST)astFactory.make( (new ASTArray(3)).add(blkRoot).add((GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(ALT,"ALT")).add(s_AST).add((GrammarAST)astFactory.create(EOA,"<end-of-alt>")))).add(eob));
							
				}
			}
			else if ((_tokenSet_21.member(LA(1))) && (_tokenSet_22.member(LA(2))) && (_tokenSet_23.member(LA(3)))) {
				altList(opts);
				b_AST = (GrammarAST)returnAST;
				if ( inputState.guessing==0 ) {
					blk = b_AST;
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			semi = LT(1);
			semi_AST = (GrammarAST)astFactory.create(semi);
			match(SEMI);
			{
			switch ( LA(1)) {
			case LITERAL_exception:
			{
				exceptionGroup();
				ex_AST = (GrammarAST)returnAST;
				break;
			}
			case EOF:
			case FRAGMENT:
			case DOC_COMMENT:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				rule_AST = (GrammarAST)currentAST.root;
				
				int stop = ((TokenWithIndex)LT(1)).getIndex()-1; // point at the semi or exception thingie
					eob.setLine(semi.getLine());
					eob.setColumn(semi.getColumn());
				GrammarAST eor = (GrammarAST)astFactory.create(EOR,"<end-of-rule>");
					eor.setEnclosingRule(ruleName_AST.getText());
					eor.setLine(semi.getLine());
					eor.setColumn(semi.getColumn());
					GrammarAST root = (GrammarAST)astFactory.create(RULE,"rule");
					root.ruleStartTokenIndex = start;
					root.ruleStopTokenIndex = stop;
					root.setLine(startLine);
					root.setOptions(opts);
				rule_AST = (GrammarAST)astFactory.make( (new ASTArray(9)).add(root).add(ruleName_AST).add(modifier).add(opt).add(ra_AST).add(act_AST).add(blk).add(ex_AST).add(eor));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_24);
			} else {
			  throw ex;
			}
		}
		returnAST = rule_AST;
	}
	
	public final void constructorRule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST constructorRule_AST = null;
		
		try {      // for error handling
			GrammarAST tmp55_AST = null;
			tmp55_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp55_AST);
			match(RULE_REF);
			GrammarAST tmp56_AST = null;
			tmp56_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp56_AST);
			match(ATTRIBUTE_COLON);
			{
			int _cnt78=0;
			_loop78:
			do {
				if ((_tokenSet_25.member(LA(1)))) {
					attributeItem();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt78>=1 ) { break _loop78; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt78++;
			} while (true);
			}
			match(SEMI);
			constructorRule_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_24);
			} else {
			  throw ex;
			}
		}
		returnAST = constructorRule_AST;
	}
	
	public final void throwsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST throwsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp58_AST = null;
			tmp58_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp58_AST);
			match(LITERAL_throws);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop81:
			do {
				if ((LA(1)==COMMA)) {
					GrammarAST tmp59_AST = null;
					tmp59_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp59_AST);
					match(COMMA);
					id();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop81;
				}
				
			} while (true);
			}
			throwsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_26);
			} else {
			  throw ex;
			}
		}
		returnAST = throwsSpec_AST;
	}
	
	public final void setNoParens() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST setNoParens_AST = null;
		Token startingToken = LT(1);
		
		try {      // for error handling
			setElement();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt174=0;
			_loop174:
			do {
				if ((LA(1)==OR)) {
					match(OR);
					setElement();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt174>=1 ) { break _loop174; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt174++;
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				setNoParens_AST = (GrammarAST)currentAST.root;
				
					GrammarAST ast = new GrammarAST();
						ast.initialize(new TokenWithIndex(SET, "SET"));
						((TokenWithIndex)ast.token)
							.setIndex(((TokenWithIndex)startingToken).getIndex());
						setNoParens_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add(ast).add(setNoParens_AST));
				
				currentAST.root = setNoParens_AST;
				currentAST.child = setNoParens_AST!=null &&setNoParens_AST.getFirstChild()!=null ?
					setNoParens_AST.getFirstChild() : setNoParens_AST;
				currentAST.advanceChildToEnd();
			}
			setNoParens_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_27);
			} else {
			  throw ex;
			}
		}
		returnAST = setNoParens_AST;
	}
	
	public final void altList(
		Map opts
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST altList_AST = null;
		GrammarAST a1_AST = null;
		GrammarAST a2_AST = null;
		
			GrammarAST blkRoot = (GrammarAST)astFactory.create(BLOCK,"BLOCK");
			blkRoot.setOptions(opts);
			blkRoot.setLine(LT(1).getLine());
			blkRoot.setColumn(LT(1).getColumn());
			GrammarAST save = currentBlockAST;
			currentBlockAST = blkRoot;
		
		
		try {      // for error handling
			alternative();
			a1_AST = (GrammarAST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			if ( inputState.guessing==0 ) {
				prefixWithSynPred(a1_AST);
			}
			{
			_loop96:
			do {
				if ((LA(1)==OR)) {
					match(OR);
					alternative();
					a2_AST = (GrammarAST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						if (LA(1)==OR) prefixWithSynPred(a2_AST);
					}
				}
				else {
					break _loop96;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				altList_AST = (GrammarAST)currentAST.root;
				
				altList_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(blkRoot).add(altList_AST).add((GrammarAST)astFactory.create(EOB,"<end-of-block>")));
				currentBlockAST = save;
				
				currentAST.root = altList_AST;
				currentAST.child = altList_AST!=null &&altList_AST.getFirstChild()!=null ?
					altList_AST.getFirstChild() : altList_AST;
				currentAST.advanceChildToEnd();
			}
			altList_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = altList_AST;
	}
	
	public final void exceptionGroup() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionGroup_AST = null;
		
		try {      // for error handling
			{
			int _cnt103=0;
			_loop103:
			do {
				if ((LA(1)==LITERAL_exception)) {
					exceptionSpec();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt103>=1 ) { break _loop103; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt103++;
			} while (true);
			}
			exceptionGroup_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_24);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionGroup_AST;
	}
	
	public final void attributeItem() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeItem_AST = null;
		
		try {      // for error handling
			label();
			astFactory.addASTChild(currentAST, returnAST);
			attributeElement();
			astFactory.addASTChild(currentAST, returnAST);
			attributeItem_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_28);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeItem_AST;
	}
	
	public final void attributeDecls() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeDecls_AST = null;
		
		try {      // for error handling
			GrammarAST tmp62_AST = null;
			tmp62_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp62_AST);
			match(ATTRIBUTE_STMT);
			{
			_loop84:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF||LA(1)==LITERAL_uses)) {
					attributeDecl();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop84;
				}
				
			} while (true);
			}
			GrammarAST tmp63_AST = null;
			tmp63_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp63_AST);
			match(RCURLY);
			attributeDecls_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeDecls_AST;
	}
	
	public final void attributeDecl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeDecl_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_uses:
			{
				GrammarAST tmp64_AST = null;
				tmp64_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp64_AST);
				match(LITERAL_uses);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			id();
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp65_AST = null;
			tmp65_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp65_AST);
			match(SEMI);
			attributeDecl_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_29);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeDecl_AST;
	}
	
/** Build #(BLOCK ( #(ALT ...) EOB )+ ) */
	public final void block() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST block_AST = null;
		GrammarAST s_AST = null;
		Token  lp = null;
		GrammarAST lp_AST = null;
		GrammarAST a1_AST = null;
		GrammarAST a2_AST = null;
		Token  rp = null;
		GrammarAST rp_AST = null;
		
			GrammarAST save = currentBlockAST;
			Map opts=null;
		
		
		try {      // for error handling
			boolean synPredMatched89 = false;
			if (((LA(1)==LPAREN) && (LA(2)==STRING_LITERAL||LA(2)==KEYWORD||LA(2)==TOKEN_REF) && (LA(3)==RANGE||LA(3)==OR))) {
				int _m89 = mark();
				synPredMatched89 = true;
				inputState.guessing++;
				try {
					{
					set();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched89 = false;
				}
				rewind(_m89);
inputState.guessing--;
			}
			if ( synPredMatched89 ) {
				set();
				s_AST = (GrammarAST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				block_AST = (GrammarAST)currentAST.root;
			}
			else if ((LA(1)==LPAREN) && (_tokenSet_30.member(LA(2))) && (_tokenSet_31.member(LA(3)))) {
				lp = LT(1);
				lp_AST = (GrammarAST)astFactory.create(lp);
				astFactory.makeASTRoot(currentAST, lp_AST);
				match(LPAREN);
				if ( inputState.guessing==0 ) {
					lp_AST.setType(BLOCK); lp_AST.setText("BLOCK");
				}
				{
				if ((LA(1)==OPTIONS||LA(1)==COLON)) {
					{
					switch ( LA(1)) {
					case OPTIONS:
					{
						opts=optionsSpec();
						astFactory.addASTChild(currentAST, returnAST);
						if ( inputState.guessing==0 ) {
							block_AST = (GrammarAST)currentAST.root;
							block_AST.setOptions(grammar,opts);
						}
						break;
					}
					case COLON:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(COLON);
				}
				else if ((LA(1)==LCURLY) && (LA(2)==STRING_LITERAL||LA(2)==TOKEN_REF||LA(2)==RULE_REF) && (LA(3)==RCURLY||LA(3)==COLON||LA(3)==SEMPRED)) {
					action();
					astFactory.addASTChild(currentAST, returnAST);
					match(COLON);
				}
				else if ((_tokenSet_32.member(LA(1))) && (_tokenSet_31.member(LA(2))) && (_tokenSet_33.member(LA(3)))) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				
				}
				if ( inputState.guessing==0 ) {
					currentBlockAST = lp_AST;
				}
				alternative();
				a1_AST = (GrammarAST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					prefixWithSynPred(a1_AST);
				}
				{
				_loop93:
				do {
					if ((LA(1)==OR)) {
						match(OR);
						alternative();
						a2_AST = (GrammarAST)returnAST;
						astFactory.addASTChild(currentAST, returnAST);
						if ( inputState.guessing==0 ) {
							if (LA(1)==OR||LA(2)==QUESTION) prefixWithSynPred(a2_AST);
						}
					}
					else {
						break _loop93;
					}
					
				} while (true);
				}
				rp = LT(1);
				rp_AST = (GrammarAST)astFactory.create(rp);
				match(RPAREN);
				if ( inputState.guessing==0 ) {
					block_AST = (GrammarAST)currentAST.root;
					
							currentBlockAST = save;
					GrammarAST eob = (GrammarAST)astFactory.create(EOB,"<end-of-block>");
					eob.setLine(rp.getLine());
					eob.setColumn(rp.getColumn());
					block_AST.addChild(eob);
					
				}
				block_AST = (GrammarAST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_34);
			} else {
			  throw ex;
			}
		}
		returnAST = block_AST;
	}
	
/** Match two or more set elements */
	public final void set() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST set_AST = null;
		GrammarAST s_AST = null;
		
		try {      // for error handling
			match(LPAREN);
			setNoParens();
			s_AST = (GrammarAST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			match(RPAREN);
			set_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_35);
			} else {
			  throw ex;
			}
		}
		returnAST = set_AST;
	}
	
	public final void alternative() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST alternative_AST = null;
		GrammarAST el_AST = null;
		
		GrammarAST eoa = (GrammarAST)astFactory.create(EOA,"<end-of-alt>");
		GrammarAST altRoot = (GrammarAST)astFactory.create(ALT,"ALT");
		altRoot.setLine(LT(1).getLine());
		altRoot.setColumn(LT(1).getColumn());
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case LCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				{
				int _cnt99=0;
				_loop99:
				do {
					if ((_tokenSet_36.member(LA(1)))) {
						element();
						el_AST = (GrammarAST)returnAST;
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						if ( _cnt99>=1 ) { break _loop99; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt99++;
				} while (true);
				}
				{
				switch ( LA(1)) {
				case LITERAL_exception:
				{
					exceptionSpecNoLabel();
					break;
				}
				case SEMI:
				case OR:
				case RPAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					alternative_AST = (GrammarAST)currentAST.root;
					
					if ( alternative_AST==null ) {
					alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(altRoot).add((GrammarAST)astFactory.create(EPSILON,"epsilon")).add(eoa));
					}
					else {
						// we have a real list of stuff
						alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(altRoot).add(alternative_AST).add(eoa));
					}
					
					currentAST.root = alternative_AST;
					currentAST.child = alternative_AST!=null &&alternative_AST.getFirstChild()!=null ?
						alternative_AST.getFirstChild() : alternative_AST;
					currentAST.advanceChildToEnd();
				}
				alternative_AST = (GrammarAST)currentAST.root;
				break;
			}
			case SEMI:
			case OR:
			case RPAREN:
			{
				if ( inputState.guessing==0 ) {
					alternative_AST = (GrammarAST)currentAST.root;
					
						GrammarAST eps = (GrammarAST)astFactory.create(EPSILON,"epsilon");
							eps.setLine(LT(0).getLine()); // get line/col of '|' or ':' (prev token)
							eps.setColumn(LT(0).getColumn());
						alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(altRoot).add(eps).add(eoa));
						
					currentAST.root = alternative_AST;
					currentAST.child = alternative_AST!=null &&alternative_AST.getFirstChild()!=null ?
						alternative_AST.getFirstChild() : alternative_AST;
					currentAST.advanceChildToEnd();
				}
				alternative_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_37);
			} else {
			  throw ex;
			}
		}
		returnAST = alternative_AST;
	}
	
	public final void element() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST element_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				label();
				astFactory.addASTChild(currentAST, returnAST);
				elementItem();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LCURLY:
			{
				action();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				optionsSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case SEMI:
			case LCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case LITERAL_exception:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			element_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_38);
			} else {
			  throw ex;
			}
		}
		returnAST = element_AST;
	}
	
	public final void exceptionSpecNoLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionSpecNoLabel_AST = null;
		
		try {      // for error handling
			GrammarAST tmp71_AST = null;
			tmp71_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp71_AST);
			match(LITERAL_exception);
			{
			_loop115:
			do {
				if ((LA(1)==LITERAL_catch)) {
					exceptionHandler();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop115;
				}
				
			} while (true);
			}
			exceptionSpecNoLabel_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_37);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionSpecNoLabel_AST;
	}
	
	public final void exceptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp72_AST = null;
			tmp72_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp72_AST);
			match(LITERAL_exception);
			{
			switch ( LA(1)) {
			case LBRACKET:
			{
				arg_decl();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case EOF:
			case FRAGMENT:
			case DOC_COMMENT:
			case LITERAL_public:
			case TOKEN_REF:
			case LITERAL_protected:
			case LITERAL_private:
			case RULE_REF:
			case LITERAL_exception:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop107:
			do {
				if ((LA(1)==LITERAL_catch)) {
					exceptionHandler();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop107;
				}
				
			} while (true);
			}
			exceptionSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_39);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionSpec_AST;
	}
	
	public final void arg_decl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST arg_decl_AST = null;
		
		try {      // for error handling
			match(LBRACKET);
			{
			switch ( LA(1)) {
			case STRING_LITERAL:
			{
				GrammarAST tmp74_AST = null;
				tmp74_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp74_AST);
				match(STRING_LITERAL);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case COLON:
			{
				GrammarAST tmp75_AST = null;
				tmp75_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp75_AST);
				match(COLON);
				{
				int _cnt112=0;
				_loop112:
				do {
					if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
						assignment();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						if ( _cnt112>=1 ) { break _loop112; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt112++;
				} while (true);
				}
				break;
			}
			case RBRACKET:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			GrammarAST tmp76_AST = null;
			tmp76_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp76_AST);
			match(RBRACKET);
			arg_decl_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_40);
			} else {
			  throw ex;
			}
		}
		returnAST = arg_decl_AST;
	}
	
	public final void exceptionHandler() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionHandler_AST = null;
		
		try {      // for error handling
			GrammarAST tmp77_AST = null;
			tmp77_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp77_AST);
			match(LITERAL_catch);
			arg_decl();
			astFactory.addASTChild(currentAST, returnAST);
			action();
			astFactory.addASTChild(currentAST, returnAST);
			exceptionHandler_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_41);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionHandler_AST;
	}
	
	public final void assignment() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST assignment_AST = null;
		Token  t = null;
		GrammarAST t_AST = null;
		Token  r = null;
		GrammarAST r_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				t = LT(1);
				t_AST = (GrammarAST)astFactory.create(t);
				astFactory.makeASTRoot(currentAST, t_AST);
				match(TOKEN_REF);
				if ( inputState.guessing==0 ) {
					t_AST.setType(ID);
				}
				break;
			}
			case RULE_REF:
			{
				r = LT(1);
				r_AST = (GrammarAST)astFactory.create(r);
				astFactory.makeASTRoot(currentAST, r_AST);
				match(RULE_REF);
				if ( inputState.guessing==0 ) {
					r_AST.setType(ID);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(ASSIGN);
			{
			switch ( LA(1)) {
			case ATTRIBUTE:
			{
				attribute();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case TOKEN_REF:
			{
				GrammarAST tmp79_AST = null;
				tmp79_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp79_AST);
				match(TOKEN_REF);
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp80_AST = null;
				tmp80_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp80_AST);
				match(STRING_LITERAL);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			assignment_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_42);
			} else {
			  throw ex;
			}
		}
		returnAST = assignment_AST;
	}
	
	public final void label() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST label_AST = null;
		
		try {      // for error handling
			{
			boolean synPredMatched136 = false;
			if (((LA(1)==RULE_REF||LA(1)==ATTRIBUTE) && (LA(2)==DOT_TEXT||LA(2)==LBRACKET||LA(2)==ASSIGN) && (_tokenSet_43.member(LA(3))))) {
				int _m136 = mark();
				synPredMatched136 = true;
				inputState.guessing++;
				try {
					{
					attrLabel();
					}
				}
				catch (RecognitionException pe) {
					synPredMatched136 = false;
				}
				rewind(_m136);
inputState.guessing--;
			}
			if ( synPredMatched136 ) {
				attrLabel();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else if ((_tokenSet_44.member(LA(1))) && (_tokenSet_45.member(LA(2))) && (_tokenSet_46.member(LA(3)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			label_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_44);
			} else {
			  throw ex;
			}
		}
		returnAST = label_AST;
	}
	
	public final void elementItem() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST elementItem_AST = null;
		Token  r = null;
		GrammarAST r_AST = null;
		Token  b = null;
		GrammarAST b_AST = null;
		GrammarAST n_AST = null;
		Token  b1 = null;
		GrammarAST b1_AST = null;
		GrammarAST subrule=null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case NOT:
			{
				notSet();
				n_AST = (GrammarAST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case STAR:
				case QUESTION:
				case PLUS:
				{
					subrule=ebnfSuffix(n_AST);
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						elementItem_AST = (GrammarAST)currentAST.root;
						elementItem_AST = subrule;
						currentAST.root = elementItem_AST;
						currentAST.child = elementItem_AST!=null &&elementItem_AST.getFirstChild()!=null ?
							elementItem_AST.getFirstChild() : elementItem_AST;
						currentAST.advanceChildToEnd();
					}
					{
					switch ( LA(1)) {
					case BANG:
					{
						b1 = LT(1);
						b1_AST = (GrammarAST)astFactory.create(b1);
						astFactory.makeASTRoot(currentAST, b1_AST);
						match(BANG);
						if ( inputState.guessing==0 ) {
							b1_AST.setType(BANGEDUP);
						}
						break;
					}
					case OPTIONS:
					case SEMI:
					case LCURLY:
					case ATTRIBUTE_STMT:
					case STRING_LITERAL:
					case KEYWORD:
					case TOKEN_REF:
					case RULE_REF:
					case LPAREN:
					case OR:
					case RPAREN:
					case LITERAL_exception:
					case ATTRIBUTE:
					case ATTRIBUTE_GROUP:
					case CURRENT_TREE:
					case TREE_CONSTRUCTOR:
					case NOT:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case BANG:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CARET:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					{
					switch ( LA(1)) {
					case BANG:
					case CARET:
					{
						ast_suffix();
						astFactory.addASTChild(currentAST, returnAST);
						break;
					}
					case OPTIONS:
					case SEMI:
					case LCURLY:
					case ATTRIBUTE_STMT:
					case STRING_LITERAL:
					case KEYWORD:
					case TOKEN_REF:
					case RULE_REF:
					case LPAREN:
					case OR:
					case RPAREN:
					case LITERAL_exception:
					case ATTRIBUTE:
					case ATTRIBUTE_GROUP:
					case CURRENT_TREE:
					case TREE_CONSTRUCTOR:
					case NOT:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
						int line = LT(1).getLine();
									int col = LT(1).getColumn();
					
									n_AST.setLine(line);
									n_AST.setColumn(col);
								
				}
				break;
			}
			case TREE_BEGIN:
			{
				treeMatcher();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
				if ((LA(1)==RULE_REF) && (_tokenSet_47.member(LA(2))) && (_tokenSet_46.member(LA(3)))) {
					r = LT(1);
					r_AST = (GrammarAST)astFactory.create(r);
					astFactory.addASTChild(currentAST, r_AST);
					match(RULE_REF);
					{
					switch ( LA(1)) {
					case STAR:
					case QUESTION:
					case PLUS:
					{
						subrule=ebnfSuffix(r_AST);
						astFactory.addASTChild(currentAST, returnAST);
						if ( inputState.guessing==0 ) {
							elementItem_AST = (GrammarAST)currentAST.root;
							elementItem_AST=subrule;
							currentAST.root = elementItem_AST;
							currentAST.child = elementItem_AST!=null &&elementItem_AST.getFirstChild()!=null ?
								elementItem_AST.getFirstChild() : elementItem_AST;
							currentAST.advanceChildToEnd();
						}
						{
						switch ( LA(1)) {
						case BANG:
						{
							b = LT(1);
							b_AST = (GrammarAST)astFactory.create(b);
							astFactory.makeASTRoot(currentAST, b_AST);
							match(BANG);
							if ( inputState.guessing==0 ) {
								b_AST.setType(BANGEDUP);
							}
							break;
						}
						case OPTIONS:
						case SEMI:
						case LCURLY:
						case ATTRIBUTE_STMT:
						case STRING_LITERAL:
						case KEYWORD:
						case TOKEN_REF:
						case RULE_REF:
						case LPAREN:
						case OR:
						case RPAREN:
						case LITERAL_exception:
						case ATTRIBUTE:
						case ATTRIBUTE_GROUP:
						case CURRENT_TREE:
						case TREE_CONSTRUCTOR:
						case NOT:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					case BANG:
					{
						GrammarAST tmp82_AST = null;
						tmp82_AST = (GrammarAST)astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp82_AST);
						match(BANG);
						break;
					}
					case OPTIONS:
					case SEMI:
					case LCURLY:
					case ATTRIBUTE_STMT:
					case STRING_LITERAL:
					case KEYWORD:
					case TOKEN_REF:
					case RULE_REF:
					case LPAREN:
					case OR:
					case RPAREN:
					case LITERAL_exception:
					case ATTRIBUTE:
					case ATTRIBUTE_GROUP:
					case CURRENT_TREE:
					case TREE_CONSTRUCTOR:
					case NOT:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				else if ((LA(1)==KEYWORD) && (LA(2)==RANGE)) {
					range();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((_tokenSet_48.member(LA(1))) && (_tokenSet_49.member(LA(2)))) {
					terminal();
					astFactory.addASTChild(currentAST, returnAST);
					{
					switch ( LA(1)) {
					case BANG:
					case CARET:
					{
						ast_suffix();
						astFactory.addASTChild(currentAST, returnAST);
						break;
					}
					case OPTIONS:
					case SEMI:
					case LCURLY:
					case ATTRIBUTE_STMT:
					case STRING_LITERAL:
					case KEYWORD:
					case TOKEN_REF:
					case RULE_REF:
					case LPAREN:
					case OR:
					case RPAREN:
					case LITERAL_exception:
					case ATTRIBUTE:
					case ATTRIBUTE_GROUP:
					case CURRENT_TREE:
					case TREE_CONSTRUCTOR:
					case NOT:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				else if ((LA(1)==LPAREN) && (_tokenSet_30.member(LA(2))) && (_tokenSet_31.member(LA(3)))) {
					ebnf();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((_tokenSet_25.member(LA(1))) && (_tokenSet_50.member(LA(2))) && (_tokenSet_46.member(LA(3)))) {
					attributeItem();
					astFactory.addASTChild(currentAST, returnAST);
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			elementItem_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_51);
			} else {
			  throw ex;
			}
		}
		returnAST = elementItem_AST;
	}
	
	public final void attribute() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attribute_AST = null;
		
		try {      // for error handling
			GrammarAST tmp83_AST = null;
			tmp83_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp83_AST);
			match(ATTRIBUTE);
			{
			_loop147:
			do {
				if ((LA(1)==DOT_TEXT||LA(1)==LBRACKET)) {
					idQualifier();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop147;
				}
				
			} while (true);
			}
			attribute_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_52);
			} else {
			  throw ex;
			}
		}
		returnAST = attribute_AST;
	}
	
	public final void attrLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attrLabel_AST = null;
		Token  a = null;
		GrammarAST a_AST = null;
		Token  i = null;
		GrammarAST i_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ATTRIBUTE:
			{
				a = LT(1);
				a_AST = (GrammarAST)astFactory.create(a);
				astFactory.addASTChild(currentAST, a_AST);
				match(ATTRIBUTE);
				if ( inputState.guessing==0 ) {
					a_AST.setType(ASSIGN_ATTRIBUTE);
				}
				break;
			}
			case RULE_REF:
			{
				i = LT(1);
				i_AST = (GrammarAST)astFactory.create(i);
				astFactory.addASTChild(currentAST, i_AST);
				match(RULE_REF);
				if ( inputState.guessing==0 ) {
					i_AST.setType(LABEL_ATTRIBUTE);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop132:
			do {
				if ((LA(1)==DOT_TEXT||LA(1)==LBRACKET)) {
					idQualifier();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop132;
				}
				
			} while (true);
			}
			match(ASSIGN);
			attrLabel_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_44);
			} else {
			  throw ex;
			}
		}
		returnAST = attrLabel_AST;
	}
	
	public final GrammarAST  ebnfSuffix(
		GrammarAST elemAST
	) throws RecognitionException, TokenStreamException {
		GrammarAST subrule=null;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ebnfSuffix_AST = null;
		
		GrammarAST ebnfRoot=null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case QUESTION:
			{
				GrammarAST tmp85_AST = null;
				tmp85_AST = (GrammarAST)astFactory.create(LT(1));
				match(QUESTION);
				if ( inputState.guessing==0 ) {
					ebnfRoot = (GrammarAST)astFactory.create(OPTIONAL,"?");
				}
				break;
			}
			case STAR:
			{
				GrammarAST tmp86_AST = null;
				tmp86_AST = (GrammarAST)astFactory.create(LT(1));
				match(STAR);
				if ( inputState.guessing==0 ) {
					ebnfRoot = (GrammarAST)astFactory.create(CLOSURE,"*");
				}
				break;
			}
			case PLUS:
			{
				GrammarAST tmp87_AST = null;
				tmp87_AST = (GrammarAST)astFactory.create(LT(1));
				match(PLUS);
				if ( inputState.guessing==0 ) {
					ebnfRoot = (GrammarAST)astFactory.create(POSITIVE_CLOSURE,"+");
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						ebnfRoot.setLine(elemAST.getLine());
						ebnfRoot.setColumn(elemAST.getColumn());
						GrammarAST blkRoot = (GrammarAST)astFactory.create(BLOCK,"BLOCK");
						GrammarAST eob = (GrammarAST)astFactory.create(EOB,"<end-of-block>");
						GrammarAST save = currentBlockAST;
						eob.setLine(elemAST.getLine());
						eob.setColumn(elemAST.getColumn());
						GrammarAST alt = (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(ALT,"ALT")).add(elemAST).add((GrammarAST)astFactory.create(EOA,"<end-of-alt>")));
						prefixWithSynPred(alt);
						subrule =
							(GrammarAST)astFactory.make( (new ASTArray(2)).add(ebnfRoot).add((GrammarAST)astFactory.make( (new ASTArray(3)).add(blkRoot).add(alt).add(eob))));
							currentBlockAST = save;
					
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_53);
			} else {
			  throw ex;
			}
		}
		returnAST = ebnfSuffix_AST;
		return subrule;
	}
	
	public final void range() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST range_AST = null;
		Token  c1 = null;
		GrammarAST c1_AST = null;
		Token  c2 = null;
		GrammarAST c2_AST = null;
		
		GrammarAST subrule=null, root=null;
		
		
		try {      // for error handling
			c1 = LT(1);
			c1_AST = (GrammarAST)astFactory.create(c1);
			match(KEYWORD);
			GrammarAST tmp88_AST = null;
			tmp88_AST = (GrammarAST)astFactory.create(LT(1));
			match(RANGE);
			c2 = LT(1);
			c2_AST = (GrammarAST)astFactory.create(c2);
			match(KEYWORD);
			if ( inputState.guessing==0 ) {
				range_AST = (GrammarAST)currentAST.root;
				
						GrammarAST r = (GrammarAST)astFactory.create(CHAR_RANGE,"..");
						r.setLine(c1.getLine());
						r.setColumn(c1.getColumn());
						range_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(r).add(c1_AST).add(c2_AST));
						root = (GrammarAST) range_AST;
					
				currentAST.root = range_AST;
				currentAST.child = range_AST!=null &&range_AST.getFirstChild()!=null ?
					range_AST.getFirstChild() : range_AST;
				currentAST.advanceChildToEnd();
			}
			{
			switch ( LA(1)) {
			case STAR:
			case QUESTION:
			case PLUS:
			{
				subrule=ebnfSuffix(root);
				if ( inputState.guessing==0 ) {
					range_AST = (GrammarAST)currentAST.root;
					range_AST=subrule;
					currentAST.root = range_AST;
					currentAST.child = range_AST!=null &&range_AST.getFirstChild()!=null ?
						range_AST.getFirstChild() : range_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case OPTIONS:
			case SEMI:
			case LCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case LITERAL_exception:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_51);
			} else {
			  throw ex;
			}
		}
		returnAST = range_AST;
	}
	
	public final void terminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST terminal_AST = null;
		Token  cl = null;
		GrammarAST cl_AST = null;
		Token  tr = null;
		GrammarAST tr_AST = null;
		Token  sl = null;
		GrammarAST sl_AST = null;
		Token  wi = null;
		GrammarAST wi_AST = null;
		
		GrammarAST ebnfRoot=null, subrule=null;
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case KEYWORD:
			{
				cl = LT(1);
				cl_AST = (GrammarAST)astFactory.create(cl);
				astFactory.addASTChild(currentAST, cl_AST);
				match(KEYWORD);
				{
				switch ( LA(1)) {
				case STAR:
				case QUESTION:
				case PLUS:
				{
					subrule=ebnfSuffix(cl_AST);
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						terminal_AST = (GrammarAST)currentAST.root;
						terminal_AST=subrule;
						currentAST.root = terminal_AST;
						currentAST.child = terminal_AST!=null &&terminal_AST.getFirstChild()!=null ?
							terminal_AST.getFirstChild() : terminal_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case BANG:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CARET:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case TOKEN_REF:
			{
				tr = LT(1);
				tr_AST = (GrammarAST)astFactory.create(tr);
				astFactory.addASTChild(currentAST, tr_AST);
				match(TOKEN_REF);
				{
				switch ( LA(1)) {
				case STAR:
				case QUESTION:
				case PLUS:
				{
					subrule=ebnfSuffix(tr_AST);
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						terminal_AST = (GrammarAST)currentAST.root;
						terminal_AST=subrule;
						currentAST.root = terminal_AST;
						currentAST.child = terminal_AST!=null &&terminal_AST.getFirstChild()!=null ?
							terminal_AST.getFirstChild() : terminal_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case BANG:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CARET:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				sl = LT(1);
				sl_AST = (GrammarAST)astFactory.create(sl);
				astFactory.addASTChild(currentAST, sl_AST);
				match(STRING_LITERAL);
				if ( inputState.guessing==0 ) {
					terminal_AST = (GrammarAST)currentAST.root;
					if ((gtype != LEXER_GRAMMAR)
								|| ((gtype == COMBINED_GRAMMAR) 
								&& Character.isUpperCase(currentRuleName.charAt(0))))
								terminal_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add(null).add((GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(SEMPRED,"}?")).add((GrammarAST)astFactory.create(ID,"stringPred")).add((GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ID,"string")).add(sl_AST))))).add((GrammarAST)astFactory.create(WILDCARD,".")));
							
					currentAST.root = terminal_AST;
					currentAST.child = terminal_AST!=null &&terminal_AST.getFirstChild()!=null ?
						terminal_AST.getFirstChild() : terminal_AST;
					currentAST.advanceChildToEnd();
				}
				{
				switch ( LA(1)) {
				case STAR:
				case QUESTION:
				case PLUS:
				{
					subrule=ebnfSuffix(sl_AST);
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						terminal_AST = (GrammarAST)currentAST.root;
						terminal_AST=subrule;
						currentAST.root = terminal_AST;
						currentAST.child = terminal_AST!=null &&terminal_AST.getFirstChild()!=null ?
							terminal_AST.getFirstChild() : terminal_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case BANG:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CARET:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case WILDCARD:
			{
				wi = LT(1);
				wi_AST = (GrammarAST)astFactory.create(wi);
				astFactory.addASTChild(currentAST, wi_AST);
				match(WILDCARD);
				{
				switch ( LA(1)) {
				case STAR:
				case QUESTION:
				case PLUS:
				{
					subrule=ebnfSuffix(wi_AST);
					astFactory.addASTChild(currentAST, returnAST);
					if ( inputState.guessing==0 ) {
						terminal_AST = (GrammarAST)currentAST.root;
						terminal_AST=subrule;
						currentAST.root = terminal_AST;
						currentAST.child = terminal_AST!=null &&terminal_AST.getFirstChild()!=null ?
							terminal_AST.getFirstChild() : terminal_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case BANG:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CARET:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_53);
			} else {
			  throw ex;
			}
		}
		returnAST = terminal_AST;
	}
	
	public final void ast_suffix() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ast_suffix_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CARET:
			{
				GrammarAST tmp89_AST = null;
				tmp89_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp89_AST);
				match(CARET);
				ast_suffix_AST = (GrammarAST)currentAST.root;
				break;
			}
			case BANG:
			{
				GrammarAST tmp90_AST = null;
				tmp90_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp90_AST);
				match(BANG);
				ast_suffix_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_51);
			} else {
			  throw ex;
			}
		}
		returnAST = ast_suffix_AST;
	}
	
	public final void notSet() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST notSet_AST = null;
		Token  n = null;
		GrammarAST n_AST = null;
		
		GrammarAST subrule=null;
		
		
		try {      // for error handling
			n = LT(1);
			n_AST = (GrammarAST)astFactory.create(n);
			astFactory.makeASTRoot(currentAST, n_AST);
			match(NOT);
			{
			if ((LA(1)==STRING_LITERAL||LA(1)==KEYWORD||LA(1)==TOKEN_REF)) {
				notTerminal();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				boolean synPredMatched170 = false;
				if (((LA(1)==LPAREN) && (LA(2)==STRING_LITERAL||LA(2)==KEYWORD||LA(2)==TOKEN_REF) && (LA(3)==RANGE||LA(3)==RPAREN))) {
					int _m170 = mark();
					synPredMatched170 = true;
					inputState.guessing++;
					try {
						{
						match(LPAREN);
						setElement();
						match(RPAREN);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched170 = false;
					}
					rewind(_m170);
inputState.guessing--;
				}
				if ( synPredMatched170 ) {
					match(LPAREN);
					setElement();
					astFactory.addASTChild(currentAST, returnAST);
					match(RPAREN);
				}
				else if ((LA(1)==LPAREN) && (LA(2)==STRING_LITERAL||LA(2)==KEYWORD||LA(2)==TOKEN_REF) && (LA(3)==RANGE||LA(3)==OR)) {
					set();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				notSet_AST = (GrammarAST)currentAST.root;
			}
			catch (RecognitionException ex) {
				if (inputState.guessing==0) {
					reportError(ex);
					recover(ex,_tokenSet_49);
				} else {
				  throw ex;
				}
			}
			returnAST = notSet_AST;
		}
		
/** matches ENBF blocks (and sets via block rule) */
	public final void ebnf() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ebnf_AST = null;
		GrammarAST b_AST = null;
		Token  ba = null;
		GrammarAST ba_AST = null;
		
		int line = LT(1).getLine();
		int col = LT(1).getColumn();
		
		
		try {      // for error handling
			block();
			b_AST = (GrammarAST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case STAR:
			case QUESTION:
			case PLUS:
			{
				{
				switch ( LA(1)) {
				case QUESTION:
				{
					match(QUESTION);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						if (b_AST.getType()==SET) b_AST=setToBlockWithSet(b_AST);
												 ebnf_AST=(GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(OPTIONAL,"?")).add(b_AST));
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case STAR:
				{
					match(STAR);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						if (b_AST.getType()==SET) b_AST=setToBlockWithSet(b_AST);
												 ebnf_AST=(GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(CLOSURE,"*")).add(b_AST));
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case PLUS:
				{
					match(PLUS);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						if (b_AST.getType()==SET) b_AST=setToBlockWithSet(b_AST);
												 ebnf_AST=(GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(POSITIVE_CLOSURE,"+")).add(b_AST));
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case BANG:
				{
					ba = LT(1);
					ba_AST = (GrammarAST)astFactory.create(ba);
					astFactory.makeASTRoot(currentAST, ba_AST);
					match(BANG);
					if ( inputState.guessing==0 ) {
						ba_AST.setType(BANGEDUP);
					}
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case IMPLIES:
			{
				match(IMPLIES);
				if ( inputState.guessing==0 ) {
					ebnf_AST = (GrammarAST)currentAST.root;
					
								if ( gtype==COMBINED_GRAMMAR &&
								     Character.isUpperCase(currentRuleName.charAt(0)) )
								{
							    		ebnf_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(SYNPRED,"=>")).add(b_AST));
									// ignore for lexer rules in combined
							 	}
								else {
							    		ebnf_AST = createSynSemPredFromBlock(b_AST);
								}
							
					currentAST.root = ebnf_AST;
					currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
						ebnf_AST.getFirstChild() : ebnf_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case OPTIONS:
			case SEMI:
			case LCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case LITERAL_exception:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				if ( inputState.guessing==0 ) {
					ebnf_AST = (GrammarAST)currentAST.root;
					ebnf_AST = b_AST;
					currentAST.root = ebnf_AST;
					currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
						ebnf_AST.getFirstChild() : ebnf_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				ebnf_AST = (GrammarAST)currentAST.root;
					((GrammarAST) ebnf_AST).setLine(line);
						((GrammarAST) ebnf_AST).setColumn(col);
			}
			ebnf_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_51);
			} else {
			  throw ex;
			}
		}
		returnAST = ebnf_AST;
	}
	
	public final void treeMatcher() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST treeMatcher_AST = null;
		
		try {      // for error handling
			GrammarAST tmp97_AST = null;
			tmp97_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp97_AST);
			match(TREE_BEGIN);
			rootNode();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt178=0;
			_loop178:
			do {
				if ((_tokenSet_36.member(LA(1)))) {
					element();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt178>=1 ) { break _loop178; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt178++;
			} while (true);
			}
			match(RPAREN);
			treeMatcher_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_51);
			} else {
			  throw ex;
			}
		}
		returnAST = treeMatcher_AST;
	}
	
	public final void attributeGroup() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeGroup_AST = null;
		
		try {      // for error handling
			GrammarAST tmp99_AST = null;
			tmp99_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp99_AST);
			match(ATTRIBUTE_GROUP);
			{
			_loop150:
			do {
				switch ( LA(1)) {
				case ATTRIBUTE_STMT:
				case RULE_REF:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeItem();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp100_AST = null;
					tmp100_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp100_AST);
					match(STRING_LITERAL);
					break;
				}
				default:
				{
					break _loop150;
				}
				}
			} while (true);
			}
			match(RPAREN);
			attributeGroup_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_52);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeGroup_AST;
	}
	
	public final void attributeBlock() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeBlock_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LCURLY:
			{
				action();
				astFactory.addASTChild(currentAST, returnAST);
				{
				{
				_loop154:
				do {
					if ((_tokenSet_25.member(LA(1)))) {
						attributeItem();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop154;
					}
					
				} while (true);
				}
				}
				GrammarAST tmp102_AST = null;
				tmp102_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp102_AST);
				match(OR);
				attributeBlock();
				astFactory.addASTChild(currentAST, returnAST);
				attributeBlock_AST = (GrammarAST)currentAST.root;
				break;
			}
			case RCURLY:
			case ATTRIBUTE_STMT:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				{
				_loop156:
				do {
					if ((_tokenSet_25.member(LA(1)))) {
						attributeItem();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop156;
					}
					
				} while (true);
				}
				attributeBlock_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_54);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeBlock_AST;
	}
	
	public final void attributeElement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST attributeElement_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case ATTRIBUTE:
			{
				attribute();
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case CARET:
				{
					GrammarAST tmp103_AST = null;
					tmp103_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp103_AST);
					match(CARET);
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				attributeGroup();
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case CARET:
				{
					GrammarAST tmp104_AST = null;
					tmp104_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp104_AST);
					match(CARET);
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			case ATTRIBUTE_STMT:
			{
				GrammarAST tmp105_AST = null;
				tmp105_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp105_AST);
				match(ATTRIBUTE_STMT);
				attributeBlock();
				astFactory.addASTChild(currentAST, returnAST);
				match(RCURLY);
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp107_AST = null;
				tmp107_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp107_AST);
				match(LPAREN);
				{
				_loop162:
				do {
					if ((_tokenSet_25.member(LA(1)))) {
						attributeItem();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop162;
					}
					
				} while (true);
				}
				GrammarAST tmp108_AST = null;
				tmp108_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp108_AST);
				match(RPAREN);
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				treeConstructor();
				astFactory.addASTChild(currentAST, returnAST);
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp109_AST = null;
				tmp109_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp109_AST);
				match(CURRENT_TREE);
				{
				switch ( LA(1)) {
				case BANG:
				{
					GrammarAST tmp110_AST = null;
					tmp110_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp110_AST);
					match(BANG);
					break;
				}
				case OPTIONS:
				case SEMI:
				case LCURLY:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case LITERAL_exception:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				attributeElement_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_28);
			} else {
			  throw ex;
			}
		}
		returnAST = attributeElement_AST;
	}
	
	public final void treeConstructor() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST treeConstructor_AST = null;
		
		try {      // for error handling
			GrammarAST tmp111_AST = null;
			tmp111_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp111_AST);
			match(TREE_CONSTRUCTOR);
			attributeItem();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt166=0;
			_loop166:
			do {
				if ((_tokenSet_25.member(LA(1)))) {
					attributeItem();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt166>=1 ) { break _loop166; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt166++;
			} while (true);
			}
			match(RPAREN);
			treeConstructor_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_28);
			} else {
			  throw ex;
			}
		}
		returnAST = treeConstructor_AST;
	}
	
	public final void notTerminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST notTerminal_AST = null;
		Token  cl = null;
		GrammarAST cl_AST = null;
		Token  tr = null;
		GrammarAST tr_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case KEYWORD:
			{
				cl = LT(1);
				cl_AST = (GrammarAST)astFactory.create(cl);
				astFactory.addASTChild(currentAST, cl_AST);
				match(KEYWORD);
				notTerminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case TOKEN_REF:
			{
				tr = LT(1);
				tr_AST = (GrammarAST)astFactory.create(tr);
				astFactory.addASTChild(currentAST, tr_AST);
				match(TOKEN_REF);
				notTerminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp113_AST = null;
				tmp113_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp113_AST);
				match(STRING_LITERAL);
				notTerminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_49);
			} else {
			  throw ex;
			}
		}
		returnAST = notTerminal_AST;
	}
	
	public final void setElement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST setElement_AST = null;
		
		try {      // for error handling
			if ((LA(1)==KEYWORD) && (LA(2)==SEMI||LA(2)==OR||LA(2)==RPAREN)) {
				GrammarAST tmp114_AST = null;
				tmp114_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp114_AST);
				match(KEYWORD);
				setElement_AST = (GrammarAST)currentAST.root;
			}
			else if (((LA(1)==TOKEN_REF))&&(gtype!=LEXER_GRAMMAR)) {
				GrammarAST tmp115_AST = null;
				tmp115_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp115_AST);
				match(TOKEN_REF);
				setElement_AST = (GrammarAST)currentAST.root;
			}
			else if (((LA(1)==STRING_LITERAL))&&(gtype!=LEXER_GRAMMAR)) {
				GrammarAST tmp116_AST = null;
				tmp116_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp116_AST);
				match(STRING_LITERAL);
				setElement_AST = (GrammarAST)currentAST.root;
			}
			else if ((LA(1)==KEYWORD) && (LA(2)==RANGE)) {
				range();
				astFactory.addASTChild(currentAST, returnAST);
				setElement_AST = (GrammarAST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_37);
			} else {
			  throw ex;
			}
		}
		returnAST = setElement_AST;
	}
	
	public final void rootNode() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rootNode_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case RULE_REF:
			case ATTRIBUTE:
			{
				attrLabel();
				astFactory.addASTChild(currentAST, returnAST);
				terminal();
				astFactory.addASTChild(currentAST, returnAST);
				rootNode_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case WILDCARD:
			{
				terminal();
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case BANG:
				case CARET:
				{
					ast_suffix();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case LCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				rootNode_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_36);
			} else {
			  throw ex;
			}
		}
		returnAST = rootNode_AST;
	}
	
	public final void idList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST idList_AST = null;
		
		try {      // for error handling
			{
			int _cnt200=0;
			_loop200:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt200>=1 ) { break _loop200; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt200++;
			} while (true);
			}
			idList_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = idList_AST;
	}
	
/** Match anything that looks like an ID and return tree as token type ID */
	public final void idToken() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST idToken_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				GrammarAST tmp117_AST = null;
				tmp117_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp117_AST);
				match(TOKEN_REF);
				if ( inputState.guessing==0 ) {
					idToken_AST = (GrammarAST)currentAST.root;
					idToken_AST.setType(ID);
				}
				idToken_AST = (GrammarAST)currentAST.root;
				break;
			}
			case RULE_REF:
			{
				GrammarAST tmp118_AST = null;
				tmp118_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp118_AST);
				match(RULE_REF);
				if ( inputState.guessing==0 ) {
					idToken_AST = (GrammarAST)currentAST.root;
					idToken_AST.setType(ID);
				}
				idToken_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = idToken_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 576464918421700688L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 1932735283280L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { -5116062829216006048L, 1174769L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 576460752303423488L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { -4017313964009455598L, 517L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 576473946442956800L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 4035229743627370544L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 4035229881066323968L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { -5116064753361354734L, 1175025L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 4035229674907893760L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { -576454084366696432L, 5L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 576474083881910272L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 630517279410356224L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 630503947831869440L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	private static final long[] mk_tokenSet_15() {
		long[] data = { -9223371968135299072L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
	private static final long[] mk_tokenSet_16() {
		long[] data = { 630504085270822912L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
	private static final long[] mk_tokenSet_17() {
		long[] data = { 576496074114465792L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
	private static final long[] mk_tokenSet_18() {
		long[] data = { 665426859491590160L, 1178865L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
	private static final long[] mk_tokenSet_19() {
		long[] data = { 17179869184L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
	private static final long[] mk_tokenSet_20() {
		long[] data = { 576460889742376960L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
	private static final long[] mk_tokenSet_21() {
		long[] data = { 648538223449997312L, 1174577L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
	private static final long[] mk_tokenSet_22() {
		long[] data = { -203763459806920686L, 1572081L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
	private static final long[] mk_tokenSet_23() {
		long[] data = { -203763459806920686L, 2097143L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
	private static final long[] mk_tokenSet_24() {
		long[] data = { 4035229674907893762L, 1L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
	private static final long[] mk_tokenSet_25() {
		long[] data = { 2199023255552L, 27665L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
	private static final long[] mk_tokenSet_26() {
		long[] data = { -9223369769112043504L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
	private static final long[] mk_tokenSet_27() {
		long[] data = { 17179869184L, 64L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
	private static final long[] mk_tokenSet_28() {
		long[] data = { 648538360888950800L, 1174769L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
	private static final long[] mk_tokenSet_29() {
		long[] data = { 576460889742376960L, 9L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
	private static final long[] mk_tokenSet_30() {
		long[] data = { -8574833830584647664L, 1174641L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
	private static final long[] mk_tokenSet_31() {
		long[] data = { -3662532382411390960L, 2096369L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_31 = new BitSet(mk_tokenSet_31());
	private static final long[] mk_tokenSet_32() {
		long[] data = { 648538206270128128L, 1174641L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_32 = new BitSet(mk_tokenSet_32());
	private static final long[] mk_tokenSet_33() {
		long[] data = { -203763459806920686L, 2097137L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_33 = new BitSet(mk_tokenSet_33());
	private static final long[] mk_tokenSet_34() {
		long[] data = { 936768599601709072L, 2092273L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_34 = new BitSet(mk_tokenSet_34());
	private static final long[] mk_tokenSet_35() {
		long[] data = { 5548454618029096976L, 2096369L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_35 = new BitSet(mk_tokenSet_35());
	private static final long[] mk_tokenSet_36() {
		long[] data = { 648538206270128128L, 1174545L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_36 = new BitSet(mk_tokenSet_36());
	private static final long[] mk_tokenSet_37() {
		long[] data = { 17179869184L, 96L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_37 = new BitSet(mk_tokenSet_37());
	private static final long[] mk_tokenSet_38() {
		long[] data = { 648538223449997312L, 1174769L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_38 = new BitSet(mk_tokenSet_38());
	private static final long[] mk_tokenSet_39() {
		long[] data = { 4035229674907893762L, 129L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_39 = new BitSet(mk_tokenSet_39());
	private static final long[] mk_tokenSet_40() {
		long[] data = { 4035229743627370498L, 385L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_40 = new BitSet(mk_tokenSet_40());
	private static final long[] mk_tokenSet_41() {
		long[] data = { 4035229692087762946L, 481L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_41 = new BitSet(mk_tokenSet_41());
	private static final long[] mk_tokenSet_42() {
		long[] data = { 580964489369747456L, 513L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_42 = new BitSet(mk_tokenSet_42());
	private static final long[] mk_tokenSet_43() {
		long[] data = { 660923036525920256L, 1174545L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_43 = new BitSet(mk_tokenSet_43());
	private static final long[] mk_tokenSet_44() {
		long[] data = { 648538137550651392L, 1174545L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_44 = new BitSet(mk_tokenSet_44());
	private static final long[] mk_tokenSet_45() {
		long[] data = { -3662532382411390960L, 1572081L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_45 = new BitSet(mk_tokenSet_45());
	private static final long[] mk_tokenSet_46() {
		long[] data = { -203763459806920686L, 2096625L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_46 = new BitSet(mk_tokenSet_46());
	private static final long[] mk_tokenSet_47() {
		long[] data = { 5548454618029096976L, 1567985L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_47 = new BitSet(mk_tokenSet_47());
	private static final long[] mk_tokenSet_48() {
		long[] data = { 648535938527395840L, 1048576L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_48 = new BitSet(mk_tokenSet_48());
	private static final long[] mk_tokenSet_49() {
		long[] data = { 5548454618029096976L, 1572081L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_49 = new BitSet(mk_tokenSet_49());
	private static final long[] mk_tokenSet_50() {
		long[] data = { 5272609278291607568L, 1178865L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_50 = new BitSet(mk_tokenSet_50());
	private static final long[] mk_tokenSet_51() {
		long[] data = { 648538223449997328L, 1174769L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_51 = new BitSet(mk_tokenSet_51());
	private static final long[] mk_tokenSet_52() {
		long[] data = { 648538360888950800L, 1178865L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_52 = new BitSet(mk_tokenSet_52());
	private static final long[] mk_tokenSet_53() {
		long[] data = { 5260224241877385232L, 1178865L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_53 = new BitSet(mk_tokenSet_53());
	private static final long[] mk_tokenSet_54() {
		long[] data = { 137438953472L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_54 = new BitSet(mk_tokenSet_54());
	
	}
