// $ANTLR 2.7.6 (2005-12-22): "YggdrasilAssign.g" -> "YggdrasilAssignTokenTypes.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
	package org.antlr_yggdrasil.generated;
	import org.antlr_yggdrasil.tool.*;
	import org.antlr_yggdrasil.tool.Grammar;
	import java.util.*;
	import org.antlr_yggdrasil.analysis.*;
	import java.io.*;
	import org.antlr_yggdrasil.tool.ErrorManager;
	import org.antlr_yggdrasil.tool.GrammarAST;
	import org.antlr_yggdrasil.runtime.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** [Warning: TJP says that this is probably out of date as of 11/19/2005,
 *   but since it's probably still useful, I'll leave in.  Don't have energy
 *   to update at the moment.]
 *
 *  Compute the token types for all literals and rules etc..  There are
 *  a few different cases to consider for grammar types and a few situations
 *  within.
 *
 *  CASE 1 : pure parser grammar
 *	a) Any reference to a token gets a token type.
 *  b) The tokens section may alias a token name to a string or char
 *
 *  CASE 2 : pure lexer grammar
 *  a) Import token vocabulary if available. Set token types for any new tokens
 *     to values above last imported token type
 *  b) token rule definitions get token types if not already defined
 *  c) literals do NOT get token types
 *
 *  CASE 3 : merged parser / lexer grammar
 *	a) Any char or string literal gets a token type in a parser rule
 *  b) Any reference to a token gets a token type if not referencing
 *     a fragment lexer rule
 *  c) The tokens section may alias a token name to a string or char
 *     which must add a rule to the lexer
 *  d) token rule definitions get token types if not already defined
 *  e) token rule definitions may also alias a token name to a literal.
 *     E.g., Rule 'FOR : "for";' will alias FOR to "for" in the sense that
 *     references to either in the parser grammar will yield the token type
 *
 *  What this pass does:
 *
 *  0. Collects basic info about the grammar like grammar name and type;
 *     Oh, I have go get the options in case they affect the token types.
 *     E.g., tokenVocab option.
 *     Imports any token vocab name/type pairs into a local hashtable.
 *  1. Finds a list of all literals and token names.
 *  2. Finds a list of all token name rule definitions;
 *     no token rules implies pure parser.
 *  3. Finds a list of all simple token rule defs of form "<NAME> : <literal>;"
 *     and aliases them.
 *  4. Walks token names table and assign types to any unassigned
 *  5. Walks aliases and assign types to referenced literals
 *  6. Walks literals, assigning types if untyped
 *  4. Informs the Grammar object of the type definitions such as:
 *     g.defineToken(<charliteral>, ttype);
 *     g.defineToken(<stringliteral>, ttype);
 *     g.defineToken(<tokenID>, ttype);
 *     where some of the ttype values will be the same for aliases tokens.
 */
public class YggdrasilAssignTokenTypes extends antlr.TreeParser       implements YggdrasilAssignTokenTypesTokenTypes
 {

    public void reportError(RecognitionException ex) {
		Token token = null;
		if ( ex instanceof MismatchedTokenException ) {
			token = ((MismatchedTokenException)ex).token;
		}
		else if ( ex instanceof NoViableAltException ) {
			token = ((NoViableAltException)ex).token;
		}
        ErrorManager.syntaxError(
            ErrorManager.MSG_SYNTAX_ERROR,
            token,
            "assign.types: "+ex.toString(),
            ex);
    }

protected Grammar grammar;
protected Map stringLiterals = new LinkedHashMap(); // Map<literal,Integer>
protected Map tokens = new LinkedHashMap();         // Map<name,Integer>
protected TypeMap types = new TypeMap();
/** Track actual lexer rule defs so we don't get repeated token defs in 
 *  generated lexer.
 */
protected Set tokenRuleDefs = new HashSet();        // Set<name>
protected Map aliases = new LinkedHashMap();        // Map<name,literal>
protected String currentRuleName;
protected static final Integer UNASSIGNED = new Integer(-1);
protected static final Integer UNASSIGNED_IN_PARSER_RULE = new Integer(-2);

/** Track string literals in any non-lexer rule (could be in tokens{} section) */

public TypeMap getTypes() {
	return types;
}

protected void trackString(GrammarAST t) {
	// if lexer, don't allow aliasing in tokens section
	if ( currentRuleName==null && grammar.type==Grammar.LEXER ) {
		ErrorManager.grammarError(ErrorManager.MSG_CANNOT_ALIAS_TOKENS_IN_LEXER,
								  grammar,
								  t.token,
								  t.getText());
		return;
	}
	// if not in a combined grammar rule or lexer rule, cannot reference literals
	// (unless defined previously via tokenVocab option)
	if ( grammar.type!=Grammar.COMBINED && grammar.type!=Grammar.LEXER &&
	     grammar.getTokenType(t.getText())==Label.INVALID )
    {
		ErrorManager.grammarError(ErrorManager.MSG_LITERAL_NOT_ASSOCIATED_WITH_LEXER_RULE,
								  grammar,
								  t.token,
								  t.getText());
	}
	// otherwise add literal to token types if referenced from parser rule
	// or in the tokens{} section
	if ( (currentRuleName==null ||
         Character.isLowerCase(currentRuleName.charAt(0))) &&
         grammar.getTokenType(t.getText())==Label.INVALID )
	{
		stringLiterals.put(t.getText(), UNASSIGNED_IN_PARSER_RULE);
	}
}

protected void trackToken(GrammarAST t) {
	// imported token names might exist, only add if new
	if ( grammar.getTokenType(t.getText())==Label.INVALID ) {
		tokens.put(t.getText(), UNASSIGNED);
	}
}

protected void trackTokenRule(GrammarAST t,
							  GrammarAST modifier,
							  GrammarAST block)
{
	// imported token names might exist, only add if new
	if ( grammar.type==Grammar.LEXER || grammar.type==Grammar.COMBINED ) {
		if ( !Character.isUpperCase(t.getText().charAt(0)) ) {
			return;
		}
		int existing = grammar.getTokenType(t.getText());
		if ( existing==Label.INVALID ) {
			tokens.put(t.getText(), UNASSIGNED);
		}
		// look for "<TOKEN> : <literal> ;" pattern
		GrammarAST stringAlias = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(BLOCK)).add((GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ALT)).add((GrammarAST)astFactory.create(STRING_LITERAL)))));
		GrammarAST charAlias = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(BLOCK)).add((GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ALT)).add((GrammarAST)astFactory.create(KEYWORD)))));
		if ( matchesStructure(block,charAlias) ||
             matchesStructure(block,stringAlias) )
		{
			alias(t, (GrammarAST)block.getFirstChild().getFirstChild());
			tokenRuleDefs.add(t.getText());
		}
	}
	// else error
}

protected boolean matchesStructure(AST a, AST b) {
	// the empty tree is always a subset of any tree.
	if (b == null || a==null) {
		return true;
	}

	// check roots first.
	if ( a.getType()!=b.getType() ) {
		return false;
	}

	// if roots match, do full list partial match test on children.
	if (a.getFirstChild() != null) {
		if (!matchesStructure(a.getFirstChild(),b.getFirstChild())) {
			return false;
		}
	}
	return true;
}

protected void alias(GrammarAST t, GrammarAST s) {
	aliases.put(t.getText(), s.getText());
}

protected void assignTypes() {
	/*
	System.out.println("stringLiterals="+stringLiterals);
	System.out.println("tokens="+tokens);
	System.out.println("aliases="+aliases);
	*/

	assignTokenIDTypes();

	aliasTokenIDsAndLiterals();

	assignStringTypes();

	/*
	System.out.println("AFTER:");
	System.out.println("stringLiterals="+stringLiterals);
	System.out.println("tokens="+tokens);
	System.out.println("aliases="+aliases);
	*/

	notifyGrammarObject();
}

	protected void assignStringTypes() {
		// walk string literals assigning types to unassigned ones
		Set s = stringLiterals.keySet();
		for (Iterator it = s.iterator(); it.hasNext();) {
			String lit = (String) it.next();
			Integer oldTypeI = (Integer)stringLiterals.get(lit);
			int oldType = oldTypeI.intValue();
			if ( oldType<Label.MIN_TOKEN_TYPE ) {
				Integer typeI = new Integer(grammar.getNewTokenType());
				stringLiterals.put(lit, typeI);
				// if string referenced in combined grammar parser rule,
				// automatically define in the generated lexer
				grammar.defineLexerRuleForStringLiteral(lit, typeI.intValue());
			}
		}
	}

	protected void aliasTokenIDsAndLiterals() {
		if ( grammar.type==Grammar.LEXER ) {
			return; // strings/chars are never token types in LEXER
		}
		// walk aliases if any and assign types to aliased literals if literal
		// was referenced
		Set s = aliases.keySet();
		for (Iterator it = s.iterator(); it.hasNext();) {
			String tokenID = (String) it.next();
			String literal = (String)aliases.get(tokenID);
			if ( literal.charAt(0)==Grammar.QUOTE_CHAR && stringLiterals.get(literal)!=null ) {
				stringLiterals.put(literal, tokens.get(tokenID));
				// an alias still means you need a lexer rule for it
				Integer typeI = (Integer)tokens.get(tokenID);
				if ( !tokenRuleDefs.contains(tokenID) ) {
					grammar.defineLexerRuleForAliasedStringLiteral(tokenID, literal, typeI.intValue());
				}
			}
		}
	}

	protected void assignTokenIDTypes() {
		// walk token names, assigning values if unassigned
		Set s = tokens.keySet();
		for (Iterator it = s.iterator(); it.hasNext();) {
			String tokenID = (String) it.next();
			if ( tokens.get(tokenID)==UNASSIGNED ) {
				tokens.put(tokenID, new Integer(grammar.getNewTokenType()));
			}
		}
	}

	protected void notifyGrammarObject() {
		Set s = tokens.keySet();
		for (Iterator it = s.iterator(); it.hasNext();) {
			String tokenID = (String) it.next();
			int ttype = ((Integer)tokens.get(tokenID)).intValue();
			grammar.defineToken(tokenID, ttype);
		}
		s = stringLiterals.keySet();
		for (Iterator it = s.iterator(); it.hasNext();) {
			String lit = (String) it.next();
			int ttype = ((Integer)stringLiterals.get(lit)).intValue();
			grammar.defineToken(lit, ttype);
		}
	}

	protected void init(Grammar g) {
		this.grammar = g;
		g.setTypes(types);
		g.initTypeMap();
	}
public YggdrasilAssignTokenTypes() {
	tokenNames = _tokenNames;
}

	public final void file(AST _t,
		Grammar g
	) throws RecognitionException {
		
		GrammarAST file_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
			init(g);
		
		
		try {      // for error handling
			{
			_loop3:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_header)) {
					fileheader(_t);
					_t = _retTree;
				}
				else {
					break _loop3;
				}
				
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				typeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			grammar(_t,g);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void fileheader(AST _t) throws RecognitionException {
		
		GrammarAST fileheader_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t7 = _t;
			GrammarAST tmp1_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_header);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp2_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp3_AST_in = (GrammarAST)_t;
			match(_t,LCURLY);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case TOKENS:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t7;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void typeDecls(AST _t) throws RecognitionException {
		
		GrammarAST typeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t23 = _t;
			GrammarAST tmp4_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop25:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LCURLY||_t.getType()==LITERAL_atomic)) {
					attributeTypeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop25;
				}
				
			} while (true);
			}
			_t = __t23;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final Map  optionsSpec(AST _t) throws RecognitionException {
		Map opts=new HashMap();
		
		GrammarAST optionsSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t62 = _t;
			GrammarAST tmp5_AST_in = (GrammarAST)_t;
			match(_t,OPTIONS);
			_t = _t.getFirstChild();
			{
			int _cnt64=0;
			_loop64:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN)) {
					option(_t,opts);
					_t = _retTree;
				}
				else {
					if ( _cnt64>=1 ) { break _loop64; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt64++;
			} while (true);
			}
			_t = __t62;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return opts;
	}
	
	public final void grammar(AST _t,
		Grammar g
	) throws RecognitionException {
		
		GrammarAST grammar_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LEXER_GRAMMAR:
			{
				AST __t52 = _t;
				GrammarAST tmp6_AST_in = (GrammarAST)_t;
				match(_t,LEXER_GRAMMAR);
				_t = _t.getFirstChild();
				grammar.type = Grammar.LEXER;
				grammarSpec(_t);
				_t = _retTree;
				_t = __t52;
				_t = _t.getNextSibling();
				break;
			}
			case PARSER_GRAMMAR:
			{
				AST __t53 = _t;
				GrammarAST tmp7_AST_in = (GrammarAST)_t;
				match(_t,PARSER_GRAMMAR);
				_t = _t.getFirstChild();
				grammar.type = Grammar.PARSER;
				grammarSpec(_t);
				_t = _retTree;
				_t = __t53;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_GRAMMAR:
			{
				AST __t54 = _t;
				GrammarAST tmp8_AST_in = (GrammarAST)_t;
				match(_t,TREE_GRAMMAR);
				_t = _t.getFirstChild();
				grammar.type = Grammar.TREE_PARSER;
				grammarSpec(_t);
				_t = _retTree;
				_t = __t54;
				_t = _t.getNextSibling();
				break;
			}
			case COMBINED_GRAMMAR:
			{
				AST __t55 = _t;
				GrammarAST tmp9_AST_in = (GrammarAST)_t;
				match(_t,COMBINED_GRAMMAR);
				_t = _t.getFirstChild();
				grammar.type = Grammar.COMBINED;
				grammarSpec(_t);
				_t = _retTree;
				_t = __t55;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			assignTypes();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokensSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokensSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t74 = _t;
			GrammarAST tmp10_AST_in = (GrammarAST)_t;
			match(_t,TOKENS);
			_t = _t.getFirstChild();
			{
			int _cnt76=0;
			_loop76:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN||_t.getType()==TOKEN_REF)) {
					tokenSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt76>=1 ) { break _loop76; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt76++;
			} while (true);
			}
			_t = __t74;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void action(AST _t) throws RecognitionException {
		
		GrammarAST action_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t131 = _t;
			GrammarAST tmp11_AST_in = (GrammarAST)_t;
			match(_t,RCURLY);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t131;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t13 = _t;
			GrammarAST tmp12_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop15:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==SEMI||_t.getType()==LITERAL_public||_t.getType()==LITERAL_import)) {
					grammarAttributeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop15;
				}
				
			} while (true);
			}
			_t = __t13;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecl(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_public:
				{
					GrammarAST tmp13_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_public);
					_t = _t.getNextSibling();
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				attributeVarDecl(_t,null);
				_t = _retTree;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp14_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_import);
				_t = _t.getNextSibling();
				GrammarAST tmp15_AST_in = (GrammarAST)_t;
				match(_t,STRING);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeVarDecl(AST _t,
		TypeInfo info 
	) throws RecognitionException {
		
		GrammarAST attributeVarDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST data = null;
		GrammarAST i = null;
			ArrayList typeArgs = null;
			String type = null;
		
		
		try {      // for error handling
			AST __t33 = _t;
			GrammarAST tmp16_AST_in = (GrammarAST)_t;
			match(_t,SEMI);
			_t = _t.getFirstChild();
			t = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp17_AST_in = (GrammarAST)_t;
				match(_t,OPEN_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				typeArgs = new ArrayList();
				{
				int _cnt36=0;
				_loop36:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						data = (GrammarAST)_t;
						match(_t,ID);
						_t = _t.getNextSibling();
						typeArgs.add(data.getText());
					}
					else {
						if ( _cnt36>=1 ) { break _loop36; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt36++;
				} while (true);
				}
				GrammarAST tmp18_AST_in = (GrammarAST)_t;
				match(_t,CLOSE_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			i = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
				if (typeArgs == null)
							type = t.getText();
						else
							type = types.addGenericType(t.getText(),
									typeArgs);
			
						if (info != null)
							info.addField(type, i.getText());
						else
							types.addVariable(i.getText(), type);
					
			_t = __t33;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ruleAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST ruleAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t19 = _t;
			GrammarAST tmp19_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop21:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SEMI:
				{
					attributeVarDecl(_t,null);
					_t = _retTree;
					break;
				}
				case ID:
				case LITERAL_new:
				case LITERAL_using:
				{
					attributeUseDecl(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					break _loop21;
				}
				}
			} while (true);
			}
			_t = __t19;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeUseDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeUseDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp20_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp21_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getNextSibling();
				{
				GrammarAST tmp22_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ID:
				case SEMI:
				case DOT_TEXT:
				case LITERAL_new:
				case LITERAL_using:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop49:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop49;
					}
					
				} while (true);
				}
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp23_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_new);
				_t = _t.getNextSibling();
				GrammarAST tmp24_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp25_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_using);
				_t = _t.getNextSibling();
				GrammarAST tmp26_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeTypeDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeTypeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST i = null;
		GrammarAST i1 = null;
		GrammarAST i2 = null;
			TypeInfo info = null;
			boolean isNative = false;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_atomic:
			{
				AST __t27 = _t;
				GrammarAST tmp27_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_atomic);
				_t = _t.getFirstChild();
				GrammarAST tmp28_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_native);
				_t = _t.getNextSibling();
				i = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
					info = new TypeInfo(i.getText());
							info.setNative(true);
							info.setAtomic(true);
							types.addType(info);
						
				_t = __t27;
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				AST __t28 = _t;
				GrammarAST tmp29_AST_in = (GrammarAST)_t;
				match(_t,LCURLY);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_native:
				{
					GrammarAST tmp30_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_native);
					_t = _t.getNextSibling();
					isNative = true;
					break;
				}
				case ID:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				i1 = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				i2 = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
					TypeInfo parent = types.getInfo(i1.getText());
								info = new TypeInfo(i2.getText(), parent);
								info.setArrayed(parent.isArrayed());
						
								if (isNative)
									info.setNative(true);
							
				{
				_loop31:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI)) {
						attributeVarDecl(_t,info);
						_t = _retTree;
					}
					else {
						break _loop31;
					}
					
				} while (true);
				}
				types.addType(info);
				_t = __t28;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void idQualifier(AST _t) throws RecognitionException {
		
		GrammarAST idQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp31_AST_in = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case ID:
			case SYN_SEMPRED:
			case BANGEDUP:
			case SEMI:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arrayQualifier(AST _t) throws RecognitionException {
		
		GrammarAST arrayQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t40 = _t;
			GrammarAST tmp32_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp33_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp34_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case DOT_TEXT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop44:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t40;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void grammarSpec(AST _t) throws RecognitionException {
		
		GrammarAST grammarSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST cmt = null;
		Map opts=null;
		
		try {      // for error handling
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			grammar.setName(id.getText());
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOC_COMMENT:
			{
				cmt = (GrammarAST)_t;
				match(_t,DOC_COMMENT);
				_t = _t.getNextSibling();
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_STMT:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			rules(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		GrammarAST rules_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt83=0;
			_loop83:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case RULE:
				{
					rule(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_COLON:
				{
					constructorRule(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					if ( _cnt83>=1 ) { break _loop83; } else {throw new NoViableAltException(_t);}
				}
				}
				_cnt83++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void option(AST _t,
		Map opts
	) throws RecognitionException {
		
		GrammarAST option_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		
		String key=null;
		Object value=null;
		
		
		try {      // for error handling
			AST __t66 = _t;
			GrammarAST tmp35_AST_in = (GrammarAST)_t;
			match(_t,ASSIGN);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			key=id.getText();
			value=optionValue(_t);
			_t = _retTree;
			_t = __t66;
			_t = _t.getNextSibling();
			
			opts.put(key,value);
			// check for grammar-level option to import vocabulary
			if ( currentRuleName==null && key.equals("tokenVocab") ) {
			grammar.importTokenVocabulary((String)value);
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final Object  optionValue(AST _t) throws RecognitionException {
		Object value=null;
		
		GrammarAST optionValue_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST s = null;
		GrammarAST c = null;
		GrammarAST i = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				id = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				value = id.getText();
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				value = s.getText();
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				value = c.getText();
				break;
			}
			case INT:
			{
				i = (GrammarAST)_t;
				match(_t,INT);
				_t = _t.getNextSibling();
				value = new Integer(i.getText());
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return value;
	}
	
	public final void charSet(AST _t) throws RecognitionException {
		
		GrammarAST charSet_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t69 = _t;
			GrammarAST tmp36_AST_in = (GrammarAST)_t;
			match(_t,CHARSET);
			_t = _t.getFirstChild();
			charSetElement(_t);
			_t = _retTree;
			_t = __t69;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void charSetElement(AST _t) throws RecognitionException {
		
		GrammarAST charSetElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		GrammarAST c3 = null;
		GrammarAST c4 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				break;
			}
			case OR:
			{
				AST __t71 = _t;
				GrammarAST tmp37_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t71;
				_t = _t.getNextSibling();
				break;
			}
			case RANGE:
			{
				AST __t72 = _t;
				GrammarAST tmp38_AST_in = (GrammarAST)_t;
				match(_t,RANGE);
				_t = _t.getFirstChild();
				c3 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c4 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t72;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tokenSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokenSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST i = null;
		GrammarAST t2 = null;
		GrammarAST c = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				trackToken(t);
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp39_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					i = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN:
				case TOKEN_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN:
			{
				AST __t79 = _t;
				GrammarAST tmp40_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getFirstChild();
				t2 = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				trackToken(t2);
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp41_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp42_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case KEYWORD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				trackString(c); alias(t2,c);
				_t = __t79;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		GrammarAST rule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST m = null;
		GrammarAST b = null;
		
		try {      // for error handling
			AST __t85 = _t;
			GrammarAST tmp43_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			currentRuleName=id.getText();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				m = _t==ASTNULL ? null : (GrammarAST)_t;
				modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			b = _t==ASTNULL ? null : (GrammarAST)_t;
			block(_t);
			_t = _retTree;
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp44_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			trackTokenRule(id,m,b);
			_t = __t85;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void constructorRule(AST _t) throws RecognitionException {
		
		GrammarAST constructorRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t92 = _t;
			GrammarAST tmp45_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_COLON);
			_t = _t.getFirstChild();
			GrammarAST tmp46_AST_in = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			{
			int _cnt94=0;
			_loop94:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt94>=1 ) { break _loop94; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt94++;
			} while (true);
			}
			_t = __t92;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void modifier(AST _t) throws RecognitionException {
		
		GrammarAST modifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_protected:
			{
				GrammarAST tmp47_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_protected);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_public:
			{
				GrammarAST tmp48_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_public);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_private:
			{
				GrammarAST tmp49_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_private);
				_t = _t.getNextSibling();
				break;
			}
			case FRAGMENT:
			{
				GrammarAST tmp50_AST_in = (GrammarAST)_t;
				match(_t,FRAGMENT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void block(AST _t) throws RecognitionException {
		
		GrammarAST block_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t97 = _t;
			GrammarAST tmp51_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt100=0;
			_loop100:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					alternative(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt100>=1 ) { break _loop100; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt100++;
			} while (true);
			}
			GrammarAST tmp52_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t97;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionGroup(AST _t) throws RecognitionException {
		
		GrammarAST exceptionGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt107=0;
			_loop107:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_exception)) {
					exceptionSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt107>=1 ) { break _loop107; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt107++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeItem(AST _t) throws RecognitionException {
		
		GrammarAST attributeItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			attributeElement(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		GrammarAST alternative_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t102 = _t;
			GrammarAST tmp53_AST_in = (GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt104=0;
			_loop104:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt104>=1 ) { break _loop104; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt104++;
			} while (true);
			}
			GrammarAST tmp54_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t102;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		GrammarAST element_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case RANGE:
			case CHAR_RANGE:
			case SET:
			case BANGEDUP:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					atom(_t);
					_t = _retTree;
					break;
				}
				case NOT:
				{
					AST __t123 = _t;
					GrammarAST tmp55_AST_in = (GrammarAST)_t;
					match(_t,NOT);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					_t = __t123;
					_t = _t.getNextSibling();
					break;
				}
				case RANGE:
				{
					AST __t124 = _t;
					GrammarAST tmp56_AST_in = (GrammarAST)_t;
					match(_t,RANGE);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					atom(_t);
					_t = _retTree;
					_t = __t124;
					_t = _t.getNextSibling();
					break;
				}
				case CHAR_RANGE:
				{
					AST __t125 = _t;
					GrammarAST tmp57_AST_in = (GrammarAST)_t;
					match(_t,CHAR_RANGE);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					atom(_t);
					_t = _retTree;
					_t = __t125;
					_t = _t.getNextSibling();
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case BANGEDUP:
				{
					ebnf(_t);
					_t = _retTree;
					break;
				}
				case TREE_BEGIN:
				{
					tree(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					atom(_t);
					_t = _retTree;
					break;
				}
				case NOT:
				{
					AST __t128 = _t;
					GrammarAST tmp58_AST_in = (GrammarAST)_t;
					match(_t,NOT);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					_t = __t128;
					_t = _t.getNextSibling();
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case BANGEDUP:
				{
					ebnf(_t);
					_t = _retTree;
					break;
				}
				case TREE_BEGIN:
				{
					tree(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeElement(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				attributeElement(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t129 = _t;
				GrammarAST tmp59_AST_in = (GrammarAST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t129;
				_t = _t.getNextSibling();
				break;
			}
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				break;
			}
			case SYN_SEMPRED:
			{
				GrammarAST tmp60_AST_in = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp61_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionSpec(AST _t) throws RecognitionException {
		
		GrammarAST exceptionSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t109 = _t;
			GrammarAST tmp62_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_exception);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RBRACKET:
			{
				arg_decl(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop112:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_catch)) {
					exceptionHandler(_t);
					_t = _retTree;
				}
				else {
					break _loop112;
				}
				
			} while (true);
			}
			_t = __t109;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void arg_decl(AST _t) throws RecognitionException {
		
		GrammarAST arg_decl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t114 = _t;
			GrammarAST tmp63_AST_in = (GrammarAST)_t;
			match(_t,RBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING:
			{
				GrammarAST tmp64_AST_in = (GrammarAST)_t;
				match(_t,STRING);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp65_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case COLON:
			{
				GrammarAST tmp66_AST_in = (GrammarAST)_t;
				match(_t,COLON);
				_t = _t.getNextSibling();
				{
				int _cnt118=0;
				_loop118:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt118>=1 ) { break _loop118; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt118++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t114;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void exceptionHandler(AST _t) throws RecognitionException {
		
		GrammarAST exceptionHandler_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t120 = _t;
			GrammarAST tmp67_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_catch);
			_t = _t.getFirstChild();
			arg_decl(_t);
			_t = _retTree;
			action(_t);
			_t = _retTree;
			_t = __t120;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void assignment(AST _t) throws RecognitionException {
		
		GrammarAST assignment_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t140 = _t;
			GrammarAST tmp68_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				break;
			}
			case TOKEN_REF:
			{
				GrammarAST tmp69_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp70_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t140;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t) throws RecognitionException {
		
		GrammarAST atom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST c = null;
		GrammarAST s = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				GrammarAST tmp71_AST_in = (GrammarAST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				trackToken(t);
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				trackString(c);
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case WILDCARD:
			{
				GrammarAST tmp72_AST_in = (GrammarAST)_t;
				match(_t,WILDCARD);
				_t = _t.getNextSibling();
				break;
			}
			case SET:
			{
				set(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		GrammarAST ebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANGEDUP:
			{
				AST __t148 = _t;
				GrammarAST tmp73_AST_in = (GrammarAST)_t;
				match(_t,BANGEDUP);
				_t = _t.getFirstChild();
				baseebnf(_t);
				_t = _retTree;
				_t = __t148;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				baseebnf(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tree(AST _t) throws RecognitionException {
		
		GrammarAST tree_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t154 = _t;
			GrammarAST tmp74_AST_in = (GrammarAST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			element(_t);
			_t = _retTree;
			{
			_loop156:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					break _loop156;
				}
				
			} while (true);
			}
			_t = __t154;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ast_suffix(AST _t) throws RecognitionException {
		
		GrammarAST ast_suffix_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case CARET:
			{
				GrammarAST tmp75_AST_in = (GrammarAST)_t;
				match(_t,CARET);
				_t = _t.getNextSibling();
				break;
			}
			case BANG:
			{
				GrammarAST tmp76_AST_in = (GrammarAST)_t;
				match(_t,BANG);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attrLabel(AST _t) throws RecognitionException {
		
		GrammarAST attrLabel_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LABEL_ATTRIBUTE:
			{
				a = (GrammarAST)_t;
				match(_t,LABEL_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			case ASSIGN_ATTRIBUTE:
			{
				GrammarAST tmp77_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SET:
			case BANGEDUP:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop146:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop146;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeElement(AST _t) throws RecognitionException {
		
		GrammarAST attributeElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp78_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				attributeGroup(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp79_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			{
				attributeStatements(_t);
				_t = _retTree;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp80_AST_in = (GrammarAST)_t;
				match(_t,CURRENT_TREE);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp81_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp82_AST_in = (GrammarAST)_t;
				match(_t,LPAREN);
				_t = _t.getNextSibling();
				{
				_loop188:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop188;
					}
					
				} while (true);
				}
				GrammarAST tmp83_AST_in = (GrammarAST)_t;
				match(_t,RPAREN);
				_t = _t.getNextSibling();
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				treeConstructor(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void sempred(AST _t) throws RecognitionException {
		
		GrammarAST sempred_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t133 = _t;
			GrammarAST tmp84_AST_in = (GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t133;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void template(AST _t) throws RecognitionException {
		
		GrammarAST template_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING:
			{
				GrammarAST tmp85_AST_in = (GrammarAST)_t;
				match(_t,STRING);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp86_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				{
				int _cnt138=0;
				_loop138:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt138>=1 ) { break _loop138; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt138++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attribute(AST _t) throws RecognitionException {
		
		GrammarAST attribute_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp87_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop160:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop160;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void baseebnf(AST _t) throws RecognitionException {
		
		GrammarAST baseebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				block(_t);
				_t = _retTree;
				break;
			}
			case OPTIONAL:
			{
				AST __t150 = _t;
				GrammarAST tmp88_AST_in = (GrammarAST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t150;
				_t = _t.getNextSibling();
				break;
			}
			case CLOSURE:
			{
				AST __t151 = _t;
				GrammarAST tmp89_AST_in = (GrammarAST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t151;
				_t = _t.getNextSibling();
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t152 = _t;
				GrammarAST tmp90_AST_in = (GrammarAST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t152;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void set(AST _t) throws RecognitionException {
		
		GrammarAST set_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t164 = _t;
			GrammarAST tmp91_AST_in = (GrammarAST)_t;
			match(_t,SET);
			_t = _t.getFirstChild();
			{
			int _cnt166=0;
			_loop166:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==CHAR_RANGE||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF)) {
					setElement(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt166>=1 ) { break _loop166; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt166++;
			} while (true);
			}
			_t = __t164;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void setElement(AST _t) throws RecognitionException {
		
		GrammarAST setElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		GrammarAST t = null;
		GrammarAST s = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				trackString(c);
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				trackToken(t);
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t168 = _t;
				GrammarAST tmp92_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t168;
				_t = _t.getNextSibling();
				
					trackString(c1);
					trackString(c2);
					
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeGroup(AST _t) throws RecognitionException {
		
		GrammarAST attributeGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t170 = _t;
			GrammarAST tmp93_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_GROUP);
			_t = _t.getFirstChild();
			{
			_loop172:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeItem(_t);
					_t = _retTree;
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp94_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					break _loop172;
				}
				}
			} while (true);
			}
			_t = __t170;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeBlock(AST _t) throws RecognitionException {
		
		GrammarAST attributeBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				{
				_loop175:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop175;
					}
					
				} while (true);
				}
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				{
				_loop177:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop177;
					}
					
				} while (true);
				}
				{
				GrammarAST tmp95_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getNextSibling();
				attributeBlock(_t);
				_t = _retTree;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void attributeStatements(AST _t) throws RecognitionException {
		
		GrammarAST attributeStatements_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t180 = _t;
			GrammarAST tmp96_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			attributeBlock(_t);
			_t = _retTree;
			_t = __t180;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void treeConstructor(AST _t) throws RecognitionException {
		
		GrammarAST treeConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t190 = _t;
			GrammarAST tmp97_AST_in = (GrammarAST)_t;
			match(_t,TREE_CONSTRUCTOR);
			_t = _t.getFirstChild();
			attributeItem(_t);
			_t = _retTree;
			{
			int _cnt192=0;
			_loop192:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt192>=1 ) { break _loop192; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt192++;
			} while (true);
			}
			_t = __t190;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF",
		"STRING"
	};
	
	}
	
