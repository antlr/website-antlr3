/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/* Java main for testing tree construction syntax */

import org.antlr_yggdrasil.runtime.*;
import org.antlr_yggdrasil.runtime.debug.*;
import java.io.*;


class Test {
	protected transient TestFilter filter;
	protected transient TestLexer lexer;
	protected transient TestParser parser;
	protected transient CommonTokenStream stream;
	protected transient MeteredCarrierStream tstream;
	protected transient MeteredCarrierStream t1stream;
	TestParserTree treeWalker1;
	TestParserTreeTree treeWalker2;
	Payload retTok;
	Payload testInfo = null;
	boolean eof = false;
	
	protected transient ANTLRStringStream buffer;
	
	Test(String filename) {
		ANTLRFileStream reader = null;
		try {
			if (filename != null) {
				reader = new ANTLRFileStream(filename);
			}
		} catch (IOException e) {
			System.err.println("cannot open grammar file " + filename);
			System.exit(1);
		}
		
		TraceMeteredEventListener listener = new TraceMeteredEventListener();
		
		try {
			filter = new TestFilter(reader);
			buffer = new ANTLRStringStream("    ");
			lexer = new TestLexer(buffer);
			stream = new CommonTokenStream(lexer);
			parser = new TestParser(stream);
			parser.addListener(listener);
			tstream = new MeteredCarrierStream(new CarrierStream(parser.getTree()));
			treeWalker1 = new TestParserTree(tstream);
			treeWalker1.addListener(listener);
			t1stream = new MeteredCarrierStream(new CarrierStream(treeWalker1.getTree()));
			treeWalker2 = new TestParserTreeTree(t1stream);
			treeWalker2.addListener(listener);
			
		} catch (Exception e) {
			System.err.println("exception: "+e);
		}
		
	}
	
	Test() {
		
	}
	
	public static void main(String[] args) {
		
		String filename = args[0];
		Test test = new Test(filename);
		
		try {
			String data = test.nextString();

			if ((test.testInfo == null) && (test.retTok.getType() != TestFilter.EOF)) {
				test.setTest();
				data = test.nextString();
			}

			while (!test.eof) {
				test.nextTest(data);
				data = test.nextString();
			}
			if (data != "") {
				test.nextTest(data);
			}
		} catch (Exception e) {
			System.err.println("exception: "+e);
		}
	}
	
	public void setTest() {
		testInfo = retTok;
	}
	
	public String nextString() {
		Payload tok = filter.nextToken();
		String s = "";
		
		while (tok.getType() == TestFilter.SEPARATOR) {
			tok = filter.nextToken();
		}
		
		while ((tok != null) && (tok.getType() != TestFilter.SEPARATOR) && tok.getType() != TestFilter.EOF) {
			s += tok.getText();
			tok = filter.nextToken();
		}
		retTok = tok;
		if (retTok.getType() == TestFilter.EOF) {
			eof = true;
		}
		
		return s;
	}
		
	public void nextTest(String data) {
		eof = false;
		buffer.reset();
		parser.reset();
		
		// Print test header; reset for next test.
		System.out.println(testInfo.getText());
		setTest();
		
		try {
			buffer.setInputTo(data);
			stream.reset();
			parser.topLevel();
			
			Carrier ast = parser.getTree();
//			System.out.println("Parse syntax tree:");
//			System.out.println(ast.toStringList());

			treeWalker1.reset();
			treeWalker1.getCarrierStream().setRoot(ast);
			treeWalker1.topLevel();
			
			treeWalker2.reset();
			ast = treeWalker1.getTree();
			treeWalker2.getCarrierStream().setRoot(ast);
			treeWalker2.topLevel();
		} catch (RecognitionException e) {
			
		}
	}
}
