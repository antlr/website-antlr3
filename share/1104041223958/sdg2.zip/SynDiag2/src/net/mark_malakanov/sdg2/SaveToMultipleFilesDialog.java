package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */
import java.awt.Frame;
import java.awt.Dimension;
import java.util.Iterator;
import java.util.Locale;
import javax.imageio.spi.IIORegistry;
import javax.imageio.spi.ImageWriterSpi;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JFormattedTextField;
import oracle.jdeveloper.layout.VerticalFlowLayout;
import oracle.jdeveloper.layout.XYLayout;
import oracle.jdeveloper.layout.XYConstraints;
import javax.swing.ActionMap;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SaveToMultipleFilesDialog extends JDialog   {
  private JTextField htmlDirName = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JTextField htmlFileName = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JButton jButton2 = new JButton();
  private JComboBox imgFormat = new JComboBox();
  private JLabel jLabel3 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private JFormattedTextField htmlImgBorder = new JFormattedTextField();
  private JLabel jLabel4 = new JLabel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel5 = new JLabel();
  private JTextField htmlTitle = new JTextField();
  private JLabel jLabel6 = new JLabel();
  private JTextField htmlHeader = new JTextField();
  private JButton jButton3 = new JButton();
  private JButton jButton4 = new JButton();
  private ActionMap actionMap1 = new ActionMap();
  private String result;
  
  
  
  public SaveToMultipleFilesDialog() {
    this(null, "", false);
  }

  /**
   * 
   * @param parent
   * @param title
   * @param modal
   */
  public SaveToMultipleFilesDialog(Frame parent, String title, boolean modal) {
    super(parent, title, modal);
    try {
      jbInit();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setSize(new Dimension(400, 342));
    this.getContentPane().setLayout(null);
    this.setTitle("Save to Multiple Files");
    this.setModal(true);
    
    htmlDirName.setText("diagram");
    htmlDirName.setBounds(new Rectangle(75, 25, 265, 25));
    jLabel1.setText("Directory");
    jLabel1.setBounds(new Rectangle(20, 25, 50, 25));
    jLabel1.setLabelFor(htmlDirName);
    jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
    jButton1.setText("...");
    jButton1.setBounds(new Rectangle(345, 25, 30, 25));
    
    htmlFileName.setText("diagram.html");
    htmlFileName.setBounds(new Rectangle(75, 60, 265, 25));
    jLabel2.setText("HTML File");
    jLabel2.setBounds(new Rectangle(20, 60, 50, 25));
    jLabel2.setLabelFor(htmlDirName);
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    
    jButton2.setText("...");
    jButton2.setBounds(new Rectangle(345, 60, 30, 25));
    
    imgFormat.setBounds(new Rectangle(240, 95, 100, 25));
    jLabel3.setText("Format of Image Files");
    jLabel3.setBounds(new Rectangle(25, 95, 205, 25));
    jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
    
    jPanel1.setBounds(new Rectangle(15, 140, 360, 110));
    jPanel1.setBorder(BorderFactory.createTitledBorder("HTML properties"));
    jPanel1.setLayout(xYLayout1);
    
    htmlImgBorder.setText("0");
    jLabel4.setText("Image border");
    jLabel4.setLabelFor(htmlImgBorder);
    jLabel4.setSize(new Dimension(90, 15));
    jLabel4.setBounds(new Rectangle(11, 80, 60, 15));
    jLabel5.setText("Title");
    jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
    htmlTitle.setText("Diagram");
    jLabel6.setText("Header");
    htmlHeader.setText("Diagram");
    jButton3.setText("OK");
    jButton3.setBounds(new Rectangle(60, 260, 110, 35));
    jButton3.setActionMap(actionMap1);
    jButton3.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jButton3_actionPerformed(e);
        }
      });
    jButton4.setText("Cancel");
    jButton4.setBounds(new Rectangle(210, 260, 105, 35));
    jButton4.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jButton4_actionPerformed(e);
        }
      });
    jPanel1.add(htmlHeader, new XYConstraints(60, 25, 285, 20));
    jPanel1.add(jLabel6, new XYConstraints(10, 25, -1, -1));
    jPanel1.add(htmlTitle, new XYConstraints(60, 0, 285, 20));
    jPanel1.add(jLabel5, new XYConstraints(10, 0, 35, 15));
    jPanel1.add(htmlImgBorder, new XYConstraints(85, 60, 45, 20));
    jPanel1.add(jLabel4, new XYConstraints(5, 60, 95, 15));
    
    
    this.getContentPane().add(jButton4, null);
    this.getContentPane().add(jButton3, null);
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(imgFormat, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(htmlDirName, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(htmlFileName, null);
    
    result = "Cancel";
    jButton2.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jButton2_actionPerformed(e);
        }
      });
    jButton1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          jButton1_actionPerformed(e);
        }
      });
      
    populateFormatList();  
  }

  public String getHtmlDirName() {
    return htmlDirName.getText();
  }
  public String getHtmlFileName() {
    return htmlDirName.getText();
  }
  public String getImgFormat() {
    return imgFormat.getSelectedItem().toString();
  }
  public String getHtmlImgBorder() {
    return htmlImgBorder.getText();
  }
  public String getHtmlTitle() {
    return htmlTitle.getText();
  }
  public String getHtmlHeader() {
    return htmlHeader.getText();
  }

  public String getResult() {
    return result;
  }
  
  private void jButton3_actionPerformed(ActionEvent e) {
      result = "OK";
      setVisible(false);
  }

  private void jButton4_actionPerformed(ActionEvent e) {
      result = "Cancel";
      setVisible(false);
  }

  private void jButton1_actionPerformed(ActionEvent e) {
      JFileChooser chooser = new JFileChooser(".");

      int returnVal = chooser.showSaveDialog(null);
    
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
              htmlFileName.setText( chooser.getSelectedFile().getAbsolutePath() );
      }
  }

  private void jButton2_actionPerformed(ActionEvent e) {
      JFileChooser chooser = new JFileChooser(".");

      chooser.addChoosableFileFilter( new UniversalFilter("html","SVG Vector Image") );
      
      int returnVal = chooser.showSaveDialog(null);
    
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
              htmlFileName.setText( chooser.getSelectedFile().getAbsolutePath() );
      }
}
  

  private void populateFormatList() {
      IIORegistry iior = IIORegistry.getDefaultInstance();
      Iterator spi = iior.getServiceProviders(ImageWriterSpi.class,true);
      
      while (spi.hasNext()) {  
               ImageWriterSpi writerSpi = (ImageWriterSpi)spi.next();  
               String fn = writerSpi.getDescription(Locale.US);  
               String[] sfxs = writerSpi.getFileSuffixes();  
               for (int i=0; i<sfxs.length; i++) {
                 imgFormat.addItem(sfxs[i]);
               }
       }   
      imgFormat.setSelectedIndex(0);
  }

}