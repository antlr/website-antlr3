/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc.swing;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import javax.swing.JTree;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.PlainDocument;
import javax.swing.text.View;
import javax.swing.tree.DefaultMutableTreeNode;

import satc.MultiStateLexer;
import satc.Syntax;
import satc.SyntaxFactory;
import satc.TokenFilter;
import satc.TokenList;
import antlr.LLkParser;



/**
 * Implementation of a syntax aware editor kit.
 */
public class SyntaxEditorKit extends DefaultEditorKit {

    public SyntaxEditorKit( String syntaxName) {
        this.syntaxName = syntaxName;
        contentType = Syntax.getContentType( syntaxName);        
    }
    
    /**
     * Creates an uninitialized text storage model
     * that is appropriate for this type of editor.
     *
     * @return the model
     */
    public Document createDefaultDocument() {
        Document doc = new PlainDocument();
        installEditorKit( doc);
        return doc;
    }

    /**
     * Installs this editor kit into a document.
     */
    public void installEditorKit( Document doc) {
        MultiStateLexer lexer = SyntaxFactory.createLexer( syntaxName, new SwingDocumentStream( doc));
        TokenList tokenList = new TokenList();     
        TokenFilter tokenFilter = SyntaxFactory.createTokenFilter( syntaxName, tokenList);  
		LLkParser parser = SyntaxFactory.createParser( syntaxName, tokenFilter);
//		LLkParser parser = SyntaxFactory.createParser( syntaxName, lexer);
//        lexer.setDocumentStream( new SwingDocumentStream( doc));
        doc.putProperty( "lexer", lexer);
		doc.putProperty( "tokenList", tokenList);
		doc.putProperty( "tokenFilter", tokenFilter);
        doc.putProperty( "parser", parser);
        JTree tree = new JTree( new DefaultMutableTreeNode( "Root"));
        doc.putProperty( "AST", tree);
        doc.putProperty( "content-type", getContentType());
        LexerDocumentListener lexerListener = new LexerDocumentListener();
        doc.addDocumentListener( lexerListener);
        doc.putProperty( "lexerDocumentListener", lexerListener);
		lexerListener.setTokenFilter( tokenFilter);
//        if( Syntax.getReparseOnEdit()) {
        if (doc.getProperty( "parser") != null) {
            ParserDocumentListener parserListener = new ParserDocumentListener();
//            doc.addDocumentListener( parserListener);
            doc.putProperty( "parserDocumentListener", parserListener);
            parserListener.setEnabled( Syntax.getReparseOnEdit());
        }
    }
    /**
     * ViewFactory method.
     */
    public View createView( Element elem) {
        SyntaxView view = new SyntaxView( elem);
        view.setTokenContext( SyntaxFactory.createTokenContext( syntaxName));
        return view;
    }

    public void read( InputStream in, Document doc, int pos) throws IOException, BadLocationException {
        ParserDocumentListener pdl = (ParserDocumentListener) doc.getProperty("parserDocumentListener");        
        if( pdl != null) {
            pdl.setEnabled( false);
        }
        super.read( in, doc, pos);
        pdl.setEnabled( Syntax.getReparseOnEdit());
        pdl.updateTree( doc);
    }

    public void read( Reader in, Document doc, int pos) throws IOException, BadLocationException {
        ParserDocumentListener pdl = (ParserDocumentListener) doc.getProperty("parserDocumentListener");        
        if( pdl != null) {
            pdl.setEnabled( false);
        }
        super.read( in, doc, pos);
        if( pdl != null) {
            pdl.setEnabled( Syntax.getReparseOnEdit());
//          if( pdl.isEnabled()) {
                pdl.updateTree( doc);
//          }
        }
    }
    
    /**
     * Gets the MIME type of the data that this
     * kit represents support for.  
     *
     * @return the type
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Gets the syntax name that this
     * kit represents support for.  
     *
     * @return the syntax name
     */
    public String getSyntaxName() {
        return syntaxName;
    }


///////////////////////////////////////////////////////////////////////////////////


    private String syntaxName;
    private String contentType;

}

