// $ANTLR : "XMLCommentLexer.g" -> "XMLCommentLexer.java"$

package satc.lang; 

public interface XMLCommentTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int XF_WS = 4;
	int XF_ID = 5;
	int XC_CLOSE = 6;
	int XC_WS = 7;
	int XC_WORD = 8;
}
