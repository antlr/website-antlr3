package satc.antlr;

import java.util.logging.Logger;

import satc.ListToken;
import antlr.ASTFactory;
import antlr.Token;
import antlr.collections.AST;

public class DocASTFactory extends ASTFactory {

	private int startLine = 1;
	private int startColumn = 1;
	private int endLine = 1;
	private int endColumn = 1;

	public int crtLine = 1;
	public int crtColumn = 1;


	public DocASTFactory() {
		setASTNodeType("satc.antlr.DocAST");
	}

    public AST create(Token tok) {
		DocAST ast;
	
		if ((ast = ((ListToken)tok).getAST()) != null) {// && ast.getType() == tok.getType()) {
			ast.setNextSibling( null);
			ast.initialize(tok);
//			ast.setDamaged(false);
//			ast.setParentPN(null);
			ast.setPreviousSibling(null);
			return ast;
		}
		
		log.finest("-->create(Token tok) - " + tok);

        ast = (DocAST) create();
        ast.initialize(tok);
		ast.line = tok.getLine();
		ast.column = tok.getColumn();

        return ast;
    }

	private static Logger log = Logger.getLogger("satc.antlr.DocASTFactory");




/* ==================================================================
 * 
 * Methods below are only for tracing the creation of ASTs
 * 
 * ==================================================================
 */
 
 
 
 
 
 

	public AST create() {
		log.finest("-->create()");
		return super.create();
	}
/*
	public AST create(int type) {
		log.finest("-->create( type)");
		return super.create( type);
	}

	public AST create(int type, String txt) {
		log.finest("-->create( type, txt)");
		return super.create( type, txt);
	}

	public AST create(int type, String txt, String className) {
		log.finest("-->create( type, txt, className)");
		return super.create( type, txt, className);
	}

	public AST create(AST tr) {
		log.finest("-->create( AST tr)");
		return super.create( tr);
	}

	public AST create(Token tok, String className) {
		log.finest("-->create(Token tok, String className)");
		return super.create( tok, className);
	}

	protected AST create(String className) {
		log.finest("-->create( String className)");
		return super.create( className);
	}
*/
	protected AST create(Class c) {
		log.finest("-->create( Class c)");
//		log.entering("DocASTFactory", "create", c);
		return super.create( c);
	}

	protected AST createUsingCtor(Token token, String className) {
		log.finest("-->createUsingCtor(Token token, String className)");
//		log.entering("DocASTFactory", "createUsingCtor(Token token, String className)", token);
		return super.create( token, className);
	}



}