 

import java.util.*;

/** Represents the definition of a method within the
 *  package/class hierarchy.  Normally this would include
 *  parameters / codeblockscopes, but we don't care about
 *  variables at this point.
 */
public class MethodScope extends Scope {
    protected ParameterScope parameterScope = null;

    protected ClassScope returnType = null;

    public MethodScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    public void setParameterScope(ParameterScope s) {
        parameterScope = s;
    }

    public void setReturnType(ClassScope t) {
        returnType = t;
    }

    public ClassScope getReturnType() {
        return returnType;
    }

    public void dump() {
        tab();
        if ( returnType!=null ) {
            System.out.print(returnType.getFullyQualifiedName()+" ");
        }
        else {
            System.out.print("void ");
        }
        System.out.print(getName()+"(");
        if ( parameterScope!=null ) {
            parameterScope.dump();
        }
        System.out.println(")");
    }
}
