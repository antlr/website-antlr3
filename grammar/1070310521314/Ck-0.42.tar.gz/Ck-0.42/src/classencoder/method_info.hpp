/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef METHODINFO_HPP
#define METHODINFO_HPP

#include <string>
#include <vector>

#include "classwriterbase.hpp"

namespace ClassEncoder
{

class code_attribute;
class ByteCode;
class ConstantPool;

//! This class holds information about a method.
/*!
 * The details of the method_info structure is defined by SUN: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#1513
 * For each method that you specify you must set the access parameters, the parametres themselves and the return type. After you are done with this the function finish() must be called.
 */
class method_info : public ClassWriterBase
{
public:
    method_info( ConstantPool *constantPool, const std::string &name );
    virtual ~method_info();

    void write( std::ofstream &stream );
    void setAccess( u2 flags );

    void addParameter( const std::string &objectType, bool addLocal = false );
    void setReturnType( const std::string &type );
    unsigned int addLocal();

    ByteCode *code();

    void finish();

private:
    std::string buildMethodDescriptor();

private:
    ConstantPool *ConstantPoolEntries;
    code_attribute *CodeAttribute;

    u2 access_flags;
    u2 name_index;
    u2 descriptor_index;
    std::string FunctionName;
    // for method_descriptor
    std::vector<std::string> Parameters;
    std::string ReturnType;
};

} // end of namespace

#endif // METHODINFO_HPP
