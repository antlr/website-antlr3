// $ANTLR 3.0b7 FunctionID.g 2007-05-03 14:07:36

	import java.util.HashMap;
	import java.util.Vector;
	import java.util.Map;
	import java.io.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class FunctionID extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "POS", "NEG", "POSTFIX", "PREFIX", "NOP", "PROGRAM", "FUNCTION", "VARDEF", "ARRDEF", "VARPAR", "ARRPAR", "BLOCK", "ASSIGN", "EXPR", "EXPRLIST", "CALL", "INDEX", "NOT", "NEGATE", "FUNCTIONS", "VARIABLES", "PARAMATERS", "STMTS", "NUM", "VAR", "TYPE", "ID", "INT", "RETURN", "READ", "WRITE", "WRITELN", "BREAK", "WHILE", "IF", "SCHAR", "SQUOTE", "CHAR", "LCHAR", "DIGIT", "LC", "UC", "NEWLINE", "WS", "COMMENT", "LINECOMMENT", "';'", "'['", "']'", "'('", "')'", "','", "'{'", "'}'", "'do'", "'for'", "'else'", "'unless'", "'='", "'or'", "'||'", "'and'", "'&&'", "'=='", "'!='", "'<>'", "'>'", "'<'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'!'", "'not'", "'++'", "'--'"
    };
    public static final int INDEX=20;
    public static final int TYPE=29;
    public static final int EXPR=17;
    public static final int VARPAR=13;
    public static final int PARAMATERS=25;
    public static final int ARRPAR=14;
    public static final int NEGATE=22;
    public static final int VARIABLES=24;
    public static final int SQUOTE=40;
    public static final int VARDEF=11;
    public static final int STMTS=26;
    public static final int PROGRAM=9;
    public static final int NEWLINE=46;
    public static final int FUNCTIONS=23;
    public static final int BLOCK=15;
    public static final int PREFIX=7;
    public static final int FUNCTION=10;
    public static final int INT=31;
    public static final int SCHAR=39;
    public static final int ASSIGN=16;
    public static final int POS=4;
    public static final int POSTFIX=6;
    public static final int DIGIT=43;
    public static final int EXPRLIST=18;
    public static final int LCHAR=42;
    public static final int ID=30;
    public static final int WHILE=37;
    public static final int WS=47;
    public static final int CHAR=41;
    public static final int WRITE=34;
    public static final int LC=44;
    public static final int COMMENT=48;
    public static final int LINECOMMENT=49;
    public static final int VAR=28;
    public static final int RETURN=32;
    public static final int IF=38;
    public static final int EOF=-1;
    public static final int NOP=8;
    public static final int BREAK=36;
    public static final int NUM=27;
    public static final int CALL=19;
    public static final int UC=45;
    public static final int NEG=5;
    public static final int NOT=21;
    public static final int WRITELN=35;
    public static final int READ=33;
    public static final int ARRDEF=12;

        public FunctionID(TreeNodeStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "FunctionID.g"; }



    // $ANTLR start program
    // FunctionID.g:15:1: program : ^( PROGRAM ^( VARIABLES ( . )* ) ^( FUNCTIONS ( funDecl )* ) . ) EOF ;
    public final void program() throws RecognitionException {
        try {
            // FunctionID.g:16:3: ( ^( PROGRAM ^( VARIABLES ( . )* ) ^( FUNCTIONS ( funDecl )* ) . ) EOF )
            // FunctionID.g:16:3: ^( PROGRAM ^( VARIABLES ( . )* ) ^( FUNCTIONS ( funDecl )* ) . ) EOF
            {
            match(input,PROGRAM,FOLLOW_PROGRAM_in_program41); 

            match(input, Token.DOWN, null); 
            match(input,VARIABLES,FOLLOW_VARIABLES_in_program44); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // FunctionID.g:16:25: ( . )*
                loop1:
                do {
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( (LA1_0==UP) ) {
                        alt1=2;
                    }
                    else if ( ((LA1_0>=POS && LA1_0<=81)) ) {
                        alt1=1;
                    }


                    switch (alt1) {
                	case 1 :
                	    // FunctionID.g:16:25: .
                	    {
                	    matchAny(input); 

                	    }
                	    break;

                	default :
                	    break loop1;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            match(input,FUNCTIONS,FOLLOW_FUNCTIONS_in_program51); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // FunctionID.g:16:41: ( funDecl )*
                loop2:
                do {
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==FUNCTION) ) {
                        alt2=1;
                    }


                    switch (alt2) {
                	case 1 :
                	    // FunctionID.g:16:41: funDecl
                	    {
                	    pushFollow(FOLLOW_funDecl_in_program53);
                	    funDecl();
                	    _fsp--;


                	    }
                	    break;

                	default :
                	    break loop2;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            matchAny(input); 

            match(input, Token.UP, null); 
            match(input,EOF,FOLLOW_EOF_in_program60); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end program

    public static class funDecl_return extends TreeRuleReturnScope {
    };

    // $ANTLR start funDecl
    // FunctionID.g:19:1: funDecl : ^( FUNCTION type= TYPE name= ID ^( PARAMATERS (par= paramDecl )* ) . ) ;
    public final funDecl_return funDecl() throws RecognitionException {
        funDecl_return retval = new funDecl_return();
        retval.start = input.LT(1);

        CommonTree type=null;
        CommonTree name=null;
        FunctionParam par = null;



        	Vector params=new Vector();

        try {
            // FunctionID.g:27:4: ( ^( FUNCTION type= TYPE name= ID ^( PARAMATERS (par= paramDecl )* ) . ) )
            // FunctionID.g:27:4: ^( FUNCTION type= TYPE name= ID ^( PARAMATERS (par= paramDecl )* ) . )
            {
            match(input,FUNCTION,FOLLOW_FUNCTION_in_funDecl81); 

            match(input, Token.DOWN, null); 
            type=(CommonTree)input.LT(1);
            match(input,TYPE,FOLLOW_TYPE_in_funDecl85); 
            name=(CommonTree)input.LT(1);
            match(input,ID,FOLLOW_ID_in_funDecl89); 
            match(input,PARAMATERS,FOLLOW_PARAMATERS_in_funDecl92); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // FunctionID.g:27:46: (par= paramDecl )*
                loop3:
                do {
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( ((LA3_0>=VARPAR && LA3_0<=ARRPAR)) ) {
                        alt3=1;
                    }


                    switch (alt3) {
                	case 1 :
                	    // FunctionID.g:27:47: par= paramDecl
                	    {
                	    pushFollow(FOLLOW_paramDecl_in_funDecl97);
                	    par=paramDecl();
                	    _fsp--;

                	    params.add(par);

                	    }
                	    break;

                	default :
                	    break loop3;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            matchAny(input); 

            match(input, Token.UP, null); 

            }


                    CommonTree blockNode = (CommonTree)((CommonTree)retval.start).getChild(3);
            	Main.symbols.declare_function(name.getText(),type.getText(),params,blockNode);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end funDecl


    // $ANTLR start paramDecl
    // FunctionID.g:30:1: paramDecl returns [FunctionParam p] : ( ^( VARPAR TYPE ID ) | ^( ARRPAR TYPE ID ) );
    public final FunctionParam paramDecl() throws RecognitionException {
        FunctionParam p = null;

        CommonTree ID1=null;
        CommonTree TYPE2=null;
        CommonTree ID3=null;
        CommonTree TYPE4=null;

        try {
            // FunctionID.g:31:4: ( ^( VARPAR TYPE ID ) | ^( ARRPAR TYPE ID ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==VARPAR) ) {
                alt4=1;
            }
            else if ( (LA4_0==ARRPAR) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("30:1: paramDecl returns [FunctionParam p] : ( ^( VARPAR TYPE ID ) | ^( ARRPAR TYPE ID ) );", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // FunctionID.g:31:4: ^( VARPAR TYPE ID )
                    {
                    match(input,VARPAR,FOLLOW_VARPAR_in_paramDecl120); 

                    match(input, Token.DOWN, null); 
                    TYPE2=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_paramDecl122); 
                    ID1=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_paramDecl124); 

                    match(input, Token.UP, null); 
                    p =new FunctionParam(ID1.getText(),TYPE2.getText(),"scalar");

                    }
                    break;
                case 2 :
                    // FunctionID.g:32:4: ^( ARRPAR TYPE ID )
                    {
                    match(input,ARRPAR,FOLLOW_ARRPAR_in_paramDecl133); 

                    match(input, Token.DOWN, null); 
                    TYPE4=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_paramDecl135); 
                    ID3=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_paramDecl137); 

                    match(input, Token.UP, null); 
                    p =new FunctionParam(ID3.getText(),TYPE4.getText(),"array");

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return p;
    }
    // $ANTLR end paramDecl


 

    public static final BitSet FOLLOW_PROGRAM_in_program41 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VARIABLES_in_program44 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_FUNCTIONS_in_program51 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_funDecl_in_program53 = new BitSet(new long[]{0x0000000000000408L});
    public static final BitSet FOLLOW_EOF_in_program60 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_funDecl81 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_funDecl85 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_funDecl89 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_PARAMATERS_in_funDecl92 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramDecl_in_funDecl97 = new BitSet(new long[]{0x0000000000006008L});
    public static final BitSet FOLLOW_VARPAR_in_paramDecl120 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_paramDecl122 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_paramDecl124 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRPAR_in_paramDecl133 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_paramDecl135 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_paramDecl137 = new BitSet(new long[]{0x0000000000000008L});

}