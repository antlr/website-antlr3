package edu.usfca.syndiag;

import java.awt.*;
import javax.swing.*;

public class DefaultSyntaxDiagramGenerator implements SyntaxDiagramGenerator {
	GraphicsEngine engine = null;
	
	public DefaultSyntaxDiagramGenerator(GraphicsEngine engine){
		this.engine = engine;
	}
	
	public void drawArrow(int x1, int y1, int x2, int y2){
    	if (x1 < x2){
    		engine.drawLine(x1, y1, x2, y2);
    		int[] xCoordinates = {x2-8, x2-8, x2};
        	int[] yCoordinates = {y2-3, y2+3, y2};
        	engine.fillPolygon(xCoordinates, yCoordinates, 3);
    	}else if (x1 > x2){
    		engine.drawLine(x1, y1, x2, y2);
    		int[] xCoordinates = {x2+8, x2+8, x2};
        	int[] yCoordinates = {y2-3, y2+3, y2};
        	engine.fillPolygon(xCoordinates, yCoordinates, 3);
    	}else if (y1 > y2){
    		engine.drawLine(x1, y1, x2, y2);
    		int[] xCoordinates = {x2-3, x2+3, x2};
        	int[] yCoordinates = {y2+8, y2+8, y2};
        	engine.fillPolygon(xCoordinates, yCoordinates, 3);
    	}else if (y1 < y2){
    		engine.drawLine(x1, y1, x2, y2);
    		int[] xCoordinates = {x2-3, x2+3, x2};
        	int[] yCoordinates = {y2-8, y2-8, y2};
        	engine.fillPolygon(xCoordinates, yCoordinates, 3);
    	}
    }
    
    public void drawDFConnLine(int x1, int y1, int x2, int y2){
    	engine.drawLine(x1, y1, x1, y2);
    	drawArrow(x1, y2, x2, y2);
    }
    	 	
    public void drawFUConnLine(int x1, int y1, int x2, int y2){
    	engine.drawLine(x1, y1, x2, y1);
    	drawArrow(x2, y1, x2, y2);
    }    

    public void drawDBConnLine(int x1, int y1, int x2, int y2){
    	engine.drawLine(x1, y1, x1, y2);
    	drawArrow(x1, y2, x2, y2);
    }

    public void drawBUConnLine(int x1, int y1, int x2, int y2){
     	engine.drawLine(x1, y1, x2, y1);
    	drawArrow(x2, y1, x2, y2);
    }
	
	public void drawBackConnLine(int x1, int y1, int x2, int y2, int h){
		engine.drawLine(x2, y2, x2, y2+h);
		engine.drawLine(x2, y2+h, x1, y1+h);
		drawArrow(x1, y1+h, x1, y1);
	}

	public void drawForwardConnLine(int x1, int y1, int x2, int y2, int h){
		engine.drawLine(x1, y1, x1, y1-h);
		engine.drawLine(x1, y1-h, x2, y2-h);
		drawArrow(x2, y2-h, x2, y2);
	}	

	public void drawDotRect(int x, int y, int w, int h){
		BasicStroke dotted = new BasicStroke(3, BasicStroke.CAP_ROUND, 
                     BasicStroke.JOIN_ROUND, 0, new float[]{0,6,0,6}, 0);
        engine.drawRect(x, y, w, h, dotted);
    }
    
	public void drawLeftRangeRect(int x, int y, int w, int h){
		engine.drawLine(x, y, x+w, y);
		engine.drawLine(x, y, x, y+h);
		engine.drawLine(x, y+h, x+w, y+h);
	}

	public void drawRightRangeRect(int x, int y, int w, int h){
		engine.drawLine(x, y, x+w, y);
		engine.drawLine(x+w, y, x+w, y+h);
		engine.drawLine(x, y+h, x+w, y+h);
	}
	
	public void drawText(String str, Font f, int x, int y){
		engine.drawString(str, x, y, f);
	}
	
	public void drawRule(int x1, int y1, int x2, int y2, int w, int s){
		if (s == 0){
			drawArrow(x1, y1+10, x2, y2+10);
			drawArrow(x1 + 40 + w, y1 + 10, x1 + 40 + w + 90, y1 + 10);	
		} else {
			drawArrow(x1 + 40, y1+10, x2, y2+10);
			drawArrow(x1 + 40 + w, y1 + 10, x1 + 40 + w + 90, y1 + 10);	
		}
	}
	
	public void drawBlock(int[] connPoint1, int[] connPoint2, int[] leftConnPoint, int[] rightConnPoint, int i){
		if (i == 1){
    		engine.drawLine(connPoint1[0], connPoint1[1], leftConnPoint[0], connPoint1[1] );
    		engine.drawLine(rightConnPoint[0], connPoint2[1], connPoint2[0], connPoint2[1]);
    		// This is for connecting the right side of the first alternative in the block,
    		// in which, the right connect point of the first alternative is less than
    		// the block's right connect point.
    	}else{
    		drawDFConnLine(connPoint1[0], connPoint1[1], leftConnPoint[0], leftConnPoint[1]);
    		drawFUConnLine(rightConnPoint[0], rightConnPoint[1], connPoint2[0], connPoint2[1]);    		 
    	}
	}
	
	public void drawOptional(int[] connPoint1, int[] connPoint2, int h){
		drawForwardConnLine(connPoint1[0]-5, connPoint1[1], connPoint2[0]+5, connPoint2[1], h);
	}

	public void drawClosure(int[] connPoint1, int[] connPoint2, int h){
		drawForwardConnLine(connPoint1[0]-5, connPoint1[1], connPoint2[0]+5, connPoint2[1], 20);	 		 
		drawBackConnLine(connPoint1[0]-5, connPoint1[1], connPoint2[0]+5, connPoint2[1], h );
	}
	
	public void drawPClosure(int[] connPoint1, int[] connPoint2, int h){
		drawBackConnLine(connPoint1[0]-5, connPoint1[1], connPoint2[0]+5, connPoint2[1], h);
	}
	
	public void drawRuleRef(int x, int y, int w, int h, String str, Font f){
		engine.drawOval(x, y, w, h);
		drawText(str, f, x+14, y+15);
	}
	
	public void drawNot(int x, int y, int w, int h, String str, Font f){
		engine.drawRect(x, y, w, h);
    	drawText(str, f, x+6, y+15);
    }
	
	public void drawRange(int x, int y, int w, int h, String str, int pos){
		if (pos == 1){
    		drawLeftRangeRect(x, y, w, h);
    		drawText(str + "  ..", new Font("Monospaces", Font.PLAIN, 15), x+14, y+15);
    	}else if (pos == 2){
    		drawRightRangeRect(x, y, w, h);
    		drawText(str, new Font("Monospaces", Font.PLAIN, 15), x+14, y+15);
    	}
	}
	
	public void drawTokenRef(int x, int y, int w, int h, String str, Font f){
		engine.drawRect(x, y, w, h);
		drawText(str, f, x+14, y+15);
	}
	
	public void drawL(int x, int y, int w, int h, String str, Font f){
		engine.drawRect(x, y, w, h);
		drawText(str, f, x+14, y+15);
	}

}
