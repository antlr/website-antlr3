/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc.swing;

import java.io.IOException;

import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Segment;

import satc.DocumentStream;


/**
 * Class to provide InputStream functionality from a portion of a Swing Document.
 */
public class SwingDocumentStream extends DocumentStream {

    private Document doc;

    /**
     * Creates a new document stream from a Swing document.
     */
    public SwingDocumentStream( Document doc) {
        this();
        setDocument( doc);      
    }

    /**
     * Creates a new document stream with no document attached.
     */
    public SwingDocumentStream() {
        this.segment = new Segment();
    }

    /**
     * Attaches this input stream to a document.
     */
    public void setDocument( Object doc) {
        this.doc = (Document) doc;
        setRange( 0, this.doc.getLength());
    }
    
    /**
     *  Reset the document stream.  The stream is positioned at the begining
     *  of the document and the range of the stream is set to cover the
     *  whole document.
     */
    public void reset() {
        if( doc != null) 
            setRange( 0, doc.getLength());   
    }

    /**
     *  Restrict the stream to a range of the document.
     */ 
    public void setRange( int p0, int p1) {
        this.p0 = p0;
        this.p1 = Math.min( doc.getLength(), p1);
        pos = p0;
        try {
            loadSegment();
        } catch (IOException ioe) {
            throw new Error("unexpected: " + ioe);
        }
    }

    /**
     * Reads the next byte of data from this input stream. The value 
     * byte is returned as an <code>int</code> in the range 
     * <code>0</code> to <code>255</code>. If no byte is available 
     * because the end of the stream has been reached, the value 
     * <code>-1</code> is returned. This method blocks until input data 
     * is available, the end of the stream is detected, or an exception 
     * is thrown. 
     * <p>
     * A subclass must provide an implementation of this method. 
     *
     * @return     the next byte of data, or <code>-1</code> if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     */
    public int read() throws IOException {
        if (index >= segment.offset + segment.count) {
        if (pos >= p1) {
            // no more data
            return -1;
        }
        loadSegment();
        }
        pos++;
        return segment.array[index++];
    }

    private void loadSegment() throws IOException {
        try {
            int n = Math.min(1024, p1 - pos);
            doc.getText(pos, n, segment);
//          pos += n;
            index = segment.offset;
        } catch (BadLocationException e) {
            throw new IOException("Bad location");
        }
    }
    
    private Segment segment;
    private int p0;    // start position
    private int p1;    // end position
    private int pos;   // pos in document
    private int index; // index into array of the segment

}

