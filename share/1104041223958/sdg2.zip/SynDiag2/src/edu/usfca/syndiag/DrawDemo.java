package edu.usfca.syndiag;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.mark_malakanov.sindiag.SvgEngine;


public class DrawDemo extends JPanel {
	AST t = null;

    public void init() {
        setBackground(Color.white);
        setForeground(Color.black);
    }

    public void setAST(AST t){
    	this.t = t;
    }
   
    public void paint(Graphics g) {

        Graphics2D g2 = (Graphics2D) g;
        Dimension d = getSize();
        g2.setBackground(getBackground());
        g2.setPaint(getBackground());
        g2.fillRect(0,0, d.width, d.height);
        g2.setPaint(getForeground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);        
		
	SwingEngine swing = new SwingEngine();
	swing.setGraphics2D(g2);
	DefaultSyntaxDiagramGenerator diagramGen =
        new DefaultSyntaxDiagramGenerator(swing);
	Draw draw = new Draw();
	draw.setDiagGen(diagramGen);
	
	if(t==null)return;
    	try{
    		draw.grammar(t);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	int width = ((GrammarAST)t).getWidth();
    	int height = ((GrammarAST)t).getHeight();
    	setPreferredSize(new Dimension(width, height));
    	revalidate();
    }

    public void paintSvg(String fileName) {

        int width = ((GrammarAST)t).getWidth();
        int height = ((GrammarAST)t).getHeight();
        
        SvgEngine svg = new SvgEngine();
        svg.setColor("black");
        svg.setBgColor("white");
        
        svg.setWriter( fileName );
        svg.beginDraw(new Rectangle(0,0,width,height));
        
        DefaultSyntaxDiagramGenerator diagramGen =
              new DefaultSyntaxDiagramGenerator(svg);
        Draw draw = new Draw();
        draw.setDiagGen(diagramGen);
        
        if(t==null)return;
            try{
              draw.grammar(t);
            }catch(Exception e){
              e.printStackTrace();
            }

        svg.endDraw();  
     }
          
        
        
}
