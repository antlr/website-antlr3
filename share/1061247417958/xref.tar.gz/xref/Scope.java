 

public abstract class Scope {
    /** Which project does this scope belong to? */
    protected CodeProject project = null;

    /** What scope encloses this one?  E.g., for a class
     *  scope, the parent will be either a ClassScope
     *  or a PackageScope.  A package will have a parent
     *  that is a package scope or none (indicating
     *  it is top level).
     */
    protected Scope parent;

    /** The name of this scope; NOT fully-qualified; E.g., class java.io.File
     *  would result in a ClassScope whose name is "File".  It's immediate
     *  parent would point to the PackageScope of "io" whose parent, in turn,
     *  would be PackageScope of "java".
     */
    protected String name;

    protected static int tabIndent = 0;

    protected static void tab() {
        for (int i=0; i<tabIndent; i++) {
            System.out.print("  ");
        }
    }

    public void dump() {
    }

    public void addScope(Scope s) {
    }

    public void addScopeMember(Scope s) {
    }

    public Scope(CodeProject project, String name, Scope parent) {
        this.project = project;
        setName(name);
        setParent(parent);
    }

    /** Given a simple typename or qualified type name, find the ClassScope */
    public ClassScope resolveClass(String name) {
        if ( parent!=null ) {
            return parent.resolveClass(name);
        }
        return null;
    }

    public MethodScope resolveMethod(String name) {
        if ( parent!=null ) {
            return parent.resolveMethod(name);
        }
        return null;
    }

    public FieldVariable resolveField(String name) {
        if ( parent!=null ) {
            return parent.resolveField(name);
        }
        return null;
    }

    /** Could be a field or local or parameter */
    public Variable resolveVariable(String name) {
        if ( parent!=null ) {
            return parent.resolveVariable(name);
        }
        return null;
    }

    public String getName() {
        return name;
    }

    /** Walk up through scopes to compute fully qualified name.
     *  For example, if this is a class name, it will combine
     *  the full package name + "." + getName().
     */
    public String getFullyQualifiedName() {
        if ( parent==null ) {
            return getName();
        }
        return parent.getFullyQualifiedName() + "." + name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Scope getParent() {
        return parent;
    }

    public void setParent(Scope parent) {
        this.parent = parent;
    }

    public String toString() {
        return getClass().getName()+":"+getFullyQualifiedName();
    }
}
