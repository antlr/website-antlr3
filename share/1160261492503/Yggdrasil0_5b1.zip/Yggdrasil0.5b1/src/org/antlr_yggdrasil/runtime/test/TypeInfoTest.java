package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.TypeInfo;
import java.util.HashMap;
import java.util.HashSet;

public class TypeInfoTest extends TestCase {
	TypeInfo typeInfo = null;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(TypeInfoTest.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		typeInfo = new TypeInfo("this", new TypeInfo("parent"));
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAddField() {
		HashMap f = null;
		assertTrue(typeInfo.getTypeOf("key") == null);
		
		typeInfo.addField("item", "key");
		assertTrue(typeInfo.getTypeOf("key") != null);
		f = typeInfo.getLocalFields();
		assertFalse((f != null)  && f.containsKey("key"));
		f = typeInfo.getExternalFields();
		assertFalse((f != null)  && f.containsKey("key"));
	}

	public void testAddLocalField() {
		HashMap f = null;
		
		typeInfo.addLocalField("item", "key");
		assertTrue(typeInfo.getTypeOf("key") != null);
		f = typeInfo.getLocalFields();
		assertTrue((f != null) && f.containsKey("key"));
		f = typeInfo.getExternalFields();
		assertFalse((f != null) && f.containsKey("key"));
	}

	public void testAddExternalField() {
		HashMap f = null;
		
		typeInfo.addExternalField("item", "key");
		assertTrue(typeInfo.getTypeOf("key") != null);
		f = typeInfo.getLocalFields();
		assertFalse((f != null) && f.containsKey("key"));
		f = typeInfo.getExternalFields();
		assertTrue((f != null) && f.containsKey("key"));
	}

	public void testGetParent() {
		assertTrue(((String) typeInfo.getParent()).equals("parent"));
	}

	public void testGetTypeOf() {
		// tested above
	}

	public void testVerify() {
		HashMap f = null;
		String verify = "verify";
		
		typeInfo.addField(verify, "test");
		
		assertTrue(typeInfo.verify(verify, "test"));
		f = typeInfo.getExternalFields();
		assertFalse((f != null) && f.containsKey("key"));
		
		String vName = "v2";
		assertFalse(typeInfo.verify(vName, "key"));
		assertFalse(typeInfo.getExternalFields().containsKey("test"));
		assertTrue(typeInfo.verify(vName, "key"));
	}
	
	public void testIsa() {
		HashSet parents = new HashSet();
		parents.add("mom");
		parents.add("grandma");
		parents.add("great-grandma");
		
		typeInfo.setAncestors(parents);
		
		assertTrue(typeInfo.isa("mom"));
		assertFalse(typeInfo.isa("cousin"));
		assertTrue(typeInfo.isa("this"));
	}

}
