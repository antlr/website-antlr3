public class Edge {
	public static final int INVALID = -3;
    public static final int EPSILON = -2;
    public static final int EOF = 1;
    public static final int MIN_TOKEN_TYPE = 2; // won't work for char parsers!

    // ... deleted
}
