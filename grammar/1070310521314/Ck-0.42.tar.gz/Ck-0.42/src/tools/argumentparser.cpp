/*
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


/*
 * This file was copied from the open source project IRCan.
 *
 * Copyright (C) 2003, Frederik Holljen <larson@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: argumentparser.cpp,v 1.2 2003/11/28 15:41:27 bosman Exp $
 */

#include "argumentparser.hpp"
#include <iostream>
#include <string.h> // for strlen

/*! \file argumentparser.cpp
 *  Implementation of ArgumentParser class
 */

/*!
  \class ArgumentParser argumentparser.hpp
  \brief Parses the command line arguments and stores the configuration after parsing.
  \author <a href="mailto:fh@ez.no">Frederik Holljen</a>
  \date Enter current date here

*/

/*!
 *  Default constructor
 */

ArgumentParser::ArgumentParser()
{
    NoParamArgs = "";
}

/*!
  Destroys the object
*/

ArgumentParser::~ArgumentParser()
{
}

/*!
  Parses the arguments. Returns true if the arguments are valid and the program should
  continue.
  This function accepts the following:
  -a param ; // standard with parameter
  -a ; // no parameter
  -ab ; // a and b are both parameterless
  -ab param; // a has no param, b does
 */
bool ArgumentParser::parseArguments( int argc, char **argv )
{
    if( argc == 1 ) // nothing to do
        return true;

    string pendingArg;
    for( int i = 1; i < argc; i++ )
    {
        uint len = strlen( argv[i] );
        if( argv[i][0] == '-' && len > 1) // if it's only the '-' ignore it.
        {
            if( !pendingArg.empty() )
            {
                NoParamArgs += pendingArg;
                pendingArg = "";
            }

            uint j = 1;
            for( ; j < len - 1; j++ )
            {
                NoParamArgs += argv[i][j];
            }
            pendingArg = argv[i][j];
        }
        else if( !pendingArg.empty() )
        {
            ArgsMap[pendingArg] = argv[i];
            pendingArg = "";
        }
        else // this could be a mode..for now it's an error
        {
            return false;
        }
    }

    if( !pendingArg.empty() )
    {
        NoParamArgs += pendingArg;
    }
    return true;
}

/*!
  Returns the number of arguments parsed.
 */
uint ArgumentParser::numArguments() const
{
    return ArgsMap.size() + NoParamArgs.length();
}

/*!
  Returns the value of the argument arg. Returns an empty string if the argument was not specified.
  Note: Current implementation requires you to specify the complete parameter name. If the user specifies -l blah use argValue( "-l" )
 */
typedef map<string, string>::const_iterator mapIt;
string ArgumentParser::argValue( const string &arg ) const
{
    mapIt it = ArgsMap.find( arg );
    if( it != ArgsMap.end() )
    {
        return (*it).second;
    }

    return "";
}

/*!
 *   Returns the boolean value of the argument arg.
 * Returns an empty string if the argument was not specified.
 * true, 1 and on are accepted as true, all other values are false.
 */
bool ArgumentParser::boolArgValue( const string &arg ) const
{
    mapIt it = ArgsMap.find( arg );
    if( it != ArgsMap.end() )
    {
        if( (*it).second == "true" ||
            (*it).second == "1" ||
            (*it).second == "on" )
        {
            return true;
        }
    }

    return false;
}

/*!
  Returns true if the character arg was set in any of the allowed ways.
 */
bool ArgumentParser::singleArgSet( char arg ) const
{
    if( NoParamArgs.find( arg ) != string::npos )
        return true;
    return false;
}
