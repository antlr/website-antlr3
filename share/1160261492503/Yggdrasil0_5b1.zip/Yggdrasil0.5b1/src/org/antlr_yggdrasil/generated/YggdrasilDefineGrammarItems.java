// $ANTLR 2.7.6 (2005-12-22): "YggdrasilDefine.g" -> "YggdrasilDefineGrammarItems.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
	package org.antlr_yggdrasil.generated;
	import org.antlr_yggdrasil.tool.*;
	import org.antlr_yggdrasil.tool.Grammar;
	import java.util.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


public class YggdrasilDefineGrammarItems extends antlr.TreeParser       implements YggdrasilDefineGrammarItemsTokenTypes
 {

protected Grammar grammar;
protected GrammarAST root;
protected String currentRuleName;
protected int outerAltNum = 0;
protected int blockLevel = 0;

    public void reportError(RecognitionException ex) {
		Token token = null;
		if ( ex instanceof MismatchedTokenException ) {
			token = ((MismatchedTokenException)ex).token;
		}
		else if ( ex instanceof NoViableAltException ) {
			token = ((NoViableAltException)ex).token;
		}
        ErrorManager.syntaxError(
            ErrorManager.MSG_SYNTAX_ERROR,
            token,
            "define: "+ex.toString(),
            ex);
    }

	protected void finish() {
		trimGrammar();
	}

	/** Remove any lexer rules from a COMBINED; already passed to lexer */
	protected void trimGrammar() {
		if ( grammar.type!=Grammar.COMBINED ) {
			return;
		}
		// form is (header ... ) ( grammar ID (scope ...) ... ( rule ... ) ( rule ... ) ... )
		GrammarAST p = root;
		// find the grammar spec
		while ( !p.getText().equals("grammar") ) {
			p = (GrammarAST)p.getNextSibling();
		}
		p = (GrammarAST)p.getFirstChild(); // jump down to first child of grammar
		// look for first RULE def
		GrammarAST prev = p; // points to the ID (grammar name)
		while ( p.getType()!=RULE ) {
			prev = p;
			p = (GrammarAST)p.getNextSibling();
		}
		// prev points at last node before first rule subtree at this point
		while ( p!=null ) {
			String ruleName = p.getFirstChild().getText();
			//System.out.println("rule "+ruleName+" prev="+prev.getText());
			if ( Character.isUpperCase(ruleName.charAt(0)) ) {
				// remove lexer rule
				prev.setNextSibling(p.getNextSibling());
			}
			else {
				prev = p; // non-lexer rule; move on
			}
			p = (GrammarAST)p.getNextSibling();
		}
		//System.out.println("root after removal is: "+root.toStringList());
	}
public YggdrasilDefineGrammarItems() {
	tokenNames = _tokenNames;
}

	public final void file(AST _t,
		Grammar g
	) throws RecognitionException {
		
		GrammarAST file_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			_loop3:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_header)) {
					fileheader(_t);
					_t = _retTree;
				}
				else {
					break _loop3;
				}
				
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				typeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			grammar(_t,g);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void fileheader(AST _t) throws RecognitionException {
		
		GrammarAST fileheader_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t7 = _t;
			GrammarAST tmp1_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_header);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp2_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp3_AST_in = (GrammarAST)_t;
			match(_t,LCURLY);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case TOKENS:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t7;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void typeDecls(AST _t) throws RecognitionException {
		
		GrammarAST typeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t23 = _t;
			GrammarAST tmp4_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop25:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LCURLY||_t.getType()==LITERAL_atomic)) {
					attributeTypeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop25;
				}
				
			} while (true);
			}
			_t = __t23;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void optionsSpec(AST _t) throws RecognitionException {
		
		GrammarAST optionsSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp5_AST_in = (GrammarAST)_t;
			match(_t,OPTIONS);
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammar(AST _t,
		Grammar g
	) throws RecognitionException {
		
		GrammarAST grammar_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		grammar = g;
		root = grammar_AST_in;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LEXER_GRAMMAR:
			{
				AST __t52 = _t;
				GrammarAST tmp6_AST_in = (GrammarAST)_t;
				match(_t,LEXER_GRAMMAR);
				_t = _t.getFirstChild();
				if ( inputState.guessing==0 ) {
					grammar.type = Grammar.LEXER;
				}
				grammarSpec(_t);
				_t = _retTree;
				_t = __t52;
				_t = _t.getNextSibling();
				break;
			}
			case PARSER_GRAMMAR:
			{
				AST __t53 = _t;
				GrammarAST tmp7_AST_in = (GrammarAST)_t;
				match(_t,PARSER_GRAMMAR);
				_t = _t.getFirstChild();
				if ( inputState.guessing==0 ) {
					grammar.type = Grammar.PARSER;
				}
				grammarSpec(_t);
				_t = _retTree;
				_t = __t53;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_GRAMMAR:
			{
				AST __t54 = _t;
				GrammarAST tmp8_AST_in = (GrammarAST)_t;
				match(_t,TREE_GRAMMAR);
				_t = _t.getFirstChild();
				if ( inputState.guessing==0 ) {
					grammar.type = Grammar.TREE_PARSER;
				}
				grammarSpec(_t);
				_t = _retTree;
				_t = __t54;
				_t = _t.getNextSibling();
				break;
			}
			case COMBINED_GRAMMAR:
			{
				AST __t55 = _t;
				GrammarAST tmp9_AST_in = (GrammarAST)_t;
				match(_t,COMBINED_GRAMMAR);
				_t = _t.getFirstChild();
				if ( inputState.guessing==0 ) {
					grammar.type = Grammar.COMBINED;
				}
				grammarSpec(_t);
				_t = _retTree;
				_t = __t55;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				finish();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void tokensSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokensSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t63 = _t;
			GrammarAST tmp10_AST_in = (GrammarAST)_t;
			match(_t,TOKENS);
			_t = _t.getFirstChild();
			{
			int _cnt65=0;
			_loop65:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN||_t.getType()==TOKEN_REF)) {
					tokenSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt65>=1 ) { break _loop65; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt65++;
			} while (true);
			}
			_t = __t63;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void action(AST _t) throws RecognitionException {
		
		GrammarAST action_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t132 = _t;
			GrammarAST tmp11_AST_in = (GrammarAST)_t;
			match(_t,RCURLY);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t132;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t13 = _t;
			GrammarAST tmp12_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop15:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==SEMI||_t.getType()==LITERAL_public||_t.getType()==LITERAL_import)) {
					grammarAttributeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop15;
				}
				
			} while (true);
			}
			_t = __t13;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecl(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_public:
				{
					GrammarAST tmp13_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_public);
					_t = _t.getNextSibling();
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				attributeVarDecl(_t);
				_t = _retTree;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp14_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_import);
				_t = _t.getNextSibling();
				GrammarAST tmp15_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeVarDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeVarDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t33 = _t;
			GrammarAST tmp16_AST_in = (GrammarAST)_t;
			match(_t,SEMI);
			_t = _t.getFirstChild();
			GrammarAST tmp17_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp18_AST_in = (GrammarAST)_t;
				match(_t,OPEN_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				GrammarAST tmp19_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				_loop36:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						GrammarAST tmp20_AST_in = (GrammarAST)_t;
						match(_t,ID);
						_t = _t.getNextSibling();
					}
					else {
						break _loop36;
					}
					
				} while (true);
				}
				GrammarAST tmp21_AST_in = (GrammarAST)_t;
				match(_t,CLOSE_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp22_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			_t = __t33;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void ruleAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST ruleAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t19 = _t;
			GrammarAST tmp23_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop21:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SEMI:
				{
					attributeVarDecl(_t);
					_t = _retTree;
					break;
				}
				case ID:
				case LITERAL_new:
				case LITERAL_using:
				{
					attributeUseDecl(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					break _loop21;
				}
				}
			} while (true);
			}
			_t = __t19;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeUseDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeUseDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp24_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp25_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getNextSibling();
				{
				GrammarAST tmp26_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ID:
				case SEMI:
				case DOT_TEXT:
				case LITERAL_new:
				case LITERAL_using:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop49:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop49;
					}
					
				} while (true);
				}
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp27_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_new);
				_t = _t.getNextSibling();
				GrammarAST tmp28_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp29_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_using);
				_t = _t.getNextSibling();
				GrammarAST tmp30_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeTypeDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeTypeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_atomic:
			{
				AST __t27 = _t;
				GrammarAST tmp31_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_atomic);
				_t = _t.getFirstChild();
				GrammarAST tmp32_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_native);
				_t = _t.getNextSibling();
				GrammarAST tmp33_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				_t = __t27;
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				AST __t28 = _t;
				GrammarAST tmp34_AST_in = (GrammarAST)_t;
				match(_t,LCURLY);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_native:
				{
					GrammarAST tmp35_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_native);
					_t = _t.getNextSibling();
					break;
				}
				case ID:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				GrammarAST tmp36_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				GrammarAST tmp37_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				_loop31:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI)) {
						attributeVarDecl(_t);
						_t = _retTree;
					}
					else {
						break _loop31;
					}
					
				} while (true);
				}
				_t = __t28;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void idQualifier(AST _t) throws RecognitionException {
		
		GrammarAST idQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp38_AST_in = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case ID:
			case SYN_SEMPRED:
			case BANGEDUP:
			case SEMI:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void arrayQualifier(AST _t) throws RecognitionException {
		
		GrammarAST arrayQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t40 = _t;
			GrammarAST tmp39_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp40_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp41_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LBRACKET:
				{
					arrayQualifier(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case DOT_TEXT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				_loop44:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==DOT_TEXT)) {
						idQualifier(_t);
						_t = _retTree;
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t40;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammarSpec(AST _t) throws RecognitionException {
		
		GrammarAST grammarSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST cmt = null;
		
		Map opts=null;
		Token optionsStartToken=null;
		
		
		try {      // for error handling
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOC_COMMENT:
			{
				cmt = (GrammarAST)_t;
				match(_t,DOC_COMMENT);
				_t = _t.getNextSibling();
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_STMT:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				if ( inputState.guessing==0 ) {
					optionsStartToken=((GrammarAST)_t).getToken();
				}
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			rules(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		GrammarAST rules_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt72=0;
			_loop72:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case RULE:
				{
					rule(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_COLON:
				{
					constructorRule(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					if ( _cnt72>=1 ) { break _loop72; } else {throw new NoViableAltException(_t);}
				}
				}
				_cnt72++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void tokenSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokenSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST t2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp42_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp43_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN:
				case TOKEN_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN:
			{
				AST __t68 = _t;
				GrammarAST tmp44_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getFirstChild();
				t2 = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp45_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					GrammarAST tmp46_AST_in = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					break;
				}
				case KEYWORD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				GrammarAST tmp47_AST_in = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t68;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		GrammarAST rule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST b = null;
		
			String mod=null;
			String name=null;
			Rule r = null;
		
		
		try {      // for error handling
			AST __t74 = _t;
			GrammarAST tmp48_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				mod=modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
					name = id.getText();
							currentRuleName = name;
							if ( Character.isUpperCase(name.charAt(0)) &&
									 grammar.type==Grammar.COMBINED )
							{
							// a merged grammar spec, track lexer rules and send to another grammar
								grammar.defineLexerRuleFoundInParser(id.getToken(), rule_AST_in);
							}
							else {
								int numAlts = countAltsForRule(rule_AST_in);
								grammar.defineRule(id.getToken(), mod, null, rule_AST_in, null, numAlts);
								r = grammar.getRule(name);
							}
						
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				this.blockLevel=0;
			}
			b = _t==ASTNULL ? null : (GrammarAST)_t;
			block(_t);
			_t = _retTree;
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp49_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t74;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void constructorRule(AST _t) throws RecognitionException {
		
		GrammarAST constructorRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t81 = _t;
			GrammarAST tmp50_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_COLON);
			_t = _t.getFirstChild();
			GrammarAST tmp51_AST_in = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			{
			int _cnt83=0;
			_loop83:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt83>=1 ) { break _loop83; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt83++;
			} while (true);
			}
			_t = __t81;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final String  modifier(AST _t) throws RecognitionException {
		String mod;
		
		GrammarAST modifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		mod = modifier_AST_in.getText();
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_protected:
			{
				GrammarAST tmp52_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_protected);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_public:
			{
				GrammarAST tmp53_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_public);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_private:
			{
				GrammarAST tmp54_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_private);
				_t = _t.getNextSibling();
				break;
			}
			case FRAGMENT:
			{
				GrammarAST tmp55_AST_in = (GrammarAST)_t;
				match(_t,FRAGMENT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return mod;
	}
	
	public final void block(AST _t) throws RecognitionException {
		
		GrammarAST block_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		this.blockLevel++;
		if ( this.blockLevel==1 ) {this.outerAltNum=1;}
		
		
		try {      // for error handling
			AST __t97 = _t;
			GrammarAST tmp56_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt100=0;
			_loop100:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					alternative(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						if ( this.blockLevel==1 ) {this.outerAltNum++;}
					}
				}
				else {
					if ( _cnt100>=1 ) { break _loop100; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt100++;
			} while (true);
			}
			GrammarAST tmp57_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t97;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				this.blockLevel--;
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void exceptionGroup(AST _t) throws RecognitionException {
		
		GrammarAST exceptionGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt107=0;
			_loop107:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_exception)) {
					exceptionSpec(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt107>=1 ) { break _loop107; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt107++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeItem(AST _t) throws RecognitionException {
		
		GrammarAST attributeItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				attrLabel(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			attributeElement(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final int  countAltsForRule(AST _t) throws RecognitionException {
		int n=0;
		
		GrammarAST countAltsForRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		
		try {      // for error handling
			AST __t85 = _t;
			GrammarAST tmp58_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			AST __t90 = _t;
			GrammarAST tmp59_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt93=0;
			_loop93:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					GrammarAST tmp60_AST_in = (GrammarAST)_t;
					match(_t,ALT);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						n++;
					}
				}
				else {
					if ( _cnt93>=1 ) { break _loop93; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt93++;
			} while (true);
			}
			GrammarAST tmp61_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t90;
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp62_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t85;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return n;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		GrammarAST alternative_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t102 = _t;
			GrammarAST tmp63_AST_in = (GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt104=0;
			_loop104:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt104>=1 ) { break _loop104; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt104++;
			} while (true);
			}
			GrammarAST tmp64_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t102;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		GrammarAST element_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST l = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RANGE:
			case CHAR_RANGE:
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case NOT:
			case WILDCARD:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					atom(_t);
					_t = _retTree;
					break;
				}
				case NOT:
				{
					AST __t123 = _t;
					GrammarAST tmp65_AST_in = (GrammarAST)_t;
					match(_t,NOT);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					_t = __t123;
					_t = _t.getNextSibling();
					break;
				}
				case RANGE:
				{
					AST __t124 = _t;
					GrammarAST tmp66_AST_in = (GrammarAST)_t;
					match(_t,RANGE);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					atom(_t);
					_t = _retTree;
					_t = __t124;
					_t = _t.getNextSibling();
					break;
				}
				case CHAR_RANGE:
				{
					AST __t125 = _t;
					GrammarAST tmp67_AST_in = (GrammarAST)_t;
					match(_t,CHAR_RANGE);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					atom(_t);
					_t = _retTree;
					_t = __t125;
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				case CARET:
				{
					ast_suffix(_t);
					_t = _retTree;
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case BANGEDUP:
			{
				ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				treeMatcher(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp68_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			{
				l = _t==ASTNULL ? null : (GrammarAST)_t;
				attrLabel(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case WILDCARD:
				{
					atom(_t);
					_t = _retTree;
					break;
				}
				case NOT:
				{
					AST __t129 = _t;
					GrammarAST tmp69_AST_in = (GrammarAST)_t;
					match(_t,NOT);
					_t = _t.getFirstChild();
					atom(_t);
					_t = _retTree;
					_t = __t129;
					_t = _t.getNextSibling();
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				{
					baseebnf(_t);
					_t = _retTree;
					break;
				}
				case TREE_BEGIN:
				{
					treeMatcher(_t);
					_t = _retTree;
					break;
				}
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeElement(_t);
					_t = _retTree;
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				attributeElement(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t130 = _t;
				GrammarAST tmp70_AST_in = (GrammarAST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t130;
				_t = _t.getNextSibling();
				break;
			}
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				break;
			}
			case SYN_SEMPRED:
			{
				GrammarAST tmp71_AST_in = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp72_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void exceptionSpec(AST _t) throws RecognitionException {
		
		GrammarAST exceptionSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t115 = _t;
			GrammarAST tmp73_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_exception);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RBRACKET:
			{
				arg_decl(_t);
				_t = _retTree;
				break;
			}
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt118=0;
			_loop118:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_catch)) {
					exceptionHandler(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt118>=1 ) { break _loop118; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt118++;
			} while (true);
			}
			_t = __t115;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void arg_decl(AST _t) throws RecognitionException {
		
		GrammarAST arg_decl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t109 = _t;
			GrammarAST tmp74_AST_in = (GrammarAST)_t;
			match(_t,RBRACKET);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp75_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp76_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case COLON:
			{
				GrammarAST tmp77_AST_in = (GrammarAST)_t;
				match(_t,COLON);
				_t = _t.getNextSibling();
				{
				int _cnt113=0;
				_loop113:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt113>=1 ) { break _loop113; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt113++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t109;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void assignment(AST _t) throws RecognitionException {
		
		GrammarAST assignment_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t141 = _t;
			GrammarAST tmp78_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				break;
			}
			case TOKEN_REF:
			{
				GrammarAST tmp79_AST_in = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp80_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t141;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void exceptionHandler(AST _t) throws RecognitionException {
		
		GrammarAST exceptionHandler_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t120 = _t;
			GrammarAST tmp81_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_catch);
			_t = _t.getFirstChild();
			arg_decl(_t);
			_t = _retTree;
			action(_t);
			_t = _retTree;
			_t = __t120;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t) throws RecognitionException {
		
		GrammarAST atom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST r = null;
		GrammarAST t = null;
		GrammarAST c = null;
		GrammarAST s = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				r = (GrammarAST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					grammar.altReferencesRule(currentRuleName, r, this.outerAltNum);
				}
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						if ( grammar.type==Grammar.LEXER ) {
							grammar.altReferencesRule(currentRuleName, t, this.outerAltNum);
						}
						else {
							grammar.altReferencesTokenID(currentRuleName, t, this.outerAltNum);
						}
						
				}
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						if ( grammar.type!=Grammar.LEXER ) {
							Rule rule = grammar.getRule(currentRuleName);
								if ( rule!=null ) {
									rule.trackTokenReferenceInAlt(c, outerAltNum);
							}
						}
						
				}
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						if ( grammar.type!=Grammar.LEXER ) {
							Rule rule = grammar.getRule(currentRuleName);
								if ( rule!=null ) {
									rule.trackTokenReferenceInAlt(s, outerAltNum);
							}
						}
						
				}
				break;
			}
			case WILDCARD:
			{
				GrammarAST tmp82_AST_in = (GrammarAST)_t;
				match(_t,WILDCARD);
				_t = _t.getNextSibling();
				break;
			}
			case SET:
			{
				set(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void ast_suffix(AST _t) throws RecognitionException {
		
		GrammarAST ast_suffix_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case CARET:
			{
				GrammarAST tmp83_AST_in = (GrammarAST)_t;
				match(_t,CARET);
				_t = _t.getNextSibling();
				break;
			}
			case BANG:
			{
				GrammarAST tmp84_AST_in = (GrammarAST)_t;
				match(_t,BANG);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		GrammarAST ebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANGEDUP:
			{
				AST __t153 = _t;
				GrammarAST tmp85_AST_in = (GrammarAST)_t;
				match(_t,BANGEDUP);
				_t = _t.getFirstChild();
				baseebnf(_t);
				_t = _retTree;
				_t = __t153;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				baseebnf(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void treeMatcher(AST _t) throws RecognitionException {
		
		GrammarAST treeMatcher_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t168 = _t;
			GrammarAST tmp86_AST_in = (GrammarAST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			element(_t);
			_t = _retTree;
			{
			_loop170:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==RANGE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					break _loop170;
				}
				
			} while (true);
			}
			_t = __t168;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attrLabel(AST _t) throws RecognitionException {
		
		GrammarAST attrLabel_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LABEL_ATTRIBUTE:
			{
				a = (GrammarAST)_t;
				match(_t,LABEL_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			case ASSIGN_ATTRIBUTE:
			{
				GrammarAST tmp87_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN_ATTRIBUTE);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SET:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop147:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop147;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void baseebnf(AST _t) throws RecognitionException {
		
		GrammarAST baseebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				block(_t);
				_t = _retTree;
				break;
			}
			case OPTIONAL:
			{
				AST __t157 = _t;
				GrammarAST tmp88_AST_in = (GrammarAST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t157;
				_t = _t.getNextSibling();
				break;
			}
			default:
				boolean synPredMatched156 = false;
				if (_t==null) _t=ASTNULL;
				if (((_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE))) {
					AST __t156 = _t;
					synPredMatched156 = true;
					inputState.guessing++;
					try {
						{
						dotLoop(_t);
						_t = _retTree;
						}
					}
					catch (RecognitionException pe) {
						synPredMatched156 = false;
					}
					_t = __t156;
inputState.guessing--;
				}
				if ( synPredMatched156 ) {
					dotLoop(_t);
					_t = _retTree;
				}
				else if ((_t.getType()==CLOSURE)) {
					AST __t158 = _t;
					GrammarAST tmp89_AST_in = (GrammarAST)_t;
					match(_t,CLOSURE);
					_t = _t.getFirstChild();
					block(_t);
					_t = _retTree;
					_t = __t158;
					_t = _t.getNextSibling();
				}
				else if ((_t.getType()==POSITIVE_CLOSURE)) {
					AST __t159 = _t;
					GrammarAST tmp90_AST_in = (GrammarAST)_t;
					match(_t,POSITIVE_CLOSURE);
					_t = _t.getFirstChild();
					block(_t);
					_t = _retTree;
					_t = __t159;
					_t = _t.getNextSibling();
				}
			else {
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeElement(AST _t) throws RecognitionException {
		
		GrammarAST attributeElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				attribute(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp91_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				attributeGroup(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp92_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ATTRIBUTE_STMT:
			{
				attributeStatements(_t);
				_t = _retTree;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp93_AST_in = (GrammarAST)_t;
				match(_t,CURRENT_TREE);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp94_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case SYNPRED:
				case RANGE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp95_AST_in = (GrammarAST)_t;
				match(_t,LPAREN);
				_t = _t.getNextSibling();
				{
				_loop199:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop199;
					}
					
				} while (true);
				}
				GrammarAST tmp96_AST_in = (GrammarAST)_t;
				match(_t,RPAREN);
				_t = _t.getNextSibling();
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				treeConstructor(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void sempred(AST _t) throws RecognitionException {
		
		GrammarAST sempred_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t134 = _t;
			GrammarAST tmp97_AST_in = (GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			template(_t);
			_t = _retTree;
			_t = __t134;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void template(AST _t) throws RecognitionException {
		
		GrammarAST template_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				GrammarAST tmp98_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				GrammarAST tmp99_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				{
				int _cnt139=0;
				_loop139:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						assignment(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt139>=1 ) { break _loop139; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt139++;
				} while (true);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attribute(AST _t) throws RecognitionException {
		
		GrammarAST attribute_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			GrammarAST tmp100_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				arrayQualifier(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SYNPRED:
			case RANGE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop151:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					idQualifier(_t);
					_t = _retTree;
				}
				else {
					break _loop151;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
/** Track the .* and .+ idioms and make them greedy by default.
 *  If someone specifies an option, it won't match these
 */
	public final void dotLoop(AST _t) throws RecognitionException {
		
		GrammarAST dotLoop_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		GrammarAST block = (GrammarAST)dotLoop_AST_in.getFirstChild();
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case CLOSURE:
			{
				AST __t162 = _t;
				GrammarAST tmp101_AST_in = (GrammarAST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				dotBlock(_t);
				_t = _retTree;
				_t = __t162;
				_t = _t.getNextSibling();
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t163 = _t;
				GrammarAST tmp102_AST_in = (GrammarAST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				dotBlock(_t);
				_t = _retTree;
				_t = __t163;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
				Map opts=new HashMap();
				opts.put("greedy", "false");
				if ( grammar.type!=Grammar.LEXER ) {
				// parser grammars assume k=1 for .* loops
				// otherwise they look til EOF!
				opts.put("k", new Integer(1));
				}
				block.setOptions(grammar,opts);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void dotBlock(AST _t) throws RecognitionException {
		
		GrammarAST dotBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t165 = _t;
			GrammarAST tmp103_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			AST __t166 = _t;
			GrammarAST tmp104_AST_in = (GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			GrammarAST tmp105_AST_in = (GrammarAST)_t;
			match(_t,WILDCARD);
			_t = _t.getNextSibling();
			GrammarAST tmp106_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t166;
			_t = _t.getNextSibling();
			GrammarAST tmp107_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t165;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void set(AST _t) throws RecognitionException {
		
		GrammarAST set_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t174 = _t;
			GrammarAST tmp108_AST_in = (GrammarAST)_t;
			match(_t,SET);
			_t = _t.getFirstChild();
			{
			int _cnt176=0;
			_loop176:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==CHAR_RANGE||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF)) {
					setElement(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt176>=1 ) { break _loop176; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt176++;
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANG:
			case CARET:
			{
				ast_suffix(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t174;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void setElement(AST _t) throws RecognitionException {
		
		GrammarAST setElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		GrammarAST t = null;
		GrammarAST s = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t179 = _t;
				GrammarAST tmp109_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t179;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeGroup(AST _t) throws RecognitionException {
		
		GrammarAST attributeGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t181 = _t;
			GrammarAST tmp110_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_GROUP);
			_t = _t.getFirstChild();
			{
			_loop183:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					attributeItem(_t);
					_t = _retTree;
					break;
				}
				case STRING_LITERAL:
				{
					GrammarAST tmp111_AST_in = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					break _loop183;
				}
				}
			} while (true);
			}
			_t = __t181;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeBlock(AST _t) throws RecognitionException {
		
		GrammarAST attributeBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				{
				_loop186:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop186;
					}
					
				} while (true);
				}
				break;
			}
			case SEMPRED:
			{
				sempred(_t);
				_t = _retTree;
				{
				_loop188:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						attributeItem(_t);
						_t = _retTree;
					}
					else {
						break _loop188;
					}
					
				} while (true);
				}
				{
				GrammarAST tmp112_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getNextSibling();
				attributeBlock(_t);
				_t = _retTree;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeStatements(AST _t) throws RecognitionException {
		
		GrammarAST attributeStatements_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t191 = _t;
			GrammarAST tmp113_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			attributeBlock(_t);
			_t = _retTree;
			_t = __t191;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void treeConstructor(AST _t) throws RecognitionException {
		
		GrammarAST treeConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t201 = _t;
			GrammarAST tmp114_AST_in = (GrammarAST)_t;
			match(_t,TREE_CONSTRUCTOR);
			_t = _t.getFirstChild();
			attributeItem(_t);
			_t = _retTree;
			{
			int _cnt203=0;
			_loop203:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt203>=1 ) { break _loop203; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt203++;
			} while (true);
			}
			_t = __t201;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF"
	};
	
	}
	
