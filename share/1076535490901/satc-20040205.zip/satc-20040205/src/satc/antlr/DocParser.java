package satc.antlr;

import java.util.ArrayList;

import antlr.LLkParser;
import antlr.MismatchedTokenException;
import antlr.ParserSharedInputState;
import antlr.RecognitionException;
import antlr.TokenBuffer;
import antlr.TokenStream;
import antlr.TokenStreamException;

public class DocParser extends LLkParser {

    public DocParser(int k_) {
		super(k_);
    }

    public DocParser(ParserSharedInputState state, int k_) {
		super(state, k_);
    }

    public DocParser(TokenBuffer tokenBuf, int k_) {
		super(tokenBuf, k_);
    }

    public DocParser(TokenStream lexer, int k_) {
		super(lexer, k_);
    }

    public int currentLine;
    public int nextLine;
	public int previousStartLine;
	public boolean justStarted = true;
public int startLine = 0;

public ArrayList newNodes = new ArrayList();


	public void match( int i) throws MismatchedTokenException, TokenStreamException {
//		System.out.println("matching: " + i);
        if (LA(1) == i) 
			if ( inputState.guessing==0 ) { 
				currentLine = LT(1).getLine();
				if( justStarted) {
					previousStartLine = currentLine;
					justStarted = false;
				}
			}
//		System.out.println("line = " + currentLine);
		super.match( i);
if( LT(1) != null)
nextLine = LT(1).getLine();

	}

    /** Parser error-reporting function can be overridden in subclass */
    public void reportError(RecognitionException ex) {
        System.err.println(ex);
		errorFound = true;
    }

public boolean errorFound = false;

}