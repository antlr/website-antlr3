/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.JTextComponent;

import satc.swing.SyntaxTextAreaUI;


/**
 *  This class acts as a a portal to the SATC package, providing a collection 
 *  of utility methods that should cover the common usage of SATC.
 */
public class Syntax {

    public static boolean filesLoaded = false;

	private static boolean reparseOnEdit = true;

    /**
     *  Register a new syntax mode.
     */
    public static void register( SyntaxInfo info) {
        infoList.add( info);
    }

    /**
     *  Load a textArea from a Reader. 
     */
    public static void read( JTextArea textArea, Reader in, String syntaxName) {
        setSyntax( textArea, syntaxName);
        try {
            textArea.read( in, "");
        } catch( Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *  Load a textArea from a file.
     */
    public static void read( JTextArea textArea, File f) {
        BufferedReader in = null;
        try {
            in = new BufferedReader( new FileReader( f));
            SyntaxInfo info = getSyntaxInfoOrDefault( f);
            read( textArea, in, info.getName());
	    in.close();
        } catch( Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *  Returns a new textArea with syntax mode <code>syntaxName<code/>.
     */
    public static JTextArea createTextArea( String syntaxName) {
        JTextArea textArea = new JTextArea();
        setSyntax( textArea, syntaxName);
        return textArea;
    }
    
    /**
     *  Set the syntax mode for a textArea. The current content is preserved. 
     */
    public static void setSyntax( JTextComponent textArea, String syntaxName) {
        textArea.setUI( new SyntaxTextAreaUI( syntaxName));
    }

    /**
     *  Installs file filters for all registered syntax modes.
     */
    public static void setFileFilters( JFileChooser fileChooser) {
        Iterator it = infoList.iterator();
        while( it.hasNext()) {
            fileChooser.addChoosableFileFilter((FileFilter) it.next());
        }
        fileChooser.addChoosableFileFilter( new FileFilter() {
            public String getDescription() {
                return "All known files";
            }
            public boolean accept( File f ) {
                return f.isDirectory() || getSyntaxInfo( f) != null;
            }
        });
    }
    
    /**
     *  Enables/disables the continuous reparsing of text as it is typed.
     *  Default value is false, for reason of speed.
     */
    public static void setReparseOnEdit( boolean b) {
        reparseOnEdit = b;
    }
    
    /**
     *  Returns true if the continuous reparsing of text as it is typed
     *  is enabled.
     */
    public static boolean getReparseOnEdit() {
        return reparseOnEdit;
    }
    
    
///////////////////////////////////////////////////////////////////////////////////////////////
    
    /**
     *  Translates the syntax mode name to a MIME type.
     */
    public static String getContentType( String syntaxName) {
        String contentType = "text/plain";
        SyntaxInfo si;
        Iterator it = infoList.iterator();
        while( it.hasNext()) {
            si = (SyntaxInfo) it.next();
            if( si.getName().equals( syntaxName)) {
                contentType = si.getType();
            }
        }
        return contentType;
    }
   
///////////////////////////////////////////////////////////////////////////////////////////////
    
    private static SyntaxInfo getSyntaxInfoOrDefault( File f) {
        SyntaxInfo si = getSyntaxInfo( f );
        return si == null ? SyntaxInfo.getDefaultSyntaxInfo() : si;
    }
    
    private static SyntaxInfo getSyntaxInfo( File f) {
        for( int i = 0; i < infoList.size(); i++) {
            if( ((SyntaxInfo)infoList.get(i)).accept( f))
                return (SyntaxInfo)infoList.get(i);
        }
        return null;
    }

///////////////////////////////////////////////////////////////////////

    private static List infoList = new ArrayList();

    private static void p( String s) { System.out.println( s); }

}
