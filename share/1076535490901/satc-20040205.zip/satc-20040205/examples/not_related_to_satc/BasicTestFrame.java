/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package examples.not_related_to_satc;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.basic.BasicSplitPaneUI;
import javax.swing.plaf.metal.MetalLookAndFeel;

import satc.Syntax;
/**
*  A frame with several documents opened in a tabbed pane,
*  each document with a different syntax.
*  You can open your own files using the "Open" button.
*/
public class BasicTestFrame extends JFrame {

    /**
     * Creates the frame.
     */
    public BasicTestFrame() {
        try {
	        UIManager.setLookAndFeel(
	            UIManager.getCrossPlatformLookAndFeelClassName()
            );
            MetalLookAndFeel.setCurrentTheme( new FontPlain11MetalTheme());
        } catch( Exception e) {
            e.printStackTrace();
        }
        setTitle("SATC");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(
//        	0, 0, screenSize.width, screenSize.height
            screenSize.width/8,
            screenSize.height/8,
            3*screenSize.width/4,
            3*screenSize.height/4
        );

        addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e) {
                System.exit(0);
            };
        });
		fileChooser = new JFileChooser();
        toolBar = new JToolBar();
        toolBar.add( new OpenAction());
        getContentPane().add( toolBar, BorderLayout.NORTH);
        JPanel panel = new JPanel( new BorderLayout());
		leftTabbedPane = new JTabbedPane(3);
        JSplitPane splitPane = new JSplitPane( 1, leftTabbedPane, getTabbedPane());
        if (Syntax.getReparseOnEdit())
        	splitPane.setDividerLocation(300);
        else
			splitPane.setDividerLocation(0);
		splitPane.setDividerSize(3);
        ((BasicSplitPaneUI) splitPane.getUI()).getDivider().setBorder( BorderFactory.createEmptyBorder());
        getContentPane().add( splitPane, BorderLayout.CENTER);
    }
    
    public void readSettings() { }

    public void updateTextArea( JTextArea textArea) { }
    
    /**
     * Starts the application.
     */
    public static void main(String[] args) {
        try {
            BasicTestFrame frame = new BasicTestFrame();
            frame.setVisible(true);
        } catch( Throwable exception) {
            exception.printStackTrace();
        }
    }

    /**
    *  Returns the tabbed pane. If the tabbed pane is not existing,
    *  it is created and populated with sample documents.
    */
    public JTabbedPane getTabbedPane() {
        if( tabbedPane == null) {
            tabbedPane = new JTabbedPane(3);
        }
        
        tabbedPane.addChangeListener(
            new ChangeListener() {
                public void stateChanged( ChangeEvent e) {
                	JTextArea textArea = getCurrentTextArea();
                    if( textArea != null) {                 	
                        textArea.grabFocus();
                        updateTextArea( textArea);
                    }
                }
            }
        );
        return tabbedPane;
    }

    /**
     * Opens a file and load it in a new tab of the tabbed pane.
     */
    public void loadFile( File f) { }
    
    /**
     * Updates the AST for the current file.
     */
    public void updateAST( JTextArea textArea) { }
    
    
    public JTextArea getNewTextArea() {
        JTextArea textArea = new JTextArea();
        textArea.setFont( new Font( "MonoSpaced", Font.PLAIN, 12));
        textArea.setMargin( new Insets( 7, 7, 7, 7));
        textArea.setTabSize(4);
        return textArea;
    }
    
    public void addTextArea( JTextArea textArea, String name) {
        tabbedPane.addTab( name, new JScrollPane( textArea));
        tabbedPane.setSelectedIndex( tabbedPane.getTabCount()-1);          
    }
    
    protected JTabbedPane tabbedPane;
    protected JTabbedPane leftTabbedPane;
    protected JPanel astPanel;
    protected JFileChooser fileChooser;// = new JFileChooser();
	protected JToolBar toolBar;
     
    private JTextArea getTextArea( int index) {
        JScrollPane scp = (JScrollPane) tabbedPane.getComponent( index);
        return (JTextArea) scp.getViewport().getView();
    }
    
    private JTextArea getCurrentTextArea() {
        if( tabbedPane.getSelectedIndex() >= 0) {
            return getTextArea( tabbedPane.getSelectedIndex());
        }
        else return null;
    }
    
    /**
    *  Action handler for the "Open" button
    */
    public class OpenAction extends AbstractAction {
        public OpenAction() {
            super( "Open");
        }
        public void actionPerformed( ActionEvent evt) {
            File f = null;
    	    fileChooser.setCurrentDirectory( new File( "."));
    	    int result = fileChooser.showOpenDialog( BasicTestFrame.this);
    	    if( result == JFileChooser.APPROVE_OPTION) {
    	        f = fileChooser.getSelectedFile();
            }
            if( f == null) return;
            loadFile( f);
        }
    }
    
}
