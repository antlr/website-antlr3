package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.CarrierStream;
import org.antlr_yggdrasil.runtime.DefaultCarrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.DefaultPayload;

public class TestTreeNodeStream extends TestCase {

	Carrier[] data;
	Carrier root;
	String[] names = { "Root", "One", "Two", "Three", "Four", "Five", "Six",
			"Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen",
			"Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
	};
	
	int indices[] = { 100, 2, 101, 2, 103, 104, 2, 105, 2, 107, 108, 2, 109,
			2, 111, 112, 2, 113, 2, 115, 116, 2, 117, 2, 119, 3, 118, 3, 3, 114, 3, 3,
			110, 3, 3, 106, 3, 3, 102, -1 };
	
	CarrierStream stream = null;

	public TestTreeNodeStream(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
		data = new DefaultCarrier[20];
		for (int i=0; i<20; i++)
			data[i] = new DefaultCarrier(new DefaultPayload(100 + i, names[i]));
		
		root = data[0];
		for (int i=0; i<19; i++) {
			switch (i % 4) {
			case 0:
				data[i].setFirstChild(data[i+1]);
				break;
				
			case 1:
				data[i].setNextSibling(data[i+1]);
				break;
				
			case 2:
				data[i-1].setFirstChild(data[i+1]);
				break;
				
			case 3:
				data[i].setNextSibling(data[i+1]);
				break;				
			}
		}
		stream = new CarrierStream(root);
//		System.out.println(root.toString());
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		root = null;
		data = null;
		stream = null;
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.CommonTreeNodeStream()'
	 */
	public void testCommonTreeNodeStream() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.LT(int)'
	 */
	public void testLT() {
		int idx[] = new int[40];
		
		for (int i=0; i<40; i++) {
			idx[i] = stream.LT(i+1).getType();
//			System.out.println("" + i + ":  " + idx[i]);
		}
		
		for (int i = 0; i<40; i++) {
//			System.out.println("" + i + ": " + idx[i] + " == " + indices[i]);
			assertTrue(idx[i] == indices[i]);
		}
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.getTreeSource()'
	 */
	public void testGetTreeSource() {
		assertTrue(stream.getTreeSource() == root);
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.toString(Object, Object)'
	 */
	public void testToStringObjectObject() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.consume()'
	 */
	public void testConsume() {
		assertTrue(stream.LT(1) == root.getAttributes());
		stream.consume();
		assertTrue(stream.LT(1).getType() == indices[1]);
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.LA(int)'
	 */
	public void testLA() {
		int[] idx = new int[40];
		
		for (int i=0; i<39; i++) {
			idx[i] = stream.LA(i+1);
			assertTrue(idx[i] == indices[i]);
		}
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.mark()'
	 */
	public void testMark() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.index()'
	 */
	public void testIndex() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.rewind(int)'
	 */
	public void testRewindInt() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.rewind()'
	 */
	public void testRewind() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.release(int)'
	 */
	public void testRelease() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.seek(int)'
	 */
	public void testSeek() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.size()'
	 */
	public void testSize() {
		// TODO Auto-generated method stub

	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.hasNext()'
	 */
	public void testHasNext() {
		int i = 0;
		for (; i<40; i++) {
			assertTrue(stream.hasNext());
			System.out.println("" + i + ": " + stream.LA(1));
			stream.consume();
		}
		assertFalse(stream.hasNext());
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.next()'
	 */
	public void testNext() {
		System.out.println(stream.LA(1));
		assertTrue(stream.next().getType() == indices[1]);
		System.out.println(stream.LA(1));
		assertTrue(stream.next().getType() == indices[2]);
		System.out.println(stream.LA(1));
		assertTrue(stream.next().getType() == indices[3]);
		System.out.println(stream.LA(1));
	}

	/*
	 * Test method for 'antlr.CommonTreeNodeStream.remove()'
	 */
	public void testRemove() {
		// TODO Auto-generated method stub

	}

}
