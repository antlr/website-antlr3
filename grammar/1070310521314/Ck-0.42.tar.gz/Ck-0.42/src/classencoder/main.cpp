/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


/*!
 * Represents a java class file.
 */

#include <iostream>
#include <string>
#include "defs.hpp"
#include "class.hpp"
#include "method_info.hpp"
#include "bytecode.hpp"

using namespace std;

int main( int argc, char **argv )
{
    Class test;
    method_info *method = test.addMethod( "<init>" );
    ByteCode *code = method->code();
    code->emit_aload( 0 );
    code->emit_invokespecial( "java/lang/Object", "<init>", "()V" );
    code->emit_return();
    method->finish();

    method = test.addMethod( "main" );
    method->setAccess( ACC_PUBLIC | ACC_STATIC );
    method->addParameter( "java/lang/String", true );
    code = method->code();
    code->emit_getstatic( "java/lang/System", "out", "Ljava/io/PrintStream;" );
    code->emit_sipush( 42 );
    code->emit_invokevirtual( "java/io/PrintStream", "println", "(I)V" );
    code->emit_return();
    method->finish();

    test.write( "output.class" );
    return 0;
}
