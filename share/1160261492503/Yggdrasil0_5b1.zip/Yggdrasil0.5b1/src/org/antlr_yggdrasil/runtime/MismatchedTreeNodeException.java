package org.antlr_yggdrasil.runtime;


/**
 */
public class MismatchedTreeNodeException extends RecognitionException {
	public int expecting;
	public Object foundNode;

	public MismatchedTreeNodeException() {
	}

	public MismatchedTreeNodeException(int expecting, CarrierStream input) {
		super(input);
		this.foundNode = input.LT(1);
		this.expecting = expecting;
	}

	public String toString() {
		return "MismatchedTreeNodeException("+getUnexpectedType()+"!="+expecting+")";
	}
}
