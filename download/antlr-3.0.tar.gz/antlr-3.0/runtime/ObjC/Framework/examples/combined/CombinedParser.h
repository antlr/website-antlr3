// $ANTLR 3.0b6 Combined.g 2007-02-01 01:27:56

#import <Cocoa/Cocoa.h>
#import <ANTLR/ANTLR.h>


#pragma mark Cyclic DFA

#pragma mark Tokens
#define CombinedParser_INT	5
#define CombinedParser_WS	6
#define CombinedParser_EOF	-1
#define CombinedParser_ID	4

#pragma mark Dynamic Global Scopes

#pragma mark Dynamic Rule Scopes

#pragma mark Rule Return Scopes


@interface CombinedParser : ANTLRParser {

			

 }


- (void) stat;
- (void) identifier;



@end