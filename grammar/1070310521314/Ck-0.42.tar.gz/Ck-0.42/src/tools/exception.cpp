/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "exception.hpp"
#include <sstream>

using namespace std;

/*!
 *  Constructor.
 * \param error the error message
 */
Exception::Exception( const std::string &error )
{
    ErrorMsg = error;
}

//! Advanced constructor.
/*!
 * This constructor takes the additional file and line arguments to provide more useful
 * debug output.
 * \param file The filename of the sourcefile where the exception occured. The __FILE__
 * macro can be useful for this purpose.
 * \param line The line number in the sourcefile where the exception occured. The __LINE__
 * macro can be useful for this purpose.
 */
Exception::Exception( const char *file, int line, const std::string &error )
{
    stringstream ss;
    ss << file << ":" << line << " " << error;
    ErrorMsg = ss.str();
}


/*!
  Destroys the object
*/
Exception::~Exception()
{
}
