// Yggdrasil generated type class


public class PayloadToken extends Payload {
	private Integer line = null;
	private Integer charPositionInLine = null;
	private Integer channel = null;
	private Integer index = null;
	private Integer start = null;
	private Integer stop = null;
	
	public PayloadToken(int type, String txt) {
		super(type, txt);
	}

	public Integer getLine() {
		return line;
	}

	public void setLine(Integer tmp_) {
		line = (Integer) tmp_;
	}

	public Integer getCharPositionInLine() {
		return charPositionInLine;
	}

	public void setCharPositionInLine(Integer tmp_) {
		charPositionInLine = (Integer) tmp_;
	}

	public Integer getChannel() {
		return channel;
	}

	public void setChannel(Integer tmp_) {
		channel = (Integer) tmp_;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer tmp_) {
		index = (Integer) tmp_;
	}

	public Integer getStart() {
		return start;
	}

	public void setStart(Integer tmp_) {
		start = (Integer) tmp_;
	}

	public Integer getStop() {
		return stop;
	}

	public void setStop(Integer tmp_) {
		stop = (Integer) tmp_;
	}

}
