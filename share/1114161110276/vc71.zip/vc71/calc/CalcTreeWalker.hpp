#ifndef INC_CalcTreeWalker_hpp_
#define INC_CalcTreeWalker_hpp_

#include <antlr/config.hpp>
#include "CalcParserTokenTypes.hpp"
/* $ANTLR 2.7.5 (20050128): "calc.g" -> "CalcTreeWalker.hpp"$ */
#include <antlr/TreeParser.hpp>

class CUSTOM_API CalcTreeWalker : public ANTLR_USE_NAMESPACE(antlr)TreeParser, public CalcParserTokenTypes
{
#line 1 "calc.g"
#line 13 "CalcTreeWalker.hpp"
public:
	CalcTreeWalker();
	static void initializeASTFactory( ANTLR_USE_NAMESPACE(antlr)ASTFactory& factory );
	int getNumTokens() const
	{
		return CalcTreeWalker::NUM_TOKENS;
	}
	const char* getTokenName( int type ) const
	{
		if( type > getNumTokens() ) return 0;
		return CalcTreeWalker::tokenNames[type];
	}
	const char* const* getTokenNames() const
	{
		return CalcTreeWalker::tokenNames;
	}
	public: float  expr(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
public:
	ANTLR_USE_NAMESPACE(antlr)RefAST getAST()
	{
		return returnAST;
	}
	
protected:
	ANTLR_USE_NAMESPACE(antlr)RefAST returnAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST _retTree;
private:
	static const char* tokenNames[];
#ifndef NO_STATIC_CONSTS
	static const int NUM_TOKENS = 12;
#else
	enum {
		NUM_TOKENS = 12
	};
#endif
	
};

#endif /*INC_CalcTreeWalker_hpp_*/
