
package org.antlr.java.crossref;

import java.io.*;


/**
* This class parses java class files and stores the information in a ClassInfo object.
*
* @see KClassInfo
*/
public class KClassFileReader implements KAccessFlags {
	/**
	* Read in and parse a java class file.
	* 
	* @param in a DataInput stream to read in the class file.
	* @param classInfo a KClassInfo to consume the class information.
	* @throws KClassFileParseException if the class file is corrupt.
	* @throws IOException if the InputStream throws an IOException.
	*/
	public void read(InputStream in, KClassInfo classInfo)
		throws KClassFileParseException, IOException 
	{
		readClass(new DataInputStream(new BufferedInputStream(in)), classInfo);
	}

	private void readClass(DataInput in, KClassInfo classInfo)
		throws KClassFileParseException, IOException
	{
		short count;

		// Magic And Version Numbers
		{
			int magic = in.readInt();
			if (magic != 0xCAFEBABE)
				throw new KClassFileParseException("Invalid classfile magic number" + 
					": expected 0xCAFEBABE, found 0x" + Integer.toHexString(magic));
			short major = in.readShort(), minor = in.readShort();
			// assume we can handle changes to the minor version number
			if (major != 0x003)
				throw new KClassFileParseException("Unrecognized classfile version " + 
					major + "." + minor);
		}

		// Constant Pool
		KConstPool cp = new KConstPool();
		cp.read(in);
		classInfo.setConstPool(cp);

		// General Class Info
		{
			short flags = in.readShort();
			short classIndex = in.readShort();
			short superClassIndex = in.readShort();
			short classNameIndex = cp.getEntryAtIndex(classIndex).getClassNameIndex();
			short superClassNameIndex = cp.getEntryAtIndex(superClassIndex).getClassNameIndex();
			String className = cp.getEntryAtIndex(classNameIndex).getString();
			String superClassName = cp.getEntryAtIndex(superClassNameIndex).getString();

			if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
				"flags=" + flags +
				"; class index=" + classIndex +
				"; super class index=" + superClassIndex);

			classInfo.setAccessFlags(flags);
			classInfo.setName(className);
			classInfo.setSuperClassName(superClassName);
		}

		// Interfaces
		count = in.readShort();
		if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
			"#interfaces=" + count);
		KDebugClassfile.indent();
		for (int i = 0; i < count; i++) 
			classInfo.addInterface(readInterface(cp, in));
		KDebugClassfile.outdent();

		// Fields
		count = in.readShort();
		if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
			"#fields=" + count);
		KDebugClassfile.indent();
		for (int i = 0; i < count; i++)
			classInfo.addField(readField(cp, in));
		KDebugClassfile.outdent();

		// Methods
		count = in.readShort();
		if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
			"#methods=" + count);
		KDebugClassfile.indent();
		for (int i = 0; i < count; i++)
			classInfo.addMethod(readMethod(cp, in));
		KDebugClassfile.outdent();

		// Attributes
		count = in.readShort();
		if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
			"#attributes=" + count);
		KDebugClassfile.indent();
		for (int i = 0; i < count; i++) 
			readClassAttribute(classInfo, cp, in);
		KDebugClassfile.outdent();
	}

	private String readInterface(KConstPool cp, DataInput in)
		throws IOException
	{
		short classIndex = in.readShort();
		if (KDebugClassfile.readInterface != null) KDebugClassfile.println(KDebugClassfile.readInterface,
			"class index=" + classIndex);
		short nameIndex = cp.getEntryAtIndex(classIndex).getClassNameIndex();
		return cp.getEntryAtIndex(nameIndex).getString();
	}

	private KFieldInfo readField(KConstPool cp, DataInput in) 
		throws KClassFileParseException, IOException 
	{
		KFieldInfo result;

		// General Field Info
		{
			short flags = in.readShort();
			short nameIndex = in.readShort();
			short signatureIndex = in.readShort();

			if (KDebugClassfile.readField != null) KDebugClassfile.println(KDebugClassfile.readField,
				"flags=" + flags +
				"; name index=" + nameIndex +
				"; signature index=" + signatureIndex);

			result = new KFieldInfo(flags, cp.getEntryAtIndex(nameIndex).getString(), 
				cp.getEntryAtIndex(signatureIndex).getString());
		}
	
		// Field Attributes
		short numAttributes = in.readShort();
		if (KDebugClassfile.readField != null) KDebugClassfile.println(KDebugClassfile.readField,
			"#attributes=" + numAttributes);
		KDebugClassfile.indent();
		for (int i = 0; i < numAttributes; i++)
			readFieldAttribute(result, cp, in);
		KDebugClassfile.outdent();

		return result;
	}

	private KMethodInfo readMethod(KConstPool cp, DataInput in) 
		throws KClassFileParseException, IOException 
	{
		KMethodInfo result;

		// General Method Info
		{
			short flags = in.readShort();
			short nameIndex = in.readShort();
			short signatureIndex = in.readShort();
			String methodName = cp.getEntryAtIndex(nameIndex).getString();
			String methodSignature = cp.getEntryAtIndex(signatureIndex).getString();

			if (KDebugClassfile.readMethod != null) KDebugClassfile.println(KDebugClassfile.readMethod,
				"flags=" + flags +
				"; name index=" + nameIndex +
				"; signature index=" + signatureIndex);

			result = new KMethodInfo(flags, methodName, methodSignature);
		}

		// Method Attributes
		short methodAttrCount = in.readShort();
		if (KDebugClassfile.readMethod != null) KDebugClassfile.println(KDebugClassfile.readMethod,
			"#attributes=" + methodAttrCount);
		KDebugClassfile.indent();

		for (int iMethodAttr = 0; iMethodAttr < methodAttrCount; iMethodAttr++)
			readMethodAttribute(result, cp, in);

		KDebugClassfile.outdent();

		return result;
	}

	private void readClassAttribute(KClassInfo classInfo, KConstPool cp, 
		DataInput in) throws IOException
	{
		short nameIndex = in.readShort();
		int length = in.readInt();

		// make sure we read the entire attribute -- if it has bad data,
		// an exception might get thrown before we've read it all
		byte[] bytes = new byte[length];
		in.readFully(bytes);
		in = new DataInputStream(new ByteArrayInputStream(bytes));

		if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
			"attribute name index=" + nameIndex +
			"; length=" + length);
		KDebugClassfile.indent();

		try {

			String name = cp.getEntryAtIndex(nameIndex).getString();

			// SourceFile Attribute
			if (name.equals("SourceFile")) {
				short filenameIndex = in.readShort();
				if (KDebugClassfile.readClass != null) KDebugClassfile.println(KDebugClassfile.readClass,
					"filename index=" + filenameIndex);
				classInfo.setSourceFile(cp.getEntryAtIndex(filenameIndex).getString());
			}

			else if (name.equals("InnerClasses"))
				classInfo.setInnerClasses(readInnerClasses(cp, in));

			else 
				classInfo.addAttribute(readUnknownAttribute(name, length, in));

		} catch (KConstPoolEntryError e) {
			if (KDebugClassfile.readBadData != null) KDebugClassfile.println(KDebugClassfile.readBadData,
				"class attribute name index=" + nameIndex);
		}

		KDebugClassfile.outdent();
	}

	private void readFieldAttribute(KFieldInfo fieldInfo, KConstPool cp, 
		DataInput in) throws IOException
	{
		short nameIndex = in.readShort();
		String name = cp.getEntryAtIndex(nameIndex).getString();
		int length = in.readInt();

		// make sure we read the entire attribute -- if it has bad data,
		// an exception might get thrown before we've read it all
		byte[] bytes = new byte[length];
		in.readFully(bytes);
		in = new DataInputStream(new ByteArrayInputStream(bytes));

		if (KDebugClassfile.readField != null) KDebugClassfile.println(KDebugClassfile.readField,
			"attribute name index=" + nameIndex +
			"; length=" + length);
		KDebugClassfile.indent();

		try {

			// ConstantValue Attribute
			if (name.equals("ConstantValue")) {
				short cvIndex = in.readShort();
				if (KDebugClassfile.readField != null) KDebugClassfile.println(KDebugClassfile.readField, 
					"constant value index=" + cvIndex);
				fieldInfo.setConstantValue(cp.getEntryAtIndex(cvIndex).getPrimitiveTypeValue());
			}

			else if (name.equals("Synthetic")) {
				if (KDebugClassfile.readField != null) KDebugClassfile.println(KDebugClassfile.readField,
					"synthetic");
				fieldInfo.setSynthetic(true);
			}

			else
				fieldInfo.addAttribute(readUnknownAttribute(name, length, in));

		} catch (KConstPoolEntryError e) {
			if (KDebugClassfile.readBadData != null) KDebugClassfile.println(KDebugClassfile.readBadData,
				"field attribute name index=" + nameIndex);
		}

		KDebugClassfile.outdent();
	}

	private void readMethodAttribute(KMethodInfo methodInfo, KConstPool cp, 
		DataInput in) throws IOException
	{
		short nameIndex = in.readShort();
		int length = in.readInt();

		// make sure we read the entire attribute -- if it has bad data,
		// an exception might get thrown before we've read it all
		byte[] bytes = new byte[length];
		in.readFully(bytes);
		in = new DataInputStream(new ByteArrayInputStream(bytes));

		if (KDebugClassfile.readMethod != null) KDebugClassfile.println(KDebugClassfile.readMethod,
			"attribute name index=" + nameIndex +
			"; length=" + length);
		KDebugClassfile.indent();

		try {

			String name = cp.getEntryAtIndex(nameIndex).getString();
			if (name.equals("Exceptions")) {
				int count = in.readShort();
				for (int i = 0; i < count; i++) {
					short exceptionClassIndex = in.readShort();
					short exceptionClassNameIndex = cp.getEntryAtIndex(exceptionClassIndex).getClassNameIndex();
					String exceptionName = cp.getEntryAtIndex(exceptionClassNameIndex). getString();
					methodInfo.addException(exceptionName);
				}
			}

			else if (name.equals("Code")) 
				methodInfo.setCodeInfo(readCode(cp, in));

			else if (name.equals("Deprecated")) {
				if (KDebugClassfile.readMethod != null) KDebugClassfile.println(KDebugClassfile.readMethod,
					"deprecated");
				methodInfo.setDeprecated(true);
			}

			else 
				methodInfo.addAttribute(readUnknownAttribute(name, length, in));

		} catch (KConstPoolEntryError e) {
			if (KDebugClassfile.readBadData != null) KDebugClassfile.println(KDebugClassfile.readBadData,
				"method attribute name index=" + nameIndex);
		}
		
		KDebugClassfile.outdent();
	}

	private KCodeInfo readCode(KConstPool cp, DataInput in) 
		throws IOException 
	{
		// General Code Info
		short maxStack = in.readShort();
		short maxLocals = in.readShort();
		byte[] bytecode = new byte[in.readInt()];

		if (KDebugClassfile.readCode != null) KDebugClassfile.println(KDebugClassfile.readCode,
			"maxStack=" + maxStack +
			"; maxLocals=" + maxLocals +
			"; bytecode length=" + bytecode.length);
		
		in.readFully(bytecode);

		// Exception Table
		KExceptionInfo[] exceptionTable = new KExceptionInfo[in.readShort()];
		if (KDebugClassfile.readCode != null) KDebugClassfile.println(KDebugClassfile.readCode,
			"exception table length=" + exceptionTable.length);
		KDebugClassfile.indent();
		for (int i = 0; i < exceptionTable.length; i++) {
			short startPC = in.readShort();
			short endPC = in.readShort();
			short handlerPC = in.readShort();
			short catchTypeIndex = in.readShort();

			if (KDebugClassfile.readCode != null) KDebugClassfile.println(KDebugClassfile.readCode,
				"startPC=" + startPC +
				"; endPC=" + endPC +
				"; handlerPC=" + handlerPC +
				"; catchTypeIndex=" + catchTypeIndex);

			String catchType = null;
			if (catchTypeIndex != 0) {		// index is null for finally blocks
				short catchTypeNameIndex = 
					cp.getEntryAtIndex(catchTypeIndex).getClassNameIndex();
				catchType = cp.getEntryAtIndex(catchTypeNameIndex).getString();
			}
			exceptionTable[i] = 
				new KExceptionInfo(startPC, endPC, handlerPC, catchType);
		}
		KDebugClassfile.outdent();

		KCodeInfo codeInfo = 
			new KCodeInfo(maxStack, maxLocals, bytecode, exceptionTable);

		// Code Attributes
		short codeAttrCount = in.readShort();
		if (KDebugClassfile.readCode != null) KDebugClassfile.println(KDebugClassfile.readCode,
			"#attributes=" + codeAttrCount);
		KDebugClassfile.indent();
		for (int iCodeAttr = 0; iCodeAttr < codeAttrCount; iCodeAttr++)
			readCodeAttribute(codeInfo, cp, in);
		KDebugClassfile.outdent();

		return codeInfo;
	}		

	private void readCodeAttribute(KCodeInfo codeInfo, KConstPool cp, 
		DataInput in) throws IOException
	{
		short nameIndex = in.readShort();
		int length = in.readInt();

		// make sure we read the entire attribute -- if it has bad data,
		// an exception might get thrown before we've read it all
		byte[] bytes = new byte[length];
		in.readFully(bytes);
		in = new DataInputStream(new ByteArrayInputStream(bytes));

		if (KDebugClassfile.readCode != null) KDebugClassfile.println(KDebugClassfile.readCode,
			"code attribute name index=" + nameIndex +
			"; length=" + length);
		KDebugClassfile.indent();

		try {

			String name = cp.getEntryAtIndex(nameIndex).getString();
			if (name.equals("LineNumberTable")) 
				codeInfo.setLineNumberTable(readLineNumberTable(in));
			else if (name.equals("LocalVariableTable")) 
				codeInfo.setLocalVariableTable(readLocalVariableTable(cp, in));
			else
				codeInfo.addAttribute(readUnknownAttribute(name, length, in));

		} catch (KConstPoolEntryError e) {
			if (KDebugClassfile.readBadData != null) KDebugClassfile.println(KDebugClassfile.readBadData,
				"code attribute name index=" + nameIndex);
		}

		KDebugClassfile.outdent();
	}

	private KInnerClassInfo[] readInnerClasses(KConstPool cp, DataInput in) 
		throws IOException
	{
		short rows = in.readShort();
		if (KDebugClassfile.readInnerClasses != null) KDebugClassfile.println(KDebugClassfile.readInnerClasses,
			"#inner classes=" + rows);
		KInnerClassInfo[] classes = new KInnerClassInfo[rows];
		for (int i = 0; i < rows; i++) {
			short innerClassIndex = in.readShort();
			short outerClassIndex = in.readShort();
			short simpleNameIndex = in.readShort();
			short flags = in.readShort();

			if (KDebugClassfile.readInnerClasses != null) KDebugClassfile.println(KDebugClassfile.readInnerClasses,
				"inner class index=" + innerClassIndex +
				"; outer class index=" + outerClassIndex +
				"; simple name index=" + simpleNameIndex +
				"; flags=" + flags);

			short innerClassNameIndex = cp.getEntryAtIndex(innerClassIndex).getClassNameIndex();
			String innerClassName = cp.getEntryAtIndex(innerClassNameIndex).getString();
			String outerClassName = null;
			if (outerClassIndex != 0) {
				short outerClassNameIndex = cp.getEntryAtIndex(outerClassIndex).getClassNameIndex();
				outerClassName = cp.getEntryAtIndex(outerClassNameIndex).getString();
			}
			String simpleName = null;
			if (simpleNameIndex != 0)
				simpleName = cp.getEntryAtIndex(simpleNameIndex).getString();

			classes[i] = new KInnerClassInfo(innerClassName, outerClassName, simpleName, flags);
		}
		return classes;
	}

	private KLocalVariableInfo[] readLocalVariableTable(KConstPool cp, DataInput in) 
		throws IOException
	{
		KLocalVariableInfo[] table = new KLocalVariableInfo[in.readShort()];
		if (KDebugClassfile.readLocalVariables != null) KDebugClassfile.println(KDebugClassfile.readLocalVariables,
			"#local variables=" + table.length);
		for (int i = 0; i < table.length; i++) {
			short startPC = in.readShort();
			short length = in.readShort();
			short nameIndex = in.readShort();
			short signatureIndex = in.readShort();
			short slot= in.readShort();
			if (KDebugClassfile.readLocalVariables != null) KDebugClassfile.println(KDebugClassfile.readLocalVariables,
				"start PC=" + startPC +
				"; length=" + length +
				"; name index=" + nameIndex +
				"; signature index=" + signatureIndex +
				"; slot=" + slot);

			String name = cp.getEntryAtIndex(nameIndex).getString();
			String signature = cp.getEntryAtIndex(signatureIndex).getString();
			table[i] = new KLocalVariableInfo(startPC, length, name, signature, slot);
		}
		return table;
	}

	private KLineNumberInfo[] readLineNumberTable(DataInput in)
		throws IOException
	{
		KLineNumberInfo[] table = new KLineNumberInfo[in.readShort()];
		if (KDebugClassfile.readLineNumbers != null) KDebugClassfile.println(KDebugClassfile.readLineNumbers,
			"#line numbers=" + table.length);
		for (int i = 0; i < table.length; i++) {
			short startPC = in.readShort();
			short lineNumber = in.readShort();

			if (KDebugClassfile.readLineNumbers != null) KDebugClassfile.println(KDebugClassfile.readLineNumbers,
				"start PC=" + startPC +
				"; line number=" + lineNumber);

			table[i] = new KLineNumberInfo(startPC, lineNumber);
		}
		return table;
	}

	private KAttributeInfo readUnknownAttribute(String name, int length, DataInput in) 
		throws IOException
	{
		if (KDebugClassfile.readUnknownAttribute != null) KDebugClassfile.println(KDebugClassfile.readUnknownAttribute,
			"attribute name=\"" + name + "\"");
		byte[] data = new byte[length];
		in.readFully(data);
		return new KAttributeInfo(name, data);
	}
}
