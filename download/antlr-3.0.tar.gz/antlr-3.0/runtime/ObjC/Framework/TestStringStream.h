//
//  TestStringStream.h
//  ANTLR
//
//  Created by Kay R�pke on 09.03.2006.
//  Copyright 2006 classDump. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface TestStringStream : SenTestCase {

}

@end
