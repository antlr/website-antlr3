# $ANTLR 2.7.2a2 (20020112-1): "calc.g" -> "CalcLexer.py"$

# Generate headers specific to lexer Python file
from java.io import InputStream
from antlr import TokenStreamException
from antlr import TokenStreamIOException
from antlr import TokenStreamRecognitionException
from antlr import CharStreamException
from antlr import CharStreamIOException
from antlr import ANTLRException
from java.io import Reader
from java.util import Hashtable
from antlr import CharScanner
from antlr import InputBuffer
from antlr import ByteBuffer
from antlr import CharBuffer
from antlr import Token
from antlr import CommonToken
from antlr import RecognitionException
from antlr import NoViableAltForCharException
from antlr import MismatchedCharException
from antlr import TokenStream
from antlr import ANTLRHashString
from antlr import LexerSharedInputState
from antlr.collections.impl import BitSet
from antlr import SemanticException
from antlr import TokenStream
from CalcParserTokenTypes import *

true = 1
false = 0

class CalcLexer(antlr.CharScanner, TokenStream, CalcParserTokenTypes):
	def __init__(self, stream=None, reader=None, ib=None, state=None):
		if stream:
			state = ByteBuffer(stream)
		elif reader:
			state = CharBuffer(reader)
		elif ib:
			state = LexerSharedInputState(ib)
		CharScanner.__init__(self, state)
		self.caseSensitiveLiterals = 1
		self.setCaseSensitive(1)
		self.literals = Hashtable()
	
	def nextToken(self):
		theRetToken = None
		while 1:
			_token = None
			_ttype = Token.INVALID_TYPE
			self.resetText()
			try:   # for char stream error handling
				try:   # for lexical error handling
					if (self.LA(1) == '\t')  or (self.LA(1) == '\n')  or (self.LA(1) == '\r')  or (self.LA(1) == ' ') :
						self.mWS(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == '(') :
						self.mLPAREN(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == ')') :
						self.mRPAREN(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == '*') :
						self.mSTAR(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == '+') :
						self.mPLUS(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == ';') :
						self.mSEMI(true)
						theRetToken = self._returnToken
					elif (self.LA(1) == '0')  or (self.LA(1) == '1')  or (self.LA(1) == '2')  or (self.LA(1) == '3')  or (self.LA(1) == '4')  or (self.LA(1) == '5')  or (self.LA(1) == '6')  or (self.LA(1) == '7')  or (self.LA(1) == '8')  or (self.LA(1) == '9') :
						self.mINT(true)
						theRetToken = self._returnToken
					else:
						if self.LA(1)==self.EOF_CHAR: 
							self.uponEOF() 
							_returnToken = self.makeToken(Token.EOF_TYPE)

						else:
							raise NoViableAltForCharException(self.LA(1), getFilename(), getLine(), getColumn())
					
					if not self._returnToken: continue
					_ttype = self._returnToken.getType()
					_ttype = self.testLiteralsTable(_ttype)
					self._returnToken.setType(_ttype)
					return self._returnToken
				except RecognitionException, e:
					raise TokenStreamRecognitionException(e)
			except CharStreamException, cse:
				if cse.__class__.__name__ == 'CharStreamIOException':
					raise TokenStreamIOException(cse.io)
				else:
					raise TokenStreamException(cse.getMessage())
	
	def mWS(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.WS
		_saveIndex = 0
		
		while 1:
			if (self.LA(1) == ' ') :
				self.match(' ')
			elif (self.LA(1) == '\t') :
				self.match('\t')
			elif (self.LA(1) == '\n') :
				self.match('\n')
			elif (self.LA(1) == '\r') :
				self.match('\r')
			else:
				raise NoViableAltForCharException(self.LA(1), getFilename(), getLine(), getColumn())
			
_ttype = Token.SKIP
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mLPAREN(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.LPAREN
		_saveIndex = 0
		
		self.match('(')
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mRPAREN(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.RPAREN
		_saveIndex = 0
		
		self.match(')')
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mSTAR(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.STAR
		_saveIndex = 0
		
		self.match('*')
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mPLUS(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.PLUS
		_saveIndex = 0
		
		self.match('+')
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mSEMI(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.SEMI
		_saveIndex = 0
		
		self.match(';')
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mDIGIT(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.DIGIT
		_saveIndex = 0
		
		self.matchRange('0','9');
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	def mINT(self, _createToken	):
		_ttype=0
		_token=None
		_begin=self.text.length()

		
		_ttype = self.INT
		_saveIndex = 0
		
		if 1:
			_cnt18= 0
			while 1:
				if (((self.LA(1) >= '0' and self.LA(1) <= '9'))):
						self.mDIGIT(false)
					else:
						if _cnt18 >= 1: break
						else: raise NoViableAltForCharException(self.LA(1), getFilename(), getLine(), getColumn())
					
				_cnt18 = _cnt18 + 1
		if _createToken and _token==None and _ttype!=Token.SKIP:
			_token = self.makeToken(_ttype)
			_token.setText(str(self.getText()[_begin:self.text.length()]))
		self._returnToken = _token
	
	
	
