/*
 * Created on Sep 24, 2003
 *
 */
package org.antlr.java.crossref;
/**
 * Interface to control JavaRecognizer output
 * OutputProject will be called when all files have been
 * load/parsed and references have been resolved
 * The OutputRef methods will "fire" when the parser realizes 
 * the relation.
 */
public interface OutputCrossRefInfo {

	/**
	 * Method OutputProject
	 * @param project CodeProject
	 */
	public void OutputProject(CodeProject project);

	/**
	 * Method OutputRefClass
	 * @param refMethod MethodScope
	 * @param defClass ClassScope
	 * @param code LocationAST
	 */
	public void OutputRefClass(MethodScope refMethod, 
	                              ClassScope defClass,
	                              LocationAST code);
	/**
	 * Method OutputRefElement
	 * @param refClassOrMethod Scope
	 * @param defClassOrVariable Scope
	 * @param code LocationAST
	 */
	public void OutputRefElement(Scope refClassOrMethod,
								  Scope defClassOrVariable,
						  			LocationAST code);
	/**
	 * Method OutputRefMethod
	 * @param referencingScope Scope
	 * @param defMethod MethodScope
	 * @param code LocationAST
	 */
	public void OutputRefMethod(Scope referencingScope,
								  MethodScope defMethod,
									LocationAST code);
}
