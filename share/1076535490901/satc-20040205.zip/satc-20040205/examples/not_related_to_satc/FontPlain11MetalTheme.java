/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */
package examples.not_related_to_satc;
import java.awt.Font;

import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
public class FontPlain11MetalTheme extends DefaultMetalTheme {
  	private FontUIResource font = new FontUIResource( new Font( "Dialog", Font.PLAIN, 11));
 	public FontUIResource getControlTextFont() {
    	return font;
  	}
  	public FontUIResource getMenuTextFont() {
    	return font;
  	}
    public FontUIResource getSystemTextFont() {
    	return font;
  	}
    public FontUIResource getUserTextFont() {
    	return font;
  	}
    public FontUIResource getWindowTitleFont() {
    	return font;
  	}
}