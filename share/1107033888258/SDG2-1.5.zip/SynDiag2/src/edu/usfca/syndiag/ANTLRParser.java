// $ANTLR 2.7.3rc3: "antlr.g" -> "ANTLRParser.java"$

package edu.usfca.syndiag;
import java.util.*;
import java.io.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

/** Read in an ANTLR grammar and build an AST.  For now, I'm ignoring
 *  anything except the rules.
 *
 *  Terence Parr
 *  University of San Francisco
 *  August 19, 2003
 */
public class ANTLRParser extends antlr.LLkParser       implements ANTLRTokenTypes
 {

// a bunch of (non thread safe and terrible OO design) maps/lists
// that you might find useful.  I'll refactor later...this stuff
// is in my "playground" not my "repository" yet. :)  TJP 8-19-2003
public static Hashtable ruleToTreeMap = new Hashtable();
public static List subruleToTreeList = new ArrayList();
public int tokenType = Edge.MIN_TOKEN_TYPE;
public static Hashtable tokenToTypeMap = new Hashtable();
public static Vector typeToTokenList = new Vector();

private int ruleIndex = 1;
public static Hashtable ruleToIndexMap = new Hashtable();
public static Vector ruleIndexToRuleList = new Vector();

public void defineToken(String text) {
		tokenToTypeMap.put(text, new Integer(tokenType));
		typeToTokenList.setSize(tokenType+1);
		typeToTokenList.set(tokenType, text);
		tokenType++;
}

public void defineCharLiteralToken(String charLiteral) {
		int c = charLiteral.charAt(1);
		tokenToTypeMap.put(charLiteral, new Integer(c));
}

public void defineRule(String ruleName) {
		ruleToIndexMap.put(ruleName, new Integer(ruleIndex));
		ruleIndexToRuleList.setSize(ruleIndex+1);
		ruleIndexToRuleList.set(ruleIndex, ruleName);
		ruleIndex++;
}

public void init() {
	typeToTokenList.setSize(Edge.EOF+1);
    typeToTokenList.set(0, "<INVALID>");
    typeToTokenList.set(Edge.EOF, "<EOF>");
    tokenToTypeMap.put("<INVALID>", new Integer(0));
    tokenToTypeMap.put("<EOF>", new Integer(Edge.EOF));
}

public void finish() {
}


protected ANTLRParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected ANTLRParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenStream lexer) {
  this(lexer,2);
}

public ANTLRParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void grammar() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST grammar_AST = null;
		Token  n = null;
		GrammarAST n_AST = null;
		Token  h = null;
		GrammarAST h_AST = null;
		GrammarAST cd_AST = null;
		GrammarAST c=null;
		
		try {      // for error handling
			if ( inputState.guessing==0 ) {
				init();
			}
			{
			_loop4:
			do {
				if ((LA(1)==LITERAL_header)) {
					match(LITERAL_header);
					{
					switch ( LA(1)) {
					case STRING_LITERAL:
					{
						n = LT(1);
						n_AST = (GrammarAST)astFactory.create(n);
						match(STRING_LITERAL);
						break;
					}
					case ACTION:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					h = LT(1);
					h_AST = (GrammarAST)astFactory.create(h);
					match(ACTION);
				}
				else {
					break _loop4;
				}
				
			} while (true);
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				fileOptionsSpec();
				break;
			}
			case EOF:
			case ACTION:
			case DOC_COMMENT:
			case LITERAL_lexclass:
			case LITERAL_class:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop7:
			do {
				if (((LA(1) >= ACTION && LA(1) <= LITERAL_class))) {
					classDef();
					cd_AST = (GrammarAST)returnAST;
					if ( inputState.guessing==0 ) {
						if (c==null) {c=cd_AST;} else {c.setNextSibling(cd_AST);}
					}
				}
				else {
					break _loop7;
				}
				
			} while (true);
			}
			GrammarAST tmp2_AST = null;
			tmp2_AST = (GrammarAST)astFactory.create(LT(1));
			match(Token.EOF_TYPE);
			if ( inputState.guessing==0 ) {
				grammar_AST = (GrammarAST)currentAST.root;
				grammar_AST = c;
				currentAST.root = grammar_AST;
				currentAST.child = grammar_AST!=null &&grammar_AST.getFirstChild()!=null ?
					grammar_AST.getFirstChild() : grammar_AST;
				currentAST.advanceChildToEnd();
			}
			if ( inputState.guessing==0 ) {
				finish();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = grammar_AST;
	}
	
	public final void fileOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST fileOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp3_AST = null;
			tmp3_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp3_AST);
			match(OPTIONS);
			{
			_loop18:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp4_AST = null;
					tmp4_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp4_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp5_AST = null;
					tmp5_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp5_AST);
					match(SEMI);
				}
				else {
					break _loop18;
				}
				
			} while (true);
			}
			GrammarAST tmp6_AST = null;
			tmp6_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp6_AST);
			match(RCURLY);
			fileOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = fileOptionsSpec_AST;
	}
	
	public final void classDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST classDef_AST = null;
		Token  a = null;
		GrammarAST a_AST = null;
		Token  d = null;
		GrammarAST d_AST = null;
		GrammarAST lexer_AST = null;
		GrammarAST treeparser_AST = null;
		GrammarAST parser_AST = null;
		GrammarAST r_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ACTION:
			{
				a = LT(1);
				a_AST = (GrammarAST)astFactory.create(a);
				match(ACTION);
				break;
			}
			case DOC_COMMENT:
			case LITERAL_lexclass:
			case LITERAL_class:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case DOC_COMMENT:
			{
				d = LT(1);
				d_AST = (GrammarAST)astFactory.create(d);
				match(DOC_COMMENT);
				break;
			}
			case LITERAL_lexclass:
			case LITERAL_class:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			boolean synPredMatched13 = false;
			if (((LA(1)==LITERAL_lexclass||LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF))) {
				int _m13 = mark();
				synPredMatched13 = true;
				inputState.guessing++;
				try {
					{
					switch ( LA(1)) {
					case LITERAL_lexclass:
					{
						match(LITERAL_lexclass);
						break;
					}
					case LITERAL_class:
					{
						match(LITERAL_class);
						id();
						match(LITERAL_extends);
						match(LITERAL_Lexer);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				catch (RecognitionException pe) {
					synPredMatched13 = false;
				}
				rewind(_m13);
				inputState.guessing--;
			}
			if ( synPredMatched13 ) {
				lexerSpec();
				lexer_AST = (GrammarAST)returnAST;
				if ( inputState.guessing==0 ) {
					classDef_AST = (GrammarAST)currentAST.root;
					classDef_AST = (GrammarAST)astFactory.create(LEXER,"lexer");
					currentAST.root = classDef_AST;
					currentAST.child = classDef_AST!=null &&classDef_AST.getFirstChild()!=null ?
						classDef_AST.getFirstChild() : classDef_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				boolean synPredMatched15 = false;
				if (((LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF))) {
					int _m15 = mark();
					synPredMatched15 = true;
					inputState.guessing++;
					try {
						{
						match(LITERAL_class);
						id();
						match(LITERAL_extends);
						match(LITERAL_TreeParser);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched15 = false;
					}
					rewind(_m15);
					inputState.guessing--;
				}
				if ( synPredMatched15 ) {
					treeParserSpec();
					treeparser_AST = (GrammarAST)returnAST;
					if ( inputState.guessing==0 ) {
						classDef_AST = (GrammarAST)currentAST.root;
						classDef_AST = (GrammarAST)astFactory.create(TREE_PARSER,"tree_parser");
						currentAST.root = classDef_AST;
						currentAST.child = classDef_AST!=null &&classDef_AST.getFirstChild()!=null ?
							classDef_AST.getFirstChild() : classDef_AST;
						currentAST.advanceChildToEnd();
					}
				}
				else if ((LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF)) {
					parserSpec();
					parser_AST = (GrammarAST)returnAST;
					if ( inputState.guessing==0 ) {
						classDef_AST = (GrammarAST)currentAST.root;
						classDef_AST = (GrammarAST)astFactory.create(PARSER,"parser");
						currentAST.root = classDef_AST;
						currentAST.child = classDef_AST!=null &&classDef_AST.getFirstChild()!=null ?
							classDef_AST.getFirstChild() : classDef_AST;
						currentAST.advanceChildToEnd();
					}
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				rules();
				r_AST = (GrammarAST)returnAST;
				if ( inputState.guessing==0 ) {
					classDef_AST = (GrammarAST)currentAST.root;
					classDef_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add(classDef_AST).add(r_AST));
					currentAST.root = classDef_AST;
					currentAST.child = classDef_AST!=null &&classDef_AST.getFirstChild()!=null ?
						classDef_AST.getFirstChild() : classDef_AST;
					currentAST.advanceChildToEnd();
				}
			}
			catch (RecognitionException ex) {
				if (inputState.guessing==0) {
					reportError(ex);
					consume();
					consumeUntil(_tokenSet_1);
				} else {
				  throw ex;
				}
			}
			returnAST = classDef_AST;
		}
		
	public final void id() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST id_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				GrammarAST tmp7_AST = null;
				tmp7_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp7_AST);
				match(TOKEN_REF);
				id_AST = (GrammarAST)currentAST.root;
				break;
			}
			case RULE_REF:
			{
				GrammarAST tmp8_AST = null;
				tmp8_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp8_AST);
				match(RULE_REF);
				id_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = id_AST;
	}
	
	public final void lexerSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST lexerSpec_AST = null;
		Token  lc = null;
		GrammarAST lc_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_lexclass:
			{
				lc = LT(1);
				lc_AST = (GrammarAST)astFactory.create(lc);
				astFactory.addASTChild(currentAST, lc_AST);
				match(LITERAL_lexclass);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_class:
			{
				GrammarAST tmp9_AST = null;
				tmp9_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp9_AST);
				match(LITERAL_class);
				id();
				astFactory.addASTChild(currentAST, returnAST);
				GrammarAST tmp10_AST = null;
				tmp10_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp10_AST);
				match(LITERAL_extends);
				GrammarAST tmp11_AST = null;
				tmp11_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp11_AST);
				match(LITERAL_Lexer);
				{
				switch ( LA(1)) {
				case LPAREN:
				{
					superClass();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				lexerOptionsSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKENS:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case TOKENS:
			{
				tokensSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				match(ACTION);
				break;
			}
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			lexerSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = lexerSpec_AST;
	}
	
	public final void treeParserSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST treeParserSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp14_AST = null;
			tmp14_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp14_AST);
			match(LITERAL_class);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp15_AST = null;
			tmp15_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp15_AST);
			match(LITERAL_extends);
			GrammarAST tmp16_AST = null;
			tmp16_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp16_AST);
			match(LITERAL_TreeParser);
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				superClass();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				treeParserOptionsSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKENS:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case TOKENS:
			{
				tokensSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				match(ACTION);
				break;
			}
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			treeParserSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = treeParserSpec_AST;
	}
	
	public final void parserSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST parserSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp19_AST = null;
			tmp19_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp19_AST);
			match(LITERAL_class);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case LITERAL_extends:
			{
				GrammarAST tmp20_AST = null;
				tmp20_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp20_AST);
				match(LITERAL_extends);
				GrammarAST tmp21_AST = null;
				tmp21_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp21_AST);
				match(LITERAL_Parser);
				{
				switch ( LA(1)) {
				case LPAREN:
				{
					superClass();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				parserOptionsSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKENS:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case TOKENS:
			{
				tokensSpec();
				break;
			}
			case ACTION:
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				match(ACTION);
				break;
			}
			case DOC_COMMENT:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			parserSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = parserSpec_AST;
	}
	
	public final void rules() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rules_AST = null;
		
		try {      // for error handling
			{
			int _cnt68=0;
			_loop68:
			do {
				if ((_tokenSet_3.member(LA(1))) && (_tokenSet_4.member(LA(2)))) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt68>=1 ) { break _loop68; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt68++;
			} while (true);
			}
			rules_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = rules_AST;
	}
	
	public final void optionValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST optionValue_AST = null;
		Token  sl = null;
		GrammarAST sl_AST = null;
		Token  cl = null;
		GrammarAST cl_AST = null;
		Token  il = null;
		GrammarAST il_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case TOKEN_REF:
			case RULE_REF:
			{
				qualifiedID();
				astFactory.addASTChild(currentAST, returnAST);
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				sl = LT(1);
				sl_AST = (GrammarAST)astFactory.create(sl);
				astFactory.addASTChild(currentAST, sl_AST);
				match(STRING_LITERAL);
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case CHAR_LITERAL:
			{
				cl = LT(1);
				cl_AST = (GrammarAST)astFactory.create(cl);
				astFactory.addASTChild(currentAST, cl_AST);
				match(CHAR_LITERAL);
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			case INT:
			{
				il = LT(1);
				il_AST = (GrammarAST)astFactory.create(il);
				astFactory.addASTChild(currentAST, il_AST);
				match(INT);
				optionValue_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = optionValue_AST;
	}
	
	public final void parserOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST parserOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp24_AST = null;
			tmp24_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp24_AST);
			match(OPTIONS);
			{
			_loop21:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp25_AST = null;
					tmp25_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp25_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp26_AST = null;
					tmp26_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp26_AST);
					match(SEMI);
				}
				else {
					break _loop21;
				}
				
			} while (true);
			}
			GrammarAST tmp27_AST = null;
			tmp27_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp27_AST);
			match(RCURLY);
			parserOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = parserOptionsSpec_AST;
	}
	
	public final void treeParserOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST treeParserOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp28_AST = null;
			tmp28_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp28_AST);
			match(OPTIONS);
			{
			_loop24:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp29_AST = null;
					tmp29_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp29_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp30_AST = null;
					tmp30_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp30_AST);
					match(SEMI);
				}
				else {
					break _loop24;
				}
				
			} while (true);
			}
			GrammarAST tmp31_AST = null;
			tmp31_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp31_AST);
			match(RCURLY);
			treeParserOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = treeParserOptionsSpec_AST;
	}
	
	public final void lexerOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST lexerOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp32_AST = null;
			tmp32_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp32_AST);
			match(OPTIONS);
			{
			_loop27:
			do {
				switch ( LA(1)) {
				case LITERAL_charVocabulary:
				{
					GrammarAST tmp33_AST = null;
					tmp33_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp33_AST);
					match(LITERAL_charVocabulary);
					GrammarAST tmp34_AST = null;
					tmp34_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp34_AST);
					match(ASSIGN);
					charSet();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp35_AST = null;
					tmp35_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp35_AST);
					match(SEMI);
					break;
				}
				case TOKEN_REF:
				case RULE_REF:
				{
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp36_AST = null;
					tmp36_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp36_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp37_AST = null;
					tmp37_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp37_AST);
					match(SEMI);
					break;
				}
				default:
				{
					break _loop27;
				}
				}
			} while (true);
			}
			GrammarAST tmp38_AST = null;
			tmp38_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp38_AST);
			match(RCURLY);
			lexerOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = lexerOptionsSpec_AST;
	}
	
	public final void charSet() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST charSet_AST = null;
		
		try {      // for error handling
			setBlockElement();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop34:
			do {
				if ((LA(1)==OR)) {
					GrammarAST tmp39_AST = null;
					tmp39_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp39_AST);
					match(OR);
					setBlockElement();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop34;
				}
				
			} while (true);
			}
			charSet_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = charSet_AST;
	}
	
	public final void subruleOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST subruleOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp40_AST = null;
			tmp40_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp40_AST);
			match(OPTIONS);
			{
			_loop30:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp41_AST = null;
					tmp41_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp41_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp42_AST = null;
					tmp42_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp42_AST);
					match(SEMI);
				}
				else {
					break _loop30;
				}
				
			} while (true);
			}
			GrammarAST tmp43_AST = null;
			tmp43_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp43_AST);
			match(RCURLY);
			subruleOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = subruleOptionsSpec_AST;
	}
	
/** Match a.b.c.d qualified ids; WILDCARD here is overloaded as
 *  id separator; that is, I need a reference to the '.' token.
 */
	public final void qualifiedID() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST qualifiedID_AST = null;
		
		try {      // for error handling
			id();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop144:
			do {
				if ((LA(1)==WILDCARD)) {
					GrammarAST tmp44_AST = null;
					tmp44_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp44_AST);
					match(WILDCARD);
					id();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop144;
				}
				
			} while (true);
			}
			qualifiedID_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = qualifiedID_AST;
	}
	
	public final void setBlockElement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST setBlockElement_AST = null;
		Token  c1 = null;
		GrammarAST c1_AST = null;
		Token  c2 = null;
		GrammarAST c2_AST = null;
		
		try {      // for error handling
			c1 = LT(1);
			c1_AST = (GrammarAST)astFactory.create(c1);
			astFactory.addASTChild(currentAST, c1_AST);
			match(CHAR_LITERAL);
			{
			switch ( LA(1)) {
			case RANGE:
			{
				GrammarAST tmp45_AST = null;
				tmp45_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp45_AST);
				match(RANGE);
				c2 = LT(1);
				c2_AST = (GrammarAST)astFactory.create(c2);
				astFactory.addASTChild(currentAST, c2_AST);
				match(CHAR_LITERAL);
				break;
			}
			case SEMI:
			case OR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			setBlockElement_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		returnAST = setBlockElement_AST;
	}
	
	public final void tokensSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST tokensSpec_AST = null;
		Token  t1 = null;
		GrammarAST t1_AST = null;
		Token  s1 = null;
		GrammarAST s1_AST = null;
		Token  s3 = null;
		GrammarAST s3_AST = null;
		
		try {      // for error handling
			GrammarAST tmp46_AST = null;
			tmp46_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp46_AST);
			match(TOKENS);
			{
			int _cnt43=0;
			_loop43:
			do {
				if ((LA(1)==STRING_LITERAL||LA(1)==TOKEN_REF)) {
					{
					switch ( LA(1)) {
					case TOKEN_REF:
					{
						t1 = LT(1);
						t1_AST = (GrammarAST)astFactory.create(t1);
						astFactory.addASTChild(currentAST, t1_AST);
						match(TOKEN_REF);
						{
						switch ( LA(1)) {
						case ASSIGN:
						{
							GrammarAST tmp47_AST = null;
							tmp47_AST = (GrammarAST)astFactory.create(LT(1));
							astFactory.addASTChild(currentAST, tmp47_AST);
							match(ASSIGN);
							s1 = LT(1);
							s1_AST = (GrammarAST)astFactory.create(s1);
							astFactory.addASTChild(currentAST, s1_AST);
							match(STRING_LITERAL);
							break;
						}
						case SEMI:
						case OPEN_ELEMENT_OPTION:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						{
						switch ( LA(1)) {
						case OPEN_ELEMENT_OPTION:
						{
							tokensSpecOptions();
							astFactory.addASTChild(currentAST, returnAST);
							break;
						}
						case SEMI:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					case STRING_LITERAL:
					{
						s3 = LT(1);
						s3_AST = (GrammarAST)astFactory.create(s3);
						astFactory.addASTChild(currentAST, s3_AST);
						match(STRING_LITERAL);
						{
						switch ( LA(1)) {
						case OPEN_ELEMENT_OPTION:
						{
							tokensSpecOptions();
							astFactory.addASTChild(currentAST, returnAST);
							break;
						}
						case SEMI:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					GrammarAST tmp48_AST = null;
					tmp48_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp48_AST);
					match(SEMI);
				}
				else {
					if ( _cnt43>=1 ) { break _loop43; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt43++;
			} while (true);
			}
			GrammarAST tmp49_AST = null;
			tmp49_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp49_AST);
			match(RCURLY);
			tokensSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_10);
			} else {
			  throw ex;
			}
		}
		returnAST = tokensSpec_AST;
	}
	
	public final void tokensSpecOptions() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST tokensSpecOptions_AST = null;
		
		try {      // for error handling
			GrammarAST tmp50_AST = null;
			tmp50_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp50_AST);
			match(OPEN_ELEMENT_OPTION);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp51_AST = null;
			tmp51_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp51_AST);
			match(ASSIGN);
			optionValue();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop46:
			do {
				if ((LA(1)==SEMI)) {
					GrammarAST tmp52_AST = null;
					tmp52_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp52_AST);
					match(SEMI);
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp53_AST = null;
					tmp53_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp53_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop46;
				}
				
			} while (true);
			}
			GrammarAST tmp54_AST = null;
			tmp54_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp54_AST);
			match(CLOSE_ELEMENT_OPTION);
			tokensSpecOptions_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = tokensSpecOptions_AST;
	}
	
	public final void superClass() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST superClass_AST = null;
		
		try {      // for error handling
			GrammarAST tmp55_AST = null;
			tmp55_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp55_AST);
			match(LPAREN);
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				GrammarAST tmp56_AST = null;
				tmp56_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp56_AST);
				match(TOKEN_REF);
				break;
			}
			case RULE_REF:
			{
				GrammarAST tmp57_AST = null;
				tmp57_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp57_AST);
				match(RULE_REF);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			GrammarAST tmp58_AST = null;
			tmp58_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp58_AST);
			match(RPAREN);
			superClass_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = superClass_AST;
	}
	
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rule_AST = null;
		Token  d = null;
		GrammarAST d_AST = null;
		Token  p1 = null;
		GrammarAST p1_AST = null;
		Token  p2 = null;
		GrammarAST p2_AST = null;
		Token  p3 = null;
		GrammarAST p3_AST = null;
		GrammarAST ruleName_AST = null;
		Token  aa = null;
		GrammarAST aa_AST = null;
		Token  rt = null;
		GrammarAST rt_AST = null;
		Token  a = null;
		GrammarAST a_AST = null;
		GrammarAST b_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case DOC_COMMENT:
			{
				d = LT(1);
				d_AST = (GrammarAST)astFactory.create(d);
				match(DOC_COMMENT);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_protected:
			{
				p1 = LT(1);
				p1_AST = (GrammarAST)astFactory.create(p1);
				match(LITERAL_protected);
				break;
			}
			case LITERAL_public:
			{
				p2 = LT(1);
				p2_AST = (GrammarAST)astFactory.create(p2);
				match(LITERAL_public);
				break;
			}
			case LITERAL_private:
			{
				p3 = LT(1);
				p3_AST = (GrammarAST)astFactory.create(p3);
				match(LITERAL_private);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			id();
			ruleName_AST = (GrammarAST)returnAST;
			if ( inputState.guessing==0 ) {
				defineRule(ruleName_AST.getText());
			}
			{
			switch ( LA(1)) {
			case BANG:
			{
				GrammarAST tmp59_AST = null;
				tmp59_AST = (GrammarAST)astFactory.create(LT(1));
				match(BANG);
				break;
			}
			case ACTION:
			case OPTIONS:
			case ARG_ACTION:
			case LITERAL_returns:
			case COLON:
			case LITERAL_throws:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ARG_ACTION:
			{
				aa = LT(1);
				aa_AST = (GrammarAST)astFactory.create(aa);
				match(ARG_ACTION);
				break;
			}
			case ACTION:
			case OPTIONS:
			case LITERAL_returns:
			case COLON:
			case LITERAL_throws:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_returns:
			{
				match(LITERAL_returns);
				rt = LT(1);
				rt_AST = (GrammarAST)astFactory.create(rt);
				match(ARG_ACTION);
				break;
			}
			case ACTION:
			case OPTIONS:
			case COLON:
			case LITERAL_throws:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_throws:
			{
				throwsSpec();
				break;
			}
			case ACTION:
			case OPTIONS:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case OPTIONS:
			{
				ruleOptionsSpec();
				break;
			}
			case ACTION:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				a = LT(1);
				a_AST = (GrammarAST)astFactory.create(a);
				match(ACTION);
				break;
			}
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			GrammarAST tmp61_AST = null;
			tmp61_AST = (GrammarAST)astFactory.create(LT(1));
			match(COLON);
			block();
			b_AST = (GrammarAST)returnAST;
			GrammarAST tmp62_AST = null;
			tmp62_AST = (GrammarAST)astFactory.create(LT(1));
			match(SEMI);
			{
			switch ( LA(1)) {
			case LITERAL_exception:
			{
				exceptionGroup();
				break;
			}
			case EOF:
			case ACTION:
			case DOC_COMMENT:
			case LITERAL_lexclass:
			case LITERAL_class:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				rule_AST = (GrammarAST)currentAST.root;
				
				GrammarAST eor = (GrammarAST)astFactory.create(EOR,"<end-of-rule>");
				eor.setEnclosingRule(ruleName_AST.getText());
				rule_AST = (GrammarAST)astFactory.make( (new ASTArray(4)).add((GrammarAST)astFactory.create(RULE,"rule")).add(ruleName_AST).add(b_AST).add(eor));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			if ( inputState.guessing==0 ) {
				rule_AST = (GrammarAST)currentAST.root;
				ruleToTreeMap.put(ruleName_AST.getText(), rule_AST);
			}
			if ( inputState.guessing==0 ) {
				subruleToTreeList.add(b_AST);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		returnAST = rule_AST;
	}
	
	public final void throwsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST throwsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp63_AST = null;
			tmp63_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp63_AST);
			match(LITERAL_throws);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop84:
			do {
				if ((LA(1)==COMMA)) {
					GrammarAST tmp64_AST = null;
					tmp64_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp64_AST);
					match(COMMA);
					id();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop84;
				}
				
			} while (true);
			}
			throwsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		returnAST = throwsSpec_AST;
	}
	
	public final void ruleOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ruleOptionsSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp65_AST = null;
			tmp65_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp65_AST);
			match(OPTIONS);
			{
			_loop81:
			do {
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp66_AST = null;
					tmp66_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp66_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp67_AST = null;
					tmp67_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp67_AST);
					match(SEMI);
				}
				else {
					break _loop81;
				}
				
			} while (true);
			}
			GrammarAST tmp68_AST = null;
			tmp68_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp68_AST);
			match(RCURLY);
			ruleOptionsSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = ruleOptionsSpec_AST;
	}
	
	public final void block() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST block_AST = null;
		GrammarAST a1_AST = null;
		GrammarAST a2_AST = null;
		
		GrammarAST root = (GrammarAST)astFactory.create(BLOCK);
		
		
		try {      // for error handling
			alternative();
			a1_AST = (GrammarAST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop87:
			do {
				if ((LA(1)==OR)) {
					match(OR);
					alternative();
					a2_AST = (GrammarAST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop87;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				block_AST = (GrammarAST)currentAST.root;
				block_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add(root).add(block_AST));
				currentAST.root = block_AST;
				currentAST.child = block_AST!=null &&block_AST.getFirstChild()!=null ?
					block_AST.getFirstChild() : block_AST;
				currentAST.advanceChildToEnd();
			}
			block_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = block_AST;
	}
	
	public final void exceptionGroup() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionGroup_AST = null;
		
		try {      // for error handling
			{
			int _cnt95=0;
			_loop95:
			do {
				if ((LA(1)==LITERAL_exception)) {
					exceptionSpec();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt95>=1 ) { break _loop95; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt95++;
			} while (true);
			}
			exceptionGroup_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionGroup_AST;
	}
	
	public final void alternative() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST alternative_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case STRING_LITERAL:
			case ACTION:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case LPAREN:
			case RULE_REF:
			case BANG:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				{
				switch ( LA(1)) {
				case BANG:
				{
					match(BANG);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case CHAR_LITERAL:
				case TOKEN_REF:
				case LPAREN:
				case RULE_REF:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				int _cnt91=0;
				_loop91:
				do {
					if ((_tokenSet_14.member(LA(1)))) {
						element();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						if ( _cnt91>=1 ) { break _loop91; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt91++;
				} while (true);
				}
				{
				switch ( LA(1)) {
				case LITERAL_exception:
				{
					exceptionSpecNoLabel();
					break;
				}
				case SEMI:
				case OR:
				case RPAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					alternative_AST = (GrammarAST)currentAST.root;
					
					if ( alternative_AST==null ) {
					alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ALT,"ALT")).add((GrammarAST)astFactory.create(EPSILON,"epsilon")));
					}
					else {
					alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ALT,"ALT")).add(alternative_AST));
					}
					
					currentAST.root = alternative_AST;
					currentAST.child = alternative_AST!=null &&alternative_AST.getFirstChild()!=null ?
						alternative_AST.getFirstChild() : alternative_AST;
					currentAST.advanceChildToEnd();
				}
				alternative_AST = (GrammarAST)currentAST.root;
				break;
			}
			case SEMI:
			case OR:
			case RPAREN:
			{
				if ( inputState.guessing==0 ) {
					alternative_AST = (GrammarAST)currentAST.root;
					alternative_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(ALT,"ALT")).add((GrammarAST)astFactory.create(EPSILON,"epsilon")));
					currentAST.root = alternative_AST;
					currentAST.child = alternative_AST!=null &&alternative_AST.getFirstChild()!=null ?
						alternative_AST.getFirstChild() : alternative_AST;
					currentAST.advanceChildToEnd();
				}
				alternative_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_15);
			} else {
			  throw ex;
			}
		}
		returnAST = alternative_AST;
	}
	
	public final void element() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST element_AST = null;
		
		try {      // for error handling
			elementNoOptionSpec();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_ELEMENT_OPTION:
			{
				elementOptionSpec();
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case CHAR_LITERAL:
			case OR:
			case TOKEN_REF:
			case LPAREN:
			case RULE_REF:
			case RPAREN:
			case LITERAL_exception:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			element_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_16);
			} else {
			  throw ex;
			}
		}
		returnAST = element_AST;
	}
	
	public final void exceptionSpecNoLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionSpecNoLabel_AST = null;
		
		try {      // for error handling
			GrammarAST tmp71_AST = null;
			tmp71_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp71_AST);
			match(LITERAL_exception);
			{
			_loop102:
			do {
				if ((LA(1)==LITERAL_catch)) {
					exceptionHandler();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop102;
				}
				
			} while (true);
			}
			exceptionSpecNoLabel_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_15);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionSpecNoLabel_AST;
	}
	
	public final void exceptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp72_AST = null;
			tmp72_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp72_AST);
			match(LITERAL_exception);
			{
			switch ( LA(1)) {
			case ARG_ACTION:
			{
				GrammarAST tmp73_AST = null;
				tmp73_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp73_AST);
				match(ARG_ACTION);
				break;
			}
			case EOF:
			case ACTION:
			case DOC_COMMENT:
			case LITERAL_lexclass:
			case LITERAL_class:
			case TOKEN_REF:
			case RULE_REF:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			case LITERAL_exception:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop99:
			do {
				if ((LA(1)==LITERAL_catch)) {
					exceptionHandler();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop99;
				}
				
			} while (true);
			}
			exceptionSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_17);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionSpec_AST;
	}
	
	public final void exceptionHandler() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST exceptionHandler_AST = null;
		
		try {      // for error handling
			GrammarAST tmp74_AST = null;
			tmp74_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp74_AST);
			match(LITERAL_catch);
			GrammarAST tmp75_AST = null;
			tmp75_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp75_AST);
			match(ARG_ACTION);
			GrammarAST tmp76_AST = null;
			tmp76_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp76_AST);
			match(ACTION);
			exceptionHandler_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_18);
			} else {
			  throw ex;
			}
		}
		returnAST = exceptionHandler_AST;
	}
	
	public final void elementNoOptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST elementNoOptionSpec_AST = null;
		Token  rr = null;
		GrammarAST rr_AST = null;
		Token  tr = null;
		GrammarAST tr_AST = null;
		Token  r2 = null;
		GrammarAST r2_AST = null;
		GrammarAST r_AST = null;
		GrammarAST t_AST = null;
		GrammarAST nt_AST = null;
		GrammarAST e1_AST = null;
		GrammarAST e2_AST = null;
		GrammarAST t3_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case ACTION:
			{
				GrammarAST tmp77_AST = null;
				tmp77_AST = (GrammarAST)astFactory.create(LT(1));
				match(ACTION);
				break;
			}
			case SEMPRED:
			{
				GrammarAST tmp78_AST = null;
				tmp78_AST = (GrammarAST)astFactory.create(LT(1));
				match(SEMPRED);
				break;
			}
			case TREE_BEGIN:
			{
				tree();
				t3_AST = (GrammarAST)returnAST;
				if ( inputState.guessing==0 ) {
					elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
					elementNoOptionSpec_AST = t3_AST;
					currentAST.root = elementNoOptionSpec_AST;
					currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
						elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==ASSIGN)) {
					id();
					GrammarAST tmp79_AST = null;
					tmp79_AST = (GrammarAST)astFactory.create(LT(1));
					match(ASSIGN);
					{
					if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
						id();
						GrammarAST tmp80_AST = null;
						tmp80_AST = (GrammarAST)astFactory.create(LT(1));
						match(COLON);
					}
					else if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (_tokenSet_19.member(LA(2)))) {
					}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					
					}
					{
					switch ( LA(1)) {
					case RULE_REF:
					{
						rr = LT(1);
						rr_AST = (GrammarAST)astFactory.create(rr);
						match(RULE_REF);
						if ( inputState.guessing==0 ) {
							elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
							elementNoOptionSpec_AST = rr_AST;
							currentAST.root = elementNoOptionSpec_AST;
							currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
								elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
							currentAST.advanceChildToEnd();
						}
						{
						switch ( LA(1)) {
						case ARG_ACTION:
						{
							GrammarAST tmp81_AST = null;
							tmp81_AST = (GrammarAST)astFactory.create(LT(1));
							match(ARG_ACTION);
							break;
						}
						case STRING_LITERAL:
						case ACTION:
						case SEMI:
						case CHAR_LITERAL:
						case OR:
						case TOKEN_REF:
						case OPEN_ELEMENT_OPTION:
						case LPAREN:
						case RULE_REF:
						case RPAREN:
						case BANG:
						case LITERAL_exception:
						case NOT_OP:
						case SEMPRED:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						{
						switch ( LA(1)) {
						case BANG:
						{
							GrammarAST tmp82_AST = null;
							tmp82_AST = (GrammarAST)astFactory.create(LT(1));
							match(BANG);
							break;
						}
						case STRING_LITERAL:
						case ACTION:
						case SEMI:
						case CHAR_LITERAL:
						case OR:
						case TOKEN_REF:
						case OPEN_ELEMENT_OPTION:
						case LPAREN:
						case RULE_REF:
						case RPAREN:
						case LITERAL_exception:
						case NOT_OP:
						case SEMPRED:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					case TOKEN_REF:
					{
						tr = LT(1);
						tr_AST = (GrammarAST)astFactory.create(tr);
						match(TOKEN_REF);
						if ( inputState.guessing==0 ) {
							elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
							elementNoOptionSpec_AST = tr_AST;
							currentAST.root = elementNoOptionSpec_AST;
							currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
								elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
							currentAST.advanceChildToEnd();
						}
						{
						switch ( LA(1)) {
						case ARG_ACTION:
						{
							GrammarAST tmp83_AST = null;
							tmp83_AST = (GrammarAST)astFactory.create(LT(1));
							match(ARG_ACTION);
							break;
						}
						case STRING_LITERAL:
						case ACTION:
						case SEMI:
						case CHAR_LITERAL:
						case OR:
						case TOKEN_REF:
						case OPEN_ELEMENT_OPTION:
						case LPAREN:
						case RULE_REF:
						case RPAREN:
						case LITERAL_exception:
						case NOT_OP:
						case SEMPRED:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				else if ((_tokenSet_20.member(LA(1))) && (_tokenSet_21.member(LA(2)))) {
					{
					if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
						id();
						GrammarAST tmp84_AST = null;
						tmp84_AST = (GrammarAST)astFactory.create(LT(1));
						match(COLON);
					}
					else if ((_tokenSet_20.member(LA(1))) && (_tokenSet_22.member(LA(2)))) {
					}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					
					}
					{
					switch ( LA(1)) {
					case RULE_REF:
					{
						r2 = LT(1);
						r2_AST = (GrammarAST)astFactory.create(r2);
						match(RULE_REF);
						if ( inputState.guessing==0 ) {
							elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
							elementNoOptionSpec_AST = r2_AST;
							currentAST.root = elementNoOptionSpec_AST;
							currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
								elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
							currentAST.advanceChildToEnd();
						}
						{
						switch ( LA(1)) {
						case ARG_ACTION:
						{
							GrammarAST tmp85_AST = null;
							tmp85_AST = (GrammarAST)astFactory.create(LT(1));
							match(ARG_ACTION);
							break;
						}
						case STRING_LITERAL:
						case ACTION:
						case SEMI:
						case CHAR_LITERAL:
						case OR:
						case TOKEN_REF:
						case OPEN_ELEMENT_OPTION:
						case LPAREN:
						case RULE_REF:
						case RPAREN:
						case BANG:
						case LITERAL_exception:
						case NOT_OP:
						case SEMPRED:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						{
						switch ( LA(1)) {
						case BANG:
						{
							GrammarAST tmp86_AST = null;
							tmp86_AST = (GrammarAST)astFactory.create(LT(1));
							match(BANG);
							break;
						}
						case STRING_LITERAL:
						case ACTION:
						case SEMI:
						case CHAR_LITERAL:
						case OR:
						case TOKEN_REF:
						case OPEN_ELEMENT_OPTION:
						case LPAREN:
						case RULE_REF:
						case RPAREN:
						case LITERAL_exception:
						case NOT_OP:
						case SEMPRED:
						case TREE_BEGIN:
						case WILDCARD:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					case NOT_OP:
					{
						GrammarAST tmp87_AST = null;
						tmp87_AST = (GrammarAST)astFactory.create(LT(1));
						match(NOT_OP);
						{
						switch ( LA(1)) {
						case CHAR_LITERAL:
						case TOKEN_REF:
						{
							notTerminal();
							nt_AST = (GrammarAST)returnAST;
							if ( inputState.guessing==0 ) {
								elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
								elementNoOptionSpec_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(NOT,"~")).add(nt_AST));
								currentAST.root = elementNoOptionSpec_AST;
								currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
									elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
								currentAST.advanceChildToEnd();
							}
							break;
						}
						case LPAREN:
						{
							ebnf();
							e1_AST = (GrammarAST)returnAST;
							if ( inputState.guessing==0 ) {
								elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
								elementNoOptionSpec_AST = (GrammarAST)astFactory.make( (new ASTArray(2)).add((GrammarAST)astFactory.create(NOT,"~")).add(e1_AST));
								currentAST.root = elementNoOptionSpec_AST;
								currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
									elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
								currentAST.advanceChildToEnd();
							}
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						break;
					}
					case LPAREN:
					{
						ebnf();
						e2_AST = (GrammarAST)returnAST;
						if ( inputState.guessing==0 ) {
							elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
							elementNoOptionSpec_AST = e2_AST;
							currentAST.root = elementNoOptionSpec_AST;
							currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
								elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
							currentAST.advanceChildToEnd();
						}
						break;
					}
					default:
						if ((LA(1)==STRING_LITERAL||LA(1)==CHAR_LITERAL||LA(1)==TOKEN_REF) && (LA(2)==RANGE)) {
							range();
							r_AST = (GrammarAST)returnAST;
							if ( inputState.guessing==0 ) {
								elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
								elementNoOptionSpec_AST = r_AST;
								currentAST.root = elementNoOptionSpec_AST;
								currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
									elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
								currentAST.advanceChildToEnd();
							}
						}
						else if ((_tokenSet_23.member(LA(1))) && (_tokenSet_24.member(LA(2)))) {
							terminal();
							t_AST = (GrammarAST)returnAST;
							if ( inputState.guessing==0 ) {
								elementNoOptionSpec_AST = (GrammarAST)currentAST.root;
								elementNoOptionSpec_AST = t_AST;
								currentAST.root = elementNoOptionSpec_AST;
								currentAST.child = elementNoOptionSpec_AST!=null &&elementNoOptionSpec_AST.getFirstChild()!=null ?
									elementNoOptionSpec_AST.getFirstChild() : elementNoOptionSpec_AST;
								currentAST.advanceChildToEnd();
							}
						}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = elementNoOptionSpec_AST;
	}
	
	public final void elementOptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST elementOptionSpec_AST = null;
		
		try {      // for error handling
			GrammarAST tmp88_AST = null;
			tmp88_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp88_AST);
			match(OPEN_ELEMENT_OPTION);
			id();
			astFactory.addASTChild(currentAST, returnAST);
			GrammarAST tmp89_AST = null;
			tmp89_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp89_AST);
			match(ASSIGN);
			optionValue();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop108:
			do {
				if ((LA(1)==SEMI)) {
					GrammarAST tmp90_AST = null;
					tmp90_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp90_AST);
					match(SEMI);
					id();
					astFactory.addASTChild(currentAST, returnAST);
					GrammarAST tmp91_AST = null;
					tmp91_AST = (GrammarAST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp91_AST);
					match(ASSIGN);
					optionValue();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop108;
				}
				
			} while (true);
			}
			GrammarAST tmp92_AST = null;
			tmp92_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp92_AST);
			match(CLOSE_ELEMENT_OPTION);
			elementOptionSpec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_16);
			} else {
			  throw ex;
			}
		}
		returnAST = elementOptionSpec_AST;
	}
	
	public final void range() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST range_AST = null;
		Token  crLeft = null;
		GrammarAST crLeft_AST = null;
		Token  crRight = null;
		GrammarAST crRight_AST = null;
		Token  t = null;
		GrammarAST t_AST = null;
		Token  u = null;
		GrammarAST u_AST = null;
		Token  v = null;
		GrammarAST v_AST = null;
		Token  w = null;
		GrammarAST w_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CHAR_LITERAL:
			{
				crLeft = LT(1);
				crLeft_AST = (GrammarAST)astFactory.create(crLeft);
				match(CHAR_LITERAL);
				GrammarAST tmp93_AST = null;
				tmp93_AST = (GrammarAST)astFactory.create(LT(1));
				match(RANGE);
				crRight = LT(1);
				crRight_AST = (GrammarAST)astFactory.create(crRight);
				match(CHAR_LITERAL);
				{
				switch ( LA(1)) {
				case BANG:
				{
					GrammarAST tmp94_AST = null;
					tmp94_AST = (GrammarAST)astFactory.create(LT(1));
					match(BANG);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case SEMI:
				case CHAR_LITERAL:
				case OR:
				case TOKEN_REF:
				case OPEN_ELEMENT_OPTION:
				case LPAREN:
				case RULE_REF:
				case RPAREN:
				case LITERAL_exception:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					range_AST = (GrammarAST)currentAST.root;
					range_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(CHAR_RANGE,"..")).add(crLeft_AST).add(crRight_AST));
					currentAST.root = range_AST;
					currentAST.child = range_AST!=null &&range_AST.getFirstChild()!=null ?
						range_AST.getFirstChild() : range_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case STRING_LITERAL:
			case TOKEN_REF:
			{
				{
				switch ( LA(1)) {
				case TOKEN_REF:
				{
					t = LT(1);
					t_AST = (GrammarAST)astFactory.create(t);
					match(TOKEN_REF);
					break;
				}
				case STRING_LITERAL:
				{
					u = LT(1);
					u_AST = (GrammarAST)astFactory.create(u);
					match(STRING_LITERAL);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				GrammarAST tmp95_AST = null;
				tmp95_AST = (GrammarAST)astFactory.create(LT(1));
				match(RANGE);
				{
				switch ( LA(1)) {
				case TOKEN_REF:
				{
					v = LT(1);
					v_AST = (GrammarAST)astFactory.create(v);
					match(TOKEN_REF);
					break;
				}
				case STRING_LITERAL:
				{
					w = LT(1);
					w_AST = (GrammarAST)astFactory.create(w);
					match(STRING_LITERAL);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				ast_type_spec();
				if ( inputState.guessing==0 ) {
					range_AST = (GrammarAST)currentAST.root;
					
					AST a = (t_AST!=null) ? t_AST : u_AST;
					AST b = (v_AST!=null) ? v_AST : w_AST;
					range_AST = (GrammarAST)astFactory.make( (new ASTArray(3)).add((GrammarAST)astFactory.create(TOKEN_RANGE,"..")).add(a).add(b));
					
					currentAST.root = range_AST;
					currentAST.child = range_AST!=null &&range_AST.getFirstChild()!=null ?
						range_AST.getFirstChild() : range_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = range_AST;
	}
	
	public final void terminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST terminal_AST = null;
		Token  cl = null;
		GrammarAST cl_AST = null;
		Token  tr = null;
		GrammarAST tr_AST = null;
		Token  sl = null;
		GrammarAST sl_AST = null;
		Token  wi = null;
		GrammarAST wi_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CHAR_LITERAL:
			{
				cl = LT(1);
				cl_AST = (GrammarAST)astFactory.create(cl);
				astFactory.addASTChild(currentAST, cl_AST);
				match(CHAR_LITERAL);
				{
				switch ( LA(1)) {
				case BANG:
				{
					match(BANG);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case SEMI:
				case CHAR_LITERAL:
				case OR:
				case TOKEN_REF:
				case OPEN_ELEMENT_OPTION:
				case LPAREN:
				case RULE_REF:
				case RPAREN:
				case LITERAL_exception:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case TOKEN_REF:
			{
				tr = LT(1);
				tr_AST = (GrammarAST)astFactory.create(tr);
				astFactory.addASTChild(currentAST, tr_AST);
				match(TOKEN_REF);
				if ( inputState.guessing==0 ) {
					
							defineToken(tr.getText());
							
				}
				ast_type_spec();
				{
				switch ( LA(1)) {
				case ARG_ACTION:
				{
					match(ARG_ACTION);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case SEMI:
				case CHAR_LITERAL:
				case OR:
				case TOKEN_REF:
				case OPEN_ELEMENT_OPTION:
				case LPAREN:
				case RULE_REF:
				case RPAREN:
				case LITERAL_exception:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				sl = LT(1);
				sl_AST = (GrammarAST)astFactory.create(sl);
				astFactory.addASTChild(currentAST, sl_AST);
				match(STRING_LITERAL);
				if ( inputState.guessing==0 ) {
					
							defineToken(sl.getText());
							
				}
				ast_type_spec();
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case WILDCARD:
			{
				wi = LT(1);
				wi_AST = (GrammarAST)astFactory.create(wi);
				astFactory.addASTChild(currentAST, wi_AST);
				match(WILDCARD);
				ast_type_spec();
				terminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = terminal_AST;
	}
	
	public final void notTerminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST notTerminal_AST = null;
		Token  cl = null;
		GrammarAST cl_AST = null;
		Token  tr = null;
		GrammarAST tr_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CHAR_LITERAL:
			{
				cl = LT(1);
				cl_AST = (GrammarAST)astFactory.create(cl);
				astFactory.addASTChild(currentAST, cl_AST);
				match(CHAR_LITERAL);
				{
				switch ( LA(1)) {
				case BANG:
				{
					match(BANG);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case SEMI:
				case CHAR_LITERAL:
				case OR:
				case TOKEN_REF:
				case OPEN_ELEMENT_OPTION:
				case LPAREN:
				case RULE_REF:
				case RPAREN:
				case LITERAL_exception:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				notTerminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			case TOKEN_REF:
			{
				tr = LT(1);
				tr_AST = (GrammarAST)astFactory.create(tr);
				astFactory.addASTChild(currentAST, tr_AST);
				match(TOKEN_REF);
				ast_type_spec();
				notTerminal_AST = (GrammarAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = notTerminal_AST;
	}
	
	public final void ebnf() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ebnf_AST = null;
		Token  lp = null;
		GrammarAST lp_AST = null;
		GrammarAST b_AST = null;
		
		try {      // for error handling
			lp = LT(1);
			lp_AST = (GrammarAST)astFactory.create(lp);
			match(LPAREN);
			{
			if ((LA(1)==OPTIONS)) {
				subruleOptionsSpec();
				{
				switch ( LA(1)) {
				case ACTION:
				{
					GrammarAST tmp99_AST = null;
					tmp99_AST = (GrammarAST)astFactory.create(LT(1));
					match(ACTION);
					break;
				}
				case COLON:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				GrammarAST tmp100_AST = null;
				tmp100_AST = (GrammarAST)astFactory.create(LT(1));
				match(COLON);
			}
			else if ((LA(1)==ACTION) && (LA(2)==COLON)) {
				GrammarAST tmp101_AST = null;
				tmp101_AST = (GrammarAST)astFactory.create(LT(1));
				match(ACTION);
				GrammarAST tmp102_AST = null;
				tmp102_AST = (GrammarAST)astFactory.create(LT(1));
				match(COLON);
			}
			else if ((_tokenSet_26.member(LA(1))) && (_tokenSet_27.member(LA(2)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			block();
			b_AST = (GrammarAST)returnAST;
			GrammarAST tmp103_AST = null;
			tmp103_AST = (GrammarAST)astFactory.create(LT(1));
			match(RPAREN);
			{
			switch ( LA(1)) {
			case QUESTION:
			case STAR:
			case PLUS:
			{
				{
				switch ( LA(1)) {
				case QUESTION:
				{
					GrammarAST tmp104_AST = null;
					tmp104_AST = (GrammarAST)astFactory.create(LT(1));
					match(QUESTION);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						b_AST.setType(OPTIONAL); ebnf_AST=b_AST;
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case STAR:
				{
					GrammarAST tmp105_AST = null;
					tmp105_AST = (GrammarAST)astFactory.create(LT(1));
					match(STAR);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						b_AST.setType(CLOSURE); ebnf_AST=b_AST;
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				case PLUS:
				{
					GrammarAST tmp106_AST = null;
					tmp106_AST = (GrammarAST)astFactory.create(LT(1));
					match(PLUS);
					if ( inputState.guessing==0 ) {
						ebnf_AST = (GrammarAST)currentAST.root;
						b_AST.setType(POSITIVE_CLOSURE); ebnf_AST=b_AST;
						currentAST.root = ebnf_AST;
						currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
							ebnf_AST.getFirstChild() : ebnf_AST;
						currentAST.advanceChildToEnd();
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case BANG:
				{
					GrammarAST tmp107_AST = null;
					tmp107_AST = (GrammarAST)astFactory.create(LT(1));
					match(BANG);
					break;
				}
				case STRING_LITERAL:
				case ACTION:
				case SEMI:
				case CHAR_LITERAL:
				case OR:
				case TOKEN_REF:
				case OPEN_ELEMENT_OPTION:
				case LPAREN:
				case RULE_REF:
				case RPAREN:
				case LITERAL_exception:
				case NOT_OP:
				case SEMPRED:
				case TREE_BEGIN:
				case WILDCARD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case IMPLIES:
			{
				GrammarAST tmp108_AST = null;
				tmp108_AST = (GrammarAST)astFactory.create(LT(1));
				match(IMPLIES);
				if ( inputState.guessing==0 ) {
					ebnf_AST = (GrammarAST)currentAST.root;
					b_AST.setType(SYNPRED); ebnf_AST=b_AST;
					currentAST.root = ebnf_AST;
					currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
						ebnf_AST.getFirstChild() : ebnf_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case CHAR_LITERAL:
			case OR:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RULE_REF:
			case RPAREN:
			case LITERAL_exception:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				if ( inputState.guessing==0 ) {
					ebnf_AST = (GrammarAST)currentAST.root;
					ebnf_AST = b_AST;
					currentAST.root = ebnf_AST;
					currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
						ebnf_AST.getFirstChild() : ebnf_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				ebnf_AST = (GrammarAST)currentAST.root;
				subruleToTreeList.add(ebnf_AST);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = ebnf_AST;
	}
	
	public final void tree() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST tree_AST = null;
		
		try {      // for error handling
			GrammarAST tmp109_AST = null;
			tmp109_AST = (GrammarAST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp109_AST);
			match(TREE_BEGIN);
			rootNode();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt122=0;
			_loop122:
			do {
				if ((_tokenSet_14.member(LA(1)))) {
					element();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt122>=1 ) { break _loop122; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt122++;
			} while (true);
			}
			match(RPAREN);
			tree_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = tree_AST;
	}
	
	public final void rootNode() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST rootNode_AST = null;
		
		try {      // for error handling
			{
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
				id();
				match(COLON);
			}
			else if ((_tokenSet_23.member(LA(1))) && (_tokenSet_28.member(LA(2)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			terminal();
			astFactory.addASTChild(currentAST, returnAST);
			rootNode_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_14);
			} else {
			  throw ex;
			}
		}
		returnAST = rootNode_AST;
	}
	
	public final void ast_type_spec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		GrammarAST ast_type_spec_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case CARET:
			{
				GrammarAST tmp112_AST = null;
				tmp112_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp112_AST);
				match(CARET);
				break;
			}
			case BANG:
			{
				GrammarAST tmp113_AST = null;
				tmp113_AST = (GrammarAST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp113_AST);
				match(BANG);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case CHAR_LITERAL:
			case OR:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RULE_REF:
			case RPAREN:
			case ARG_ACTION:
			case LITERAL_exception:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			ast_type_spec_AST = (GrammarAST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_29);
			} else {
			  throw ex;
			}
		}
		returnAST = ast_type_spec_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"LEXER",
		"PARSER",
		"TREE_PARSER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"TOKEN_RANGE",
		"CHAR_RANGE",
		"NOT",
		"EPSILON",
		"ALT",
		"EOR",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LITERAL",
		"INT",
		"OR",
		"RANGE",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RULE_REF",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 62914562L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 35468049918197760L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 501927066468352L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 17953376155205632L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 2201170739200L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 502201948569600L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 2147483648L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 4503599631564800L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 70866960384L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 501927070662656L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 501927120994306L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 4503600168435712L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 17594333528064L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 1008820077612498944L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	private static final long[] mk_tokenSet_15() {
		long[] data = { 17663053004800L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
	private static final long[] mk_tokenSet_16() {
		long[] data = { 1044866537684467712L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
	private static final long[] mk_tokenSet_17() {
		long[] data = { 36530724139958274L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
	private static final long[] mk_tokenSet_18() {
		long[] data = { 108605981230891010L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
	private static final long[] mk_tokenSet_19() {
		long[] data = { 1046556487056359424L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
	private static final long[] mk_tokenSet_20() {
		long[] data = { 144128949153169408L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
	private static final long[] mk_tokenSet_21() {
		long[] data = { 1051060224659554304L, 3L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
	private static final long[] mk_tokenSet_22() {
		long[] data = { 1046556625032183808L, 3L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
	private static final long[] mk_tokenSet_23() {
		long[] data = { 566937780224L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
	private static final long[] mk_tokenSet_24() {
		long[] data = { 1046556487056359424L, 3L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
	private static final long[] mk_tokenSet_25() {
		long[] data = { 1044867637196095488L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
	private static final long[] mk_tokenSet_26() {
		long[] data = { 1009400688471441408L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
	private static final long[] mk_tokenSet_27() {
		long[] data = { -101861278873550848L, 3L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
	private static final long[] mk_tokenSet_28() {
		long[] data = { 1010508927472762880L, 3L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
	private static final long[] mk_tokenSet_29() {
		long[] data = { 1045993537102938112L, 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
	
	}
