// $ANTLR : "ANTLROptionLexer.g" -> "ANTLROptionLexer.java"$
 package satc.lang; 
public interface ANTLROptionLexerTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int MLC_STAR = 4;
	int MLC_CLOSE = 5;
	int MLC_WORD = 6;
	int MLC_WS = 7;
	int LITERAL_charVocabulary = 8;
	int LITERAL_importVocab = 9;
	int LITERAL_exportVocab = 10;
	int LITERAL_testLiterals = 11;
	int LITERAL_warnWhenFollowAmbig = 12;
	int LITERAL_filter = 13;
	int LITERAL_true = 14;
	int LITERAL_false = 15;
	int LITERAL_k = 16;
	int OPTION_EQUAL = 17;
	int OPTION_CLOSE = 18;
	int OPTION_WORD = 19;
	int OPTION_WS = 20;
	int SL_COMMENT = 21;
	int SEMI = 22;
}
