package satc;

/* ANTLR Translator Generator
 * Project led by Terence Parr at http://www.jGuru.com
 * Software rights: http://www.antlr.org/RIGHTS.html
 *
 * $Id: TokenFilter.java,v 1.25 2004/02/05 23:51:08 bogdan Exp $
 * 
 * 01/16/2004 - 22.42 : 
 * 		optimize damageBefore(), damageAfter()
 * 
 * 
 */

import java.util.logging.Logger;

import satc.antlr.DocAST;
import satc.swing.LexerDocumentListener;
import antlr.Token;
import antlr.TokenStream;
import antlr.TokenStreamException;
import antlr.collections.impl.BitSet;

/** This object is a TokenStream that passes through all
 *  tokens except for those that you tell it to discard.
 *  There is no buffering of the tokens.
 */
public class TokenFilter implements TokenStream {

    private TokenList tokenList;

	/** The set of token types to discard */
    protected BitSet discardMask;

    public TokenFilter(TokenList input) {
        this.tokenList = (TokenList) input;
        discardMask = new BitSet();
    }

    public void discard(int ttype) {
        discardMask.add(ttype);
    }

    public void discard(BitSet mask) {
        discardMask = mask;
    }

	public Token nextToken() throws TokenStreamException {
		ListToken tok = (ListToken) tokenList.nextToken();
		while (tok != null && discardMask.member(tok.getType())) {
			tok = (ListToken) tokenList.nextToken();
		}
		DocAST parent = tok.getCleanAST();
		if (parent != null) {
			log.finer("" + tok);
			log.fine("  --> " + parent);

			tokenList.reset( parent.getLastToken());
			log.finer(" <-- ");
			
			tok = (ListToken) tokenList.nextToken();
			log.finer("" + tok);
			
			return parent.getToken();
		}
		else {
			tok.setPN( null);
			log.fine(" " + tok);
		}
		return tok;
	}
	
	public Token previousToken() throws TokenStreamException {
		Token tok = tokenList.previousToken();
		while (tok != null && discardMask.member(tok.getType())) {
			tok = tokenList.previousToken();
		}
		return tok;
	}

DocAST[] pathBefore;
DocAST[] pathAfter;
DocAST nodeBefore;
DocAST nodeAfter;

	public void damageBefore( ListToken token) {
		log.finer("-->damageBefore(" + token + ");");

		if (token ==  null) return;
		
		nodeBefore = null;
		DocAST parentAST = null;
		tokenList.reset( token);
		tokenList.reset( token);
		loop:
		try {
			for (; token != null; token = (ListToken) tokenList.previousToken()) {
				parentAST = token.getPN();
				if (parentAST != null) { 
					if (parentAST.getLastToken() == token) {
						parentAST.setDamagedAfter();					
					} else {
						parentAST.setDamaged( true);					
					}
					break loop;
				}
			}		
		} catch (Exception x) {
			x.printStackTrace();
		}
	}

	public void damageAfter( ListToken token) {
		log.finer("-->damageAfter(" + token + ");");
		
		if (token ==  null) return;
		
		nodeAfter = null;
		DocAST parentAST = null;
		tokenList.reset( token);
		loop:
		try {
			for (; token != null && token.getType() != antlr.ANTLRTokenTypes.EOF; token = (ListToken) tokenList.nextToken()) {
				parentAST = token.getPN();
				if (parentAST != null) { 
					if (parentAST.getFirstToken() == token) {
						parentAST.setDamagedBefore();
						break loop;
					} else {					
						parentAST.setDamaged( true);
					}					
					break loop;
				}
			}		
		} catch (Exception x) {
			x.printStackTrace();
		}
	}

	
	public void tokenListChanged (
		LexerDocumentListener ldl,
		ListToken startToken, 
		ListToken endToken, 
		ListToken firstDamagedToken, 
		ListToken lastDamagedToken)
	{
		log.finer("-->TokenFilter.tokenListChanged()");
		log.fine("    startToken = " + startToken);	
		log.fine("    endToken = " + endToken);	
		damageBefore( startToken);
		damageAfter( endToken);
	}	

	private static Logger log = Logger.getLogger("satc.TokenFilter");

}

