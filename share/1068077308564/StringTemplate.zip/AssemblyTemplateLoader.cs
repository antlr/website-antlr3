using System;
using System.IO;
using System.Reflection;

namespace Antlr.StringTemplate {
	/// <summary>
	/// Loads templates from an assembly manifest.
	/// </summary>
	public class AssemblyTemplateLoader : IStringTemplateLoader {
		private Assembly assembly;
		private String nameSpace;

		public AssemblyTemplateLoader() : 
			this(Assembly.GetExecutingAssembly(), null) {
		}

		public AssemblyTemplateLoader(String assemblyName, String nameSpace) :
			this(Assembly.LoadWithPartialName(assemblyName), nameSpace) {
		}

		public AssemblyTemplateLoader(Assembly assembly, String nameSpace) {
			if (assembly == null) {
				throw new ArgumentNullException("assembly");
			}

			this.assembly = assembly;

			if (nameSpace == null) {
				this.nameSpace = this.GetType().Namespace;
			}
			else {
				this.nameSpace = nameSpace;
			}
		}

		/// <summary>
		/// Convert a filename relativePath/name.st to relativePath/name.
		/// </summary>
		/// <param name="relativePath">Relative template path.</param>
		/// <returns>The template name.</returns>
		public String DeriveTemplateNameFromLocation(String location) {
			return Path.ChangeExtension(location, null);
		}

		/// <summary>
		/// Derive a template path from a name.
		/// </summary>
		/// <param name="templateName">Template name.</param>
		/// <returns>The template path.</returns>
		public String DeriveLocationFromTemplateName(String templateName) {
			return templateName + ".st";
		}

		public String LoadTemplate(String name, String location) {
			TextReader tr = null;
			String templateSource = null;
			String templateName = this.nameSpace + "." + location;

			try {
				Stream str = assembly.GetManifestResourceStream(templateName);
                tr = new StreamReader(str);
				templateSource = tr.ReadToEnd();

				if ( templateSource == null || templateSource.Length == 0 ) {
					throw new Exception("No text in template '" + name + "'");
				}

				// strip newlines etc.. from front/back since filesystem
				// may add newlines etc...
				templateSource = templateSource.Trim();
				tr.Close();
				tr = null;
			}
			catch (IOException) {
				if ( tr != null ) {
					try {
						tr.Close();
					}
					catch (IOException e) {
						throw new Exception("Cannot close template file: " + location, e);
					}
				}
			}

			return templateSource;
		}

		public String Base { 
			get {
				return this.nameSpace;
			}
			set {
				this.nameSpace = value;
			}
		}
	}
}
