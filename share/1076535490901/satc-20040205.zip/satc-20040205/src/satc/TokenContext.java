/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;
                                              
import java.awt.Color;

import javax.swing.text.AttributeSet;
import javax.swing.text.StyleConstants;

import antlr.Token;

/**
 * This class stores token properties and other 
 * token-related information. A different instance
 * should be created for each syntax mode.
 */
public class TokenContext {
 
    /**
     * Retrieves the color that should be used to render 
     * the text of a token.
     */
    public Color getColor( Token token) {
        Color color = getTokenColors()[token.getType()];
        return color;
    }

    public void setStyle( int tokenType, AttributeSet style) {
        if( tokenStyles == null) {
            tokenStyles = new AttributeSet[getTokenCount()];
        }
        tokenStyles [tokenType] = style;
    }

    public AttributeSet getStyle( int tokenType) {
        if( tokenStyles == null) 
        	return null;      
        else
        	return tokenStyles [tokenType];
    }

    /**
     * Returns the number of token types.
     */
    public int getTokenCount() {
        return tokenCount;
    }

    /**
     * Stores information about the number of token types.
     */
    public void setTokenCount( int count) {
        tokenCount = count;
    }

    private Color[] getTokenColors() {
        tokenColors = new Color [getTokenCount()];
        AttributeSet[] tokenStyles = getTokenStyles();
        for( int i = 0; i < tokenColors.length; i++) {
            if( tokenStyles[i] == null) {
                tokenColors[i] = Color.black;
            } else {
                tokenColors[i] = StyleConstants.getForeground( tokenStyles[i]);
            }
        }
        return tokenColors;
    }

    /**
     * Cache of foreground colors to represent the 
     * various tokens.
     */
    protected Color[] tokenColors;
    protected AttributeSet[] tokenStyles;
    
    protected AttributeSet[] getTokenStyles() {
        return tokenStyles;
    }

    protected int tokenCount;
 }
