/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;



public class CarrierStream implements TreeNodeStream, Iterator<Payload> {
	public static final PayloadToken DOWN = new PayloadToken(Token.DOWN, "DOWN");

	public static final PayloadToken UP = new PayloadToken(Token.UP, "UP");

	public static final PayloadToken EOF_NODE = new PayloadToken(Token.EOF, "EOF");

	/** Reuse same DOWN, UP navigation nodes unless this is true */
	protected boolean uniqueNavigationNodes = false;

	/** Pull nodes from which tree? */
	private Carrier root;

	/** As we walk down the nodes, we must track parent nodes so we know
	 *  where to go after walking the last child of a node.  When visiting
	 *  a child, push current node and current index.
	 */
	protected Stack<Carrier> carrierStack = new Stack<Carrier>();

	/** Track the last mark() call result value for use in rewind(). */
	protected int lastMarker;

	/** Which node are we currently visiting? */
	protected Payload currentNode;
	
	private Carrier cursor;

	/** Which node did we visit last?  Used for LT(-1) calls. */
	protected Payload previousNode;

	/** What node index did we just consume?  i=0..n-1 for n node trees.
	 *  IntStream.next is hence 1 + this value.  Size will be same.
	 */
	protected int absoluteNodeIndex;

	/** When walking ahead with cyclic DFA or for syntactic predicates,
	  *  we need to record the state of the tree node stream.  This
	 *  class wraps up the current state of the CommonTreeNodeStream.
	 *  Calling mark() will push another of these on the markers stack.
	 */
	protected class TreeWalkState {
		int absoluteNodeIndex;
		Payload previousNode;
		Payload currentNode;
		Carrier cursor;
		/** Record state of the nodeStack */
		Stack<Carrier> carrierStack;
	}

	/** Calls to mark() may be nested so we have to track a stack of
	 *  them.  The marker is an index into this stack.  Index 0 is
	 *  the first marker.  This is a List<TreeWalkState>
	 */
	protected List<TreeWalkState> markers;
	
	protected CarrierStream() {
		reset();
	}

	public CarrierStream(Carrier tree) {
		this.setRoot(tree);
		reset();
	}

	public void reset() {
		if (getRoot() == null)
			currentNode = Token.EOF_TOKEN;	// sneaky trick
		else
			currentNode = getRoot().getAttributes();
		
		setCursor(getRoot());
		previousNode = null;
		absoluteNodeIndex = -1;
	}

	public Payload LT(int k) {
		if (k == 1)	// usual case
			return currentNode;
		else if (k > 1)
			return peek(k);
		else if (k == -1)
			return previousNode;

			return Token.EOF_TOKEN;
	}

	public Carrier getTreeSource() {
		return getRoot();
	}

	public String toString(Object start, Object stop) {
		// TODO Auto-generated method stub
		return null;
	}

	public void consume() {
		next();
	}

	public int LA(int i) {
		Payload t = (Payload)LT(i);
		if ( t==null ) {
			return Token.INVALID_TOKEN_TYPE;
		}
		return t.getType();
	}

	public int mark() {
		if ( markers==null ) {
			markers = new ArrayList<TreeWalkState>();
		}
		TreeWalkState state = new TreeWalkState();
		state.absoluteNodeIndex = absoluteNodeIndex;
		state.cursor = getCursor();
		state.previousNode = previousNode;
		state.currentNode = currentNode;
		state.carrierStack = (Stack) carrierStack.clone();
		markers.add(state);
		lastMarker = markers.size();
		return markers.size(); // markers go 1..depth
	}

	public int index() {
		return absoluteNodeIndex+1;
	}

	public void rewind(int marker) {
		if ( markers==null || markers.size()<marker ) {
			return; // do nothing upon error; perhaps this should throw exception?
		}
		TreeWalkState state = (TreeWalkState)markers.get(marker-1);
		markers.remove(marker-1); // "pop" state from stack
		lastMarker = markers.size();
		absoluteNodeIndex = state.absoluteNodeIndex;
		setCursor(state.cursor);
		previousNode = state.previousNode;
		currentNode = state.currentNode;
		// restore stack
		carrierStack = state.carrierStack;
	}

	public void rewind() {
		rewind(lastMarker);
	}

	public void release(int marker) {
		throw new NoSuchMethodError("can't release tree parse; email lgcraymer@yahoo.com");
	}

	public void seek(int index) {
		if ( index<this.index() ) {
			throw new IllegalArgumentException("can't seek backwards in node stream");
		}
		// seek forward, consume until we hit index
		while ( this.index()<index - 1 ) {
			consume();
		}
	}

	public int size() {
		return -1;
	}

	public boolean hasNext() {
		return currentNode!=null;
	}

	/*
	 *  (non-Javadoc)
	 * @see java.util.Iterator#next()
	 */
	public Payload next() {
		previousNode = currentNode;
		if (currentNode == DOWN) {
			carrierStack.push(getCursor());
			setCursor(getCursor().getFirstChild());
			currentNode = getCursor().getAttributes();
		}
		else if (currentNode == UP) {
			setCursor(getCursor().getNextSibling());
			if (getCursor() != null) {
				currentNode = getCursor().getAttributes();
			}
			else {
				if (carrierStack.size() > 0) {
					setCursor(carrierStack.pop());
					currentNode = UP;
				}
				else
					currentNode = EOF_NODE;
			}
		}
		else if ((currentNode == EOF_NODE) || (getCursor() == null)) {
			return currentNode;
		}
		else if (getCursor().hasChildren()) {
			currentNode = DOWN;
		}
		else if (getCursor().hasSiblings()) {
			setCursor(getCursor().getNextSibling());
			currentNode = getCursor().getAttributes();
		}
		else {
			if (carrierStack.size() > 0) {
				setCursor(carrierStack.pop());
				currentNode = UP;
			}
			else
				currentNode = EOF_NODE;
		}
		
		absoluteNodeIndex++;
		return previousNode;
	}
	
	protected Payload peek(int n) {
		int offset = 0;
		int depth = 0;
		Carrier[] carriers = new Carrier[10];
		Carrier local = getCursor();
		
		for (int i=1; i<n; i++ ) {
			if (local == null){
				if ((offset == 0) && (depth == carrierStack.size())) {
						return EOF_NODE;
				}
					
				if (offset == 0) {
					local = carrierStack.elementAt(carrierStack.size() - depth++ - 1);
				}
				else {
					local = carriers[--offset];
				}
			
				local = local.getNextSibling();			
			}
			else if (local.getFirstChild() != null) {
				i++;
				if (i == n)
					return DOWN;
				
				carriers[offset++] = local;
				local = local.getFirstChild();
			}
			else {
				local = local.getNextSibling();
			}
		}
		
		if (local == null) {
			if ((offset == 0) && (depth == carrierStack.size())) {
				return EOF_NODE;
			}
			return UP;
		}
		return local.getAttributes();
	}
	
	public void remove() {
		throw new NoSuchMethodError();
	}

	public void setCursor(Carrier cursor) {
		this.cursor = cursor;
	}

	public Carrier getCursor() {
		return cursor;
	}

	public void setRoot(Carrier root) {
		reset();
		if (root == null)
			return;
		
		this.root = root;
		this.cursor = root;
		currentNode = root.getAttributes();
	}

	public Carrier getRoot() {
		return root;
	}

}
