// $ANTLR 2.7.5 (20050201): "antlr.g" -> "ANTLRParser.java"$

package antlr;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import antlr.AntlrGrammarGraph;
import java.util.Enumeration;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ANTLRParser extends antlr.LLkParser       implements ANTLRTokenTypes
 {

protected ANTLRParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected ANTLRParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenStream lexer) {
  this(lexer,2);
}

public ANTLRParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void grammar() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST grammar_AST = null;
		
		{
		_loop4:
		do {
			if ((LA(1)==LITERAL_header)) {
				match(LITERAL_header);
				{
				switch ( LA(1)) {
				case STRING_LITERAL:
				{
					match(STRING_LITERAL);
					break;
				}
				case ACTION:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(ACTION);
			}
			else {
				break _loop4;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case OPTIONS:
		{
			fileOptionsSpec();
			break;
		}
		case EOF:
		case ACTION:
		case DOC_COMMENT:
		case LITERAL_lexclass:
		case LITERAL_class:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop7:
		do {
			if (((LA(1) >= ACTION && LA(1) <= LITERAL_class))) {
				classDef();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop7;
			}
			
		} while (true);
		}
		match(Token.EOF_TYPE);
		grammar_AST = (AST)currentAST.root;
		returnAST = grammar_AST;
	}
	
	public final void fileOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST fileOptionsSpec_AST = null;
		
		AST tmp5_AST = null;
		tmp5_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop18:
		do {
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
				id();
				AST tmp6_AST = null;
				tmp6_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp7_AST = null;
				tmp7_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				break _loop18;
			}
			
		} while (true);
		}
		AST tmp8_AST = null;
		tmp8_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = fileOptionsSpec_AST;
	}
	
	public final void classDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST classDef_AST = null;
		
		{
		switch ( LA(1)) {
		case ACTION:
		{
			AST tmp9_AST = null;
			tmp9_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp9_AST);
			match(ACTION);
			break;
		}
		case DOC_COMMENT:
		case LITERAL_lexclass:
		case LITERAL_class:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case DOC_COMMENT:
		{
			AST tmp10_AST = null;
			tmp10_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp10_AST);
			match(DOC_COMMENT);
			break;
		}
		case LITERAL_lexclass:
		case LITERAL_class:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		boolean synPredMatched13 = false;
		if (((LA(1)==LITERAL_lexclass||LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF))) {
			int _m13 = mark();
			synPredMatched13 = true;
			inputState.guessing++;
			try {
				{
				switch ( LA(1)) {
				case LITERAL_lexclass:
				{
					match(LITERAL_lexclass);
					break;
				}
				case LITERAL_class:
				{
					match(LITERAL_class);
					id();
					match(LITERAL_extends);
					match(LITERAL_Lexer);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
			}
			catch (RecognitionException pe) {
				synPredMatched13 = false;
			}
			rewind(_m13);
			inputState.guessing--;
		}
		if ( synPredMatched13 ) {
			lexerSpec();
		}
		else {
			boolean synPredMatched15 = false;
			if (((LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF))) {
				int _m15 = mark();
				synPredMatched15 = true;
				inputState.guessing++;
				try {
					{
					match(LITERAL_class);
					id();
					match(LITERAL_extends);
					match(LITERAL_TreeParser);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched15 = false;
				}
				rewind(_m15);
				inputState.guessing--;
			}
			if ( synPredMatched15 ) {
				treeParserSpec();
			}
			else if ((LA(1)==LITERAL_class) && (LA(2)==TOKEN_REF||LA(2)==RULE_REF)) {
				parserSpec();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			rules();
			astFactory.addASTChild(currentAST, returnAST);
			classDef_AST = (AST)currentAST.root;
			returnAST = classDef_AST;
		}
		
	public final void id() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST id_AST = null;
		
		switch ( LA(1)) {
		case TOKEN_REF:
		{
			AST tmp11_AST = null;
			tmp11_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp11_AST);
			match(TOKEN_REF);
			id_AST = (AST)currentAST.root;
			break;
		}
		case RULE_REF:
		{
			AST tmp12_AST = null;
			tmp12_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp12_AST);
			match(RULE_REF);
			id_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = id_AST;
	}
	
	public final void lexerSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lexerSpec_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_lexclass:
		{
			match(LITERAL_lexclass);
			id();
			if ( inputState.guessing==0 ) {
				
				AntlrGrammarGraph.currentMap = AntlrGrammarGraph.lexerMap;
				
			}
			break;
		}
		case LITERAL_class:
		{
			match(LITERAL_class);
			id();
			if ( inputState.guessing==0 ) {
				
				AntlrGrammarGraph.currentMap = AntlrGrammarGraph.lexerMap;
				
			}
			match(LITERAL_extends);
			match(LITERAL_Lexer);
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				superClass();
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp17_AST = null;
		tmp17_AST = astFactory.create(LT(1));
		match(SEMI);
		{
		switch ( LA(1)) {
		case OPTIONS:
		{
			lexerOptionsSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKENS:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case TOKENS:
		{
			tokensSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ACTION:
		{
			AST tmp18_AST = null;
			tmp18_AST = astFactory.create(LT(1));
			match(ACTION);
			break;
		}
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		returnAST = lexerSpec_AST;
	}
	
	public final void treeParserSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST treeParserSpec_AST = null;
		
		match(LITERAL_class);
		id();
		match(LITERAL_extends);
		match(LITERAL_TreeParser);
		{
		switch ( LA(1)) {
		case LPAREN:
		{
			superClass();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp22_AST = null;
		tmp22_AST = astFactory.create(LT(1));
		match(SEMI);
		{
		switch ( LA(1)) {
		case OPTIONS:
		{
			treeParserOptionsSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKENS:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case TOKENS:
		{
			tokensSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ACTION:
		{
			AST tmp23_AST = null;
			tmp23_AST = astFactory.create(LT(1));
			match(ACTION);
			break;
		}
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		returnAST = treeParserSpec_AST;
	}
	
	public final void parserSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parserSpec_AST = null;
		
		match(LITERAL_class);
		id();
		if ( inputState.guessing==0 ) {
			
			AntlrGrammarGraph.currentMap = AntlrGrammarGraph.parserRules;
			
		}
		{
		switch ( LA(1)) {
		case LITERAL_extends:
		{
			match(LITERAL_extends);
			match(LITERAL_Parser);
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				superClass();
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp27_AST = null;
		tmp27_AST = astFactory.create(LT(1));
		match(SEMI);
		{
		switch ( LA(1)) {
		case OPTIONS:
		{
			parserOptionsSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKENS:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case TOKENS:
		{
			tokensSpec();
			break;
		}
		case ACTION:
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ACTION:
		{
			AST tmp28_AST = null;
			tmp28_AST = astFactory.create(LT(1));
			match(ACTION);
			break;
		}
		case DOC_COMMENT:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		returnAST = parserSpec_AST;
	}
	
	public final void rules() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rules_AST = null;
		
		{
		int _cnt68=0;
		_loop68:
		do {
			if ((_tokenSet_0.member(LA(1))) && (_tokenSet_1.member(LA(2)))) {
				rule();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				if ( _cnt68>=1 ) { break _loop68; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt68++;
		} while (true);
		}
		rules_AST = (AST)currentAST.root;
		returnAST = rules_AST;
	}
	
	public final void optionValue() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST optionValue_AST = null;
		
		switch ( LA(1)) {
		case TOKEN_REF:
		case RULE_REF:
		{
			qualifiedID();
			break;
		}
		case STRING_LITERAL:
		{
			AST tmp29_AST = null;
			tmp29_AST = astFactory.create(LT(1));
			match(STRING_LITERAL);
			break;
		}
		case CHAR_LTERAL:
		{
			AST tmp30_AST = null;
			tmp30_AST = astFactory.create(LT(1));
			match(CHAR_LTERAL);
			break;
		}
		case INT:
		{
			AST tmp31_AST = null;
			tmp31_AST = astFactory.create(LT(1));
			match(INT);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = optionValue_AST;
	}
	
	public final void parserOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parserOptionsSpec_AST = null;
		
		AST tmp32_AST = null;
		tmp32_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop21:
		do {
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
				id();
				AST tmp33_AST = null;
				tmp33_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp34_AST = null;
				tmp34_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				break _loop21;
			}
			
		} while (true);
		}
		AST tmp35_AST = null;
		tmp35_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = parserOptionsSpec_AST;
	}
	
	public final void treeParserOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST treeParserOptionsSpec_AST = null;
		
		AST tmp36_AST = null;
		tmp36_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop24:
		do {
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
				id();
				AST tmp37_AST = null;
				tmp37_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp38_AST = null;
				tmp38_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				break _loop24;
			}
			
		} while (true);
		}
		AST tmp39_AST = null;
		tmp39_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = treeParserOptionsSpec_AST;
	}
	
	public final void lexerOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lexerOptionsSpec_AST = null;
		
		AST tmp40_AST = null;
		tmp40_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop27:
		do {
			switch ( LA(1)) {
			case LITERAL_charVocabulary:
			{
				match(LITERAL_charVocabulary);
				AST tmp42_AST = null;
				tmp42_AST = astFactory.create(LT(1));
				match(ASSIGN);
				charSet();
				AST tmp43_AST = null;
				tmp43_AST = astFactory.create(LT(1));
				match(SEMI);
				break;
			}
			case TOKEN_REF:
			case RULE_REF:
			{
				id();
				AST tmp44_AST = null;
				tmp44_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp45_AST = null;
				tmp45_AST = astFactory.create(LT(1));
				match(SEMI);
				break;
			}
			default:
			{
				break _loop27;
			}
			}
		} while (true);
		}
		AST tmp46_AST = null;
		tmp46_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = lexerOptionsSpec_AST;
	}
	
	public final void charSet() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST charSet_AST = null;
		
		setBlockElement();
		{
		_loop34:
		do {
			if ((LA(1)==OR)) {
				AST tmp47_AST = null;
				tmp47_AST = astFactory.create(LT(1));
				match(OR);
				setBlockElement();
			}
			else {
				break _loop34;
			}
			
		} while (true);
		}
		returnAST = charSet_AST;
	}
	
	public final void subruleOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST subruleOptionsSpec_AST = null;
		
		AST tmp48_AST = null;
		tmp48_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop30:
		do {
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
				id();
				AST tmp49_AST = null;
				tmp49_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp50_AST = null;
				tmp50_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				break _loop30;
			}
			
		} while (true);
		}
		AST tmp51_AST = null;
		tmp51_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = subruleOptionsSpec_AST;
	}
	
/** Match a.b.c.d qualified ids; WILDCARD here is overloaded as
 *  id separator; that is, I need a reference to the '.' token.
 */
	public final void qualifiedID() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST qualifiedID_AST = null;
		
		id();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop143:
		do {
			if ((LA(1)==WILDCARD)) {
				AST tmp52_AST = null;
				tmp52_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp52_AST);
				match(WILDCARD);
				id();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop143;
			}
			
		} while (true);
		}
		qualifiedID_AST = (AST)currentAST.root;
		returnAST = qualifiedID_AST;
	}
	
	public final void setBlockElement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST setBlockElement_AST = null;
		
		AST tmp53_AST = null;
		tmp53_AST = astFactory.create(LT(1));
		match(CHAR_LITERAL);
		{
		switch ( LA(1)) {
		case CHAR_LITERAL:
		{
			AST tmp54_AST = null;
			tmp54_AST = astFactory.create(LT(1));
			match(CHAR_LITERAL);
			break;
		}
		case SEMI:
		case OR:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		returnAST = setBlockElement_AST;
	}
	
	public final void tokensSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST tokensSpec_AST = null;
		
		AST tmp55_AST = null;
		tmp55_AST = astFactory.create(LT(1));
		match(TOKENS);
		{
		int _cnt43=0;
		_loop43:
		do {
			if ((LA(1)==STRING_LITERAL||LA(1)==TOKEN_REF)) {
				{
				switch ( LA(1)) {
				case TOKEN_REF:
				{
					AST tmp56_AST = null;
					tmp56_AST = astFactory.create(LT(1));
					match(TOKEN_REF);
					{
					switch ( LA(1)) {
					case STRING_LITERAL:
					{
						AST tmp57_AST = null;
						tmp57_AST = astFactory.create(LT(1));
						match(STRING_LITERAL);
						break;
					}
					case SEMI:
					case OPEN_ELEMENT_OPTION:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					{
					switch ( LA(1)) {
					case OPEN_ELEMENT_OPTION:
					{
						tokensSpecOptions();
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				case STRING_LITERAL:
				{
					AST tmp58_AST = null;
					tmp58_AST = astFactory.create(LT(1));
					match(STRING_LITERAL);
					{
					switch ( LA(1)) {
					case OPEN_ELEMENT_OPTION:
					{
						tokensSpecOptions();
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp59_AST = null;
				tmp59_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				if ( _cnt43>=1 ) { break _loop43; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt43++;
		} while (true);
		}
		AST tmp60_AST = null;
		tmp60_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = tokensSpec_AST;
	}
	
	public final void tokensSpecOptions() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST tokensSpecOptions_AST = null;
		
		AST tmp61_AST = null;
		tmp61_AST = astFactory.create(LT(1));
		match(OPEN_ELEMENT_OPTION);
		id();
		AST tmp62_AST = null;
		tmp62_AST = astFactory.create(LT(1));
		match(ASSIGN);
		optionValue();
		{
		_loop46:
		do {
			if ((LA(1)==SEMI)) {
				AST tmp63_AST = null;
				tmp63_AST = astFactory.create(LT(1));
				match(SEMI);
				id();
				AST tmp64_AST = null;
				tmp64_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
			}
			else {
				break _loop46;
			}
			
		} while (true);
		}
		AST tmp65_AST = null;
		tmp65_AST = astFactory.create(LT(1));
		match(CLOSE_ELEMENT_OPTION);
		returnAST = tokensSpecOptions_AST;
	}
	
	public final void superClass() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST superClass_AST = null;
		
		AST tmp66_AST = null;
		tmp66_AST = astFactory.create(LT(1));
		match(LPAREN);
		{
		AST tmp67_AST = null;
		tmp67_AST = astFactory.create(LT(1));
		match(STRING_LITERAL);
		}
		AST tmp68_AST = null;
		tmp68_AST = astFactory.create(LT(1));
		match(RPAREN);
		returnAST = superClass_AST;
	}
	
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rule_AST = null;
		AST theID_AST = null;
		AST aBlock_AST = null;
		
		{
		switch ( LA(1)) {
		case DOC_COMMENT:
		{
			match(DOC_COMMENT);
			break;
		}
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_protected:
		{
			match(LITERAL_protected);
			break;
		}
		case LITERAL_public:
		{
			match(LITERAL_public);
			break;
		}
		case LITERAL_private:
		{
			match(LITERAL_private);
			break;
		}
		case TOKEN_REF:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		id();
		theID_AST = (AST)returnAST;
		{
		switch ( LA(1)) {
		case BANG:
		{
			match(BANG);
			break;
		}
		case ACTION:
		case OPTIONS:
		case ARG_ACTION:
		case LITERAL_returns:
		case COLON:
		case LITERAL_throws:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ARG_ACTION:
		{
			match(ARG_ACTION);
			break;
		}
		case ACTION:
		case OPTIONS:
		case LITERAL_returns:
		case COLON:
		case LITERAL_throws:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_returns:
		{
			match(LITERAL_returns);
			match(ARG_ACTION);
			break;
		}
		case ACTION:
		case OPTIONS:
		case COLON:
		case LITERAL_throws:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_throws:
		{
			throwsSpec();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case ACTION:
		case OPTIONS:
		case COLON:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case OPTIONS:
		{
			ruleOptionsSpec();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case ACTION:
		case COLON:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ACTION:
		{
			match(ACTION);
			break;
		}
		case COLON:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(COLON);
		block();
		aBlock_AST = (AST)returnAST;
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMI);
		{
		switch ( LA(1)) {
		case LITERAL_exception:
		{
			exceptionGroup();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case ACTION:
		case DOC_COMMENT:
		case LITERAL_lexclass:
		case LITERAL_class:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			rule_AST = (AST)currentAST.root;
			
			AntlrGrammarGraph.ruleName.add(theID_AST.getText());
			if (theID_AST.getText() != null && rule_AST != null && AntlrGrammarGraph.currentMap != null) {
			AntlrGrammarGraph.currentMap.put(theID_AST.getText(),aBlock_AST); 
			}
			rule_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(RULE,"token-rule")).add(rule_AST)); 
			
			currentAST.root = rule_AST;
			currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
				rule_AST.getFirstChild() : rule_AST;
			currentAST.advanceChildToEnd();
		}
		rule_AST = (AST)currentAST.root;
		returnAST = rule_AST;
	}
	
	public final void throwsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST throwsSpec_AST = null;
		
		match(LITERAL_throws);
		id();
		{
		_loop84:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp81_AST = null;
				tmp81_AST = astFactory.create(LT(1));
				match(COMMA);
				id();
			}
			else {
				break _loop84;
			}
			
		} while (true);
		}
		returnAST = throwsSpec_AST;
	}
	
	public final void ruleOptionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ruleOptionsSpec_AST = null;
		
		AST tmp82_AST = null;
		tmp82_AST = astFactory.create(LT(1));
		match(OPTIONS);
		{
		_loop81:
		do {
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF)) {
				id();
				AST tmp83_AST = null;
				tmp83_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
				AST tmp84_AST = null;
				tmp84_AST = astFactory.create(LT(1));
				match(SEMI);
			}
			else {
				break _loop81;
			}
			
		} while (true);
		}
		AST tmp85_AST = null;
		tmp85_AST = astFactory.create(LT(1));
		match(RCURLY);
		returnAST = ruleOptionsSpec_AST;
	}
	
	public final void block() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST block_AST = null;
		
		boolean thereIsAnOR = false;
		
		
		alternative();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop87:
		do {
			if ((LA(1)==OR)) {
				match(OR);
				if ( inputState.guessing==0 ) {
					thereIsAnOR = true;
				}
				alternative();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop87;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			block_AST = (AST)currentAST.root;
			
			if(thereIsAnOR) {
			block_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OR,"|")).add(block_AST));
			}
			
			currentAST.root = block_AST;
			currentAST.child = block_AST!=null &&block_AST.getFirstChild()!=null ?
				block_AST.getFirstChild() : block_AST;
			currentAST.advanceChildToEnd();
		}
		block_AST = (AST)currentAST.root;
		returnAST = block_AST;
	}
	
	public final void exceptionGroup() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST exceptionGroup_AST = null;
		
		{
		int _cnt95=0;
		_loop95:
		do {
			if ((LA(1)==LITERAL_exception)) {
				exceptionSpec();
			}
			else {
				if ( _cnt95>=1 ) { break _loop95; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt95++;
		} while (true);
		}
		returnAST = exceptionGroup_AST;
	}
	
	public final void alternative() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alternative_AST = null;
		
		{
		switch ( LA(1)) {
		case BANG:
		{
			match(BANG);
			break;
		}
		case STRING_LITERAL:
		case ACTION:
		case SEMI:
		case OR:
		case CHAR_LITERAL:
		case TOKEN_REF:
		case LPAREN:
		case RPAREN:
		case LITERAL_exception:
		case RULE_REF:
		case NOT_OP:
		case SEMPRED:
		case TREE_BEGIN:
		case WILDCARD:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop91:
		do {
			if ((_tokenSet_2.member(LA(1)))) {
				element();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop91;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case LITERAL_exception:
		{
			exceptionSpecNoLabel();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case SEMI:
		case OR:
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			alternative_AST = (AST)currentAST.root;
			alternative_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ALTERNATIVE,"alternative")).add(alternative_AST));
			currentAST.root = alternative_AST;
			currentAST.child = alternative_AST!=null &&alternative_AST.getFirstChild()!=null ?
				alternative_AST.getFirstChild() : alternative_AST;
			currentAST.advanceChildToEnd();
		}
		alternative_AST = (AST)currentAST.root;
		returnAST = alternative_AST;
	}
	
	public final void element() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST element_AST = null;
		
		elementNoOptionSpec();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case OPEN_ELEMENT_OPTION:
		{
			elementOptionSpec();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case STRING_LITERAL:
		case ACTION:
		case SEMI:
		case OR:
		case CHAR_LITERAL:
		case TOKEN_REF:
		case LPAREN:
		case RPAREN:
		case LITERAL_exception:
		case RULE_REF:
		case NOT_OP:
		case SEMPRED:
		case TREE_BEGIN:
		case WILDCARD:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		element_AST = (AST)currentAST.root;
		returnAST = element_AST;
	}
	
	public final void exceptionSpecNoLabel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST exceptionSpecNoLabel_AST = null;
		
		match(LITERAL_exception);
		{
		_loop102:
		do {
			if ((LA(1)==LITERAL_catch)) {
				exceptionHandler();
			}
			else {
				break _loop102;
			}
			
		} while (true);
		}
		returnAST = exceptionSpecNoLabel_AST;
	}
	
	public final void exceptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST exceptionSpec_AST = null;
		
		match(LITERAL_exception);
		{
		switch ( LA(1)) {
		case ARG_ACTION:
		{
			AST tmp90_AST = null;
			tmp90_AST = astFactory.create(LT(1));
			match(ARG_ACTION);
			break;
		}
		case EOF:
		case ACTION:
		case DOC_COMMENT:
		case LITERAL_lexclass:
		case LITERAL_class:
		case TOKEN_REF:
		case LITERAL_protected:
		case LITERAL_public:
		case LITERAL_private:
		case LITERAL_exception:
		case LITERAL_catch:
		case RULE_REF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		_loop99:
		do {
			if ((LA(1)==LITERAL_catch)) {
				exceptionHandler();
			}
			else {
				break _loop99;
			}
			
		} while (true);
		}
		returnAST = exceptionSpec_AST;
	}
	
	public final void exceptionHandler() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST exceptionHandler_AST = null;
		
		match(LITERAL_catch);
		AST tmp92_AST = null;
		tmp92_AST = astFactory.create(LT(1));
		match(ARG_ACTION);
		AST tmp93_AST = null;
		tmp93_AST = astFactory.create(LT(1));
		match(ACTION);
		returnAST = exceptionHandler_AST;
	}
	
	public final void elementNoOptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST elementNoOptionSpec_AST = null;
		
		switch ( LA(1)) {
		case ACTION:
		{
			match(ACTION);
			elementNoOptionSpec_AST = (AST)currentAST.root;
			break;
		}
		case SEMPRED:
		{
			AST tmp95_AST = null;
			tmp95_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp95_AST);
			match(SEMPRED);
			elementNoOptionSpec_AST = (AST)currentAST.root;
			break;
		}
		case TREE_BEGIN:
		{
			tree();
			astFactory.addASTChild(currentAST, returnAST);
			elementNoOptionSpec_AST = (AST)currentAST.root;
			break;
		}
		default:
			if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==ASSIGN)) {
				id();
				AST tmp96_AST = null;
				tmp96_AST = astFactory.create(LT(1));
				match(ASSIGN);
				{
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
					id();
					AST tmp97_AST = null;
					tmp97_AST = astFactory.create(LT(1));
					match(COLON);
				}
				else if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (_tokenSet_3.member(LA(2)))) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				
				}
				{
				switch ( LA(1)) {
				case RULE_REF:
				{
					AST tmp98_AST = null;
					tmp98_AST = astFactory.create(LT(1));
					match(RULE_REF);
					{
					switch ( LA(1)) {
					case ARG_ACTION:
					{
						AST tmp99_AST = null;
						tmp99_AST = astFactory.create(LT(1));
						match(ARG_ACTION);
						break;
					}
					case STRING_LITERAL:
					case ACTION:
					case SEMI:
					case OR:
					case CHAR_LITERAL:
					case TOKEN_REF:
					case OPEN_ELEMENT_OPTION:
					case LPAREN:
					case RPAREN:
					case BANG:
					case LITERAL_exception:
					case RULE_REF:
					case NOT_OP:
					case SEMPRED:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					{
					switch ( LA(1)) {
					case BANG:
					{
						AST tmp100_AST = null;
						tmp100_AST = astFactory.create(LT(1));
						match(BANG);
						break;
					}
					case STRING_LITERAL:
					case ACTION:
					case SEMI:
					case OR:
					case CHAR_LITERAL:
					case TOKEN_REF:
					case OPEN_ELEMENT_OPTION:
					case LPAREN:
					case RPAREN:
					case LITERAL_exception:
					case RULE_REF:
					case NOT_OP:
					case SEMPRED:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				case TOKEN_REF:
				{
					AST tmp101_AST = null;
					tmp101_AST = astFactory.create(LT(1));
					match(TOKEN_REF);
					{
					switch ( LA(1)) {
					case ARG_ACTION:
					{
						AST tmp102_AST = null;
						tmp102_AST = astFactory.create(LT(1));
						match(ARG_ACTION);
						break;
					}
					case STRING_LITERAL:
					case ACTION:
					case SEMI:
					case OR:
					case CHAR_LITERAL:
					case TOKEN_REF:
					case OPEN_ELEMENT_OPTION:
					case LPAREN:
					case RPAREN:
					case LITERAL_exception:
					case RULE_REF:
					case NOT_OP:
					case SEMPRED:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
			}
			else if ((_tokenSet_4.member(LA(1))) && (_tokenSet_5.member(LA(2)))) {
				{
				if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
					id();
					match(COLON);
				}
				else if ((_tokenSet_4.member(LA(1))) && (_tokenSet_6.member(LA(2)))) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				
				}
				{
				switch ( LA(1)) {
				case RULE_REF:
				{
					AST tmp104_AST = null;
					tmp104_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp104_AST);
					match(RULE_REF);
					{
					switch ( LA(1)) {
					case ARG_ACTION:
					{
						match(ARG_ACTION);
						break;
					}
					case STRING_LITERAL:
					case ACTION:
					case SEMI:
					case OR:
					case CHAR_LITERAL:
					case TOKEN_REF:
					case OPEN_ELEMENT_OPTION:
					case LPAREN:
					case RPAREN:
					case BANG:
					case LITERAL_exception:
					case RULE_REF:
					case NOT_OP:
					case SEMPRED:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					{
					switch ( LA(1)) {
					case BANG:
					{
						match(BANG);
						break;
					}
					case STRING_LITERAL:
					case ACTION:
					case SEMI:
					case OR:
					case CHAR_LITERAL:
					case TOKEN_REF:
					case OPEN_ELEMENT_OPTION:
					case LPAREN:
					case RPAREN:
					case LITERAL_exception:
					case RULE_REF:
					case NOT_OP:
					case SEMPRED:
					case TREE_BEGIN:
					case WILDCARD:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				case NOT_OP:
				{
					AST tmp107_AST = null;
					tmp107_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp107_AST);
					match(NOT_OP);
					{
					switch ( LA(1)) {
					case CHAR_LITERAL:
					case TOKEN_REF:
					{
						notTerminal();
						astFactory.addASTChild(currentAST, returnAST);
						break;
					}
					case LPAREN:
					{
						ebnf();
						astFactory.addASTChild(currentAST, returnAST);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					break;
				}
				case LPAREN:
				{
					ebnf();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
					if ((LA(1)==STRING_LITERAL||LA(1)==CHAR_LITERAL||LA(1)==TOKEN_REF) && (LA(2)==RANGE)) {
						range();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else if ((_tokenSet_7.member(LA(1))) && (_tokenSet_8.member(LA(2)))) {
						terminal();
						astFactory.addASTChild(currentAST, returnAST);
					}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				elementNoOptionSpec_AST = (AST)currentAST.root;
			}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = elementNoOptionSpec_AST;
	}
	
	public final void elementOptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST elementOptionSpec_AST = null;
		
		AST tmp108_AST = null;
		tmp108_AST = astFactory.create(LT(1));
		match(OPEN_ELEMENT_OPTION);
		id();
		AST tmp109_AST = null;
		tmp109_AST = astFactory.create(LT(1));
		match(ASSIGN);
		optionValue();
		{
		_loop108:
		do {
			if ((LA(1)==SEMI)) {
				AST tmp110_AST = null;
				tmp110_AST = astFactory.create(LT(1));
				match(SEMI);
				id();
				AST tmp111_AST = null;
				tmp111_AST = astFactory.create(LT(1));
				match(ASSIGN);
				optionValue();
			}
			else {
				break _loop108;
			}
			
		} while (true);
		}
		AST tmp112_AST = null;
		tmp112_AST = astFactory.create(LT(1));
		match(CLOSE_ELEMENT_OPTION);
		returnAST = elementOptionSpec_AST;
	}
	
	public final void range() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST range_AST = null;
		
		switch ( LA(1)) {
		case CHAR_LITERAL:
		{
			AST tmp113_AST = null;
			tmp113_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp113_AST);
			match(CHAR_LITERAL);
			AST tmp114_AST = null;
			tmp114_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp114_AST);
			match(RANGE);
			AST tmp115_AST = null;
			tmp115_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp115_AST);
			match(CHAR_LITERAL);
			{
			switch ( LA(1)) {
			case BANG:
			{
				AST tmp116_AST = null;
				tmp116_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp116_AST);
				match(BANG);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			range_AST = (AST)currentAST.root;
			break;
		}
		case STRING_LITERAL:
		case TOKEN_REF:
		{
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				AST tmp117_AST = null;
				tmp117_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp117_AST);
				match(TOKEN_REF);
				break;
			}
			case STRING_LITERAL:
			{
				AST tmp118_AST = null;
				tmp118_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp118_AST);
				match(STRING_LITERAL);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp119_AST = null;
			tmp119_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp119_AST);
			match(RANGE);
			{
			switch ( LA(1)) {
			case TOKEN_REF:
			{
				AST tmp120_AST = null;
				tmp120_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp120_AST);
				match(TOKEN_REF);
				break;
			}
			case STRING_LITERAL:
			{
				AST tmp121_AST = null;
				tmp121_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp121_AST);
				match(STRING_LITERAL);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			ast_type_spec();
			astFactory.addASTChild(currentAST, returnAST);
			range_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = range_AST;
	}
	
	public final void terminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST terminal_AST = null;
		
		switch ( LA(1)) {
		case CHAR_LITERAL:
		{
			AST tmp122_AST = null;
			tmp122_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp122_AST);
			match(CHAR_LITERAL);
			{
			switch ( LA(1)) {
			case BANG:
			{
				AST tmp123_AST = null;
				tmp123_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp123_AST);
				match(BANG);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			terminal_AST = (AST)currentAST.root;
			break;
		}
		case TOKEN_REF:
		{
			AST tmp124_AST = null;
			tmp124_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp124_AST);
			match(TOKEN_REF);
			ast_type_spec();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case ARG_ACTION:
			{
				AST tmp125_AST = null;
				tmp125_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp125_AST);
				match(ARG_ACTION);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			terminal_AST = (AST)currentAST.root;
			break;
		}
		case STRING_LITERAL:
		{
			AST tmp126_AST = null;
			tmp126_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp126_AST);
			match(STRING_LITERAL);
			ast_type_spec();
			astFactory.addASTChild(currentAST, returnAST);
			terminal_AST = (AST)currentAST.root;
			break;
		}
		case WILDCARD:
		{
			AST tmp127_AST = null;
			tmp127_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp127_AST);
			match(WILDCARD);
			ast_type_spec();
			astFactory.addASTChild(currentAST, returnAST);
			terminal_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = terminal_AST;
	}
	
	public final void notTerminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST notTerminal_AST = null;
		
		switch ( LA(1)) {
		case CHAR_LITERAL:
		{
			AST tmp128_AST = null;
			tmp128_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp128_AST);
			match(CHAR_LITERAL);
			{
			switch ( LA(1)) {
			case BANG:
			{
				AST tmp129_AST = null;
				tmp129_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp129_AST);
				match(BANG);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			notTerminal_AST = (AST)currentAST.root;
			break;
		}
		case TOKEN_REF:
		{
			AST tmp130_AST = null;
			tmp130_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp130_AST);
			match(TOKEN_REF);
			ast_type_spec();
			astFactory.addASTChild(currentAST, returnAST);
			notTerminal_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = notTerminal_AST;
	}
	
	public final void ebnf() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ebnf_AST = null;
		AST aBlock_AST = null;
		
		AST tmp131_AST = null;
		tmp131_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp131_AST);
		match(LPAREN);
		{
		if ((LA(1)==OPTIONS)) {
			subruleOptionsSpec();
			match(COLON);
		}
		else if ((LA(1)==ACTION) && (LA(2)==COLON)) {
			match(ACTION);
			match(COLON);
		}
		else if ((_tokenSet_9.member(LA(1))) && (_tokenSet_10.member(LA(2)))) {
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		block();
		aBlock_AST = (AST)returnAST;
		astFactory.addASTChild(currentAST, returnAST);
		match(RPAREN);
		{
		switch ( LA(1)) {
		case STRING_LITERAL:
		case ACTION:
		case SEMI:
		case OR:
		case CHAR_LITERAL:
		case TOKEN_REF:
		case OPEN_ELEMENT_OPTION:
		case LPAREN:
		case RPAREN:
		case BANG:
		case LITERAL_exception:
		case RULE_REF:
		case NOT_OP:
		case SEMPRED:
		case TREE_BEGIN:
		case QUESTION:
		case STAR:
		case PLUS:
		case WILDCARD:
		{
			{
			switch ( LA(1)) {
			case QUESTION:
			{
				AST tmp136_AST = null;
				tmp136_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp136_AST);
				match(QUESTION);
				break;
			}
			case STAR:
			{
				AST tmp137_AST = null;
				tmp137_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp137_AST);
				match(STAR);
				break;
			}
			case PLUS:
			{
				AST tmp138_AST = null;
				tmp138_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp138_AST);
				match(PLUS);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case BANG:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case BANG:
			{
				match(BANG);
				break;
			}
			case STRING_LITERAL:
			case ACTION:
			case SEMI:
			case OR:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case OPEN_ELEMENT_OPTION:
			case LPAREN:
			case RPAREN:
			case LITERAL_exception:
			case RULE_REF:
			case NOT_OP:
			case SEMPRED:
			case TREE_BEGIN:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		case IMPLIES:
		{
			AST tmp140_AST = null;
			tmp140_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp140_AST);
			match(IMPLIES);
			if ( inputState.guessing==0 ) {
				ebnf_AST = (AST)currentAST.root;
				ebnf_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(tmp140_AST)));
				currentAST.root = ebnf_AST;
				currentAST.child = ebnf_AST!=null &&ebnf_AST.getFirstChild()!=null ?
					ebnf_AST.getFirstChild() : ebnf_AST;
				currentAST.advanceChildToEnd();
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		ebnf_AST = (AST)currentAST.root;
		returnAST = ebnf_AST;
	}
	
	public final void tree() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST tree_AST = null;
		
		AST tmp141_AST = null;
		tmp141_AST = astFactory.create(LT(1));
		match(TREE_BEGIN);
		rootNode();
		{
		int _cnt122=0;
		_loop122:
		do {
			if ((_tokenSet_2.member(LA(1)))) {
				element();
			}
			else {
				if ( _cnt122>=1 ) { break _loop122; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt122++;
		} while (true);
		}
		AST tmp142_AST = null;
		tmp142_AST = astFactory.create(LT(1));
		match(RPAREN);
		returnAST = tree_AST;
	}
	
	public final void rootNode() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rootNode_AST = null;
		
		{
		if ((LA(1)==TOKEN_REF||LA(1)==RULE_REF) && (LA(2)==COLON)) {
			id();
			AST tmp143_AST = null;
			tmp143_AST = astFactory.create(LT(1));
			match(COLON);
		}
		else if ((_tokenSet_7.member(LA(1))) && (_tokenSet_11.member(LA(2)))) {
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		terminal();
		returnAST = rootNode_AST;
	}
	
	public final void ast_type_spec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ast_type_spec_AST = null;
		
		{
		switch ( LA(1)) {
		case CARET:
		{
			AST tmp144_AST = null;
			tmp144_AST = astFactory.create(LT(1));
			match(CARET);
			break;
		}
		case BANG:
		{
			AST tmp145_AST = null;
			tmp145_AST = astFactory.create(LT(1));
			match(BANG);
			break;
		}
		case STRING_LITERAL:
		case ACTION:
		case SEMI:
		case OR:
		case CHAR_LITERAL:
		case TOKEN_REF:
		case OPEN_ELEMENT_OPTION:
		case LPAREN:
		case RPAREN:
		case ARG_ACTION:
		case LITERAL_exception:
		case RULE_REF:
		case NOT_OP:
		case SEMPRED:
		case TREE_BEGIN:
		case WILDCARD:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		returnAST = ast_type_spec_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"RULE",
		"ALTERNATIVE",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LTERAL",
		"INT",
		"OR",
		"CHAR_LITERAL",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"RULE_REF",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"RANGE",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 8826224903168L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 9891376857600L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 9139141270831872L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 9141444589912832L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 9033588154564864L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 15897118908941056L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 15896844031034112L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 9007199338627328L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 11393244403598080L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 9141375735956224L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 18012579280913152L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 11391044163732224L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	
	}
