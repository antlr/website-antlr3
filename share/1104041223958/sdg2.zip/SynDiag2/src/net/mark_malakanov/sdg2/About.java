package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Rectangle;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.Dimension;
import javax.swing.ActionMap;
import oracle.jdeveloper.layout.VerticalFlowLayout;
import oracle.jdeveloper.layout.XYLayout;
import oracle.jdeveloper.layout.XYConstraints;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

public class About extends JPanel  {
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private ActionMap actionMap1 = new ActionMap();
  private XYLayout xYLayout1 = new XYLayout();

  public About() {
    try {
      jbInit();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(xYLayout1);
    this.setBounds(new Rectangle(10, 10, 400, 300));
    this.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
    jLabel1.setText("Syntax Diagram Generator 2");
    jLabel1.setVerticalAlignment(SwingConstants.TOP);
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setFont(new Font("Tahoma", 1, 18));
    jLabel1.setSize(new Dimension(280, 22));
    jLabel1.setActionMap(actionMap1);
    jLabel2.setText("[The BSD License] (c) Mark Malakanov, 2004.");
    jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel2.setFont(new Font("Tahoma", 0, 14));
    jLabel3.setText("SDG2 based on SynDiag by Jia Zheng,");
    jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel4.setText(" [The \"BSD licence\"] Copyright (c) 2003 Jia Zheng.");
    jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel5.setText("All rights reserved.");
    jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel5.setFont(new Font("Tahoma", 0, 14));
    jLabel6.setText("All rights reserved.");
    jLabel6.setHorizontalAlignment(SwingConstants.CENTER);
    xYLayout1.setWidth(400);
    xYLayout1.setHeight(274);
    this.add(jLabel1, new XYConstraints(5, 60, 390, 20));
    this.add(jLabel2, new XYConstraints(5, 85, 390, 20));
    this.add(jLabel5, new XYConstraints(5, 110, 390, 15));
    this.add(jLabel3, new XYConstraints(5, 150, 390, 15));
    this.add(jLabel4, new XYConstraints(5, 170, 390, 15));
    this.add(jLabel6, new XYConstraints(5, 190, 390, 15));
  }
  
  
}