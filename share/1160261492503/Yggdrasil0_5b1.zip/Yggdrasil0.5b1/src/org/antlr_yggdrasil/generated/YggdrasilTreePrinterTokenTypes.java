// $ANTLR 2.7.6 (2005-12-22): "YggdrasilPrint.g" -> "YggdrasilTreePrinter.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
	package org.antlr_yggdrasil.generated;
	import org.antlr_yggdrasil.tool.*;
	import java.util.*;

public interface YggdrasilTreePrinterTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int OPTIONS = 4;
	int TOKENS = 5;
	int PARSER = 6;
	int ASSIGN_ATTRIBUTE = 7;
	int LABEL_ATTRIBUTE = 8;
	int LEXER = 9;
	int RULE = 10;
	int BLOCK = 11;
	int OPTIONAL = 12;
	int CLOSURE = 13;
	int POSITIVE_CLOSURE = 14;
	int SYNPRED = 15;
	int RANGE = 16;
	int CHAR_RANGE = 17;
	int EPSILON = 18;
	int ALT = 19;
	int EOR = 20;
	int EOB = 21;
	int EOA = 22;
	int CHARSET = 23;
	int SET = 24;
	int ID = 25;
	int LEXER_GRAMMAR = 26;
	int PARSER_GRAMMAR = 27;
	int TREE_GRAMMAR = 28;
	int COMBINED_GRAMMAR = 29;
	int SYN_SEMPRED = 30;
	int FRAGMENT = 31;
	int BANGEDUP = 32;
	int DOC_COMMENT = 33;
	int SEMI = 34;
	int LITERAL_header = 35;
	int LCURLY = 36;
	int RCURLY = 37;
	int LITERAL_lexer = 38;
	int LITERAL_tree = 39;
	int LITERAL_grammar = 40;
	int ATTRIBUTE_STMT = 41;
	int LITERAL_public = 42;
	int LITERAL_import = 43;
	int STRING_LITERAL = 44;
	int LITERAL_native = 45;
	int LITERAL_atomic = 46;
	int OPEN_ELEMENT_OPTION = 47;
	int COMMA = 48;
	int CLOSE_ELEMENT_OPTION = 49;
	int DOT_TEXT = 50;
	int LBRACKET = 51;
	int RBRACKET = 52;
	int ASSIGN = 53;
	int LITERAL_new = 54;
	int LITERAL_using = 55;
	int KEYWORD = 56;
	int INT = 57;
	int STAR = 58;
	int TOKEN_REF = 59;
	int LITERAL_protected = 60;
	int LITERAL_private = 61;
	int BANG = 62;
	int COLON = 63;
	int RULE_REF = 64;
	int ATTRIBUTE_COLON = 65;
	int LITERAL_throws = 66;
	int LITERAL_uses = 67;
	int LPAREN = 68;
	int OR = 69;
	int RPAREN = 70;
	int LITERAL_exception = 71;
	int LITERAL_catch = 72;
	int SEMPRED = 73;
	int ATTRIBUTE = 74;
	int ATTRIBUTE_GROUP = 75;
	int CARET = 76;
	int CURRENT_TREE = 77;
	int TREE_CONSTRUCTOR = 78;
	int NOT = 79;
	int TREE_BEGIN = 80;
	int QUESTION = 81;
	int PLUS = 82;
	int IMPLIES = 83;
	int WILDCARD = 84;
	int WS = 85;
	int COMMENT = 86;
	int SL_COMMENT = 87;
	int ML_COMMENT = 88;
	int ATTRIBUTE_PRED = 89;
	int ESC = 90;
	int DIGIT = 91;
	int XDIGIT = 92;
	int ACTION_STRING_LITERAL = 93;
	int ACTION_ESC = 94;
	int WS_LOOP = 95;
	int INTERNAL_RULE_REF = 96;
	int WS_OPT = 97;
	int SRC = 98;
	int INTERNAL_TEXT_REF = 99;
	int ARG_ACTION = 100;
}
