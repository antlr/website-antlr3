What is this about?
===================
The point of this sample is to show how to combine a custom TokenStream
implementation (TokenStreamRecorder) with the antlr stream multiplexing
facility (TokenStreamSelector) to parse interpolated expressions inside
double quoted strings:

	print "3*2-1: ${3*2-1}"

The sample actually implements a very simple interpreter and allows 
programs to be run interactively.

The Files
=========

si.g
----
The main grammar file, includes the parser and the main lexer, starting
reading here.

esi.g
-----
Includes the lexer for interpolated expressions.

TokenStreamRecorder.cs
----------------------
Custom TokenStream implementation that records tokens for later playback.

*.si
----
Sample "programs".

build.xml
---------
ANT build file.

How to build it
===============
An ant build file is provided for your convenience. Unfortunately you'll
still have to set some things up. The build.xml file assumes a build
environment like mine which you probably don't have. You have 2 options:

	* create a build.properties file in the same directory as the
	build.xml file and provide the path for you antlr installation:

		antlr.home=d:/antlr2.7.2

	* change the build.xml file directly to account for the changes in
	your build environment

The distributed version of the C# antlr runtime in the 2.7.2 distro had
some hidden bugs that prevented this sample to fully recognize syntax
errors. I've posted the diff files with the necessary changes to the
antlr group, the specific can be obtained by following this link[1].

Contacting the author
=====================
You can reach me at rodrigobamboo@acm.org.

Have fun!

[1] http://groups.yahoo.com/group/antlr-interest/message/9248


