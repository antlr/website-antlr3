// $ANTLR Yggdrasil 0.5b1 TestFilter.g 2006-10-04 13:50:35

import org.antlr_yggdrasil.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class TestFilter extends Lexer {
    public static final int SEPARATOR=5;
    public static final int EOF=-1;
    public static final int Tokens=7;
    public static final int CONTENT=4;
    public static final int NEWLINE=6;
    
    public TestFilter() {
 		factory = new TestFilterFactory();
    } 
    
    public TestFilter(CharStream input) {
        super(input);
        factory = new TestFilterFactory();
        ruleMemo = new HashMap[5+1];
     }
    public String getGrammarFileName() { return "TestFilter.g"; }


    // $ANTLR start CONTENT
    public void mCONTENT() throws RecognitionException {
        try {
            ruleNestingLevel++;
            type = CONTENT;
            start = getCharIndex();
            line = getLine();
            charPosition = getCharPositionInLine();
            channel = Token.DEFAULT_CHANNEL;
            // TestFilter.g:16:2: ( (~ ('\\r'|'\\n'))+ )
            // TestFilter.g:16:2: (~ ('\\r'|'\\n'))+
            {
            	// element at line 16, column 2

            	// TestFilter.g:16:2: (~ ('\\r'|'\\n'))+
            	int cnt1=0;
            	loop1:
            	do {
            	    int alt1=2;
            	    int LA1_0 = input.LA(1);
            	    if ( ((LA1_0>='\u0000' && LA1_0<='\t')||(LA1_0>='\u000B' && LA1_0<='\f')||(LA1_0>='\u000E' && LA1_0<='\uFFFE')) ) {
            	        alt1=1;
            	    }


            	    switch (alt1) {
            		case 1 :
            		    // TestFilter.g:16:4: ~ ('\\r'|'\\n')
            		    {
            		    	// element at line 16, column 19

            		    	if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFE') ) {
            		    		if (lost != 0) {
            		    			copyText(getCharIndex());
            		    			lost = 0;
            		    		}	input.consume();

            		    	failed=false;
            		    	}
            		    	else {
            		    		if (backtracking>0) {failed=true; return;}
            		    		MismatchedSetException mse =
            		    			new MismatchedSetException(null,input);
            		    		recover(mse);

            		    		throw mse;
            		    	}


            		    	// END element at line 16, column 19

            		    }
            		    break;

            		default :
            		    if ( cnt1 >= 1 ) break loop1;
            		    if (backtracking>0) {failed=true; return;}
            	            EarlyExitException eee =
            	                new EarlyExitException(1, input);
            	            throw eee;
            	    }
            	    cnt1++;
            	} while (true);


            	// END element at line 16, column 2

            }


            if ( backtracking==0 ) {

                      if ( token==null && ruleNestingLevel==1 ) {
                          emit(type,line,charPosition,channel,start,getCharIndex()-1);
                      }

                      
            }    }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end CONTENT


    // $ANTLR start SEPARATOR
    public void mSEPARATOR() throws RecognitionException {
        try {
            ruleNestingLevel++;
            // TestFilter.g:23:2: ( \"/****\" ! ( '*' )* ( (' '|'\\t'))* \"TEST\" (~ ('*'|'\\r'|'\\n'))+ ( '*' )+ '/' !)
            // TestFilter.g:23:2: \"/****\" ! ( '*' )* ( (' '|'\\t'))* \"TEST\" (~ ('*'|'\\r'|'\\n'))+ ( '*' )+ '/' !
            {
            	// element at line 23, column 2

            	if (start == getCharIndex()) {
            		String s = "/****";
            		start += s.length();
            	}
            	else {
            		String s = "/****";
            		int length = s.length();
            		if (lost == 0) {
            			if (copying) {
            				copyText(getCharIndex() - length);
            				copyStart = getCharIndex();
            			}
            			else	// mark start of copied text
            				outset = copyStream.last;		
            		}
            		lost += length;
            		copying = true;
            	};
            	match("/****"); if (failed) return;


            	// END element at line 23, column 2
            	// element at line 23, column 11

            	// TestFilter.g:23:11: ( '*' )*
            	loop2:
            	do {
            	    int alt2=2;
            	    int LA2_0 = input.LA(1);
            	    if ( (LA2_0=='*') ) {
            	        alt2=1;
            	    }


            	    switch (alt2) {
            		case 1 :
            		    // TestFilter.g:23:12: '*'
            		    {
            		    	// element at line 23, column 12

            		    	loseChar();
            		    	match('*'); if (failed) return;

            		    	// END element at line 23, column 12

            		    }
            		    break;

            		default :
            		    break loop2;
            	    }
            	} while (true);


            	// END element at line 23, column 11
            	// element at line 23, column 19

            	// TestFilter.g:23:20: ( (' '|'\\t'))*
            	loop3:
            	do {
            	    int alt3=2;
            	    int LA3_0 = input.LA(1);
            	    if ( (LA3_0=='\t'||LA3_0==' ') ) {
            	        alt3=1;
            	    }


            	    switch (alt3) {
            		case 1 :
            		    // TestFilter.g:23:20: (' '|'\\t')
            		    {
            		    	// element at line 23, column 20

            		    	if ( input.LA(1)=='\t'||input.LA(1)==' ' ) {
            		    		loseChar();	input.consume();

            		    	failed=false;
            		    	}
            		    	else {
            		    		if (backtracking>0) {failed=true; return;}
            		    		MismatchedSetException mse =
            		    			new MismatchedSetException(null,input);
            		    		recover(mse);

            		    		throw mse;
            		    	}


            		    	// END element at line 23, column 20

            		    }
            		    break;

            		default :
            		    break loop3;
            	    }
            	} while (true);


            	// END element at line 23, column 19
            	// element at line 23, column 34

            	if (lost != 0) {
            		copyText(getCharIndex());
            		lost = 0;
            	}
            	match("TEST"); if (failed) return;
            		

            	// END element at line 23, column 34
            	// element at line 24, column 2

            	// TestFilter.g:24:2: (~ ('*'|'\\r'|'\\n'))+
            	int cnt4=0;
            	loop4:
            	do {
            	    int alt4=2;
            	    int LA4_0 = input.LA(1);
            	    if ( ((LA4_0>='\u0000' && LA4_0<='\t')||(LA4_0>='\u000B' && LA4_0<='\f')||(LA4_0>='\u000E' && LA4_0<=')')||(LA4_0>='+' && LA4_0<='\uFFFE')) ) {
            	        alt4=1;
            	    }


            	    switch (alt4) {
            		case 1 :
            		    // TestFilter.g:24:4: ~ ('*'|'\\r'|'\\n')
            		    {
            		    	// element at line 25, column 2

            		    	if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<=')')||(input.LA(1)>='+' && input.LA(1)<='\uFFFE') ) {
            		    		if (lost != 0) {
            		    			copyText(getCharIndex());
            		    			lost = 0;
            		    		}	input.consume();

            		    	failed=false;
            		    	}
            		    	else {
            		    		if (backtracking>0) {failed=true; return;}
            		    		MismatchedSetException mse =
            		    			new MismatchedSetException(null,input);
            		    		recover(mse);

            		    		throw mse;
            		    	}


            		    	// END element at line 25, column 2

            		    }
            		    break;

            		default :
            		    if ( cnt4 >= 1 ) break loop4;
            		    if (backtracking>0) {failed=true; return;}
            	            EarlyExitException eee =
            	                new EarlyExitException(4, input);
            	            throw eee;
            	    }
            	    cnt4++;
            	} while (true);


            	// END element at line 24, column 2
            	// element at line 26, column 2

            	// TestFilter.g:26:2: ( '*' )+
            	int cnt5=0;
            	loop5:
            	do {
            	    int alt5=2;
            	    int LA5_0 = input.LA(1);
            	    if ( (LA5_0=='*') ) {
            	        alt5=1;
            	    }


            	    switch (alt5) {
            		case 1 :
            		    // TestFilter.g:26:3: '*'
            		    {
            		    	// element at line 26, column 3

            		    	loseChar();
            		    	match('*'); if (failed) return;

            		    	// END element at line 26, column 3

            		    }
            		    break;

            		default :
            		    if ( cnt5 >= 1 ) break loop5;
            		    if (backtracking>0) {failed=true; return;}
            	            EarlyExitException eee =
            	                new EarlyExitException(5, input);
            	            throw eee;
            	    }
            	    cnt5++;
            	} while (true);


            	// END element at line 26, column 2
            	// element at line 26, column 10

            	loseChar();
            	match('/'); if (failed) return;

            	// END element at line 26, column 10

            }

        }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end SEPARATOR


    // $ANTLR start NEWLINE
    public void mNEWLINE() throws RecognitionException {
        try {
            ruleNestingLevel++;
            type = NEWLINE;
            start = getCharIndex();
            line = getLine();
            charPosition = getCharPositionInLine();
            channel = Token.DEFAULT_CHANNEL;
            // TestFilter.g:31:2: ( ( '\\r' )? '\\n' ( ( SEPARATOR )=> SEPARATOR | ) )
            // TestFilter.g:31:2: ( '\\r' )? '\\n' ( ( SEPARATOR )=> SEPARATOR | )
            {
            	// element at line 31, column 2

            	// TestFilter.g:31:2: ( '\\r' )?
            	int alt6=2;
            	int LA6_0 = input.LA(1);
            	if ( (LA6_0=='\r') ) {
            	    alt6=1;
            	}
            	switch (alt6) {
            	    case 1 :
            	        // TestFilter.g:31:3: '\\r'
            	        {
            	        	// element at line 31, column 3

            	        	if (lost != 0) {
            	        		copyText(getCharIndex());
            	        		lost = 0;
            	        	}
            	        	match('\r'); if (failed) return;

            	        	// END element at line 31, column 3

            	        }
            	        break;

            	}


            	// END element at line 31, column 2
            	// element at line 31, column 10

            	if (lost != 0) {
            		copyText(getCharIndex());
            		lost = 0;
            	}
            	match('\n'); if (failed) return;

            	// END element at line 31, column 10
            	// element at line 32, column 2

            	// TestFilter.g:32:2: ( ( SEPARATOR )=> SEPARATOR | )
            	int alt7=2;
            	int LA7_0 = input.LA(1);
            	if ( (LA7_0=='/') ) {
            	    alt7=1;
            	}
            	else {
            	    alt7=2;}
            	switch (alt7) {
            	    case 1 :
            	        // TestFilter.g:32:4: ( SEPARATOR )=> SEPARATOR
            	        {
            	        	// element at line 32, column 18

            	        	mSEPARATOR(); if (failed) return;

            	        	// END element at line 32, column 18
            	        	// element at line 32, column 57

            	        	if ( backtracking==0 ) {
            	        	  type = SEPARATOR;
            	        	}

            	        	// END element at line 32, column 57

            	        }
            	        break;
            	    case 2 :
            	        // TestFilter.g:34:2: 
            	        {
            	        }
            	        break;

            	}


            	// END element at line 32, column 2

            }


            if ( backtracking==0 ) {

                      if ( token==null && ruleNestingLevel==1 ) {
                          emit(type,line,charPosition,channel,start,getCharIndex()-1);
                      }

                      
            }    }
        finally {
            ruleNestingLevel--;
        }
    }
    // $ANTLR end NEWLINE

    public void mTokens() throws RecognitionException {
        // TestFilter.g:1:10: ( CONTENT | NEWLINE )
        int alt8=2;
        int LA8_0 = input.LA(1);
        if ( ((LA8_0>='\u0000' && LA8_0<='\t')||(LA8_0>='\u000B' && LA8_0<='\f')||(LA8_0>='\u000E' && LA8_0<='\uFFFE')) ) {
            alt8=1;
        }
        else if ( (LA8_0=='\n'||LA8_0=='\r') ) {
            alt8=2;
        }
        else {
            if (backtracking>0) {failed=true; return;}
            NoViableAltException nvae =
                new NoViableAltException("1:1: Tokens : ( CONTENT | NEWLINE );", 8, 0, input);

            throw nvae;
        }
        switch (alt8) {
            case 1 :
                // TestFilter.g:1:10: CONTENT
                {
                	// element at line 1, column 10

                	mCONTENT(); if (failed) return;

                	// END element at line 1, column 10

                }
                break;
            case 2 :
                // TestFilter.g:1:18: NEWLINE
                {
                	// element at line 1, column 18

                	mNEWLINE(); if (failed) return;

                	// END element at line 1, column 18

                }
                break;

        }

    }

    // $ANTLR start synpred1
    public void synpred1_fragment() throws RecognitionException {   
        // TestFilter.g:32:4: ( SEPARATOR )
        // TestFilter.g:32:5: SEPARATOR
        {
        	// element at line 32, column 5

        	mSEPARATOR(); if (failed) return;

        	// END element at line 32, column 5

        }
    }
    // $ANTLR end synpred1


 

}