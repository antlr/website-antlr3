package org.antlr.java.crossref;



import java.io.IOException;

/** Represents the definition of a field (class or instance).
 */
public class FieldVariable extends Variable {
    /**
     * Constructor for FieldVariable
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public FieldVariable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /**
     * Method dump
     */
    public void dump() {
        tab();
        if ( type!=null ) {
            System.out.println("FieldVariable:dump " + "field "+type.getFullyQualifiedName()+" "+getName());
        }
        else {
            System.out.println("FieldVariable:dump " + "field "+getName());
        }
    }
	/** XML dump()
     *
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		if ( type !=null ) 
			xmlWriter.xmlOpen("FieldVariable name=\"" + getName() + "\"" 
					  + " type=\"" + type.getFullyQualifiedName() + "\"");
		else
			xmlWriter.xmlOpen("FieldVariable name=\"" + getName() + "\""); 
		if(loc != null)
			loc.xmlSerialize(xmlWriter);

		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
			
		xmlWriter.xmlClose("FieldVariable");
	}
	    
}
