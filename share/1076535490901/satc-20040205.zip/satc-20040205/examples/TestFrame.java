/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */
 
package examples;

import java.io.File;
import java.net.URL;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;

import satc.SettingsReader;
import satc.Syntax;
import examples.not_related_to_satc.BasicTestFrame;


/**
 * A frame with several documents opened in a tabbed pane,
 * each document with a different syntax.
 * You can open your own files using the "Open" button.
 */
public class TestFrame extends BasicTestFrame { 

	private static String path;
	
    /**
     * Creates the frame.
     */
    public TestFrame() {
        super();
		if( Syntax.getReparseOnEdit() == true) {
        	astTree = new JTree();
			leftTabbedPane.removeAll();
			leftTabbedPane.add( new JScrollPane( astTree), "AST");
		}
        loadFile( new File( path + "Test.java"));
		Syntax.setFileFilters( fileChooser);
        if( Syntax.getReparseOnEdit() == false) {
  //          loadFile( new File( path + "Test.e"));
  //          loadFile( new File( path + "Test.xml"));
  //          loadFile( new File( path + "Test.g"));
//            loadFile( new File( path + "Sample.ag"));
//			loadFile( new File( path + "Test.v"));
//            loadFile( new File( path + "Test.vhdl"));
        }
        
        Syntax.filesLoaded = true;
                       
        log.info("Files loaded successfully");
        
    }
    
	private static Handler handler;
    /**
     * Starts the application.
     */
    public static void main(String[] args) {
        if( args.length > 0) {
            if( args[0].equals( "-lexer")) {
                Syntax.setReparseOnEdit( false);
            }
        }
//begin JDK1.4
		Logger logger = Logger.getLogger("");
		handler = new ConsoleHandler();
		handler.setFormatter( new DefaultFormatter());
		Handler[] handlers = logger.getHandlers();
		for (int i = 0; i < handlers.length; i++)
			logger.removeHandler(handlers[i]);
		logger.addHandler(handler);	
		
        log.setLevel(Level.CONFIG);
		Logger.getLogger("satc.SettingsReader").setLevel(Level.CONFIG);
//		Logger.getLogger("satc.swing.ParserDocumentListener").setLevel(Level.FINE);
//		Logger.getLogger("satc.swing.LexerDocumentListener").setLevel(Level.FINE);
//end JDK1.4
		        
		URL url = ClassLoader.getSystemResource( "examples\\TestFrame.class");
		path = (new File( url.getPath())).getParent() + "\\files\\";
		log.config("reading settings file ...");
        SettingsReader settings = new SettingsReader();
        TestFrame frame = new TestFrame();
		frame.setVisible(true);
//begin JDK1.4       
// 		Logger.getLogger("satc.TokenFilter").setLevel(Level.FINER);
//		Logger.getLogger("satc.antlr.DocAST").setLevel(Level.FINE);
//		Logger.getLogger("satc.antlr.DocASTFactory").setLevel(Level.FINEST);
//		Logger.getLogger("satc.swing.LexerDocumentListener").setLevel(Level.FINER);
//		Logger.getLogger("satc.swing.ParserDocumentListener").setLevel(Level.FINE);
//		Logger.getLogger("satc.swing.SyntaxView").setLevel(Level.FINE);
//end JDK1.4		
     }
    
    /**
     *  Opens a file and load it in a new tab of the tabbed pane.
     */
    public void loadFile( File f) {
    	log.info("loading file " + f + " ...");
        JTextArea textArea = getNewTextArea();
        try {
            Syntax.read( textArea, f);
        } catch( Exception e) {
            e.printStackTrace();
        }
        addTextArea( textArea, f.getName());
    }

    /**
     * Updates the AST for the current file.
     */
/*    public void updateAST( JTextArea textArea) { 
    	Document doc = textArea.getDocument();
    	ParserDocumentListener pdl = (ParserDocumentListener) doc.getProperty("parserDocumentListener");
    	if( pdl == null) {
     		return;
    	}
    	pdl.updateTree( doc);
    	updateTextArea( textArea);
    }
       
    /**
     * Current textArea has changed; updates the view.
     */
    public void updateTextArea( JTextArea textArea) {
/*    	if( textArea.getDocument().getProperty("parser") instanceof PlainTextParser
    													 || Syntax.getReparseOnEdit()) {
    		updateASTAction.setEnabled( false);
    	} else {
    		updateASTAction.setEnabled( true);
    	}
*/
		if (Syntax.getReparseOnEdit()) {
			astTree = (JTree) textArea.getDocument().getProperty("AST");  
			leftTabbedPane.removeAll();
			leftTabbedPane.add( new JScrollPane( astTree), "AST");
		}
    }    

	private JTree astTree;

	private static Logger log = Logger.getLogger("examples.TestFrame");

}
