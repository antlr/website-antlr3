/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 * @author lgc
 * A TypeInfo describes a datatype:  its fields and their types by name.  Note that TypeInfo fields
 * are generally Strings:  this makes it possible to support forward references during type construction.
 *
 */
public class TypeInfo {
	private TypeMap typemap = null;
	private String name;														// this class
	private String baseType;
	String parent;																	// parent class
	ArrayList<String> templateTypes;
	HashMap<String, ArrayList<String>> templateVars;
	private HashMap<String, String> localFields = new HashMap<String, String>();	// local fields--this declaration
	private HashMap<String, String> fields = new HashMap<String, String>();			// local and parent fields--all fields for this type
	private HashMap<String, String> externalFields = null;							// inferred field names and types--compute and set-only fields
	private HashMap<String, String> translation = new HashMap<String, String>();
	private HashSet<String> ancestors = null;
	private boolean isNative = false;
	private boolean atomic = false;
	private boolean arrayed = false;

	/**
	 * 
	 */
	public TypeInfo(String type_) {
		parent = "Object";
		name = type_;
		setFields(new HashMap());
	}
	
	public TypeInfo(String type_, TypeInfo base) {
		name = type_;
		if (base != null) {
			parent = base.name;
			localFields = base.localFields;
			setFields(base.getFields());
		}
		else
			parent = "Object";
		
	}

	public void addField(String type_, String name_) {
		getFields().put(name_, type_);
		translation.put(name_, translate(name_));
	}
	
	public void addLocalField(String type_, String name_) {
		if ((templateVars != null) && (templateVars.get(type_)) != null) {
			ArrayList<String> map = templateVars.get(type_);
			map.add(name_);
		}
		getFields().put(name_, type_);
		localFields.put(name_, type_);
		translation.put(name_, translate(name_));
	}
	
	public void addLocalField(String type_, String name_, String trans) {
		getFields().put(name_, type_);
		localFields.put(name_, type_);
		translation.put(name_, trans);
	}
	
	public void addExternalField(String type_, String name_) {
		if (externalFields == null) {
			externalFields = new HashMap<String, String>();
		}
		externalFields.put(name_, type_);		
		translation.put(name_, translate(name_));
	}
	
	public String getParent() {
		return parent;
	}
	
	public void setParent(String parent_) {
		parent = parent_;
		if (ancestors != null)
			ancestors.add(parent_);
	}
	
	public String getTypeOf(String key) {
		String type = null;
		
		type = getFields().get(key);

		if (type == null) {
			if (externalFields == null) {
				externalFields = new HashMap<String, String>();
			}
			else
				type = externalFields.get(key);
		}
			
		return type;
	}
	
	public boolean verify(String type_, String name_) {
		String test = getFields().get(name_);
		if (test == null) {
			if (externalFields == null) {
				externalFields = new HashMap<String, String>();
			}
			else
				test = externalFields.get(name_);
				
			if (test == null) {
				externalFields.put(name_, type_);
				return false;
			}
			else				// recurring name--assumed valid
				return test == type_;
		}
		else
			return test == type_;
	}

	/**
	 * @param localFields The localFields to set.
	 */
	public void setLocalFields(HashMap<String, String> localFields) {
		this.localFields = localFields;
	}

	/**
	 * @return Returns the localFields.
	 */
	public HashMap<String, String> getLocalFields() {
		return localFields;
	}

	/**
	 * @param externalFields The externalFields to set.
	 */
	public void setExternalFields(HashMap<String, String> externalFields) {
		this.externalFields = externalFields;
	}

	/**
	 * @return Returns the externalFields.
	 */
	public HashMap<String, String> getExternalFields() {
		return externalFields;
	}

	/**
	 * @param isaMap The isaMap to set.
	 */
	public void setAncestors(HashSet<String> isaSet) {
		this.ancestors = isaSet;
	}

	/**
	 * @return Returns the isaMap.
	 */
	public HashSet getAncestors() {
		return ancestors;
	}
	
	public boolean isa(String type) {
		if (name.equals(type))
			return true;
		
		if (ancestors == null)
			; // TODO:  Throw exception here
		
		return ancestors.contains(type);
	}

	/**
	 * @param typeName The typeName to set.
	 */
	public void setName(String typeName) {
		this.name = typeName;
	}

	/**
	 * @return Returns the typeName.
	 */
	public String getName() {
		return name;
	}

	public void setTypemap(TypeMap typemap) {
		this.typemap = typemap;
	}

	public TypeMap getTypemap() {
		return typemap;
	}

	public void setFields(HashMap<String, String> fields) {
		this.fields = fields;
	}

	public HashMap<String, String> getFields() {
		return fields;
	}
	
	public boolean areTypesValid() {
		if (typemap == null)
			return false;
		
		Iterator<String> iter = localFields.values().iterator();
		while (iter.hasNext()) {
			if (typemap.getInfo(iter.next()) == null)
				return false;
		}

		return true;
	}

	public void setTranslation(HashMap<String, String> translation) {
		this.translation = translation;
	}

	public HashMap<String, String> getTranslation() {
		return translation;
	}
	
	private String translate(String s) {
		String t = s.substring(0, 1).toUpperCase();
		t += s.substring(1);
		return t;
	}

	public void setAtomic(boolean atomic) {
		this.atomic = atomic;
	}

	public boolean isAtomic() {
		return atomic;
	}

	public void setNative(boolean isNative) {
		this.isNative = isNative;
	}

	public boolean isNative() {
		return isNative;
	}

	public void setArrayed(boolean arrayed) {
		this.arrayed = arrayed;
	}

	public boolean isArrayed() {
		return arrayed;
	}

	public void setBaseType(String baseType) {
		this.baseType = baseType;
	}

	public String getBaseType() {
		return baseType;
	}

	public String getFieldType(String name) {
		return fields.get(name);
	}
	
	public void addTemplateType(String type) throws TypeException {
		if (templateVars.get(type) != null) {
			throw new TypeException();
		}
			
		templateTypes.add(type);
		templateVars.put(type, new ArrayList<String>());
	}
	
	public TypeInfo clone() {
		TypeInfo copy = new TypeInfo(null);
		
		copy.typemap = typemap;
		copy.name = name;
		copy.baseType = baseType;
		copy.parent = parent;
		copy.templateTypes = new ArrayList<String>(templateTypes);
		copy.templateVars = new HashMap<String,ArrayList<String>>(templateVars);
		copy.localFields = new HashMap<String, String>(this.localFields);
		copy.fields = new HashMap<String, String>(fields);
		if (externalFields != null)
			copy.externalFields = new HashMap<String, String>(externalFields);							// inferred field names and types--compute and set-only fields
		copy.translation = translation;
		copy.ancestors = ancestors;
		copy.isNative = isNative;
		copy.arrayed = arrayed;
		
		return copy;
	}
	
	public void resolveTypeTemplates(ArrayList<String> types) {
		Iterator<String> resolvers = types.iterator();
		Iterator<String> iter = templateTypes.iterator();
		
		while (resolvers.hasNext()) {
			String type = resolvers.next();
			String proxy = iter.next();
			ArrayList<String> vars = templateVars.get(proxy);
			Iterator<String> items = vars.iterator();
			while (items.hasNext()) {
				resolve(items.next(), type);
			}
		}
	}
	
	protected void resolve(String var, String type) {
		fields.put(var, type);
		if (localFields.get(var) != null)
			localFields.put(var, type);
		else
			externalFields.put(var, type);
	}
	
	public void makeTemplate() {
		templateVars = new HashMap<String, ArrayList<String>>();
		templateTypes = new ArrayList<String>();
	}
}
