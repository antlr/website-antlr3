// $ANTLR : "mlcLexer.g" -> "MLCLexer.java"$
 package satc.lang; 
public interface MLCTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int MLC_STAR = 4;
	int MLC_CLOSE = 5;
	int MLC_WORD = 6;
	int MLC_WS = 7;
}
