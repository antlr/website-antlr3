// $ANTLR 2.7.2: "action.g" -> "StringTemplateLanguageParser.cs"$

/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using Antlr.StringTemplate;
using System.Collections;

namespace Antlr.StringTemplate.Language
{
	// Generate the header common to all output files.
	using System;
	
	using TokenBuffer              = antlr.TokenBuffer;
	using TokenStreamException     = antlr.TokenStreamException;
	using TokenStreamIOException   = antlr.TokenStreamIOException;
	using ANTLRException           = antlr.ANTLRException;
	using LLkParser = antlr.LLkParser;
	using Token                    = antlr.Token;
	using TokenStream              = antlr.TokenStream;
	using RecognitionException     = antlr.RecognitionException;
	using NoViableAltException     = antlr.NoViableAltException;
	using MismatchedTokenException = antlr.MismatchedTokenException;
	using SemanticException        = antlr.SemanticException;
	using ParserSharedInputState   = antlr.ParserSharedInputState;
	using BitSet                   = antlr.collections.impl.BitSet;
	using AST                      = antlr.collections.AST;
	using ASTPair                  = antlr.ASTPair;
	using ASTFactory               = antlr.ASTFactory;
	using ASTArray                 = antlr.collections.impl.ASTArray;
	
	public 	class StringTemplateLanguageParser : antlr.LLkParser
	{
		public const int EOF = 1;
		public const int NULL_TREE_LOOKAHEAD = 3;
		public const int APPLY = 4;
		public const int ARGS = 5;
		public const int INCLUDE = 6;
		public const int CONDITIONAL = 7;
		public const int VALUE = 8;
		public const int TEMPLATE = 9;
		public const int SEMI = 10;
		public const int LPAREN = 11;
		public const int RPAREN = 12;
		public const int LITERAL_separator = 13;
		public const int ASSIGN = 14;
		public const int NOT = 15;
		public const int PLUS = 16;
		public const int COLON = 17;
		public const int COMMA = 18;
		public const int ID = 19;
		public const int ANONYMOUS_TEMPLATE = 20;
		public const int STRING = 21;
		public const int INT = 22;
		public const int DOT = 23;
		public const int ESC_CHAR = 24;
		public const int WS = 25;
		
		
    protected StringTemplate self = null;

    public StringTemplateLanguageParser(TokenStream lexer, StringTemplate self) : this(lexer, 2) {
        this.self = self;
    }
		
		protected void initialize()
		{
			tokenNames = tokenNames_;
			initializeFactory();
		}
		
		
		protected StringTemplateLanguageParser(TokenBuffer tokenBuf, int k) : base(tokenBuf, k)
		{
			initialize();
		}
		
		public StringTemplateLanguageParser(TokenBuffer tokenBuf) : this(tokenBuf,2)
		{
		}
		
		protected StringTemplateLanguageParser(TokenStream lexer, int k) : base(lexer,k)
		{
			initialize();
		}
		
		public StringTemplateLanguageParser(TokenStream lexer) : this(lexer,2)
		{
		}
		
		public StringTemplateLanguageParser(ParserSharedInputState state) : base(state,2)
		{
			initialize();
		}
		
	public Hashtable  action() //throws RecognitionException, TokenStreamException
{
		Hashtable opts=null;
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST action_AST = null;
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case LPAREN:
			case ID:
			case STRING:
			case INT:
			{
				templatesExpr();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				{
					switch ( LA(1) )
					{
					case SEMI:
					{
						match(SEMI);
						opts=optionList();
						if (0 == inputState.guessing)
						{
							astFactory.addASTChild(currentAST, (AST)returnAST);
						}
						break;
					}
					case EOF:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					 }
				}
				action_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			case CONDITIONAL:
			{
				Antlr.StringTemplate.Language.StringTemplateAST tmp2_AST = null;
				tmp2_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, (AST)tmp2_AST);
				match(CONDITIONAL);
				match(LPAREN);
				ifCondition();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				match(RPAREN);
				action_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			 }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_0_);
			}
			else
			{
				throw;
			}
		}
		returnAST = action_AST;
		return opts;
	}
	
	public void templatesExpr() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST templatesExpr_AST = null;
		Token  c = null;
		Antlr.StringTemplate.Language.StringTemplateAST c_AST = null;
		
		try {      // for error handling
			expr();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==COLON))
					{
						c = LT(1);
						c_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(c);
						astFactory.makeASTRoot(currentAST, (AST)c_AST);
						match(COLON);
						if (0==inputState.guessing)
						{
							c_AST.setType(APPLY);
						}
						template();
						if (0 == inputState.guessing)
						{
							astFactory.addASTChild(currentAST, (AST)returnAST);
						}
						{    // ( ... )*
							for (;;)
							{
								if ((LA(1)==COMMA))
								{
									match(COMMA);
									template();
									if (0 == inputState.guessing)
									{
										astFactory.addASTChild(currentAST, (AST)returnAST);
									}
								}
								else
								{
									goto _loop15_breakloop;
								}
								
							}
_loop15_breakloop:							;
						}    // ( ... )*
					}
					else
					{
						goto _loop16_breakloop;
					}
					
				}
_loop16_breakloop:				;
			}    // ( ... )*
			templatesExpr_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_1_);
			}
			else
			{
				throw;
			}
		}
		returnAST = templatesExpr_AST;
	}
	
	public Hashtable  optionList() //throws RecognitionException, TokenStreamException
{
		Hashtable opts=new Hashtable();
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST optionList_AST = null;
		Antlr.StringTemplate.Language.StringTemplateAST e_AST = null;
		
		try {      // for error handling
			match(LITERAL_separator);
			Antlr.StringTemplate.Language.StringTemplateAST tmp7_AST = null;
			tmp7_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			match(ASSIGN);
			expr();
			if (0 == inputState.guessing)
			{
				e_AST = (Antlr.StringTemplate.Language.StringTemplateAST)returnAST;
			}
			if (0==inputState.guessing)
			{
				opts["separator"] = e_AST;
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_0_);
			}
			else
			{
				throw;
			}
		}
		returnAST = optionList_AST;
		return opts;
	}
	
	public void ifCondition() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST ifCondition_AST = null;
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case LPAREN:
			case ID:
			case STRING:
			case INT:
			{
				ifAtom();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				ifCondition_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			case NOT:
			{
				Antlr.StringTemplate.Language.StringTemplateAST tmp8_AST = null;
				tmp8_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, (AST)tmp8_AST);
				match(NOT);
				ifAtom();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				ifCondition_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			 }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_2_);
			}
			else
			{
				throw;
			}
		}
		returnAST = ifCondition_AST;
	}
	
	public void expr() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST expr_AST = null;
		
		try {      // for error handling
			atom();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==PLUS))
					{
						Antlr.StringTemplate.Language.StringTemplateAST tmp9_AST = null;
						tmp9_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, (AST)tmp9_AST);
						match(PLUS);
						atom();
						if (0 == inputState.guessing)
						{
							astFactory.addASTChild(currentAST, (AST)returnAST);
						}
					}
					else
					{
						goto _loop8_breakloop;
					}
					
				}
_loop8_breakloop:				;
			}    // ( ... )*
			expr_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_3_);
			}
			else
			{
				throw;
			}
		}
		returnAST = expr_AST;
	}
	
	public void ifAtom() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST ifAtom_AST = null;
		
		try {      // for error handling
			expr();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			ifAtom_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_2_);
			}
			else
			{
				throw;
			}
		}
		returnAST = ifAtom_AST;
	}
	
	public void atom() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST atom_AST = null;
		Token  eval = null;
		Antlr.StringTemplate.Language.StringTemplateAST eval_AST = null;
		
		try {      // for error handling
			if ((LA(1)==ID||LA(1)==STRING||LA(1)==INT) && (tokenSet_4_.member(LA(2))))
			{
				attribute();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				atom_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
			}
			else {
				bool synPredMatched11 = false;
				if (((LA(1)==ID) && (LA(2)==LPAREN)))
				{
					int _m11 = mark();
					synPredMatched11 = true;
					inputState.guessing++;
					try {
						{
							templateInclude();
						}
					}
					catch (RecognitionException)
					{
						synPredMatched11 = false;
					}
					rewind(_m11);
					inputState.guessing--;
				}
				if ( synPredMatched11 )
				{
					templateInclude();
					if (0 == inputState.guessing)
					{
						astFactory.addASTChild(currentAST, (AST)returnAST);
					}
					atom_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				}
				else if ((LA(1)==LPAREN)) {
					eval = LT(1);
					eval_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(eval);
					astFactory.makeASTRoot(currentAST, (AST)eval_AST);
					match(LPAREN);
					templatesExpr();
					if (0 == inputState.guessing)
					{
						astFactory.addASTChild(currentAST, (AST)returnAST);
					}
					match(RPAREN);
					if (0==inputState.guessing)
					{
						eval_AST.setType(VALUE);
					}
					atom_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				}
				else
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
			}
			catch (RecognitionException ex)
			{
				if (0 == inputState.guessing)
				{
					reportError(ex);
					consume();
					consumeUntil(tokenSet_5_);
				}
				else
				{
					throw;
				}
			}
			returnAST = atom_AST;
		}
		
	public void attribute() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST attribute_AST = null;
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case STRING:
			{
				Antlr.StringTemplate.Language.StringTemplateAST tmp11_AST = null;
				tmp11_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, (AST)tmp11_AST);
				match(STRING);
				attribute_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			case INT:
			{
				Antlr.StringTemplate.Language.StringTemplateAST tmp12_AST = null;
				tmp12_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, (AST)tmp12_AST);
				match(INT);
				attribute_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				break;
			}
			default:
				if ((LA(1)==ID) && (tokenSet_5_.member(LA(2))))
				{
					Antlr.StringTemplate.Language.StringTemplateAST tmp13_AST = null;
					tmp13_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, (AST)tmp13_AST);
					match(ID);
					attribute_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				}
				else if ((LA(1)==ID) && (LA(2)==DOT)) {
					objPropertyRef();
					if (0 == inputState.guessing)
					{
						astFactory.addASTChild(currentAST, (AST)returnAST);
					}
					attribute_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				}
			else
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			break; }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_5_);
			}
			else
			{
				throw;
			}
		}
		returnAST = attribute_AST;
	}
	
	public void templateInclude() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST templateInclude_AST = null;
		
		try {      // for error handling
			{
				Antlr.StringTemplate.Language.StringTemplateAST tmp14_AST = null;
				tmp14_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, (AST)tmp14_AST);
				match(ID);
				argList();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
			}
			if (0==inputState.guessing)
			{
				templateInclude_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				templateInclude_AST = (Antlr.StringTemplate.Language.StringTemplateAST)astFactory.make( (new ASTArray(2)).add((AST)(Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(INCLUDE,"include")).add((AST)templateInclude_AST));
				currentAST.root = templateInclude_AST;
				if ( (null != templateInclude_AST) && (null != templateInclude_AST.getFirstChild()) )
					currentAST.child = templateInclude_AST.getFirstChild();
				else
					currentAST.child = templateInclude_AST;
				currentAST.advanceChildToEnd();
			}
			templateInclude_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_5_);
			}
			else
			{
				throw;
			}
		}
		returnAST = templateInclude_AST;
	}
	
	public void template() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST template_AST = null;
		
		try {      // for error handling
			{
				switch ( LA(1) )
				{
				case ID:
				{
					namedTemplate();
					if (0 == inputState.guessing)
					{
						astFactory.addASTChild(currentAST, (AST)returnAST);
					}
					break;
				}
				case ANONYMOUS_TEMPLATE:
				{
					anonymousTemplate();
					if (0 == inputState.guessing)
					{
						astFactory.addASTChild(currentAST, (AST)returnAST);
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				 }
			}
			if (0==inputState.guessing)
			{
				template_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				template_AST = (Antlr.StringTemplate.Language.StringTemplateAST)astFactory.make( (new ASTArray(2)).add((AST)(Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(TEMPLATE)).add((AST)template_AST));
				currentAST.root = template_AST;
				if ( (null != template_AST) && (null != template_AST.getFirstChild()) )
					currentAST.child = template_AST.getFirstChild();
				else
					currentAST.child = template_AST;
				currentAST.advanceChildToEnd();
			}
			template_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_3_);
			}
			else
			{
				throw;
			}
		}
		returnAST = template_AST;
	}
	
	public void nonAlternatingTemplateExpr() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST nonAlternatingTemplateExpr_AST = null;
		Token  c = null;
		Antlr.StringTemplate.Language.StringTemplateAST c_AST = null;
		
		try {      // for error handling
			expr();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==COLON))
					{
						c = LT(1);
						c_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(c);
						astFactory.makeASTRoot(currentAST, (AST)c_AST);
						match(COLON);
						if (0==inputState.guessing)
						{
							c_AST.setType(APPLY);
						}
						template();
						if (0 == inputState.guessing)
						{
							astFactory.addASTChild(currentAST, (AST)returnAST);
						}
					}
					else
					{
						goto _loop19_breakloop;
					}
					
				}
_loop19_breakloop:				;
			}    // ( ... )*
			nonAlternatingTemplateExpr_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_6_);
			}
			else
			{
				throw;
			}
		}
		returnAST = nonAlternatingTemplateExpr_AST;
	}
	
	public void namedTemplate() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST namedTemplate_AST = null;
		
		try {      // for error handling
			Antlr.StringTemplate.Language.StringTemplateAST tmp15_AST = null;
			tmp15_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, (AST)tmp15_AST);
			match(ID);
			argList();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			namedTemplate_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_3_);
			}
			else
			{
				throw;
			}
		}
		returnAST = namedTemplate_AST;
	}
	
	public void anonymousTemplate() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST anonymousTemplate_AST = null;
		Token  t = null;
		Antlr.StringTemplate.Language.StringTemplateAST t_AST = null;
		
		try {      // for error handling
			t = LT(1);
			t_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(t);
			astFactory.addASTChild(currentAST, (AST)t_AST);
			match(ANONYMOUS_TEMPLATE);
			if (0==inputState.guessing)
			{
				
				StringTemplate anonymous = new StringTemplate(self.Group,t.getText());
				t_AST.StringTemplate = anonymous;
				
			}
			anonymousTemplate_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_3_);
			}
			else
			{
				throw;
			}
		}
		returnAST = anonymousTemplate_AST;
	}
	
	public void argList() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST argList_AST = null;
		
		try {      // for error handling
			if ((LA(1)==LPAREN) && (LA(2)==RPAREN))
			{
				match(LPAREN);
				match(RPAREN);
				if (0==inputState.guessing)
				{
					argList_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
					argList_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(ARGS,"ARGS");
					currentAST.root = argList_AST;
					if ( (null != argList_AST) && (null != argList_AST.getFirstChild()) )
						currentAST.child = argList_AST.getFirstChild();
					else
						currentAST.child = argList_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==LPAREN) && (LA(2)==ID)) {
				match(LPAREN);
				argumentAssignment();
				if (0 == inputState.guessing)
				{
					astFactory.addASTChild(currentAST, (AST)returnAST);
				}
				{    // ( ... )*
					for (;;)
					{
						if ((LA(1)==COMMA))
						{
							match(COMMA);
							argumentAssignment();
							if (0 == inputState.guessing)
							{
								astFactory.addASTChild(currentAST, (AST)returnAST);
							}
						}
						else
						{
							goto _loop33_breakloop;
						}
						
					}
_loop33_breakloop:					;
				}    // ( ... )*
				match(RPAREN);
				if (0==inputState.guessing)
				{
					argList_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
					argList_AST = (Antlr.StringTemplate.Language.StringTemplateAST)astFactory.make( (new ASTArray(2)).add((AST)(Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(ARGS,"ARGS")).add((AST)argList_AST));
					currentAST.root = argList_AST;
					if ( (null != argList_AST) && (null != argList_AST.getFirstChild()) )
						currentAST.child = argList_AST.getFirstChild();
					else
						currentAST.child = argList_AST;
					currentAST.advanceChildToEnd();
				}
				argList_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
			}
			else
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_5_);
			}
			else
			{
				throw;
			}
		}
		returnAST = argList_AST;
	}
	
	public void objPropertyRef() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST objPropertyRef_AST = null;
		
		try {      // for error handling
			Antlr.StringTemplate.Language.StringTemplateAST tmp21_AST = null;
			tmp21_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, (AST)tmp21_AST);
			match(ID);
			{ // ( ... )+
			int _cnt30=0;
			for (;;)
			{
				if ((LA(1)==DOT))
				{
					Antlr.StringTemplate.Language.StringTemplateAST tmp22_AST = null;
					tmp22_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, (AST)tmp22_AST);
					match(DOT);
					Antlr.StringTemplate.Language.StringTemplateAST tmp23_AST = null;
					tmp23_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, (AST)tmp23_AST);
					match(ID);
				}
				else
				{
					if (_cnt30 >= 1) { goto _loop30_breakloop; } else { throw new NoViableAltException(LT(1), getFilename());; }
				}
				
				_cnt30++;
			}
_loop30_breakloop:			;
			}    // ( ... )+
			objPropertyRef_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_5_);
			}
			else
			{
				throw;
			}
		}
		returnAST = objPropertyRef_AST;
	}
	
/** Match (foo)() and (foo + ".terse")(); TJP turns off since it
    breaks encapsulation
 */
	public void indirectTemplate() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST indirectTemplate_AST = null;
		Antlr.StringTemplate.Language.StringTemplateAST e_AST = null;
		Antlr.StringTemplate.Language.StringTemplateAST args_AST = null;
		
		try {      // for error handling
			Antlr.StringTemplate.Language.StringTemplateAST tmp24_AST = null;
			tmp24_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			match(LPAREN);
			expr();
			if (0 == inputState.guessing)
			{
				e_AST = (Antlr.StringTemplate.Language.StringTemplateAST)returnAST;
			}
			Antlr.StringTemplate.Language.StringTemplateAST tmp25_AST = null;
			tmp25_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			match(RPAREN);
			argList();
			if (0 == inputState.guessing)
			{
				args_AST = (Antlr.StringTemplate.Language.StringTemplateAST)returnAST;
			}
			if (0==inputState.guessing)
			{
				indirectTemplate_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
				indirectTemplate_AST = (Antlr.StringTemplate.Language.StringTemplateAST)astFactory.make( (new ASTArray(3)).add((AST)(Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(VALUE,"value")).add((AST)e_AST).add((AST)args_AST));
				currentAST.root = indirectTemplate_AST;
				if ( (null != indirectTemplate_AST) && (null != indirectTemplate_AST.getFirstChild()) )
					currentAST.child = indirectTemplate_AST.getFirstChild();
				else
					currentAST.child = indirectTemplate_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_0_);
			}
			else
			{
				throw;
			}
		}
		returnAST = indirectTemplate_AST;
	}
	
	public void argumentAssignment() //throws RecognitionException, TokenStreamException
{
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		Antlr.StringTemplate.Language.StringTemplateAST argumentAssignment_AST = null;
		
		try {      // for error handling
			Antlr.StringTemplate.Language.StringTemplateAST tmp26_AST = null;
			tmp26_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, (AST)tmp26_AST);
			match(ID);
			Antlr.StringTemplate.Language.StringTemplateAST tmp27_AST = null;
			tmp27_AST = (Antlr.StringTemplate.Language.StringTemplateAST) astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, (AST)tmp27_AST);
			match(ASSIGN);
			nonAlternatingTemplateExpr();
			if (0 == inputState.guessing)
			{
				astFactory.addASTChild(currentAST, (AST)returnAST);
			}
			argumentAssignment_AST = (Antlr.StringTemplate.Language.StringTemplateAST)currentAST.root;
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_6_);
			}
			else
			{
				throw;
			}
		}
		returnAST = argumentAssignment_AST;
	}
	
	public new Antlr.StringTemplate.Language.StringTemplateAST getAST()
	{
		return (Antlr.StringTemplate.Language.StringTemplateAST) returnAST;
	}
	
	private void initializeFactory()
	{
		if (astFactory == null)
		{
			astFactory = new ASTFactory("Antlr.StringTemplate.Language.StringTemplateAST");
		}
		initializeASTFactory( astFactory );
	}
	static public void initializeASTFactory( ASTFactory factory )
	{
		factory.setMaxNodeType(25);
	}
	
	public static readonly string[] tokenNames_ = new string[] {
		@"""<0>""",
		@"""EOF""",
		@"""<2>""",
		@"""NULL_TREE_LOOKAHEAD""",
		@"""APPLY""",
		@"""ARGS""",
		@"""INCLUDE""",
		@"""if""",
		@"""VALUE""",
		@"""TEMPLATE""",
		@"""SEMI""",
		@"""LPAREN""",
		@"""RPAREN""",
		@"""separator""",
		@"""ASSIGN""",
		@"""NOT""",
		@"""PLUS""",
		@"""COLON""",
		@"""COMMA""",
		@"""ID""",
		@"""ANONYMOUS_TEMPLATE""",
		@"""STRING""",
		@"""INT""",
		@"""DOT""",
		@"""ESC_CHAR""",
		@"""WS"""
	};
	
	private static long[] mk_tokenSet_0_()
	{
		long[] data = { 2L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_0_ = new BitSet(mk_tokenSet_0_());
	private static long[] mk_tokenSet_1_()
	{
		long[] data = { 5122L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_1_ = new BitSet(mk_tokenSet_1_());
	private static long[] mk_tokenSet_2_()
	{
		long[] data = { 4096L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_2_ = new BitSet(mk_tokenSet_2_());
	private static long[] mk_tokenSet_3_()
	{
		long[] data = { 398338L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_3_ = new BitSet(mk_tokenSet_3_());
	private static long[] mk_tokenSet_4_()
	{
		long[] data = { 8852482L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_4_ = new BitSet(mk_tokenSet_4_());
	private static long[] mk_tokenSet_5_()
	{
		long[] data = { 463874L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_5_ = new BitSet(mk_tokenSet_5_());
	private static long[] mk_tokenSet_6_()
	{
		long[] data = { 266240L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_6_ = new BitSet(mk_tokenSet_6_());
	
}
}
