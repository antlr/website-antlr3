/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "CkASTNodeBase.hpp"
#include <iostream>

//! Default constructor
CkASTNodeBase::CkASTNodeBase() : CommonAST()
{
    LineNr = 0;
    IgnoreScope = false;
    ResultType = CkDataType::Undefined;
}

//! Construct from token
CkASTNodeBase::CkASTNodeBase( ANTLR_USE_NAMESPACE(antlr)RefToken t ) : CommonAST( t )
{
    LineNr = 0;
    IgnoreScope = false;
    ResultType = CkDataType::Undefined;
}

//! Copy constructor
CkASTNodeBase::CkASTNodeBase( const CkASTNodeBase& other ) : CommonAST( other )
{
    LineNr = other.LineNr;
    IgnoreScope = other.IgnoreScope;
    ResultType = other.ResultType;
}

/*!
  Destroys the object
*/
CkASTNodeBase::~CkASTNodeBase()
{
}

//! Clone this object
/*!
 * \return Pointer to the new object.
 */
ANTLR_USE_NAMESPACE(antlr)RefAST CkASTNodeBase::clone( ) const
{
    return new CkASTNodeBase( *this );
}

//! Initialize with default values.
/*!
 * This function is only used internally by antlr.
 */
void CkASTNodeBase::initialize(int t, const ANTLR_USE_NAMESPACE(std)string& txt)
{
    CommonAST::initialize(t, txt);
}

//! Initialize from other.
/*!
 * This function is only used internally by antlr.
 */
void CkASTNodeBase::initialize(ANTLR_USE_NAMESPACE(antlr)RefAST t)
{
    CommonAST::initialize(t);
}

//! Initialize from token.
/*!
 * This function is only used internally by antlr.
 */
void CkASTNodeBase::initialize(ANTLR_USE_NAMESPACE(antlr)RefToken tok)
{
    CommonAST::initialize(tok);
    LineNr = tok->getLine();
}

#ifdef ANTLR_SUPPORT_XML
//! Initialize from file stream.
/*!
 * This function is only used internally by antlr.
 */
CkASTNodeBase::void initialize( ANTLR_USE_NAMESPACE(std)istream& in )
{
    CommonAST::initialize(in);
}
#endif

//! Factory function used by antlr to create CkASTNodeBase objects.
/*!
 * \return Pointer to a uninizialized CkASTNodeBase object.
 */
ANTLR_USE_NAMESPACE(antlr)RefAST CkASTNodeBase::factory( )
{
    ANTLR_USE_NAMESPACE(antlr)RefAST ret =
        static_cast<ANTLR_USE_NAMESPACE(antlr)RefAST>(RefCkASTNodeBase(new CkASTNodeBase));
    return ret;
}

//! Set the result type of this node from some other datatype
/*!
 * \param type Return type of this node is set to this type.
 */
void CkASTNodeBase::setResultType( const CkDataType &type )
{
    ResultType = type;
}
