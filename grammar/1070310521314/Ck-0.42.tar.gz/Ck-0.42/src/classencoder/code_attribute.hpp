/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef CODEATTRIBUTE_HPP
#define CODEATTRIBUTE_HPP

#include <fstream>
#include "attribute_info.hpp"
#include "bytecode.hpp"

namespace ClassEncoder
{

class ConstantPool;

//! A code attribute
/*!
 * This class represents a code attribute used by the method_info class as defined by the SUN documentation: http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#1546
 * It is responsible for holding the code for one method and information about this code such as the maximum number of locals and the maximum stack size.
 */
class code_attribute : public attribute_info
{
public:
    code_attribute( ConstantPool *pool );
    virtual ~code_attribute();

    virtual void write( std::ofstream &stream );
    virtual unsigned int size();
    //! Get the bytecode object
    /*!
     * This function returns a pointer to the bytecode object. This object is used to manipulate the code for this code_attribute.
     * \return Pointer to the ByteCode object.
     */
    ByteCode *code() { return Code; }

    //! Add a local variable
    /*!
     * A single local variable can hold a value of type boolean, byte, char, short, int, float, reference,
     * or returnAddress. A pair of local variables can hold a value of type long or double.
     *
     * Local variables are addressed by indexing. The index of the first local variable is zero.
     * An integer is be considered to be an index into the local variable array if and only if that
     * integer is between zero and one less than the size of the local variable array.
     * \return The variable index.
     * Note: The JVM variable index is one less than the number of locals since indexing starts at 0.
     */
    unsigned int addLocal() { return max_locals++; }

private:
    //! Default constructor
    /*!
     * Should never be used and is therefore private.
     */
    code_attribute() {}

private:
    ConstantPool *ConstantPoolEntries;
    ByteCode *Code;
    u2 max_locals;
};

} // end of namespace
#endif // CODEATTRIBUTE_HPP
