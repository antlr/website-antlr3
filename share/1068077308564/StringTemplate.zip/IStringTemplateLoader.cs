using System;

namespace Antlr.StringTemplate {
	/// <summary>
	/// Summary description for IStringTemplateLoader.
	/// </summary>
	public interface IStringTemplateLoader {
		/// <summary>
		/// Derive the template name from the location.
		/// </summary>
		/// <param name="location">The template location.</param>
		/// <returns>The template name.</returns>
		String DeriveTemplateNameFromLocation(String location);

		/// <summary>
		/// Derive the location from the template name.
		/// </summary>
		/// <param name="templateName">The template name.</param>
		/// <returns>The template location.</returns>
		String DeriveLocationFromTemplateName(String templateName);

		/// <summary>
		/// Load a template
		/// </summary>
		/// <param name="name">The template name.</param>
		/// <param name="location">The location to load the template from.</param>
		String LoadTemplate(String name, String location); 

		String Base { get; set; }
	}
}
