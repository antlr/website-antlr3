// $ANTLR 2.7.2: "VerilogParser.g" -> "VerilogParser.java"$

package satc.lang; 

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;
import satc.antlr.DocParser;

public class VerilogParser extends DocParser       implements VerilogTokenTypes
 {

protected VerilogParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public VerilogParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected VerilogParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public VerilogParser(TokenStream lexer) {
  this(lexer,2);
}

public VerilogParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void start() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST start_AST = null;
		
		try {      // for error handling
			{
			_loop3:
			do {
				switch ( LA(1)) {
				case LITERAL_module:
				case NIL:
				case NIL2:
				{
					unit();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case NIL3:
				{
					directive();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
				{
					break _loop3;
				}
				}
			} while (true);
			}
			match(Token.EOF_TYPE);
			if ( inputState.guessing==0 ) {
				start_AST = (AST)currentAST.root;
				start_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(START,"START")).add(start_AST)) ;
				currentAST.root = start_AST;
				currentAST.child = start_AST!=null &&start_AST.getFirstChild()!=null ?
					start_AST.getFirstChild() : start_AST;
				currentAST.advanceChildToEnd();
			}
			start_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = start_AST;
	}
	
	public final void unit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST unit_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_module:
			{
				module();
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			case NIL:
			{
				macromodule();
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			case NIL2:
			{
				udp();
				astFactory.addASTChild(currentAST, returnAST);
				unit_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = unit_AST;
	}
	
	public final void directive() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST directive_AST = null;
		
		try {      // for error handling
			AST tmp2_AST = null;
			tmp2_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp2_AST);
			match(NIL3);
			directive_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = directive_AST;
	}
	
	public final void module() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST module_AST = null;
		
		try {      // for error handling
			AST tmp3_AST = null;
			tmp3_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp3_AST);
			match(LITERAL_module);
			identifier();
			astFactory.addASTChild(currentAST, returnAST);
			portList();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			{
			_loop7:
			do {
				if ((_tokenSet_2.member(LA(1)))) {
					element();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop7;
				}
				
			} while (true);
			}
			match(LITERAL_endmodule);
			module_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = module_AST;
	}
	
	public final void macromodule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST macromodule_AST = null;
		
		try {      // for error handling
			AST tmp6_AST = null;
			tmp6_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp6_AST);
			match(NIL);
			macromodule_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = macromodule_AST;
	}
	
	public final void udp() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST udp_AST = null;
		
		try {      // for error handling
			AST tmp7_AST = null;
			tmp7_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp7_AST);
			match(NIL2);
			udp_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = udp_AST;
	}
	
	public final void identifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST identifier_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case IDENTIFIER:
			{
				AST tmp8_AST = null;
				tmp8_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp8_AST);
				match(IDENTIFIER);
				identifier_AST = (AST)currentAST.root;
				break;
			}
			case ESCAPED_IDENTIFIER:
			{
				AST tmp9_AST = null;
				tmp9_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp9_AST);
				match(ESCAPED_IDENTIFIER);
				identifier_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = identifier_AST;
	}
	
	public final void portList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST portList_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				match(LPAREN);
				identifier();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop11:
				do {
					if ((LA(1)==COMMA)) {
						match(COMMA);
						identifier();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop11;
					}
					
				} while (true);
				}
				match(RPAREN);
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				portList_AST = (AST)currentAST.root;
				portList_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PORT_LIST,"PORT_LIST")).add(portList_AST)) ;
				currentAST.root = portList_AST;
				currentAST.child = portList_AST!=null &&portList_AST.getFirstChild()!=null ?
					portList_AST.getFirstChild() : portList_AST;
				currentAST.advanceChildToEnd();
			}
			portList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = portList_AST;
	}
	
	public final void element() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST element_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_parameter:
			{
				parameterDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_input:
			{
				inputDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_output:
			{
				outputDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_inout:
			{
				inoutDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL6:
			{
				netDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL7:
			{
				regDeclaration();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL4:
			{
				continuousAssign();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			case NIL5:
			{
				alwaysStatement();
				astFactory.addASTChild(currentAST, returnAST);
				element_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = element_AST;
	}
	
	public final void parameterDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp13_AST = null;
			tmp13_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp13_AST);
			match(LITERAL_parameter);
			{
			switch ( LA(1)) {
			case LBRACK:
			{
				range();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			parameterAssignmentList();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			parameterDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = parameterDeclaration_AST;
	}
	
	public final void inputDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inputDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp15_AST = null;
			tmp15_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp15_AST);
			match(LITERAL_input);
			{
			switch ( LA(1)) {
			case LBRACK:
			{
				range();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			inputList();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			inputDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = inputDeclaration_AST;
	}
	
	public final void outputDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST outputDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp17_AST = null;
			tmp17_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp17_AST);
			match(LITERAL_output);
			{
			switch ( LA(1)) {
			case LBRACK:
			{
				range();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			outputList();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			outputDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = outputDeclaration_AST;
	}
	
	public final void inoutDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inoutDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp19_AST = null;
			tmp19_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp19_AST);
			match(LITERAL_inout);
			{
			switch ( LA(1)) {
			case LBRACK:
			{
				range();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			inoutList();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			inoutDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = inoutDeclaration_AST;
	}
	
	public final void netDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST netDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp21_AST = null;
			tmp21_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp21_AST);
			match(NIL6);
			netDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = netDeclaration_AST;
	}
	
	public final void regDeclaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST regDeclaration_AST = null;
		
		try {      // for error handling
			AST tmp22_AST = null;
			tmp22_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp22_AST);
			match(NIL7);
			regDeclaration_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = regDeclaration_AST;
	}
	
	public final void continuousAssign() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST continuousAssign_AST = null;
		
		try {      // for error handling
			AST tmp23_AST = null;
			tmp23_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp23_AST);
			match(NIL4);
			continuousAssign_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = continuousAssign_AST;
	}
	
	public final void alwaysStatement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alwaysStatement_AST = null;
		
		try {      // for error handling
			AST tmp24_AST = null;
			tmp24_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp24_AST);
			match(NIL5);
			alwaysStatement_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = alwaysStatement_AST;
	}
	
	public final void range() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST range_AST = null;
		
		try {      // for error handling
			match(LBRACK);
			simpleExpression();
			astFactory.addASTChild(currentAST, returnAST);
			match(COLON);
			simpleExpression();
			astFactory.addASTChild(currentAST, returnAST);
			match(RBRACK);
			if ( inputState.guessing==0 ) {
				range_AST = (AST)currentAST.root;
				range_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(RANGE,"RANGE")).add(range_AST)) ;
				currentAST.root = range_AST;
				currentAST.child = range_AST!=null &&range_AST.getFirstChild()!=null ?
					range_AST.getFirstChild() : range_AST;
				currentAST.advanceChildToEnd();
			}
			range_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = range_AST;
	}
	
	public final void parameterAssignmentList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterAssignmentList_AST = null;
		
		try {      // for error handling
			parameterAssignment();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop19:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					parameterAssignment();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop19;
				}
				
			} while (true);
			}
			parameterAssignmentList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = parameterAssignmentList_AST;
	}
	
	public final void parameterAssignment() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameterAssignment_AST = null;
		
		try {      // for error handling
			identifier();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp29_AST = null;
			tmp29_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp29_AST);
			match(ASSIGN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			parameterAssignment_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = parameterAssignment_AST;
	}
	
	public final void expression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expression_AST = null;
		
		try {      // for error handling
			identifier();
			astFactory.addASTChild(currentAST, returnAST);
			expression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = expression_AST;
	}
	
	public final void inputList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inputList_AST = null;
		AST id1_AST = null;
		AST id2_AST = null;
		
		try {      // for error handling
			identifier();
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop29:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					identifier();
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop29;
				}
				
			} while (true);
			}
			inputList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = inputList_AST;
	}
	
	public final void outputList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST outputList_AST = null;
		AST id1_AST = null;
		AST id2_AST = null;
		
		try {      // for error handling
			identifier();
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop32:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					identifier();
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop32;
				}
				
			} while (true);
			}
			outputList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = outputList_AST;
	}
	
	public final void inoutList() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inoutList_AST = null;
		AST id1_AST = null;
		AST id2_AST = null;
		
		try {      // for error handling
			identifier();
			id1_AST = (AST)returnAST;
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop35:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					identifier();
					id2_AST = (AST)returnAST;
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop35;
				}
				
			} while (true);
			}
			inoutList_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = inoutList_AST;
	}
	
	public final void simpleExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simpleExpression_AST = null;
		
		try {      // for error handling
			shiftExpression();
			astFactory.addASTChild(currentAST, returnAST);
			simpleExpression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = simpleExpression_AST;
	}
	
	public final void shiftExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST shiftExpression_AST = null;
		
		try {      // for error handling
			additiveExpression();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop42:
			do {
				if ((LA(1)==SR||LA(1)==SL)) {
					{
					switch ( LA(1)) {
					case SL:
					{
						AST tmp33_AST = null;
						tmp33_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp33_AST);
						match(SL);
						break;
					}
					case SR:
					{
						AST tmp34_AST = null;
						tmp34_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp34_AST);
						match(SR);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					additiveExpression();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop42;
				}
				
			} while (true);
			}
			shiftExpression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = shiftExpression_AST;
	}
	
	public final void additiveExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST additiveExpression_AST = null;
		
		try {      // for error handling
			multiplicativeExpression();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop46:
			do {
				if ((LA(1)==MINUS||LA(1)==PLUS)) {
					{
					switch ( LA(1)) {
					case PLUS:
					{
						AST tmp35_AST = null;
						tmp35_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp35_AST);
						match(PLUS);
						break;
					}
					case MINUS:
					{
						AST tmp36_AST = null;
						tmp36_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp36_AST);
						match(MINUS);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					multiplicativeExpression();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop46;
				}
				
			} while (true);
			}
			additiveExpression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		returnAST = additiveExpression_AST;
	}
	
	public final void multiplicativeExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multiplicativeExpression_AST = null;
		
		try {      // for error handling
			unaryExpression();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop50:
			do {
				if (((LA(1) >= STAR && LA(1) <= MOD))) {
					{
					switch ( LA(1)) {
					case STAR:
					{
						AST tmp37_AST = null;
						tmp37_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp37_AST);
						match(STAR);
						break;
					}
					case DIV:
					{
						AST tmp38_AST = null;
						tmp38_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp38_AST);
						match(DIV);
						break;
					}
					case MOD:
					{
						AST tmp39_AST = null;
						tmp39_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp39_AST);
						match(MOD);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					unaryExpression();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop50;
				}
				
			} while (true);
			}
			multiplicativeExpression_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_10);
			} else {
			  throw ex;
			}
		}
		returnAST = multiplicativeExpression_AST;
	}
	
	public final void unaryExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST unaryExpression_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case MINUS:
			{
				AST tmp40_AST = null;
				tmp40_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp40_AST);
				match(MINUS);
				if ( inputState.guessing==0 ) {
					tmp40_AST.setType(UNARY_MINUS);
				}
				primaryExpression();
				astFactory.addASTChild(currentAST, returnAST);
				unaryExpression_AST = (AST)currentAST.root;
				break;
			}
			case PLUS:
			{
				AST tmp41_AST = null;
				tmp41_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp41_AST);
				match(PLUS);
				if ( inputState.guessing==0 ) {
					tmp41_AST.setType(UNARY_PLUS);
				}
				primaryExpression();
				astFactory.addASTChild(currentAST, returnAST);
				unaryExpression_AST = (AST)currentAST.root;
				break;
			}
			case LPAREN:
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			case NUMBER:
			{
				primaryExpression();
				astFactory.addASTChild(currentAST, returnAST);
				unaryExpression_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		returnAST = unaryExpression_AST;
	}
	
	public final void primaryExpression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST primaryExpression_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case IDENTIFIER:
			case ESCAPED_IDENTIFIER:
			{
				identifier();
				astFactory.addASTChild(currentAST, returnAST);
				primaryExpression_AST = (AST)currentAST.root;
				break;
			}
			case NUMBER:
			{
				AST tmp42_AST = null;
				tmp42_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp42_AST);
				match(NUMBER);
				primaryExpression_AST = (AST)currentAST.root;
				break;
			}
			case LPAREN:
			{
				AST tmp43_AST = null;
				tmp43_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp43_AST);
				match(LPAREN);
				simpleExpression();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp44_AST = null;
				tmp44_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp44_AST);
				match(RPAREN);
				primaryExpression_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		returnAST = primaryExpression_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"MLC_STAR",
		"MLC_CLOSE",
		"MLC_WORD",
		"MLC_WS",
		"\"module\"",
		"\"macromodule\"",
		"\"begin\"",
		"\"end\"",
		"\"initial\"",
		"\"always\"",
		"\"endmodule\"",
		"\"case\"",
		"\"casex\"",
		"\"casez\"",
		"\"endcase\"",
		"\"default\"",
		"\"if\"",
		"\"then\"",
		"\"else\"",
		"\"forever\"",
		"\"repeat\"",
		"\"while\"",
		"\"for\"",
		"\"wait\"",
		"\"posedge\"",
		"\"negedge\"",
		"\"parameter\"",
		"\"input\"",
		"\"output\"",
		"\"inout\"",
		"\"trireg\"",
		"\"wire\"",
		"\"tri\"",
		"\"wand\"",
		"\"triand\"",
		"\"wor\"",
		"\"trior\"",
		"\"scalared\"",
		"\"vectored\"",
		"\"reg\"",
		"\"time\"",
		"\"integer\"",
		"\"real\"",
		"\"event\"",
		"\"assign\"",
		"\"defparam\"",
		"\"small\"",
		"\"medium\"",
		"\"large\"",
		"\"and\"",
		"\"nand\"",
		"\"or\"",
		"\"nor\"",
		"\"xor\"",
		"\"xnor\"",
		"\"buf\"",
		"\"not\"",
		"\"supply0\"",
		"\"strong0\"",
		"\"pull0\"",
		"\"weak0\"",
		"\"highz0\"",
		"\"supply1\"",
		"\"strong1\"",
		"\"pull1\"",
		"\"weak1\"",
		"\"highz1\"",
		"\"buffif0\"",
		"\"buffif1\"",
		"\"notif0\"",
		"\"notif1\"",
		"\"tranif0\"",
		"\"rtranif0\"",
		"\"tranif1\"",
		"\"rtranif1\"",
		"\"pulldown\"",
		"\"pullup\"",
		"\"nmos\"",
		"\"rnmos\"",
		"\"pmos\"",
		"\"rpmos\"",
		"\"cmos\"",
		"\"rcmos\"",
		"\"tran\"",
		"\"rtran\"",
		"\"disable\"",
		"\"deassign\"",
		"\"force\"",
		"\"release\"",
		"\"fork\"",
		"\"join\"",
		"\"function\"",
		"\"endfunction\"",
		"\"task\"",
		"\"endtask\"",
		"\"table\"",
		"\"endtable\"",
		"\"primitive\"",
		"\"endprimitive\"",
		"\"edge\"",
		"\"specparam\"",
		"\"specify\"",
		"\"endspecify\"",
		"TAB",
		"BLANK",
		"NEWLINE",
		"SL_COMMENT",
		"MLC_OPEN",
		"AT",
		"COLON",
		"COMMA",
		"DOT",
		"ASSIGN",
		"MINUS",
		"LBRACK",
		"RBRACK",
		"LCURLY",
		"RCURLY",
		"LPAREN",
		"RPAREN",
		"POUND",
		"QUESTION",
		"SEMI",
		"PLUS",
		"LNOT",
		"BNOT",
		"BAND",
		"RNAND",
		"BOR",
		"RNOR",
		"BXOR",
		"RXNOR",
		"STAR",
		"DIV",
		"MOD",
		"EQUAL",
		"NOT_EQ",
		"NOT_EQ_CASE",
		"EQ_CASE",
		"LAND",
		"LOR",
		"LT",
		"LE",
		"GT",
		"GE",
		"SR",
		"SL",
		"TRIGGER",
		"PPATH",
		"FPATH",
		"IDENTIFIER",
		"ESCAPED_IDENTIFIER",
		"SYSTEM_TASK_NAME",
		"STRING",
		"DEFINE",
		"VOCAB",
		"NUMBER",
		"SIZED_NUMBER",
		"SIZE",
		"BASE",
		"SIZED_DIGIT",
		"UNSIZED_NUMBER",
		"DIGIT",
		"HEXDIGIT",
		"EXPONENT",
		"START",
		"PORT_LIST",
		"RANGE",
		"UNARY_MINUS",
		"UNARY_PLUS",
		"SIMPLE_EXPR",
		"EXPR",
		"NIL",
		"NIL2",
		"NIL3",
		"NIL4",
		"NIL5",
		"NIL6",
		"NIL7"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 258L, 0L, 1970324836974592L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 16106127360L, 0L, 33776997205278720L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 0L, -3695766444210913280L, 6293248L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 0L, 4611686018427387904L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 16106143744L, 0L, 33776997205278720L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 0L, 0L, 201326592L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 0L, 4612811918334230528L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 0L, 613052499275808768L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 0L, 613052499275808768L, 6291456L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 0L, -8601312338324226048L, 6291456L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 0L, -8601312338324226048L, 6293248L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	
	}
