/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef SYMBOLTABLE_HPP
#define SYMBOLTABLE_HPP

#include <string>
#include <vector>
#include <map>
#include <list>

#include "datatype.hpp"

//! Holds information about an identifier for the checker
struct CheckerIdEntry
{
    //! Constructor
    CheckerIdEntry( unsigned int linenr, const CkDataType &type = CkDataType::Undefined,
		    bool constType = false )
	{
	    LineNr = linenr;
	    Type = type;
	    Const = constType;
	}
    unsigned int LineNr;
    CkDataType Type;
    bool Const;
};

//! Holds the JVM local var id about an identifier for the Code Generator.
struct CGIdEntry
{
    //! Constructor
    CGIdEntry( unsigned int jvmid ) { JVMId = jvmid; }
    unsigned int JVMId;
};

//! Holds the JVM function footprint during code generation
struct CGFunctionEntry
{
    //! constructor
    CGFunctionEntry() { Returns = false; }
    std::string FunctionID;
    bool Returns;
};


//! Holds information about parameters and return type for a function.
class FunctionIdEntry
{
	public:

    //! Constructor
    FunctionIdEntry (unsigned int linenr) :  LineNr(linenr) {};
    //! Destructur (empty)
    virtual ~FunctionIdEntry() 
	{
		// Remove all parameters.
		while (paramSize() > 0) parameterList.pop_front();
	}
    //! Add a parameter
    void paramAdd(CkDataType type) {parameterList.push_back(type);};
    //! Returns the number of parameters
    int paramSize() const { return parameterList.size(); };
    //! Resets the parameter iterator for this function.
    void paramReset() {parameterIter = parameterList.begin();};
    //! Returns the current paramer datatype and increases the param iterator.
    CkDataType paramGet ()
	{
		CkDataType type = (*parameterIter);
		parameterIter++;

		return type;
	}

	public:
		unsigned int LineNr;
    	CkDataType ResultType;


	private:
    	std::list<CkDataType> parameterList;
		std::list<CkDataType>::iterator parameterIter;
};


//! Empty exception class
class SymbolTableException
{
};

//! Symbol table class
/*!
 * Simple template class for the symbol tabels that we use. It provides scoping functionality and stores
 * an identifier an a pointer to an object for each symbol tabel entry.
 * The symbol table opens a global scope, scope 0 on creation.
 * Usage example:
 * \code
 * SymbolTable<IdEntry> symbol_table; // create a new symbol table with IdEntries
 * symbol_table.enter( "bob", new IdEntry( whatever params IdEntry has ) );
 * IdEntry *entry = symbol_table.retrieve( "bob" ); // fetch the item we just inserted
 * \endcode
 *
 * SymbolTable will delete all entries added with enter when either the added entry goes out of scope or
 * when the symbol table is deleted.
 * The symbol table starts out in scope level 0 which represents the global scope.
 * \todo Current implementation uses map which is not hashed and might be slow. hash_map is an option but it is not widely supported.
 */
template<class T>
class SymbolTable
{
public:
    SymbolTable();
    virtual ~SymbolTable();

    void openScope();
    void closeScope();
    //! Get the current scope level.
    unsigned int currentLevel() const { return CurrentLevel; }
    T *retrieve( const std::string &id );
    void enter( const std::string &id, T *newEntry );

private:
    std::vector<std::map<std::string, T*>*> Scopes;
    unsigned int CurrentLevel;
};

#endif // SYMBOLTABLE_HPP
