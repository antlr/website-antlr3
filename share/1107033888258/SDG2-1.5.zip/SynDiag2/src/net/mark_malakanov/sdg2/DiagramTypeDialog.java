package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/DiagramTypeDialog.java,v 1.2 2005/01/25 07:42:04 Mark Exp $
 *
 * Modification Log
 * $Log: DiagramTypeDialog.java,v $
 * Revision 1.2  2005/01/25 07:42:04  Mark
 * ajusted
 *
 * Revision 1.1  2005/01/03 13:16:47  Mark
 * minor
 *
 *
 */
import java.awt.Frame;
import java.awt.Dimension;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JComboBox;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.CardLayout;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

public class DiagramTypeDialog extends JDialog  {
  private JComboBox diagType = new JComboBox();
  private JLabel jLabel1 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private CardLayout cardLayout1 = new CardLayout();
  private JTextPane CanonicTextPane = new JTextPane();
  private JTextPane HereticTextPane = new JTextPane();
  private JButton OKButton = new JButton();
  private JButton CancelButton = new JButton();
  private JPanel jPanel2 = new JPanel();
  private CardLayout cardLayout2 = new CardLayout();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();

  String resultValue;

  public DiagramTypeDialog() {
    this(null, "", false);
  }

  /**
   * 
   * @param parent
   * @param title
   * @param modal
   */
  public DiagramTypeDialog(Frame parent, String title, boolean modal) {
    super(parent, title, modal);
    try {
      jbInit();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setSize(new Dimension(400, 300));
    this.getContentPane().setLayout(null);
    this.setTitle("Diagram Style");
    diagType.setBounds(new Rectangle(175, 20, 190, 25));
    diagType.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          diagType_actionPerformed(e);
        }
      });
    diagType.addItem("Canonical");
    diagType.addItem("Heretical");
    jLabel1.setText("Diagram Style");
    jLabel1.setBounds(new Rectangle(50, 25, 120, 20));
    jLabel1.setHorizontalAlignment(SwingConstants.TRAILING);
    jPanel1.setBounds(new Rectangle(20, 55, 350, 45));
    jPanel1.setLayout(cardLayout1);
    CanonicTextPane.setText("Ovals mean terminals and literals. Rectangles mean non-terminals.");
    HereticTextPane.setText("Rectangles mean terminals and literals. Ovals mean non-terminals.");
    OKButton.setText("OK");
    OKButton.setBounds(new Rectangle(65, 215, 105, 35));
    OKButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          OKButton_actionPerformed(e);
        }
      });
    CancelButton.setText("Cancel");
    CancelButton.setBounds(new Rectangle(215, 215, 105, 35));
    CancelButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          CancelButton_actionPerformed(e);
        }
      });
    jPanel2.setBounds(new Rectangle(20, 110, 350, 85));
    jPanel2.setLayout(cardLayout2);
    jButton1.setText("");
    jButton1.setBorderPainted(false);
    jButton1.setIcon(createImageIcon("canonicImage.gif") );
    jButton2.setText("");
    jButton2.setBorderPainted(false);
    jButton2.setIcon(createImageIcon("hereticImage.gif") );
    jPanel1.add(CanonicTextPane, "jTextPane1");
    jPanel1.add(HereticTextPane, "CanonicTextPane2");
    jPanel2.add(jButton1, "jButton1");
    jPanel2.add(jButton2, "jButton2");
    this.getContentPane().add(jPanel2, null);
    this.getContentPane().add(CancelButton, null);
    this.getContentPane().add(OKButton, null);
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(diagType, null);
  }


  /** Returns an ImageIcon, or null if the path was invalid. */
  private ImageIcon createImageIcon(String path) {
    URL imgURL = DiagramTypeDialog.class.getResource(path);
    if (imgURL != null) {
        return new ImageIcon(imgURL);
    } else {
        System.err.println("Couldn't find icon file: " + path);
        return null;
    }
  }


  private void diagType_actionPerformed(ActionEvent e) {
    if ( ((String)diagType.getSelectedItem()).equals("Canonical")) {
      CanonicTextPane.setVisible(true);
      HereticTextPane.setVisible(false);
      jButton2.setVisible(false);
      jButton1.setVisible(true);
    } else if ( ((String)diagType.getSelectedItem()).equals("Heretical")) {
      CanonicTextPane.setVisible(false);
      HereticTextPane.setVisible(true);
      jButton1.setVisible(false);
      jButton2.setVisible(true);
    }
  }

  private void OKButton_actionPerformed(ActionEvent e) {
    resultValue = "OK";
    setVisible(false);
  }

  private void CancelButton_actionPerformed(ActionEvent e) {
    resultValue = "Cancel";
    setVisible(false);
  }
  
  public void setDiagramStyle(String ds) {
    diagType.setSelectedItem(ds);
  }
  
  public String getDiagramStyle() {
    return (String)diagType.getSelectedItem();
  }
}