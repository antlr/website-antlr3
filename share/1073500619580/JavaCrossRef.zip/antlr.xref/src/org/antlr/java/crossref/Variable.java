package org.antlr.java.crossref;
 

import java.io.IOException;

/** Represents the definition of a variable + type.
 */
public class Variable extends Scope {
    /**
     * Field type
     */
    protected ClassScope type = null;

    /**
     * Constructor for Variable
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public Variable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /**
     * Method setType
     * @param type ClassScope
     */
    public void setType(ClassScope type) {
        this.type = type;
    }

    /**
     * Method getType
     * @return ClassScope
     */
    public ClassScope getType() {
        return type;
    }
	/** XML dump()
     *
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		if ( type !=null ) 
			xmlWriter.xmlOpen("Variable name=\"" + getName() + "\"" 
					  + " type=\"" + type.getFullyQualifiedName() + "\"");
		else
			xmlWriter.xmlOpen("Variable name=\"" + getName() + "\""); 
		if(loc != null)
			loc.xmlSerialize(xmlWriter);
		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
			
		xmlWriter.xmlClose("Variable");
	}

	/* (non-Javadoc)
	 * @see org.antlr.java.crossref.Scope#dump()
	 */
	/**
	 * Method dump
	 */
	public void dump() {
		tab();
		if ( type!=null ) {
			System.out.println("Variable:dump " + "field "+type.getFullyQualifiedName()+" "+getName());
		}
		else {
			System.out.println("Variable:dump " + "field "+getName());
		}
	}

	/**
	 * Method addScope
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScope(org.antlr.java.crossref.Scope)
	 */
	public void addScope(Scope s) {
		return;		
	}

	/**
	 * Method addScopeMember
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScopeMember(org.antlr.java.crossref.Scope)
	 */
	public void addScopeMember(Scope s) {
		return;		
	}
    
}
