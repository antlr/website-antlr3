// $ANTLR 2.7.2: "plain.g" -> "PlainTextLexer.java"$
 package satc.lang; 
public interface PlainTextTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LINE = 4;
	int START = 5;
}
