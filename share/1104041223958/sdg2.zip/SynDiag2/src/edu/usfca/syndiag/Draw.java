// $ANTLR 2.7.4: "draw.g" -> "Draw.java"$

	package edu.usfca.syndiag;
	import java.awt.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** A tree grammar draw syntax diagram
 *
 *  Jia Zheng
 *  University of San Francisco
 *  Oct. 1, 2003
 */
public class Draw extends antlr.TreeParser       implements DrawTokenTypes
 {

	SyntaxDiagramGenerator diagGen = null;
	
	public void setDiagGen(SyntaxDiagramGenerator diagGen){
		this.diagGen = diagGen;
	}
public Draw() {
	tokenNames = _tokenNames;
}

	public final void grammar(AST _t) throws RecognitionException {
		
		AST grammar_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			classDef(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void classDef(AST _t) throws RecognitionException {
		
		AST classDef_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE:
			{
				rule(_t);
				_t = _retTree;
				break;
			}
			case PARSER:
			{
				AST __t3 = _t;
				AST tmp1_AST_in = (AST)_t;
				match(_t,PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t3;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_PARSER:
			{
				AST __t4 = _t;
				AST tmp2_AST_in = (AST)_t;
				match(_t,TREE_PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t4;
				_t = _t.getNextSibling();
				break;
			}
			case LEXER:
			{
				AST __t5 = _t;
				AST tmp3_AST_in = (AST)_t;
				match(_t,LEXER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t5;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		AST rule_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST b = null;
		GrammarAST rl = (GrammarAST)rule_AST_in;
			int x; int y;
			int x1 = ((GrammarAST)rl).getX();
		int y1 = ((GrammarAST)rl).getY();
		int h;
		
		try {      // for error handling
			AST __t10 = _t;
			AST tmp4_AST_in = (AST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			r = (AST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			x = ((GrammarAST)r).getX();
						 y = ((GrammarAST)r).getY();
						 if (rl.signal != 1){
						 	diagGen.beginRule(r.getText(), x, y);
						 }else{
						 	diagGen.continueRule(r.getText(), x, y);
						 }
						
			AST __t11 = _t;
			AST tmp5_AST_in = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			b = _t==ASTNULL ? null : (AST)_t;
			h=block(_t,BLOCK);
			_t = _retTree;
			int x2 = ((GrammarAST)b).getX();
						 int y2 = ((GrammarAST)b).getY();
			_t = __t11;
			_t = _t.getNextSibling();
			AST tmp6_AST_in = (AST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t10;
			_t = _t.getNextSibling();
			int w = ((GrammarAST)rl).getWidth();
					 diagGen.endRule(x1, y1, x2, y2, w, rl.signal);
					
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		AST rules_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					rule(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt8++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final int  block(AST _t,
		int type
	) throws RecognitionException {
		int h;
		
		AST block_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		GrammarAST b = (GrammarAST)block_AST_in;
			int[] leftConnPoint, rightConnPoint;
			int[] connPoint1 = ((GrammarAST)b).getBlockLeftConnPoint();
			int[] connPoint2 = ((GrammarAST)b).getBlockRightConnPoint();
			int i=1;
			h = ((GrammarAST)b).getBlockHeight();
			
		
		try {      // for error handling
			{
			int _cnt14=0;
			_loop14:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					a = _t==ASTNULL ? null : (AST)_t;
					alternative(_t);
					_t = _retTree;
					leftConnPoint = ((GrammarAST)a).getLeftConnPoint();
							 rightConnPoint = ((GrammarAST)a).getRightConnPoint();
							 diagGen.drawBlock(connPoint1, connPoint2, leftConnPoint, rightConnPoint, i);
							 i++;
							
				}
				else {
					if ( _cnt14>=1 ) { break _loop14; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt14++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return h;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		AST alternative_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST e = null;
		int i = 1;
			 int[] leftConnPoint, rightConnPoint;
			
		
		try {      // for error handling
			AST __t16 = _t;
			a = _t==ASTNULL ? null :(AST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			rightConnPoint = ((GrammarAST)a).getRightConnPoint();
					
			{
			int _cnt18=0;
			_loop18:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t,ALT);
					_t = _retTree;
					if (i > 1)
										{leftConnPoint = ((GrammarAST)e).getLeftConnPoint();
									 	 diagGen.drawArrow(rightConnPoint[0], rightConnPoint[1], leftConnPoint[0], leftConnPoint[1]);
									 	 }
									 rightConnPoint = ((GrammarAST)e).getRightConnPoint();
									 i++;
									
				}
				else {
					if ( _cnt18>=1 ) { break _loop18; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt18++;
			} while (true);
			}
			_t = __t16;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t,
		int type
	) throws RecognitionException {
		
		AST element_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST s = null;
		GrammarAST e = (GrammarAST)element_AST_in;
			int hb;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case RULE_REF:
			case WILD_CARD:
			{
				atom(_t,type, 1);
				_t = _retTree;
				break;
			}
			case NOT:
			{
				AST __t20 = _t;
				AST tmp7_AST_in = (AST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				element(_t,NOT);
				_t = _retTree;
				_t = __t20;
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_RANGE:
			{
				AST __t21 = _t;
				AST tmp8_AST_in = (AST)_t;
				match(_t,TOKEN_RANGE);
				_t = _t.getFirstChild();
				atom(_t,TOKEN_RANGE, 1);
				_t = _retTree;
				atom(_t,TOKEN_RANGE, 2);
				_t = _retTree;
				_t = __t21;
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t22 = _t;
				AST tmp9_AST_in = (AST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				AST tmp10_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				AST tmp11_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				_t = __t22;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				tree(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t23 = _t;
				s = _t==ASTNULL ? null :(AST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				hb=block(_t,SYNPRED);
				_t = _retTree;
				_t = __t23;
				_t = _t.getNextSibling();
				int[] point1 = ((GrammarAST)s).getLeftConnPoint();
						 int[] point2 = ((GrammarAST)s).getRightConnPoint();
						 int x = point1[0] - 5;
						 int y = point1[1] - 25;
						 int w = point2[0] - point1[0] + 10 + 5;
						 int h = ((GrammarAST)s).getHeight() + 30;
						 diagGen.drawDotRect(x, y, w, h );
					
				break;
			}
			case ACTION:
			{
				AST tmp12_AST_in = (AST)_t;
				match(_t,ACTION);
				_t = _t.getNextSibling();
				break;
			}
			case SEMPRED:
			{
				AST tmp13_AST_in = (AST)_t;
				match(_t,SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				AST tmp14_AST_in = (AST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t,
		int type, int pos
	) throws RecognitionException {
		
		AST atom_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST t = null;
		AST c = null;
		AST s = null;
		AST wi = null;
		GrammarAST a = (GrammarAST)atom_AST_in;
			int x = a.getX();
			int y = a.getY();
			int w = a.getWidth();
			int h = a.getHeight();
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				r = (AST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				diagGen.drawRuleRef(x, y, w, h, r.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
				break;
			}
			case TOKEN_REF:
			{
				t = (AST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				if (type == NOT){
						 	diagGen.drawNot(x, y, w, h, "~ " + t.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
						 }else if (type == TOKEN_RANGE){
						 	diagGen.drawRange(x, y, w, h, t.getText(), pos);
						 }else{
						 	diagGen.drawTokenRef(x, y, w, h, t.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
						 }
						
				break;
			}
			case CHAR_LITERAL:
			{
				c = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				diagGen.drawL(x, y, w, h, c.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
				break;
			}
			case STRING_LITERAL:
			{
				s = (AST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				diagGen.drawL(x, y, w, h, s.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
				break;
			}
			case WILD_CARD:
			{
				wi = (AST)_t;
				match(_t,WILD_CARD);
				_t = _t.getNextSibling();
				diagGen.drawL(x, y, w, h, wi.getText(), new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE));
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		AST ebnf_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST b3 = null;
		AST b = null;
		AST b2 = null;
		GrammarAST e = (GrammarAST)ebnf_AST_in;
			int h1, h3, h2, h;
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				AST __t25 = _t;
				AST tmp15_AST_in = (AST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				h1=block(_t,BLOCK);
				_t = _retTree;
				_t = __t25;
				_t = _t.getNextSibling();
				break;
			}
			case OPTIONAL:
			{
				AST __t26 = _t;
				AST tmp16_AST_in = (AST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				b3 = _t==ASTNULL ? null : (AST)_t;
				h3=block(_t,OPTIONAL);
				_t = _retTree;
				_t = __t26;
				_t = _t.getNextSibling();
				int[] connPoint1 = ((GrammarAST)b3).getBlockLeftConnPoint();
					 		 int[] connPoint2 = ((GrammarAST)b3).getBlockRightConnPoint();
					 		 diagGen.drawOptional(connPoint1, connPoint2, 15);
						
				break;
			}
			case CLOSURE:
			{
				AST __t27 = _t;
				AST tmp17_AST_in = (AST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				b = _t==ASTNULL ? null : (AST)_t;
				h=block(_t,CLOSURE);
				_t = _retTree;
				_t = __t27;
				_t = _t.getNextSibling();
				int[] connPoint1 = ((GrammarAST)b).getBlockLeftConnPoint();
					 		 int[] connPoint2 = ((GrammarAST)b).getBlockRightConnPoint();
					 		 diagGen.drawClosure(connPoint1, connPoint2, h);
						
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t28 = _t;
				AST tmp18_AST_in = (AST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				b2 = _t==ASTNULL ? null : (AST)_t;
				h2=block(_t,POSITIVE_CLOSURE);
				_t = _retTree;
				_t = __t28;
				_t = _t.getNextSibling();
				int[] connPoint1 = ((GrammarAST)b2).getBlockLeftConnPoint();
					 		 int[] connPoint2 = ((GrammarAST)b2).getBlockRightConnPoint();
					 		 diagGen.drawPClosure(connPoint1, connPoint2, h2);
							
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tree(AST _t) throws RecognitionException {
		
		AST tree_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST e = null;
		int[] leftPoint = new int[2];
			 int[] rightPoint = new int[2];
			
		
		try {      // for error handling
			AST __t30 = _t;
			AST tmp19_AST_in = (AST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			a = _t==ASTNULL ? null : (AST)_t;
			atom(_t,0, 1);
			_t = _retTree;
			rightPoint = ((GrammarAST)a).getRightConnPoint();
			{
			_loop32:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t,TREE_BEGIN);
					_t = _retTree;
					leftPoint = ((GrammarAST)e).getLeftConnPoint();
												 diagGen.drawArrow(rightPoint[0], rightPoint[1], 
															leftPoint[0], leftPoint[1]);
												 rightPoint = ((GrammarAST)e).getRightConnPoint();
												
				}
				else {
					break _loop32;
				}
				
			} while (true);
			}
			_t = __t30;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"LEXER",
		"PARSER",
		"TREE_PARSER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"TOKEN_RANGE",
		"CHAR_RANGE",
		"NOT",
		"EPSILON",
		"ALT",
		"EOR",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LITERAL",
		"INT",
		"OR",
		"RANGE",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RULE_REF",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"WILD_CARD"
	};
	
	}
	
