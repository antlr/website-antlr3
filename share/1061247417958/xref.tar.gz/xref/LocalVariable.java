 

import java.util.Vector;

/** Represents the definition of a field (class or instance).
 */
public class LocalVariable extends Variable {
    public LocalVariable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }
    public void dump() {
        tab();
        if ( type!=null ) {
            System.out.println("local "+type.getFullyQualifiedName()+" "+getName());
        }
        else {
            System.out.println("local "+getName());
        }
    }
}
