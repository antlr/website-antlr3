package org.antlr.java.crossref;

import java.io.IOException;
import java.io.Writer;

/**
 * XML helpers
 */
public class XmlWriter {
	
	/**
	 * Field out
	 */
	Writer out = null;
	/**
	 * Field indent
	 */
	String indent = "";

	/**
	 * Constructor for XmlWriter
	 * @param out Writer
	 * @throws IOException
	 */
	public XmlWriter(Writer out) throws IOException{
		this.out = out;
		output("<?xml version=\"1.0\"?>\n");		
	}
	/**
	 * Method flush
	 * @throws IOException
	 */
	public void flush() throws IOException
	{
		out.flush();
	}
	/**
	 * Method output
	 * @param str String
	 * @throws IOException
	 */
	void output(String str) throws IOException{
		if(out != null)
			out.write(indent+str);
		else
			System.out.print(indent+str);
	}
	/**
	 * Method xmlOpen
	 * @param str String
	 * @throws IOException
	 */
	void xmlOpen(String str) throws IOException {
		StringBuffer buf = new StringBuffer(100);
		buf.append("<");
		buf.append(str);
		buf.append(">\n");
		output(buf.toString());
		indent();
	}
	/**
	 * Method xmlClose
	 * @param str String
	 * @throws IOException
	 */
	void xmlClose(String str) throws IOException {
		StringBuffer buf = new StringBuffer(100);
		buf.append("</");
		buf.append(str);
		buf.append(">\n");
		dedent();
		output(buf.toString());
	}
	/**
	 * Method xmlNode
	 * @param str String
	 * @throws IOException
	 */
	void xmlNode(String str) throws IOException {
        StringBuffer buf = new StringBuffer(100);
        buf.append("<");
        buf.append(str);
		buf.append("/>\n");
		output(buf.toString());
    }

	/**
	 * Method dedent
	 */
	protected void dedent() 
	{
		if (indent.length() < 2)
			indent = "";
		else
			indent = indent.substring(2);
	}
	/**
	 * Method indent
	 */
	protected void indent() 
	{
		indent += "  ";
	}
	

}
