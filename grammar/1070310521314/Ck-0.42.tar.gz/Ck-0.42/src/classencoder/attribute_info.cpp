/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "attribute_info.hpp"

namespace ClassEncoder
{
using namespace std;

//! Default constructor
/*!
 * Empty
 */
attribute_info::attribute_info()
{
}

//! Default destructor
/*!
 * Empty
 */
attribute_info::~attribute_info()
{
}

//! Write contents to stream.
/*!
 * Writes the index and the size of this attribute to the stream.
 * Subclasses reimplementing this must take care to call this function before writing their contents to the stream in order to write the whole attribute to the stream correctly.
 */
void attribute_info::write( ofstream &stream )
{
    writeu2( stream, attribute_name_index );
    writeu4( stream, size() );
}

} // end namespace
