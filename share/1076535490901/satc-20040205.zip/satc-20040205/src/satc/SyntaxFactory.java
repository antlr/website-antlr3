/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.awt.Color;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import satc.antlr.DocASTFactory;
import satc.swing.SyntaxEditorKit;
import antlr.CharScanner;
import antlr.LLkParser;

 
/**
 *  Factory for creating support classes for different syntax modes. 
 */
public class SyntaxFactory {

    /**
     *  Creates a new EditorKit for a syntax mode. 
     *
     *  @param syntaxName the name of the syntax mode
     */
    public static SyntaxEditorKit createEditorKit( String syntaxName) {
        return new SyntaxEditorKit( syntaxName);
    }

    /**
     *  Creates a new TokenContext for a syntax mode. 
     *
     *  @param syntaxName the name of the syntax mode
     */
    public static TokenContext createTokenContext( String syntaxMode) {
        TokenContext context = new TokenContext();
        try {
            Properties props = getProperties( syntaxMode);
            if( props == null) {
                props = getProperties( "PlainText");
            }
            context.setTokenCount( Integer.parseInt( props.getProperty( "TokenCount")));
            setTokenStyles( context, props, syntaxMode);
        } catch( Exception e) {
            e.printStackTrace();
        }
        return context;
    }

    /**
     *  Creates a new parser for a syntax mode. 
     *
     *  @param syntaxName the name of the syntax mode
     */
    public static LLkParser createParser( String syntaxName, TokenFilter filter) {//antlr.TokenStream lexer) {
        String parserClassName = "class ?";
        LLkParser parser = null;
        parserClassName = "satc.lang." + syntaxName + "Parser";
        Object[] args = new Object[1];
        Class[] argClassArray = new Class[1];
        args[0] = filter;
        try {
            argClassArray[0] = Class.forName("antlr.TokenStream");
            parser = (LLkParser) Class.forName( parserClassName).getConstructor(argClassArray).newInstance(args);
        } catch( Exception e) {
//            System.out.println( "Class " + parserClassName + " could not be found");
            parserClassName = "satc.lang.PlainTextParser";
            try {
                parser = (LLkParser) Class.forName( parserClassName).getConstructor(argClassArray).newInstance(args);           
            } catch( Exception exc) {
                exc.printStackTrace();
            }           
        }
		parser.setASTFactory( new DocASTFactory());
        
        return parser;
    }

	public static TokenFilter createTokenFilter( String syntaxName, TokenList lexer) {
		TokenFilter filter = null;
		try {
			filter = new TokenFilter( lexer);
		} catch( Exception e) {
			e.printStackTrace();
			return null;
		}           
		setTokenFilter( filter, syntaxName);
		return filter;
	}

    /**
     *  Creates a new MultiStateLexer for a syntax mode. 
     *
     *  @param syntaxName the name of the syntax mode
     */
    public static MultiStateLexer createLexer( String syntaxName) {
        MultiStateLexer lexer = new MultiStateLexer();
        try {
            CharScanner stateLexer;
            Properties props = getProperties( syntaxName);
            setLexerStates( lexer, props);
            setLexerSwitches( lexer, props);
        } catch( Exception e) {
            e.printStackTrace();
        }
        return lexer;
    }

    /**
     *  Creates a new MultiStateLexer for a syntax mode. 
     *
     *  @param syntaxName the name of the syntax mode
     */
    public static MultiStateLexer createLexer( String syntaxName, InputStream inputStream) {
        MultiStateLexer lexer = new MultiStateLexer( inputStream);
        try {
            Properties props = getProperties( syntaxName);
            setLexerStates( lexer, props);
            setLexerSwitches( lexer, props);
        } catch( Exception e) {
            e.printStackTrace();
        }
        return lexer;
    }
   
/////////////////////////////////////////////////////////////////////////////////////////
   

    private static void setTokenFilter( TokenFilter filter, String syntaxName) {
        Properties props = null;
        String filterList;
        try {
            props = getProperties( syntaxName);
            filterList = props.getProperty( "Parser.filter");
            if( filterList == null) 
                return;
//            System.out.println( "filterList : " + filterList);
        } catch( Exception e) {
             // nothing
             return;
        }
        StringTokenizer st = new StringTokenizer( filterList, "," );
        while( st.hasMoreTokens()) {
            String filteredToken = st.nextToken();
            try {
                filter.discard( mainLexer.getClass().getField( filteredToken).getInt( null));
//                System.out.println( "discard : " + mainLexer.getClass().getField( filteredToken).getInt( null));
            } catch( Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void setLexerStates( MultiStateLexer lexer, Properties props) throws Exception {

        CharScanner stateLexer;

        String lexerList = props.getProperty( "LexerList");
        StringTokenizer st = new StringTokenizer( lexerList, "," );
        String startState = props.getProperty( "Lexer.startState");
//        System.out.println("startState = " + startState);
        while( st.hasMoreTokens()) {
            String lexerName = st.nextToken();
//            System.out.println("lexerName = " + lexerName);
            String lexerClassName = props.getProperty( "Lexer." + lexerName + ".class");
//            System.out.println("lexerClassName = " + lexerClassName);
            stateLexer = (CharScanner) Class.forName( lexerClassName).newInstance();
            stateLexer.setInputState( lexer.inputState);
			stateLexer.setTokenObjectClass("satc.ListToken");
            lexer.addStateLexer( stateLexer, lexerName + "Lexer");
            if( lexerName.equals( startState)) {
                mainLexer = stateLexer;
            }
        }
        lexer.setState( startState + "Lexer");
        String mainLexerClassName = props.getProperty( "Lexer." + startState + ".class");
        mainLexer = (CharScanner) Class.forName( mainLexerClassName).newInstance();

    }

    private static void setLexerSwitches( MultiStateLexer lexer, Properties props) throws Exception {
        Field tokenField;
        String switchList = props.getProperty( "SwitchList");
        if( switchList == null) return;
        Class tokenTypes;
        StringTokenizer st = new StringTokenizer( switchList, "," );
        while( st.hasMoreTokens()) {
            String switchName = st.nextToken();
            String switchTo = switchName.substring( switchName.lastIndexOf('-')+1) + "Lexer";
            String switchFrom = switchName.substring( 0, switchName.indexOf('-')) + "Lexer";
            String switchToken = props.getProperty( "Switch." + switchName);
            tokenField = getField( "satc.lang." + switchToken);
            lexer.setSwitch( switchFrom, tokenField.getInt( null), switchTo);
//            lexer.setSwitch( tokenField.getInt( null), switchName.substring( switchName.lastIndexOf('-')+1) + "Lexer");
         }
    }

    private static void setTokenStyles( TokenContext context, Properties props, String syntaxMode) throws Exception {
        String tokenGroupsList = props.getProperty( "Lexer.tokenGroups");
        StringTokenizer list = new StringTokenizer( tokenGroupsList, "," );
        while( list.hasMoreTokens()) {
            String groupName = list.nextToken();
            String tokenList = props.getProperty( "Lexer." + groupName);
            StringTokenizer st = new StringTokenizer( tokenList, "," );
            String groupType = removeTrailingDigits( groupName.substring( groupName.indexOf('.')+1, groupName.length()));
            while( st.hasMoreTokens()) {
                String tokenName = st.nextToken();
                if( Character.isLowerCase( tokenName.charAt(0))) {
                    tokenName = "LITERAL_" + tokenName;
                }
                Field tokenField = getField( "satc.lang." + syntaxMode + "TokenTypes." + tokenName);
                SimpleAttributeSet style = new SimpleAttributeSet();
				String colorString = props.getProperty("Lexer." + removeTrailingDigits( groupName) + ".style");
				if( colorString != null) {
					StringTokenizer colorTok = new StringTokenizer( colorString, "." );
					String color = colorTok.nextToken();		
					Field colorField = getField("java.awt.Color." + color);
					Color c = (Color) colorField.get(null);
					String colorAttribute;
             		while( colorTok.hasMoreTokens()) {
                		colorAttribute = colorTok.nextToken();
						if( colorAttribute.equals("dark"))
							c = c.darker();
						if( colorAttribute.equals("bright"))
							c = c.brighter();
					}
		        	StyleConstants.setForeground( style, c);
					if( colorString.indexOf(".bold") != -1)
			        	StyleConstants.setBold( style, true);
					if( colorString.indexOf(".italic") != -1)
			        	StyleConstants.setItalic( style, true);
				}
				else
					StyleConstants.setForeground( style, Color.black);
				if( tokenField != null)
                	context.setStyle( tokenField.getInt( null), style);
            }
        }
    }

    private static Field getField( String fieldName) {
        try {
            Class clazz = Class.forName( fieldName.substring( 0, fieldName.lastIndexOf(".")));
            Field field = clazz.getDeclaredField( fieldName.substring( fieldName.lastIndexOf(".")+1));
            return field;
        } catch( Exception e) {
            System.err.println( "Field " + fieldName + " could not be found ...");
        } return null;
    }

    private static String removeTrailingDigits( String groupName) {
        int i;
        for( i = groupName.length() - 1; Character.isDigit( groupName.charAt(i)); i--);
        return groupName.substring( 0, i+1);
    }

    private static Properties getProperties( String syntaxMode) {
        return SettingsReader.getProperties( syntaxMode);
    }

    private static CharScanner mainLexer;

}
