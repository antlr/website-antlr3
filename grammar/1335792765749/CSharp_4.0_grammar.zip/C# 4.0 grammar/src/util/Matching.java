package util;

import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Matching {

	public static String matchAll(final String content, Pattern pattern, String REPLACEMENT) {
		// realizes String.replaceAll and prints out each replacement
		Matcher matcher = pattern.matcher(content);
		StringBuffer sb = new StringBuffer();

		while (matcher.find()) {
			for (int i = 0; i <= matcher.groupCount(); i++)
				System.out.println("group " + i + " : " + matcher.group(i));
			// System.out.println("part:\t"+content.substring(matcher.start(), matcher.end()));
			System.out.println("------------");
			matcher.appendReplacement(sb, REPLACEMENT);
		}
		matcher.appendTail(sb);

		return sb.toString();
	}

	public static String matchAll(final String content, Pattern pattern, Callable<String> task) {
		// realizes String.replaceAll and prints out each replacement
		Matcher matcher = pattern.matcher(content);
		StringBuffer sb = new StringBuffer();

		while (matcher.find()) {
			String replacement;
			try {
				replacement = task.call();
			} catch (Exception e) {
				replacement = matcher.group(0);
			}
			matcher.appendReplacement(sb, replacement);
		}
		matcher.appendTail(sb);

		return sb.toString();
	}

}
