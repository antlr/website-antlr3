 

import java.util.*;

/** A File scope represents a compilation unit: a package, some
 *  imports, and one or more type definitions.
 */
public class FileScope extends Scope {
    protected PackageScope thisPackage = null;

    /** List of imported scopes; used for symbol resolution.  This list
     *  contains both packages and class scopes.
     */
    protected Vector imports = new Vector();

    public FileScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
        if ( parent!=null ) {
            parent.addScope(this); // double-link; parent knows subpackages
        }
    }

    /** If fully qualified, just look it up else look up the name in
     *  the current package or in one of the imports.
     */
    public ClassScope resolveClass(String name) {
        if ( name==null ) {
            return null;
        }
        System.out.println("Resolve Class "+name);
        if ( name.indexOf('.')>0 ) { // fully qualified?
            return project.getClassScope(name);
        }
        // is it in one of the packages / classes listed in imports?
        for (int i = 0; i < imports.size(); i++) {
            Scope scope = (Scope)imports.elementAt(i);
            if ( scope==null ) {
                System.out.println("# import scope "+i+" is null!");
                continue;
            }
            System.out.println("Checking scope "+scope.getName());
            ClassScope resolvedTo = scope.resolveClass(name);
            if ( resolvedTo!=null ) {
                System.out.println("Resolving to "+resolvedTo.getFullyQualifiedName());
                return resolvedTo;
            }
        }
        // is it in current package?
        ClassScope scope = thisPackage.resolveClass(name);
        if ( scope!=null ) {
            System.out.println("resolved to current package "+thisPackage.getFullyQualifiedName());
            return scope;
        }
        System.out.println("unresolved");
        return null;
    }

    public void addImport(Scope scope) {
        if ( scope==null ) {
            return;
        }
        imports.addElement(scope);
    }

    public void addScope(Scope s) {
        if ( thisPackage!=null ) {
            thisPackage.addScope(s);
        }
    }

    // GETTER/SETTERS
    public PackageScope getPackageScope() {
        return thisPackage;
    }

    public void setPackageScope(PackageScope thisPackage) {
        this.thisPackage = thisPackage;
    }

    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("File ");
        s.append(getName());
        s.append("\n");
        if ( getPackageScope()!=null ) {
            s.append("package "+getPackageScope().getFullyQualifiedName()+"\n");
        }
        if ( imports!=null && imports.size()>0 ) {
            s.append("imports ");
        }
        for (int i = 0; i<imports.size(); i++) {
            s.append("\n\timports "+
            ((Scope)imports.elementAt(i)).getFullyQualifiedName()+"\n");
        }
        return s.toString();
    }

    public String getName() {
        return "["+super.getName()+"]";
    }

    public String getFullyQualifiedName() {
        if ( getPackageScope()==null ) {
            return "[default]";
        }
        return getPackageScope().getFullyQualifiedName();
    }

}
