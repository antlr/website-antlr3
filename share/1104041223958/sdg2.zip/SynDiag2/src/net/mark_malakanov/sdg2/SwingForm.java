package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */
import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import edu.usfca.syndiag.ANTLRLexer;
import edu.usfca.syndiag.ANTLRParser;
import java.awt.geom.AffineTransform;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.imageio.spi.IIORegistry;
import javax.imageio.spi.ImageWriterSpi;
import javax.swing.*;
import javax.imageio.*;
import java.util.*;
import javax.swing.plaf.basic.*;
import edu.usfca.syndiag.*;
import javax.swing.text.Element;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLWriter;

public class SwingForm
 implements ActionListener
{
     AST ast;
     DrawDemo demo;
     JFrame frm;

     public JMenuBar createMenuBar() {
        // Menu
	JMenuBar menuBar = new JMenuBar();
	
  JMenu menu = new JMenu("File");
	menu.setMnemonic(KeyEvent.VK_F);
	menu.getAccessibleContext().setAccessibleDescription(
        "File functions");
	menuBar.add(menu);

  
	JMenuItem menuItem = new JMenuItem("Open", KeyEvent.VK_O);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(
        		KeyEvent.VK_O, ActionEvent.CTRL_MASK));
	menuItem.getAccessibleContext().setAccessibleDescription(
        "Open ANTLR grammar file");
	menuItem.addActionListener(this);
	menu.add(menuItem);

	menuItem = new JMenuItem("Save As", KeyEvent.VK_S);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(
        		KeyEvent.VK_S, ActionEvent.CTRL_MASK));
	menuItem.getAccessibleContext().setAccessibleDescription(
        "Save image to file");
	menuItem.addActionListener(this);
	menu.add(menuItem);


  menuItem = new JMenuItem("Save As HTML and Multiple Files", KeyEvent.VK_S);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(
        		KeyEvent.VK_S, ActionEvent.CTRL_MASK));
	menuItem.getAccessibleContext().setAccessibleDescription(
        "Save every rule to a separate file");
	menuItem.addActionListener(this);
	menu.add(menuItem);

	menu.addSeparator();
	menuItem = new JMenuItem("Exit", KeyEvent.VK_E);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(
        		KeyEvent.VK_4, ActionEvent.ALT_MASK));
	menuItem.addActionListener(this);
	menu.add(menuItem);

  JMenu helpMenu = new JMenu("Help");
	helpMenu.setMnemonic(KeyEvent.VK_H);
	helpMenu.getAccessibleContext().setAccessibleDescription(
        "Help");
	menuBar.add(helpMenu);

  helpMenu.addSeparator();
	menuItem = new JMenuItem("About", KeyEvent.VK_A);
	menuItem.addActionListener(this);
	helpMenu.add(menuItem);

  return menuBar;
}	

 public void createForm() {
	if (frm != null) return;
	//System.out.println("Form creating");

        frm = new JFrame("ANTLR syntax diagram");

        frm.setJMenuBar( createMenuBar() );

        demo = new DrawDemo();
        JScrollPane sp = new JScrollPane(demo);

        frm.setContentPane(sp);

		
        frm.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            	frm.setVisible(false);
            	frm.dispose();
            	System.exit(0);
            	}
        });

        frm.pack();
        frm.setSize(new Dimension(800,600));
        frm.setVisible(!Main.isBlind);
     }

    public void draw(AST t){	
	this.ast = t;
        demo.init();
        demo.setAST(ast);
	demo.repaint(demo.getVisibleRect());
	}

   public void saveAsFile(AST ast, String fileName ) 
   throws java.io.IOException
   {

     int width = ((GrammarAST)ast).getWidth()+170;
     int height = ((GrammarAST)ast).getHeight()+50;
     //width=1000;
     //height=1000;
     BufferedImage image = new BufferedImage(width, height, 
				BufferedImage.TYPE_3BYTE_BGR);
     Graphics2D g = image.createGraphics();
     
     DrawDemo canvas;
     canvas = new DrawDemo();
     canvas.init();
     canvas.setAST(ast);
     canvas.setBackground(Color.white);
     canvas.setForeground(Color.black);
     canvas.setBounds(0,0,width,height);
     
     g.setBackground(Color.white);
     g.setPaint(Color.gray);
     g.clearRect(0,0,width,height);
     
      AffineTransform aT = g.getTransform();
      int dX = ((GrammarAST)ast).getX();
      int dY = ((GrammarAST)ast).getY();
      aT.translate(-dX+20,-dY+20);
    	g.setTransform(aT);
     
     canvas.paint(g);
     g.dispose();

     String fmt="png";
     fmt=fileName.substring(fileName.lastIndexOf(".")+1).toLowerCase();
     System.out.println("save as " + fmt +" to "+ fileName);
     
     if ( fmt.equalsIgnoreCase("svg") ) {
       DrawDemo svgPanel = new DrawDemo();
       svgPanel.setAST(ast);
       svgPanel.paintSvg(fileName);
      
     } else {
       ImageIO.write(image, fmt, new File(fileName));
       image.flush();
    }
   }
   
   public void saveAsFiles(String dirName, String ext ) 
   throws java.io.IOException
   {
     GrammarAST gast = (GrammarAST)ast;
     GrammarAST[] rules = gast.getChildrenAsArray();
     GrammarAST rule;
     
     for (int i=0; i<rules.length; i++) {
      rule = (GrammarAST)rules[i];
      String fn = rule.getFirstChild().getText();
      saveAsFile(rule, fn +"."+ext);
     } 
   }

   public void saveAsHTMLandFiles(String dirName, String htmlName, String ext,
      String htmlTitle, String htmlHeader, String imgBorder) 
   throws java.io.IOException
   {
     GrammarAST gast = (GrammarAST)ast;
     GrammarAST[] rules = gast.getChildrenAsArray();
     GrammarAST rule;
     
     File dir = new File(dirName);
     dir.mkdir();
     
     if ( ! htmlName.toLowerCase().endsWith(".html") ) {
       htmlName = htmlName + ".html";
     }
     PrintWriter w = new PrintWriter(new BufferedOutputStream(
                new FileOutputStream(htmlName)));
          
     HtmlSyntaxDiagramGenerator hsdg 
       = new HtmlSyntaxDiagramGenerator(w,dirName,ext,
                htmlTitle, htmlHeader, imgBorder);
                
     Draw draw = new Draw();
   	 draw.setDiagGen(hsdg);
	
     for (int i=0; i<rules.length; i++) {
      rule = (GrammarAST)rules[i];
      String fn = rule.getFirstChild().getText();
      try {
        draw.grammar(rule);      
      }catch(Exception e){ throw new RuntimeException(e); }
      saveAsFile(rule, dirName+"/"+fn +"."+ext);
     } 
     
     w.println("</HTML>");
     w.flush();
     w.close();
   }

   public void load(InputStream inStr ) 
   throws java.io.IOException, antlr.RecognitionException, antlr.TokenStreamException
   {
        ANTLRLexer lexer = new ANTLRLexer(inStr);
        ANTLRParser parser = new ANTLRParser(lexer);
        parser.setASTNodeClass("edu.usfca.syndiag.GrammarAST");
        parser.grammar();
        AST grammarTree = parser.getAST();
        //System.out.println(grammarTree.toStringList());

        // print((GrammarAST)grammarTree);


	// walk the tree caculate the dimension of each item
	SetDimension sd = new SetDimension();
	sd.grammar(grammarTree);

	// if wrap
	if (Main.toWrap){
		// walk the tree find those too long sequence and alternative
		// lap them, make a new rule
		AdjustDimension ad = new AdjustDimension();
		ad.grammar(grammarTree);
		
		// caculate the dimension for the new tree
		sd.grammar(grammarTree);
	}
			
	// caculate and set the location for the new tree
	SetLocation sl = new SetLocation();
	sl.grammar(grammarTree);

        draw(grammarTree);

   }


 	
    public void actionPerformed(ActionEvent e)
    {
        String filename;
        JMenuItem source = (JMenuItem)(e.getSource());

	if (source.getText().equals("Save As") ) {
  	  try {
	    JFileChooser chooser = new JFileChooser(".");

      IIORegistry iior = IIORegistry.getDefaultInstance();
      Iterator spi = iior.getServiceProviders(ImageWriterSpi.class,true);
      
      while (spi.hasNext()) {  
               ImageWriterSpi writerSpi = (ImageWriterSpi)spi.next();  
               String fn = writerSpi.getDescription(Locale.US);  
               String[] sfxs = writerSpi.getFileSuffixes();  
               UniversalFilter uf = new UniversalFilter(sfxs,fn);
               chooser.addChoosableFileFilter( uf );
       }   

      chooser.addChoosableFileFilter( new UniversalFilter("svg","SVG Vector Image") );
      
      int returnVal = chooser.showSaveDialog(null);
    
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
              saveAsFile( ast, chooser.getSelectedFile().getAbsolutePath() );
            }
          } catch ( java.io.IOException x ) {
	     throw new RuntimeException( x );
	  }
        }
	else if (source.getText().equals("Open") ) {
  	  try {
	          JFileChooser chooser = new JFileChooser(".");

            chooser.addChoosableFileFilter( 
		           new UniversalFilter("g","ANTLR grammar") );

            int returnVal = chooser.showOpenDialog(null);
    
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
              load(new FileInputStream(
		chooser.getSelectedFile().getAbsolutePath() ) );
            }
          } catch ( Exception x ) {
	     throw new RuntimeException( x );
	  }
        }
	else if (source.getText().equals("Exit") ) { 
      	  System.exit(0);
	}
	else if (source.getText().equals("Save As HTML and Multiple Files") ) {
    SaveToMultipleFilesDialog smfd = new SaveToMultipleFilesDialog(frm,"Save As HTML and Multiple Files", true);
    smfd.pack();
    smfd.setLocationRelativeTo(frm);
    smfd.setSize(400,342);
    smfd.setVisible(true);
    
    if ( smfd.getResult().equals("OK") )
    { 
      try {
        saveAsHTMLandFiles(smfd.getHtmlDirName(),smfd.getHtmlFileName(),smfd.getImgFormat(),
         smfd.getHtmlTitle(),smfd.getHtmlHeader(),smfd.getHtmlImgBorder());
      } catch ( Exception x ) {
      throw new RuntimeException( x );
      }
    }
  }
	else if (source.getText().equals("About") ) {
    JOptionPane.showMessageDialog(frm, new About(), "About", JOptionPane.PLAIN_MESSAGE);
  }


		
}



}
