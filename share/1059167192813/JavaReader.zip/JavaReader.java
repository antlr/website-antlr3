import antlr.collections.AST;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import org.xml.sax.*;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.helpers.*;

/**
 * Reads a Java File or package and generates XML. 
 */
public class JavaReader implements XMLReader {

  //~ Static fields/initializers *******************************************************************

  public static final String RECURSIV_FEATURE = "http://www.sz.org.br/sax/features/recursiv";

  //~ Instance fields ******************************************************************************

  private ContentHandler myContentHandler;
  private ErrorHandler myErrorHandler;
  private boolean myIsRecursiv = true;

  //~ Methods **************************************************************************************

  /**
   * Allow an application to register a content event handler.
   * 
   * <p>
   * If the application does not register a content handler, all content events reported by the SAX
   * parser will be silently ignored.
   * </p>
   * 
   * <p>
   * Applications may register a new or different handler in the middle of a parse, and the SAX
   * parser must begin using the new handler immediately.
   * </p>
   *
   * @param handler The content handler.
   *
   * @see #getContentHandler
   */
  public void setContentHandler(ContentHandler handler) {
    myContentHandler = handler;
  }

  /**
   * Return the current content handler.
   *
   * @return The current content handler, or null if none has been registered.
   *
   * @see #setContentHandler
   */
  public ContentHandler getContentHandler() {
    return myContentHandler;
  }

  /**
   * not used
   *
   * @param handler The DTD handler.
   */
  public void setDTDHandler(DTDHandler handler) {
  }

  /**
   * not used.
   *
   * @return null.
   */
  public DTDHandler getDTDHandler() {
    return null;
  }

  ////////////////////////////////////////////////////////////////////
  // Event handlers.
  ////////////////////////////////////////////////////////////////////

  /**
   * not used
   *
   * @param resolver The entity resolver.
   */
  public void setEntityResolver(EntityResolver resolver) {
  }

  /**
   * not used
   *
   * @return null.
   */
  public EntityResolver getEntityResolver() {
    return null;
  }

  /**
   * Allow an application to register an error event handler.
   *
   * @param handler The error handler.
   *
   * @see #getErrorHandler
   */
  public void setErrorHandler(ErrorHandler handler) {
    myErrorHandler = handler;
  }

  /**
   * Return the current error handler.
   *
   * @return The current error handler, or null if none has been registered.
   *
   * @see #setErrorHandler
   */
  public ErrorHandler getErrorHandler() {
    return myErrorHandler;
  }

  /**
   * Set the state of a feature.
   * 
   * <p>
   * The feature name is any fully-qualified URI.  It is possible for an XMLReader to recognize a
   * feature name but to be unable to set its value; this is especially true in the case of an
   * adapter for a SAX1 {@link org.xml.sax.Parser Parser}, which has no way of affecting whether
   * the underlying parser is validating, for example.
   * </p>
   * 
   * <p>
   * All XMLReaders are required to support setting http://xml.org/sax/features/namespaces to true
   * and http://xml.org/sax/features/namespace-prefixes to false.
   * </p>
   * 
   * <p>
   * Some feature values may be immutable or mutable only  in specific contexts, such as before,
   * during, or after  a parse.
   * </p>
   *
   * @param name The feature name, which is a fully-qualified URI.
   * @param value The requested state of the feature (true or false).
   *
   * @exception SAXNotRecognizedException When the XMLReader does not recognize the feature name.
   * @exception SAXNotSupportedException When the XMLReader recognizes the feature name but  cannot
   *            set the requested value.
   *
   * @see #getFeature
   */
  public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {

    if (RECURSIV_FEATURE.equals(name)) {
      myIsRecursiv = value;
    }
  }

  /**
   * Look up the value of a feature.
   *
   * @param name name of the feature
   *
   * @return set or not
   *
   * @throws SAXNotRecognizedException 
   * @throws SAXNotSupportedException 
   */
  public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {

    if (RECURSIV_FEATURE.equals(name)) {
      return myIsRecursiv;
    } else {
      throw new SAXNotRecognizedException("Feature '" + name + "' not recognized");
    }
  }

  /**
   * not used
   *
   * @param name The property name, which is a fully-qualified URI.
   * @param value The requested value for the property.
   *
   * @throws SAXNotRecognizedException
   * @throws SAXNotSupportedException
   */
  public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
  }

  /**
   * not used
   *
   * @param name The property name, which is a fully-qualified URI.
   *
   * @return null.
   *
   * @throws SAXNotRecognizedException
   * @throws SAXNotSupportedException 
   */
  public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
    return null;
  }

  ////////////////////////////////////////////////////////////////////
  // Parsing.
  ////////////////////////////////////////////////////////////////////

  /**
   * Parse an XML document.
   * 
   * <p>
   * The application can use this method to instruct the XML reader to begin parsing an XML
   * document from any valid input source (a character stream, a byte stream, or a URI).
   * </p>
   * 
   * @param input The input source for the top-level of the XML document.
   *
   * @exception IOException Any SAX exception, possibly wrapping another exception.
   * @exception SAXException An IO exception from the parser, possibly from a byte stream or
   *            character stream supplied by the application.
   *
   * @see org.xml.sax.InputSource
   * @see #parse(java.lang.String)
   * @see #setEntityResolver
   * @see #setDTDHandler
   * @see #setContentHandler
   * @see #setErrorHandler
   */
  public void parse(InputSource input) throws IOException, SAXException {
    String path = input.getSystemId();

    if (myContentHandler != null) {
      myContentHandler.startDocument();
    }

    if (path != null) {
      doFile(new File(path));
    } else {

      if (input.getCharacterStream() == null) {
        input.setCharacterStream(new InputStreamReader(input.getByteStream()));
      }

      parseFile(null,input.getCharacterStream());
    }

    if (myContentHandler != null) {
      myContentHandler.endDocument();
    }
  }

  /**
   * Parse an XML document from a system identifier (URI).
   * 
   * <p>
   * This method is a shortcut for the common case of reading a document from a system identifier.
   * It is the exact equivalent of the following:
   * </p>
   * <pre>
   * parse(new InputSource(systemId));
   * </pre>
   * 
   * <p>
   * in this case the systemidentifier should be a path to the java sources
   * </p>
   *
   * @param systemId The system identifier (URI).
   *
   * @exception IOException Any SAX exception, possibly wrapping another exception.
   * @exception SAXException An IO exception from the parser, possibly from a byte stream or
   *            character stream supplied by the application.
   *
   * @see #parse(org.xml.sax.InputSource)
   */
  public void parse(String systemId) throws IOException, SAXException {
    parse(new InputSource(systemId));
  }

  /**
   * This method decides what action to take based on the type of file we are looking at
   *
   * @param f DOCUMENT ME!
   *
   * @throws IOException DOCUMENT ME!
   * @throws SAXException DOCUMENT ME!
   */
  private void doFile(File f) throws IOException, SAXException {
    String filename = f.getName();
    // If this is a directory, walk each file/dir in that directory
    if (f.isDirectory()) {

      if (myContentHandler != null) {
        AttributesImpl attr =  new AttributesImpl();
        attr.addAttribute( "", "", "name", "string", f.getName());
        myContentHandler.startElement("", "", "PACKAGE", attr );
      }

      String[] files = f.list();

      for (int i = 0; i < files.length; i++) {
        doFile(new File(f, files[i]));
      }

      if (myContentHandler != null) {
        myContentHandler.endElement("", "", "PACKAGE");
      }
    }
    // otherwise, if this is a java file, parse it!
    else if ((filename.length() > 5) && filename.substring(filename.length() - 5).equals(".java")) {
      parseFile(filename.substring( 0, filename.length() - 5 ), new BufferedReader(new FileReader(f)));
    }
  }

  // Here's where we do the real work...
  private void parseFile(String name, Reader r) throws SAXException {

    if (myContentHandler != null) {
      AttributesImpl attr =  new AttributesImpl();
      if ( name != null ) {
        attr.addAttribute( "", "", "name", "string", name);
      }
      myContentHandler.startElement("", "", "UNIT", attr );
    }

    // Create a scanner that reads from the input stream passed to us
    JavaLexer lexer = new JavaLexer(r);

    // Create a parser that reads from the scanner
    JavaRecognizer parser = new JavaRecognizer(lexer);

    try {
      // start parsing at the compilationUnit rule
      parser.compilationUnit();
      AST t = parser.getAST();
      String[] tokenNames = parser.getTokenNames();

      for (int i = 0; i < tokenNames.length; i++) {
        tokenNames[i] = tokenNames[i].replaceAll("\"", "").replaceAll("<", "_").replaceAll(">", "_");
      }

      while (t != null) {
        walkAST(t, tokenNames);
        t = t.getNextSibling();
      }
    } catch (Exception ex) {
      throw new SAXException(ex);
    }

    if (myContentHandler != null) {
      myContentHandler.endElement("", "", "UNIT");
    }
  }

  private void walkAST(AST ast, String[] tokenNames) throws SAXException {
    String elementName = tokenNames[ast.getType()];

    if (myContentHandler != null) {
      AttributesImpl attr = new AttributesImpl();

      myContentHandler.startElement("", "", elementName, attr);
    }

    AST child = ast.getFirstChild();

    if ((child == null) && (myContentHandler != null)) {
      String data = ast.getText();

      if (!data.equals(elementName)) {
        myContentHandler.characters(data.toCharArray(), 0, data.length());
      }
    } else {

      while (child != null) {
        walkAST(child, tokenNames);
        child = child.getNextSibling();
      }
    }

    if (myContentHandler != null) {
      myContentHandler.endElement("", "", elementName);
    }
  }
}
