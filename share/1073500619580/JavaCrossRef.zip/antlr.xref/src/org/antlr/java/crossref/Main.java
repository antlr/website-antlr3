package org.antlr.java.crossref;
 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Enumeration;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import antlr.MismatchedTokenException;
import antlr.RecognitionException;
import antlr.collections.AST;


/** class/Method to drive the JavaRecognizer.  
 * Uses MyOutput (an OutputCrossRefInfo interface) to control 
 * CodeProject output.
 * PrintInformative controls consol printing.
 * Uses java.g (JavaRecognizer) parser to create an AST.  
 * Calls defs.g (JavaDefsTreeParser) to define items.
 * Calls preref.g (JavaPreRefsTreeParser) to resolve types.
 * Calls ref.g (JavaRefsTreeParser) to resolve references.
 */
class Main {
	/**
	 * Output helpful information to consol?
	 */
	private static final boolean printInformative=false;
    /**
     * Create information repository
     */
    static CodeProject project = new CodeProject();
    /** phase constant
     */
    static final int DEFINITIONS	=1;
	/** phase constant
	 */
	static final int PREREFERENCES	=2;
	/** phase constant
	 */
	static final int REFERENCES		=3;
    /**
     * Field phase
     */
    static int phase = DEFINITIONS;
	
    /**
     * Set myoutput, go through the three phases and call 
     * project.outputStructure()
     * @param args String[]
     */
    public static void main(String[] args) {
        // Use a try/catch block for parser exceptions
        try {
            // if we have at least one command-line argument
            if (args.length > 0 ) {
            	MyOutput myOutput = new MyOutput();
				project.setOutputInfo(myOutput);
				if(printInformative)
				{
					System.err.println("Parsing...");
					System.out.println("  definitions ...");
				}
                phase = DEFINITIONS;
                // for each directory/file specified on the command line
                for(int i=0; i< args.length;i++) 
                        doFile(new File(args[i])); // parse it
                
				if(printInformative)
				{
					System.out.println("  end definitions ...");
					System.out.println("  prereferences ...");
				}
				phase = PREREFERENCES;
				// for each directory/file specified on the command line
				for(int i=0; i< args.length;i++) 
						doFile(new File(args[i])); // parse it
				
				if(printInformative)
				{
					System.out.println("  end prereferences");
					System.out.println("  references ...");
				}
				phase = REFERENCES;
				// for each directory/file specified on the command line
				for(int i=0; i< args.length;i++) 
						doFile(new File(args[i])); // parse it
				
				if(printInformative)
				{
					System.out.println("  end references ...(outputStructure) ");
				}
//				after association 
				project.outputStructure();
             }
            else
                System.err.println("Usage: java Main <directory or file name>");
        }
        catch(Exception e) {
        	if(JavaRecognizer.PRINTERROR && phase==DEFINITIONS)
        	{
				System.err.println("exception: "+e);
				e.printStackTrace(System.err);   // so we can get stack trace
        	}
		}
	}
    /**
     * For each item in jar file, call doClassFile()
     * @param jarfile JarFile
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static void doJarFile(JarFile jarfile) throws IOException, ClassNotFoundException{
    	Class jarClass = jarfile.getClass();
    	Enumeration enum = jarfile.entries();
		while(enum.hasMoreElements()){
		   JarEntry entry = (JarEntry)enum.nextElement();
		   Attributes attr =entry.getAttributes();
		   
		   InputStream in = null;
			in = jarfile.getInputStream(entry);

		   String name = entry.getName();
		   if(name.toLowerCase().endsWith(".class"))
			   doClassFile(in, entry.getSize(), name);
		  }
    	return;
    }

	/** Process classfile based on an Inputstream
	 * @param in 
	 * @param len long
	 * @param name String
	 * @throws ClassNotFoundException
	 * @throws KClassFileParseException
	 * @throws IOException
	 */
	private static void doClassFile(InputStream in, long len, String name) 
	throws ClassNotFoundException, KClassFileParseException, IOException {
		ClassFile classfile = new ClassFile(project, in, name);
		try {
			classfile.load();
		} catch (KClassFileParseException e) {
			// TODO Auto-generated catch block
			if(JavaRecognizer.PRINTERROR)
				e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			if(JavaRecognizer.PRINTERROR)
				e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			if(JavaRecognizer.PRINTERROR)
				e.printStackTrace();
		}
		return;
	}

	/** Inspect file.  Determine action
	 * Method doFile
	 * @param f File
	 * @throws Exception
	 */
	public static void doFile(File f)
							  throws Exception {
		try {
			// If this is a directory, walk each file/dir in that directory
			if (f.isDirectory()) {
				String files[] = f.list();
				for(int i=0; i < files.length; i++)
					doFile(new File(f, files[i]));
			}

			// otherwise, if this is a java file, parse it!
			else if ((f.getName().length()>5) &&
					f.getName().substring(f.getName().length()-5).equals(".java")) {
				if(printInformative)
					System.err.println("   "+f.getAbsolutePath());
				// parseFile(f.getName(), new FileInputStream(f));
				parseFile(f.getName(), new BufferedReader(new FileReader(f)));
			}
			else if (phase == DEFINITIONS && ((f.getName().length()>4) &&
			f.getName().substring(f.getName().length()-4).equals(".jar"))){
					doJarFile(new JarFile(f));
			}
		} catch (FileNotFoundException e) {
			if(phase==DEFINITIONS && JavaRecognizer.PRINTERROR)
				System.err.println("Problem finding: " + f.getAbsolutePath());
		}
		catch (IOException e){
			if(phase==DEFINITIONS && JavaRecognizer.PRINTERROR)
					System.err.println("Problem reading: " + f.getAbsolutePath());
		}
		
	}

	/**
	 * Parse a java text file.
	 * @param f String
	 * @param r Reader
	 * @throws Exception
	 */
	public static void parseFile(String f, Reader r)
								 throws Exception {
		try {
			// Create a scanner that reads from the input stream passed to us
			JavaLexer lexer = new JavaLexer(r);
			lexer.setFilename(f);
			lexer.setTokenObjectClass("org.antlr.java.crossref.LocationToken");

			// Create a parser that reads from the scanner
			JavaRecognizer parser = new JavaRecognizer(lexer);
			parser.setASTNodeClass("org.antlr.java.crossref.LocationAST");
			parser.setFilename(f);
			if(phase == DEFINITIONS)
				parser.setWarnings(project.getWarnings());

			// start parsing at the compilationUnit rule
			parser.compilationUnit();

			// do something with the tree
			doTreeAction(f, parser.getAST(), parser.getTokenNames());
		}
		catch (Exception e) {
			if(phase == DEFINITIONS && e instanceof MismatchedTokenException)
				project.getWarnings().add(new Location(((MismatchedTokenException) e).getFilename(), Location.SOURCEFILE, ((MismatchedTokenException) e).getLine(), ((MismatchedTokenException) e).getColumn())); 
			
			if(phase == DEFINITIONS && JavaRecognizer.PRINTERROR)
			{
				System.err.println("parser exception: "+e);
				e.printStackTrace();   // so we can get stack trace
			}
		}
	}

	/**
	 * Call an Antlr Tree parser for input AST
	 * @param f String
	 * @param t AST
	 * @param tokenNames String[]
	 */
	public static void doTreeAction(String f, AST t, String[] tokenNames) {
		if ( t==null ) return;

		if ( phase==DEFINITIONS ) {
			JavaDefsTreeParser dparse = new JavaDefsTreeParser();
			try {
				dparse.setFileName(f);
				dparse.setProject(project);
				dparse.setASTNodeClass("org.antlr.java.crossref.LocationAST");
				dparse.compilationUnit(t);
			}
			catch (RecognitionException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}

		if ( phase==PREREFERENCES ) {
			JavaPreRefsTreeParser prparse = new JavaPreRefsTreeParser();
			try {
				prparse.setFileName(f);
				prparse.setProject(project);
				prparse.setASTNodeClass("org.antlr.java.crossref.LocationAST");
				prparse.compilationUnit(t);
			}
			catch (RecognitionException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}

        if ( phase==REFERENCES) {
            JavaRefsTreeParser rparse = new JavaRefsTreeParser();
            try {
                rparse.setFileName(f);
                rparse.setProject(project);
				rparse.setASTNodeClass("org.antlr.java.crossref.LocationAST");
                rparse.compilationUnit(t);
                //System.out.println(project);
            }
            catch (RecognitionException e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
	}
}

