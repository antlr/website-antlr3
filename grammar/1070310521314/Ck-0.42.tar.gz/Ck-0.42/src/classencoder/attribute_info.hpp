/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef ATTRIBUTEINFO_HPP
#define ATTRIBUTEINFO_HPP

#include <fstream>

#include "defs.hpp"
#include "classwriterbase.hpp"

namespace ClassEncoder
{

//! Base class for attributes
/*!
 * This class is the base class for all JVM class attributes.
 * The JVM attributes are documented here
 * http://java.sun.com/docs/books/vmspec/2nd-edition/html/ClassFile.doc.html#43817.
 * All attributes must inherit from this class and they must all implement both the size and
 * the write function.
 * \todo Add Valid bit for name_index set.
 */
class attribute_info : public ClassWriterBase
{
public:
    attribute_info();
    virtual ~attribute_info();

    virtual void write( std::ofstream &stream );
    //! Size of this attribute
    /*!
     * All subclasses must implement this function.
     * \return The size of the contents of the subclasses not counting the attribute_name_index and the size. (6 bytes)
     */
    virtual unsigned int size() = 0;

protected:
    //! Set the index to the name in the constant pool.
    /*!
     * Set the name of this class.
     * \param index The index to the constant pool entry containing the name. All subclasses are responsible for setting the name.
     */
    void setNameIndex( u2 index ) { attribute_name_index = index; }

private:
    u2 attribute_name_index;
};

} // end of namespace
#endif // ATTRIBUTEINFO_HPP
