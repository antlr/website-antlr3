echo cleaning
rm -rf output && \
rm -rf method_chaining_demo && \
echo mkdir && \
mkdir output && \
mkdir output/classes && \
mkdir method_chaining_demo && \


echo header file generating
echo generating code && \
java -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar org.antlr.Tool -o output pipe.g decl.g && \
echo compiling lexer and parser && \
javac output/*.java -cp ~/Downloads/antlr-3.4-complete-no-antlrv2.jar -d output/classes && \
echo compiling header.java && \
javac -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes header.java && \
echo running test.java && \
java -cp .:/home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes header input.pipe


echo cpp file generating
echo generating code && \
java -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar org.antlr.Tool -o output pipe.g def.g && \
echo compiling lexer and parser && \
javac output/*.java -cp ~/Downloads/antlr-3.4-complete-no-antlrv2.jar -d output/classes && \
echo compiling cpp.java && \
javac -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes cpp.java && \
echo running test.java && \
java -cp .:/home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes cpp input.pipe

echo go.cpp file generating
echo generating code && \
java -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar org.antlr.Tool -o output pipe.g driver.g && \
echo compiling lexer and parser && \
javac output/*.java -cp ~/Downloads/antlr-3.4-complete-no-antlrv2.jar -d output/classes && \
echo compiling go.java && \
javac -cp /home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes go.java && \
echo running go.java && \
java -cp .:/home/young/Downloads/antlr-3.4-complete-no-antlrv2.jar:output/classes go input.pipe


cp run.sh method_chaining_demo/.
cd method_chaining_demo
./run.sh
./go
