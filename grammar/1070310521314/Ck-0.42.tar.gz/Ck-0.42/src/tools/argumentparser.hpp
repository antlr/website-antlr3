/*
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */

#ifndef ARGUMENTPARSER_HPP
#define ARGUMENTPARSER_HPP

#include <map>
#include <string>

using namespace std;

/*! \file argumentparser.hpp
  Definition of ArgumentParser class
*/

class ArgumentParser
{
public:
    ArgumentParser();
    virtual ~ArgumentParser();

    bool parseArguments( int argc, char **argv );
    uint numArguments() const;
    string argValue( const string &arg ) const;
    bool boolArgValue( const string &arg ) const;
    bool singleArgSet( char arg ) const;

private:
    map<string, string> ArgsMap;
    string NoParamArgs;
};


#endif // ARGUMENTPARSER_HPP
