/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.Reflection;
using System.Collections;
using System.IO;
using System.Text;

namespace Antlr.StringTemplate {

	/// <summary>
	/// Manages a group of named mutually-referential StringTemplate objects.
	/// </summary>
	/// <remarks>
	/// Currently the templates must all live under a directory so that you
	/// can reference them as foo.st or gutter/header.st.  To refresh a
	/// group of templates, just create a new StringTemplateGroup and start
	/// pulling templates from there.  Or, set the refresh interval.
	///
	/// Use GetInstanceOf(template-name) to get a string template
	/// to fill in.
	///
	/// The name of a template is the file name minus ".st" ending if present
	/// unless you name it as you load it.
	/// </remarks>
	public class StringTemplateGroup {
		/// <summary>
		/// What's the start of an attribute expression within a template?
		/// This one is good for HTML as it stands out, though I like
		/// &lt;expr&gt; even still.
		/// </summary>
		private const String DEFAULT_DELIMITER_START = "$";
		private const String DEFAULT_DELIMITER_STOP = "$";

		protected String name;

		/// <summary>
		/// Maps template name to StringTemplate object.
		/// </summary>
		private Hashtable templates = null;
		private IStringTemplateLoader templateLoader;

		/** Track all groups by name; maps name to StringTemplateGroup */
		protected static IDictionary nameToGroupMap = new Hashtable();

		/** Are we derived from another group?  Templates not found in this group
		 *  will be searched for in the superGroup recursively.
		 */
		protected StringTemplateGroup superGroup = null;

		/** Where to report errors.  All string templates in this group
		 *  use this error handler by default.
		 */
		IStringTemplateErrorListener listener = DEFAULT_ERROR_LISTENER;

		public static IStringTemplateErrorListener DEFAULT_ERROR_LISTENER =
			new ConsoleErrorListener();

		/** Maps group name to delimiter start String for that group */
		private String delimiterStart = DEFAULT_DELIMITER_START;
		private String delimiterStop = DEFAULT_DELIMITER_STOP;

		/** Used to indicate that the template doesn't exist.
		 *  We don't have to check disk for it; we know it's not there.
		 */
		private static readonly StringTemplate NOT_FOUND_ST = new StringTemplate();

		/** How long before tossing out all templates in seconds. */
		private TimeSpan refreshInterval = TimeSpan.FromSeconds(Int32.MaxValue / 1000);  // default: no refreshing from disk
		private DateTime lastCheckedDisk;


		/// <summary>
		/// Create a template group manager. 
		/// </summary>
		/// <param name="name">Template name.</param>
		/// <param name="loader">Template loader.</param>
		public StringTemplateGroup(String name, IStringTemplateLoader loader) {
			this.name = name;

			if (loader != null) {
				this.templateLoader = loader;
			}
			else {
				this.templateLoader = new FileTemplateLoader();
			}

			templates = new Hashtable();
			lastCheckedDisk = DateTime.Now;
			nameToGroupMap[name] = this;
		}

		/// <summary>
		/// Create a template group manager. 
		/// </summary>
		/// <param name="name">Template name.</param>
		public StringTemplateGroup(String name) : this(name, null) {
		}

		/// <summary>
		/// Create a template group manager. 
		/// </summary>
		/// <param name="name">Template name.</param>
		public StringTemplateGroup(String name,	String delimiterStart, 
			String delimiterStop) :	this(name, null, delimiterStart, delimiterStop) {
		}

		public StringTemplateGroup(String name,	IStringTemplateLoader loader, 
			String delimiterStart, String delimiterStop) : this(name, loader) {
			this.delimiterStart = delimiterStart;
			this.delimiterStop = delimiterStop;
		}

		/// <summary>
		/// The group name.
		/// </summary>
		public String Name {
			get {
				return name;
			}
			set {
				this.name = value;
			}
		}

		public void SetSuperGroup(String groupName) {
			this.superGroup = (StringTemplateGroup) nameToGroupMap[groupName];
		}

		public StringTemplateGroup SuperGroup {
			get {
				return superGroup;
			}
			set {
				this.superGroup = value;
			}
		}

		public String DelimiterStop {
			get {
				return this.delimiterStop;
			}
		}

		public String DelimiterStart {
			get {
				return this.delimiterStart;
			}
		}

		public StringTemplate GetInstanceOf(String name) {
			StringTemplate st = GetInstanceOf(name, null);
			return st;
		}

		public StringTemplate GetInstanceOf(String name, IDictionary initialValues) {
			StringTemplate st = this.GetTemplate(name);

			if ( st == null ) {
				return null;
			}

			return st.GetInstanceOfWithAttributes(initialValues);
		}

		public StringTemplate GetEmbeddedInstanceOf(
			StringTemplate enclosingInstance, String name) {
			return GetEmbeddedInstanceOf(enclosingInstance, name, null);
		}

		public StringTemplate GetEmbeddedInstanceOf(
			StringTemplate enclosingInstance, String name, IDictionary initialValues) {
			StringTemplate st = this.GetTemplate(name);

			if ( st == null ) {
				return null;
			}

			if ( initialValues != null ) {
				st = st.GetInstanceOfWithAttributes(initialValues);
			}
			else {
				st = st.GetInstanceOf();
			}

			st.EnclosingInstance = enclosingInstance;

			return st;
		}

		/// <summary>
		/// Get the template called 'name' from the group.
		/// </summary>
		/// <remarks>
		/// If not found, attempt to load/save.  If not found on disk, then try the superGroup
		/// if any.  If not even there, then record that it's NOT_FOUND so we don't waste time 
		/// looking again later.  If we've gone past refresh interval, flush and look again.
		/// </remarks>
		/// <param name="name"></param>
		/// <returns></returns>
		public StringTemplate GetTemplate(String name) {
			if ( StringTemplate.InDebugMode ) {
				listener.Debug("getTemplate(" + name + ")");
			}

			checkRefreshInterval();
			StringTemplate st = (StringTemplate) templates[name];

			if ( st == null ) {
				String templatePath = 
					this.templateLoader.DeriveLocationFromTemplateName(name);

				// not there?  Attempt to load
				if ( StringTemplate.InDebugMode ) {
					listener.Debug("Attempting load of: " + templatePath);
				}

				st = LoadTemplate(templatePath);

				if ( st == null ) {
					this.Error("Can't load template " + templatePath);

					// try to resolve in the superGroup
					if ( superGroup != null ) {
						st = superGroup.GetTemplate(name);
					}

					if ( st != null ) { // found in superGroup
						// insert into this group; refresh will allow super
						// to change it's def later or this group to add
						// an override.
						templates[name] = st;
					}
					else {
						// not found
						// remember that this sucker doesn't exist
						templates[name] = NOT_FOUND_ST;
					}
				}
			}
			else if ( st == NOT_FOUND_ST ) {
				return null;
			}

			return st;
		}

		private void checkRefreshInterval() {
			bool timeToFlush = refreshInterval == TimeSpan.Zero ||
				(DateTime.Now - lastCheckedDisk) >= refreshInterval;

			if ( timeToFlush ) {
				// throw away all pre-compiled references
				templates.Clear();
				lastCheckedDisk = DateTime.Now;
			}
		}

		/// <summary>
		/// Load a template whose name is derived from the template filename.
		/// Remove the ".st" suffix and any path info on the front.
		/// </summary>
		/// <param name="fileName">Template file name.</param>
		/// <returns>A StringTemplate instance.</returns>
		public StringTemplate LoadTemplate(String location) {
			String templateName = 
				this.templateLoader.DeriveTemplateNameFromLocation(location);
			
			return this.LoadTemplate(templateName, location);
		}

		public StringTemplate LoadTemplate(String name, String location) {
			String templateSource = this.templateLoader.LoadTemplate(name, location);			
			StringTemplate template = null;

			if (templateSource != null) {
				template = this.DefineTemplate(name, templateSource);
			}

			return template;
		}

		/// <summary>
		/// Define a template; precompiled and stored with no attributes.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="template"></param>
		/// <returns></returns>
		public StringTemplate DefineTemplate(String name, String template) {
			
			if ( StringTemplate.InDebugMode ) {
				listener.Debug(this.Name + ".defineTemplate(" + name + ")");
			}

			StringTemplate st = new StringTemplate();
			st.Name = name;
			st.Group = this;
			st.Template = template;
			st.ErrorListener = listener;
			templates[name] = st;

			return st;
		}

		/** How often to refresh all templates from disk.  This is a crude
		 *  mechanism at the moment--just tosses everything out at this
		 *  frequency.  Set interval to 0 to refresh constantly (no caching).
		 *  Set interval to a huge number like MAX_INT to have no refreshing
		 *  at all (DEFAULT); it will cache stuff.
		 */
		public TimeSpan RefreshInterval {
			get {
				return refreshInterval;
			}
			set {
				this.refreshInterval = value;
			}
		}

		public IStringTemplateErrorListener ErrorListener {
			get {
				return listener;
			}
			set {
				this.listener = value;
			}
		}

		/// <summary>
		/// The template loader.
		/// </summary>
		public IStringTemplateLoader Loader {
			get {
				return this.templateLoader;
			}
			set {
				if (value != null) {
					this.templateLoader = value;
				}
			}
		}

		public void Error(String msg) {
			Error(msg, null);
		}

		public void Error(String msg, Exception e) {
			if ( listener != null ) {
				listener.Error(msg, e);
			}
			else {
				Console.Error.WriteLine("StringTemplate: " + msg + ": " + e);
			}
		}

		public override String ToString() {
			StringBuilder buf = new StringBuilder();
        
			foreach ( String tname in templates.Keys ) {
				buf.Append("==== TEMPLATE ");
				buf.Append(tname);
				buf.Append("\n");
				StringTemplate st = (StringTemplate) templates[tname];

				if ( st != NOT_FOUND_ST ) {
					buf.Append(st.Template);
					buf.Append("====\n");
				}
			}

			return buf.ToString();
		}

		/*
		public StringTemplate loadTemplate(String name, String resourceName)
					throws IOException
			{
				InputStream is =
					ClassLoader.getSystemResourceAsStream(resourceName);
				if ( is == null ) {
					throw new FileNotFoundException(resourceName);
				}
				InputStreamReader isr = new InputStreamReader(is);
				TextReader bf = new TextReader(isr);
				String line;
				String nl = System.getProperty("line.separator");
				StringBuilder buf = new StringBuilder(1024);
				while ((line = bf.readLine()) != null) {
					buf.Append(line);
					buf.Append(nl);
				}
				return defineTemplate(name, buf.ToString());
			}
		*/
	}
}