/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr, Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime.debug;

import org.antlr_yggdrasil.runtime.CarrierStream;
import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.PayloadToken;
import org.antlr_yggdrasil.runtime.Payload;

/** Debug any tree node stream.  The constructor accepts the stream
 *  and a debug listener.  As node stream calls come in, debug events
 *  are triggered.
 */
public class MeteredCarrierStream extends CarrierStream {
	protected CollectedMeasures measure = new CollectedMeasures();
	protected CarrierStream input;
	protected boolean initialStreamState = true;

	/** Track the last mark() call result value for use in rewind(). */
	protected int lastMarker;

	public MeteredCarrierStream(CarrierStream input)
	{
		this.input = input;
	}

	public void setListeners(CollectedMeasures dbg) {
		this.measure = dbg;
	}

	public void consume() {
		Payload node = input.LT(1);
		input.consume();
		int ID = System.identityHashCode(node);
		String text = node.getText();
		int type = node.getType();
		measure.consumeNode(ID, text, type);
	}

	public Payload LT(int i) {
		Payload node = input.LT(i);
		int ID = System.identityHashCode(node);
		String text = node.getText();
		int type = node.getType();
		measure.LT(i, ID, text, type);
		return node;
	}

	public int LA(int i) {
		Payload node = input.LT(i);
		int ID = System.identityHashCode(node);
		String text = node.getText();
		int type = node.getType();
		measure.LT(i, ID, text, type);
		return type;
	}

	public int mark() {
		lastMarker = input.mark();
		measure.mark(lastMarker);
		return lastMarker;
	}

	public int index() {
		return input.index();
	}

	public void rewind(int marker) {
		measure.rewind(marker);
		input.rewind(marker);
	}

	public void rewind() {
		measure.rewind();
		input.rewind(lastMarker);
	}

	public void release(int marker) {
	}

	public void seek(int index) {
		// TODO: implement seek in dbg interface
		// db.seek(index);
		input.seek(index);
	}

	public int size() {
		return input.size();
	}

	public Carrier getTreeSource() {
		return input.getTreeSource();
	}

	public String toString(Object start, Object stop) {
		return input.toString(start,stop);
	}

	public void setRoot(Carrier root) {
		if (input != null)
			input.setRoot(root);
	}

	public Carrier getRoot() {
		if (input != null)
			return input.getRoot();
		
		return null;
	}
}
