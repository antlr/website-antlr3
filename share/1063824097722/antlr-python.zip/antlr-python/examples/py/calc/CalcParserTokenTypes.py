# $ANTLR 2.7.2a2 (20020112-1): "calc.g" -> "CalcLexer.py"$

class CalcParserTokenTypes:
	EOF = 1
	NULL_TREE_LOOKAHEAD = 3
	PLUS = 4
	SEMI = 5
	STAR = 6
	INT = 7
	WS = 8
	LPAREN = 9
	RPAREN = 10
	DIGIT = 11
	
	def __init__(self): pass
