#ifndef INC_LangParserTokenTypes_hpp_
#define INC_LangParserTokenTypes_hpp_

/* $ANTLR 2.7.5 (20050128): "treewalk.g" -> "LangParserTokenTypes.hpp"$ */

#ifndef CUSTOM_API
# define CUSTOM_API
#endif

#ifdef __cplusplus
struct CUSTOM_API LangParserTokenTypes {
#endif
	enum {
		EOF_ = 1,
		LCURLY = 4,
		RCURLY = 5,
		SEMI = 6,
		LITERAL_if = 7,
		LPAREN = 8,
		RPAREN = 9,
		LITERAL_else = 10,
		LITERAL_while = 11,
		ASSIGN = 12,
		PLUS = 13,
		STAR = 14,
		ID = 15,
		INT = 16,
		WS_ = 17,
		COMMA = 18,
		ESC = 19,
		DIGIT = 20,
		NULL_TREE_LOOKAHEAD = 3
	};
#ifdef __cplusplus
};
#endif
#endif /*INC_LangParserTokenTypes_hpp_*/
