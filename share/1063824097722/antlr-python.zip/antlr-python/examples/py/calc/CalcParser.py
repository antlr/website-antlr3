# $ANTLR 2.7.2a2 (20020112-1): "calc.g" -> "CalcParser.py"$

from antlr import TokenBuffer
from antlr import TokenStreamException
from antlr import TokenStreamIOException
from antlr import ANTLRException
from antlr import LLkParser
from antlr import Token
from antlr import TokenStream
from antlr import RecognitionException
from antlr import NoViableAltException
from antlr import MismatchedTokenException
from antlr import SemanticException
from antlr import ParserSharedInputState
from antlr.collections.impl import BitSet
from antlr.collections import AST
from antlr import ASTPair
from antlr.collections.impl import ASTArray

_tokenNames = [
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"PLUS",
	"SEMI",
	"STAR",
	"INT",
	"WS",
	"LPAREN",
	"RPAREN",
	"DIGIT"
]

class CalcParser(antlr.LLkParser, CalcParserTokenTypes):
	
	def __init__(self, k=0, tokenBuf=None, lexer=None, state=None):
		self.initBitSets()
		self.tokenNames = _tokenNames
		if tokenBuf:
			if k == 0:
				antlr.LLkParser.__init__(self, tokenBuf, 1)
			else:
				antlr.LLkParser.__init__(self, tokenBuf, k)
		
		elif lexer:
			if k == 0:
				antlr.LLkParser.__init__(self, lexer, 1)
			else:
				antlr.LLkParser.__init__(self, lexer, k)
		
		elif state:
			antlr.LLkParser.__init__(self, state, 1)
	
	def expr(self	):
		
		
		self.returnAST = None
		currentAST = ASTPair()
		expr_AST = None
		
		try:      # for error handling
			self.mexpr()
			self.astFactory.addASTChild(currentAST, self.returnAST)
			while 1:
				if ((self.LA(1)==PLUS)):
						tmp3_AST = None
						tmp3_AST = self.astFactory.create(self.LT(1))
						self.astFactory.makeASTRoot(currentAST, tmp3_AST)
						self.match(PLUS)
						self.mexpr()
						self.astFactory.addASTChild(currentAST, self.returnAST)
					else:
						break
					
				self.match(SEMI)
				_AST = currentAST.root
			except RecognitionException, ex:
				reportError(ex)
				consume()
				consumeUntil(_tokenSet_0)
			self.returnAST = expr_AST
		
	def mexpr(self	):
		
		
		self.returnAST = None
		currentAST = ASTPair()
		mexpr_AST = None
		
		try:      # for error handling
			self.atom()
			self.astFactory.addASTChild(currentAST, self.returnAST)
			while 1:
				if ((self.LA(1)==STAR)):
						tmp5_AST = None
						tmp5_AST = self.astFactory.create(self.LT(1))
						self.astFactory.makeASTRoot(currentAST, tmp5_AST)
						self.match(STAR)
						self.atom()
						self.astFactory.addASTChild(currentAST, self.returnAST)
					else:
						break
					
				_AST = currentAST.root
			except RecognitionException, ex:
				reportError(ex)
				consume()
				consumeUntil(_tokenSet_1)
			self.returnAST = mexpr_AST
		
	def atom(self	):
		
		
		self.returnAST = None
		currentAST = ASTPair()
		atom_AST = None
		
		try:      # for error handling
			tmp6_AST = None
			tmp6_AST = self.astFactory.create(self.LT(1))
			self.astFactory.addASTChild(currentAST, tmp6_AST)
			self.match(INT)
			_AST = currentAST.root
		except RecognitionException, ex:
			reportError(ex)
			consume()
			consumeUntil(_tokenSet_2)
		self.returnAST = atom_AST
	
	
	def mk_tokenSet_0(self):
		data = [ 2L, 0L]
		return data;
	def mk_tokenSet_1(self):
		data = [ 48L, 0L]
		return data;
	def mk_tokenSet_2(self):
		data = [ 112L, 0L]
		return data;
	
	def initBitSets(self):
		self._tokenSet_0 = BitSet(self.mk_tokenSet_0())
		self._tokenSet_1 = BitSet(self.mk_tokenSet_1())
		self._tokenSet_2 = BitSet(self.mk_tokenSet_2())
	
