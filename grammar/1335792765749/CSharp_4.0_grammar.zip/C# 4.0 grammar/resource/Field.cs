class Field {
	int IOutputFormatter.IndentationLevel {
		get { return codeBuilder.Indent; }
		set { ; }
	}
}
