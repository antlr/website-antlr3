package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.TreeBuilder;
import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.DefaultCarrier;
import org.antlr_yggdrasil.runtime.ReferenceCarrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.DefaultPayload;
import org.antlr_yggdrasil.runtime.TreeCodeBlock;
import java.util.ArrayList;

public class TreeBuilderTest extends TestCase {
	TreeBuilder builder = null;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(TreeBuilderTest.class);
	}

	public TreeBuilderTest(String arg0) {
		super(arg0);
		builder = new TreeBuilder();
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testSetIncrement() {
	}

	public void testGetIncrement() {
	}

	public void testResize() {
	}

	public void testAddPayload() {
	}
	
	public void testAddCarrier() {
	}
	
	public void testAddRef() {
	}

	public void testSetLen() {
	}

	public void testGetLen() {
	}

	public void testReset() {
		assertTrue(builder.getLen() == 0);
		Carrier carrier = new DefaultCarrier();
		builder.addCarrier(TreeCodeBlock.RIGHT, carrier);
		assertTrue(builder.getLen() == 1);
		builder.resetMark();
		assertTrue(builder.getLen() == 0);
	}

	public void testBuildFromMark() {
		Carrier[] carrier = new Carrier[20];
		for (int i=0; i<20; i++) {
			carrier[i] = new DefaultCarrier(new DefaultPayload(i, "p" + i));
		}
		
		for (int i=0; i<3; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		builder.mark();
		for (int i=3; i<6; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		builder.mark();
		for (int i=6; i<9; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		Carrier c = builder.buildFromMark();
		assertTrue(c.equals(carrier[6]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[7]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[8]));
		
		c = builder.buildFromMark();
		assertTrue(c.equals(carrier[3]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[4]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[5]));
		
		builder.addReference(TreeCodeBlock.RIGHT, new ReferenceCarrier(carrier[19]));
		
		for (int i=10; i<13; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		c = builder.buildFromMark();
		assertTrue(c.equals(carrier[0]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[1]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[2]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[19]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[10]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[11]));
		c = c.getNextSibling();
		assertTrue(c.equals(carrier[12]));
}

	public void testProcessList() {
		ArrayList v = new ArrayList();
		Carrier c0 = new DefaultCarrier(new DefaultPayload(1, "c0"));
		Payload p = new DefaultPayload(2, "p");
		Carrier c1 = new DefaultCarrier(new DefaultPayload(3, "c1"));
		v.add(c0);
		v.add(1, p);
		v.add(2, c1);
		
		builder.add(v);
		Carrier tree = builder.buildFromMark();
		System.out.println(tree.toString());
		assertTrue(tree == c0);
		Carrier cursor = tree.getNextSibling();
		assertTrue(cursor.getAttributes() == p);
		cursor = cursor.getNextSibling();
		assertTrue(cursor == c1);
	}

	public void testProcessPayloadList() {
	}

}
