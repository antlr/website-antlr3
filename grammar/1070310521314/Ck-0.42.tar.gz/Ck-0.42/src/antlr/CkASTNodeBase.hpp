/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef CKASTNODEBASE_HPP
#define CKASTNODEBASE_HPP

#include <antlr/CommonAST.hpp>
#include <antlr/config.hpp>
#include <string>

#include "../tools/datatype.hpp"

//! Our own home brewn AST node for ANTLR
/*!
 * This node provides the following extra functionality:
 * - stores result type information in the nodes with a CkDataType. This is useful
 * for type checking and for the code generation.
 * - stores information about line number so we can give useful error messages.
 * - stores scope hiding information for blocks.
 */
class CkASTNodeBase : public ANTLR_USE_NAMESPACE(antlr)CommonAST
{
 public:
    CkASTNodeBase();
    CkASTNodeBase( ANTLR_USE_NAMESPACE(antlr)RefToken t );
    CkASTNodeBase( const CkASTNodeBase& other );
    virtual ~CkASTNodeBase();

    virtual ANTLR_USE_NAMESPACE(antlr)RefAST clone( ) const;

    void initialize(int t, const ANTLR_USE_NAMESPACE(std)string& txt);
    void initialize(ANTLR_USE_NAMESPACE(antlr)RefAST t);
    void initialize(ANTLR_USE_NAMESPACE(antlr)RefToken tok);

#ifdef ANTLR_SUPPORT_XML
    virtual void initialize( ANTLR_USE_NAMESPACE(std)istream& in );
#endif

    static ANTLR_USE_NAMESPACE(antlr)RefAST factory( );

    /*** ALL THE ABOVE IS NEEDED BY ANTLR, NOW OVER TO OUR STUFF  ***/

    //! Get line number where token was defined
    unsigned int getLine() const { return LineNr; }
    //! Set line number where token was defined
    void setLine( unsigned int line ) { LineNr = line; }

    //! Set the result type of this node
    /*!
     * Constants and variables have the same result type as their definition.
     * All nodes start out with type resUndefined.
     */
    void setResultType( CkDataType::Types type ) { ResultType.setReturnType( type ); }
    void setResultType( const CkDataType &type );

    //! Get the result type of this node
    const CkDataType &getResultType() const { return ResultType; }

    //! Set if this node should ignore it's scope
    /*!
     * Unfortunatly this "hack" is needed in order to have either a single expression without a ; after it OR a open block
     */
    void setIgnoreScope( bool ignore ) { IgnoreScope = ignore; }

    //! Check if this node should ignore it's scope
    /*!
     * Unfortunatly this "hack" is needed in order to have either a single expression without a ; after it OR a open block
     */
    bool getIgnoreScope() const { return IgnoreScope; }

 private:
    unsigned int LineNr;

//    CkDataType::Types ResultType;
    CkDataType ResultType;
    bool IgnoreScope;
};

typedef antlr::ASTRefCount<CkASTNodeBase> RefCkASTNodeBase;

#endif // CKASTNODEBASE_HPP
