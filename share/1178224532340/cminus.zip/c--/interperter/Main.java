import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.HashMap;
import java.util.Vector;
import java.util.Map;
import java.io.*;

public class Main {
	
	static public CommonTreeNodeStream nodes;

    static SymbolTable symbols = new SymbolTable();

    static Boolean single_error_fatal=false;
    static Boolean error_occurred=false;
	
	static public void print_err(String s){
        if(nodes!=null){
            s="line "+Integer.toString(((CommonTree)nodes.LT(-8)).getLine())+":"+Integer.toString(((CommonTree)nodes.get(nodes.index())).getCharPositionInLine())+" "+s;
        }
		System.err.println("*** "+s);
		//FIXME: Error function returns line and char of next node, not the node that causes the error. ANTLR should add a function soon with correct noded.
        if(single_error_fatal){
            System.exit(-1);
        }else{
            error_occurred=true;
        }
	}

    static public void check_err(){
        if(error_occurred) System.exit(-1);
    }
	
    public static void main(String[] args) throws Exception{

        //Read Input
        File f = new File(args[0]); 
        FileInputStream fis = new FileInputStream(f); 
        ANTLRInputStream input = new ANTLRInputStream(fis);

        //Lexer
        CMinusLexer lexer = new CMinusLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        
        //Parser and AST construction
        CMinusParser parser = new CMinusParser(tokens);
        CMinusParser.program_return result = parser.program();
        CommonTree t = (CommonTree)result.getTree();
        //System.out.println(t.toStringTree());
        check_err();

        nodes=new CommonTreeNodeStream(t);
        
        //Function Identification
        FunctionID f_walker = new FunctionID(nodes);
        f_walker.program();
        
        //Error Checking
        nodes=new CommonTreeNodeStream(t);
        Validator v_walker = new Validator(nodes);
        v_walker.program();

        check_err();
        single_error_fatal=true;

        //Interperter
        nodes=new CommonTreeNodeStream(t);
        Eval e_walker = new Eval(nodes);
        e_walker.program();
    }
}
