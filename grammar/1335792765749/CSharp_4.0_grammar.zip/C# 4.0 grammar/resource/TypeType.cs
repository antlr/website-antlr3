class TypeType {

	static object CallMethod(Type type, string name, BindingFlags flags, object instance, params object[] args) {}
	
	static object GetProp(object instance, string name) {}
	
	FxCopRule[] GetRuleListInstanceMethod(string fxCopPath, string[] ruleAssemblies) {}
	
}
