import antlr.collections.*;
import antlr.*;

public class GrammarAST extends BaseAST {
    Token token = null;
    GrammarAST enclosingBlock = null;
    String enclosingRule = null;

    public GrammarAST getEnclosingBlock() {
        return enclosingBlock;
    }

    public void initialize(int i, String s) {
        token = new CommonToken(i,s);
    }

    public void initialize(AST ast) {
    }

    public void initialize(Token token) {
        this.token = token;
    }

    public String getText() {
        if ( token!=null ) {
            return token.getText();
        }
        return "";
    }

    public void setType(int type) {
        token.setType(type);
    }

    public int getType() {
        if ( token!=null ) {
            return token.getType();
        }
        return -1;
    }

    public int getLine() {
        if ( token!=null ) {
            return token.getLine();
        }
        return 0;
    }

    public void setEnclosingBlock(GrammarAST enclosingBlock) {
        this.enclosingBlock = enclosingBlock;
    }

    public void setEnclosingRule(String rule) {
        this.enclosingRule = rule;
    }

    public String getEnclosingRule() {
        return enclosingRule;
    }

    public GrammarAST getLastChild() {
        if ( this.getType()!=ANTLRTokenTypes.ALT ) {
            return null;
        }
        // the last child of any ALT is EOB node pointing at enclosing block
        GrammarAST[] kids = getChildrenAsArray();
        return kids[getNumberOfChildren()-1];
    }

    public GrammarAST getLastSibling() {
        GrammarAST t = this;
        GrammarAST last = null;
        while ( t!=null ) {
            last = t;
            t = (GrammarAST)t.getNextSibling();
        }
        return last;
    }

    public GrammarAST[] getChildrenAsArray() {
        AST t = getFirstChild();
        GrammarAST[] array = new GrammarAST[getNumberOfChildren()];
        int i = 0;
        while ( t!=null ) {
            array[i] = (GrammarAST)t;
            t = t.getNextSibling();
            i++;
        }
        return array;
    }
}
