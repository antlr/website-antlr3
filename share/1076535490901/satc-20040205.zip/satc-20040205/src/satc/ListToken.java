/*
 * Created on 28.11.2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package satc;

import satc.antlr.DocAST;
import antlr.CommonHiddenStreamToken;
import antlr.Token;

/**
 * @author bogdan
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListToken extends CommonHiddenStreamToken {

	private DocAST parseNode;

	/**
	 * 
	 */
	public ListToken() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ListToken(int arg0, String arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public ListToken(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	public void setHiddenAfter(CommonHiddenStreamToken t) {
		hiddenAfter = t;
	}

	public void setHiddenBefore(CommonHiddenStreamToken t) {
		hiddenBefore = t;
	}

	/**
	 * @return
	 */
	public DocAST getAST() {
		return ast;
	}

	/**
	 * @param token
	 */
	public void setAST( DocAST ast) {
		this.ast = ast;
	}
	
	/**
	 * @return
	 */
	public DocAST getPN() {
		return parseNode;
	}

	/**
	 * @param token
	 */
	public void setPN( DocAST ast) {
		this.parseNode = ast;
	}

	/**
	 * @return
	 */
	public DocAST getCleanAST() {
//p("-->getCleanParent();");
		DocAST ast = null;
		DocAST cleanAST = null;
		for (ast = this.getPN(); ast != null; ast = (DocAST) ast.getParentPN()) {	
			if (ast.isParseNode() && !ast.isDamaged()) { 
				cleanAST = ast;
//				p("--- cleanAST = " + cleanAST);
			}
		}
//p("<--return " + cleanAST);
		return cleanAST;
	}

	private void p( String s) {
		if (Syntax.filesLoaded) System.out.println( s);
	}

	private DocAST ast;
	
	public String toString() {
//		return super.toString() + "  --  ast = " + ast;
		return super.toString() + ", parseNode=" + parseNode;
	}

	public boolean equals( Token tok) {
		if (tok == null)
			return false;
		if (this.getType() != tok.getType())
			return false;
		if (tok.getText() == null && this.getText() == null)
			return true;
		else return (this.getText().equals(tok.getText()));
	}
/*	public boolean equals( Token tok) {
	public boolean equals( Object tok) {
		Token t;
		if (tok == null)
			return false;
		if (tok instanceof Token == false)
			return false;
		else
			t = (Token)tok;
		if (this.getType() != t.getType())
			return false;
		if (t.getText() == null && this.getText() == null)
			return true;
		else return (this.getText().equals(t.getText()));
	}
*/
}
