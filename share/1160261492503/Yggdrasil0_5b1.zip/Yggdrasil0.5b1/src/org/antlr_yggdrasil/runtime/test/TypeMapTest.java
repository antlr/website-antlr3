/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.TypeMap;
import org.antlr_yggdrasil.runtime.TypeInfo;

public class TypeMapTest extends TestCase {
	TypeMap map = null;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(TypeMapTest.class);
	}

	protected void setUp() throws Exception {
		map = new TypeMap();
		super.setUp();
	}
	
	public TypeMapTest() {		
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testItemIsaType() {
		map.addVariable("var", "type0");
		TypeInfo type = null;
		String next = null;
		String key = null;
		String baseName = "base";
		TypeInfo base = new TypeInfo(baseName);
		
		for (int i=0; i<4; i++) {
			next = "type" + i;
			type = new TypeInfo(next, base);
			for (int j=0; j<5; j++) {
				type.addField("type" + j, "var" + j);
			}
			base = type;
			map.setInfo(type);
		}
		
		assertTrue(map.itemIsAType("var.var0.var1", "type1"));
	}

	public void testGetInfo() {
	}

	public void testSetInfo() {
	}

	public void testRelateTypes() {
		String baseName = "base";
		TypeInfo base = new TypeInfo("base", null);
		String next = null;
		TypeInfo type = null;
		map.setInfo(base);
		int i;
		
		for (i=0; i<6; i++) {
			next = "next" + i;
			type = new TypeInfo(next, base);
			base = type;
			map.setInfo(type);
		}
		
		map.relateTypes();
		
		type = map.getInfo("base");
		assertTrue(type.isa("base"));
		for (i=0; i<6; i++) {
			assertFalse(type.isa("next" + i));
		}
		
		for (i=0; i<5; i++) {
			type = map.getInfo("next" + i);
			for (int j=i; j<6; j++)
				assertTrue(type.isa("next" + i));
		}
	}

	public void testSetAncestors() {
	}

}
