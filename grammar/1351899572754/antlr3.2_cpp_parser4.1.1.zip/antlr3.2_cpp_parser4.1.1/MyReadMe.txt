MyReadMe.txt

Version 4.1 for ANTLR 3.2, January 2011

Notes for C++ grammar file to generate ANTLR parser (in C++)
(Best viewed with tabs set to 4)

Contents
==========

1. Past

2. Present

     If you experience any problems with running these programs please read these
     notes first.

3. Future


1. Past
==========

This C++ grammar file was originally written and published in 1994 by,

Authors: Sumana Srinivasan, NeXT Inc.;            sumana_srinivasan@next.com
         Terence Parr, Parr Research Corporation; parrt@parr-research.com
         Russell Quong, Purdue University;        quong@ecn.purdue.edu

as VERSION 1.2 for use with PCCTS (The original C version of ANTLR).

Last parser version for ANTLR 2.7 is 3.2, which was maintained by 
David Wigg, Research Fellow at London South Bank University. Please see 
Reference\3.2\MyReadMe.txt for further details and history. 



2. Present
==========

Parser version 3.2 (for ANRLT 2.7) has been ported to ANTLR 3.2. The parser 
is currently functional and has all the features of that version.  Please
read:

  - HowTo.txt for build and basic usage instructions
  - Reference\3.2\MyReadMe.txt for details.  The information in that files largely 
    applies to current version.
  - Reference\3.2\NotesScopes.txt. The information applies to the current parser as well.

A C++ syntax definition (grammar.txt) is included and believed to be up to date. 
If not, please let me know.



3. Future
==========

Please e-mail the group (antlr-interest@antlr.org) of any improvement or 
modification to this grammar for the benefit of other users.

