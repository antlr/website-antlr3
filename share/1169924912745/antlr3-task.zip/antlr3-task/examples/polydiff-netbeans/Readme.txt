The following steps are necessary to integrate ANTLR3 in the build process:

1) ant-antlr3.jar 

 Do not forget to place the archive containing the antlr3 task, namely
 "ant-antlr3.jar" in the classpath. The classpath for ant can be configured in netbeans via the
 Tools->Options->ant sheet. Use Add JAR/ZIP to add ant-antr3.jar to classpath.
 
2) antlr-3.3-complete.jar

The ANTLR3 jar file (e.g. antlr-3.3-complete.jar) itself has to be added to the
Compile-time libraries via the Project-Properties dialog.

3) extend the netbeans build file

    <!-- Do not forget to place the archive containing the antlr3 task, namely
         "ant-antlr3.jar" in the ant/lib directory. The path to the ant home
         directory can be found/configured in netbeans via the
         Tools->Options->ant sheet.
         
         The antlr jar file (e.g. antlr-3.3-complete.jar) itself has to be added to the
         Compile-time libraries via the Project-Properties dialog. 
    -->
    <!-- where to place the antlr generated files -->
    <property name="src" location="src"/>
    <!-- name of the package -->
    <property name="package" value=""/>
    <!-- where to find the grammar files -->
    <property name="grammar" location="grammar"/>
    <!-- where to write/find token files -->
    <property name="token.lib" location="${src}/${package}" />

    <!-- antlr options -->
    <property name="report" value="true" />
    <property name="multithreaded" value="true" />
    <property name="debug" value="false" />

    <!-- a convenience macro which invokes antlr -->
    <macrodef name="antlr3">
        <attribute name="grammar.name"/>
        <attribute name="package" default="${package}"/>
        <sequential>
            <echo message="antlr ${grammar}/@{grammar.name}" />
            <antlr:ant-antlr3 xmlns:antlr="antlib:org/apache/tools/ant/antlr"
                  target="${grammar}/@{grammar.name}"
                  outputdirectory="${src}/@{package}"
                  libdirectory="${src}/@{package}"
                  multithreaded="${multithreaded}"
                  report="${report}"
                  debug="${debug}">
                <classpath>
                    <pathelement path="${javac.classpath}"/>
                </classpath>
            </antlr:ant-antlr3>
        </sequential>
    </macrodef>

    <!-- Modify here. Adapt the dependencies for your grammar(s).
         Watch out to specify the dependencies in the correct order!
         The sequence in which the grammars are compiled by Antlr in
         this example:
         1: Poly.g as PolyDifferentiator depends on it
         2: PolyDifferentiator as Simplifier dependends on it
         3: Simplifier.g as PolyPrinter dependends on it
         4: PolyPrinter.g
    -->
    <target name="-pre-compile" depends="PolyPrinter"/>
    <target name="PolyPrinter" depends="Simplifier">
        <antlr3 grammar.name="PolyPrinter.g"/>
    </target>
    <target name="Simplifier" depends="PolyDifferentiator">
        <antlr3 grammar.name="Simplifier.g"/>
    </target>
    <target name="PolyDifferentiator" depends="Poly">
        <antlr3 grammar.name="PolyDifferentiator.g"/>
    </target>
    <target name="Poly">
        <antlr3 grammar.name="Poly.g"/>
    </target>
    <target name="-post-clean">
        <echo message="touching grammar files in ${grammar}" />
        <touch>
            <fileset dir="${grammar}" includes="*.g"/>
        </touch>
    </target>

