/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef DATATYPE_HPP
#define DATATYPE_HPP

#include <string>

//! Complete description of a datatype.
/*!
 * All data types have a basic type which is one of the primitives void, boolean, character or integer.
 * Uninitialized datatypes start out with the type Undefined. In addition datatypes can have one or two vectors which mean that they are arrays.
 * This class can be extended later to support custom datatypes like structs and classes.
 *
 */
class CkDataType
{
public:
    //! Enum representing all the data types for the Ck language.
    enum Types{
        Undefined = 0, /*!< Unspecified data type. The initial state for empty DataType objects */
        PrimVoid,      /*!< Primitive void */
        PrimBool,      /*!< Primitive boolean */
        PrimChar,      /*!< Primitive character */
        PrimInt,       /*!< Primitive integer */
        Custom = 255   /*!< Custom datatype, structs or classes */
    };
public:
    CkDataType();
    CkDataType( Types type );
    CkDataType( Types type, int dim );
    CkDataType( Types type, int dim1, int dim2 );
    CkDataType( const CkDataType &other );

    //! destructor
    virtual ~CkDataType() {}

    void expandDimension( int dim );
    unsigned int getNumDimensions() const;
    //! Returns size of the first dimension
    unsigned int getDim1Size() const { return Dimensions[0]; }
    //! Returns size of the second dimension
    unsigned int getDim2Size() const { return Dimensions[1]; }
    //! Set the dimensions of this datatype
    /*!
     * The default is the 0,0 dimension which means that this type is not an array type.
     * \param dim1 The first dimension
     * \param dim2 The second dimension
     */
    void setDimensions( int dim1, int dim2 = 0 )
        { Dimensions[0] = dim1; Dimensions[1] = dim2; }
    //! Set the basic type of this type.
    void setReturnType( Types type ) { Type = type; }
    //! Returns the basic type of this type.
    Types getReturnType() const { return Type; }

    static std::string dataTypeToString( Types type );
    std::string toString() const;
    std::string toJVMString() const;

    // some operator overloading to make usage of this class a bit easier
    bool operator==( Types type ) const;
    bool operator!=( Types type ) const;
    bool operator==( const CkDataType &other ) const;
    bool operator!=( const CkDataType &other ) const;

    // convert routines
    CkDataType reduceDimensions( unsigned int dimensions ) const;

private:
    void commontInit();

private:
    Types Type;
    int Dimensions[2]; // if Dims[0] == 0, no array,
};

#endif // DATATYPE_HPP
