package org.antlr.java.crossref;

import java.io.IOException;
import java.util.ArrayList;

/** Abstract class.  Defines basic fields and methods for 
 *  representing packages, classes, methods, code blocks 
 *  and variables.
 */
public abstract class Scope {
	/** Which project does this scope belong to? */
	protected CodeProject project = null;

	/** What scope encloses this one?  E.g., for a class
	 *  scope, the parent will be either a ClassScope
	 *  or a PackageScope.  A package will have a parent
	 *  that is a package scope or none (indicating
	 *  it is top level).
	 */
	protected Scope parent;

	/** The name of this scope; NOT fully-qualified; E.g., class java.io.File
	 *  would result in a ClassScope whose name is "File".  It's immediate
	 *  parent would point to the PackageScope of "io" whose parent, in turn,
	 *  would be PackageScope of "java".
	 */
	protected String name;
	/**
	 * location, if any.
	 */
	protected Location loc = null;
	
	/**
	 * holds Combos for a references in this scope to other items 
	 */
	protected ArrayList refTo = null;
	/**
	 * Holds Combos representing references in other scopes to 
     * this scope 
	 */
	protected ArrayList refBy = null;
	/**
	 * Codeblocks contained in this scope (for example
     * method bodies, for loops, and try/catch bodies.
	 */
	protected ArrayList codeBlocks = null;
	

	/**
	 * Field tabIndent
     * @see tab()
	 */
	protected static int tabIndent = 0;

	/**
	 * Method tab indents text tabIndect spaces.  Used in dump()
     * @see dump()
	 */
	protected static void tab() {
		for (int i=0; i<tabIndent; i++) {
			System.out.print("  ");
		}
	}

	/**
	 * Output relevent scope information.
	 */
	public abstract void dump();

	/**
	 * Add subscope to this scope.
     * What is the difference between addScope() and addScopeMember()?
     * AddScope() is concerned with packages and classes in the hierarchy.
     * AddScopeMember() adds fields and methods to the current scope.  Fields
     * and methods "just happen" to be represented by scope information.
	 * @param s Scope
	 */
	public abstract void addScope(Scope s);

	/**
	 * Add a member to this scope. 
     * What is the difference between addScope() and addScopeMember()?
     * AddScope() is concerned with packages and classes in the hierarchy.
     * AddScopeMember() adds fields and methods to the current scope.  Fields
     * and methods "just happen" to be represented by scope information.
	 * @param s Scope
	 */
	public abstract void addScopeMember(Scope s);
	 
	/**
	 * This scope contains a reference to another scope
	 * @param s Scope
	 * @param l LocationAST
	 */
	public void addRefTo(Scope s, LocationAST l)
	{
		Combo c = new Combo(l, s);
		if(refTo == null)
			refTo = new ArrayList();
		refTo.add(c);
		return;
	}
	/**
	 * This scope is referenced by another scope
	 * @param s Scope
	 * @param l LocationAST
	 */
	public void addRefdBy(Scope s, LocationAST l)
	{
		Combo c = new Combo(l, s);
		if(refBy == null)
			refBy = new ArrayList();
		refBy.add(c);
		return;
	}

	/**
	 * Constructor for Scope
	 * @param project CodeProject
	 * @param name String
	 * @param parent Scope
	 */
	public Scope(CodeProject project, String name, Scope parent) {
		this.project = project;
		setName(name);
		setParent(parent);
	}

	/** Given a simple typename or qualified type name, find the ClassScope 
	 * @param name String
	 * @return ClassScope
	 */
	public ClassScope resolveClass(String name) {
		if ( parent!=null ) {
			return parent.resolveClass(name);
		}
		return null;
	}

	/**
	 * Given name and signature, find the method in this scope
	 * @param name String
	 * @param signature String
	 * @return MethodScope
	 */
	public MethodScope resolveMethod(String name, String signature) {
		if ( parent!=null ) {
			return parent.resolveMethod(name, signature);
		}
		return null;
	}

	/**
	 * Given the name, find the field in this scope
	 * @param name String
	 * @return FieldVariable
	 */
	public FieldVariable resolveField(String name) {
		if ( parent!=null ) {
			return parent.resolveField(name);
		}
		return null;
	}

	/** Could be a field or local or parameter 
	 * @param name String
	 * @return Variable
	 */
	public Variable resolveVariable(String name) {
		if ( parent!=null ) {
			return parent.resolveVariable(name);
		}
		return null;
	}

	/**
	 * Method getName
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/** Walk up through scopes to compute fully qualified name.
	 *  For example, if this is a class name, it will combine
	 *  the full package name + "." + getName().
	 * @return String
	 */
	public String getFullyQualifiedName() {
		String ret = null;
		if ( parent==null ) {
			ret = getName();
		}
		else
		if( name.charAt(0) == '[')
			ret = parent.getFullyQualifiedName();
		else
			ret = parent.getFullyQualifiedName() + "." + name;
		return ret;
	}

	/**
	 * Is this an instanceof a ClassScope or is the parent?
	 * @return ClassScope
	 */
	public ClassScope getNearestClass() {
		if(parent != null)
			return parent.getNearestClass();
		return null;
	}
	/**
	 * Is this an instanceof a ClassScope or MethodScope or is the parent?
	 * @return Scope
	 */
	public Scope getNearestClassOrMethodScope(){
		if(parent == null)
			return(null);
		return parent.getNearestClassOrMethodScope();
	}
	
	/**
	 * Method setName
	 * @param name String
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method getParent
	 * @return Scope
	 */
	public Scope getParent() {
		return parent;
	}

	/**
	 * Method setParent
	 * @param parent Scope
	 */
	public void setParent(Scope parent) {
		this.parent = parent;
	}

	/**
	 * Method toString
	 * @return String
	 */
	public String toString() {
		return getClass().getName()+":"+getFullyQualifiedName();
	}
	/**
	 * @return int
	 */
	public int getColumn() {
		int ret = 0;
		if(loc != null)
			ret = loc.getColumn();
		return ret;
	}

	/**
	 * @return int
	 */
	public int getLine() {
		int ret = 0;
		if(loc != null)
			ret = loc.getLine();
		return ret;
	}
	/**
	 * @return String
	 */
	public String getFilename() {
		String ret = null;
		if(loc != null)
			ret = loc.getFilename();
		return ret;
	}
	/**
	 * Method setSourceLocation
	 * @param filename String
	 * @param line int
	 * @param column int
	 * @return Location
	 */
	public Location setSourceLocation(String filename, int line, int column)
	{
		if(loc == null)
			loc = new Location(filename, Location.SOURCEFILE, line, column);
		return loc;
	}

	/**
	 * @param filename
	 * @param type
	 */
	public void setLocation(String filename, int type) {
		if(loc == null)
			loc = new Location(filename, type);
	}

	/**
	 * @param filename
	 * @param type
	 * @param line
	 * @param column
	 */
	public void setLocation(String filename, int type, int line, int column) {
		if(loc == null)
			loc = new Location(filename, type, line, column);
	}

	/**
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerializeCodeBlocks(XmlWriter xmlWriter) throws IOException 
	{
		xmlWriter.xmlOpen("CodeBlocks");
		for (int i = 0; i < codeBlocks.size(); i++) {
			CodeBlockScope codeBlockElement = (CodeBlockScope) codeBlocks.get(i);
			codeBlockElement.xmlSerialize(xmlWriter);
		}
		xmlWriter.xmlClose("CodeBlocks");
	}
	/**
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerializeTo(XmlWriter xmlWriter) throws IOException 
	{
		xmlWriter.xmlOpen("ReferenceTo");
		for (int i = 0; i < refTo.size(); i++) {
			Combo refToElement = (Combo) refTo.get(i);
			refToElement.xmlSerializeTo(xmlWriter);
		}
		xmlWriter.xmlClose("ReferenceTo");
	}

	/**
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerializeBy(XmlWriter xmlWriter) throws IOException 
	{
		xmlWriter.xmlOpen("ReferencedBy");
		for (int i = 0; i < refBy.size(); i++) {
			Combo refByElement = (Combo) refBy.get(i);
			refByElement.xmlSerializeBy(xmlWriter);
		}
			xmlWriter.xmlClose("ReferencedBy");
	}
	/** A scope and a locationAST representing a reference.
	 */
	class Combo {
		/**
		 * Field code
		 */
		protected LocationAST code;
		/**
		 * Field scope
		 */
		protected Scope scope;
		/**
		 * Constructor for Combo
		 * @param code LocationAST
		 * @param scope Scope
		 */
		public Combo(LocationAST code,Scope scope)
		{
			this.code = code;
			this.scope = scope;
		}
		/**
		 * Method xmlSerializeTo
		 * @param xmlWriter XmlWriter
		 * @throws IOException
		 */
		public void xmlSerializeTo(XmlWriter xmlWriter) throws IOException
		{
			StringBuffer s = new StringBuffer();
			if(scope == null)
			{
				s.append("Item name=\"Unresolved\"");
			}
			else 
			{
				s.append("Item name=\"" + scope.getFullyQualifiedName() + "\"");

			}

			xmlWriter.xmlOpen(s.toString());
		
			if(scope != null)
			{
				if(scope.getLine() != 0)
					xmlWriter.xmlNode("ItemLocation filename=\"" + scope.getFilename() + "\" line=\"" + scope.getLine() 
						+ "\" column=\"" + scope.getColumn() + "\"");
				else
					xmlWriter.xmlNode("ItemLocation filename=\"" + scope.getFilename() + "\"");
			}
//			if(code != null)
//				code.xmlSerializeNode(xmlWriter.out);
			if(code != null)
			{
				xmlWriter.xmlOpen("HappenedAt identifier=\"" + code.getText() +"\"");
			
				xmlWriter.xmlNode("HappenedAtLocation" + " filename=\"" + code.getFilename() + "\" line=\"" + code.getLine() 
					+ "\" column=\"" + code.getColumn() + "\"");
				xmlWriter.xmlClose("HappenedAt");
			}
			xmlWriter.xmlClose("Item");
		
		}
		/**
		 * Method xmlSerializeBy
		 * @param xmlWriter XmlWriter
		 * @throws IOException
		 */
		public void xmlSerializeBy(XmlWriter xmlWriter) throws IOException
		{
			StringBuffer s = new StringBuffer();
			s.append("Item name=\"" + scope.getFullyQualifiedName() + "\"");
			xmlWriter.xmlOpen(s.toString());
		
			if(scope.getLine() != 0)
				xmlWriter.xmlNode("ItemLocation filename=\"" + scope.getFilename() + "\" line=\"" + scope.getLine() 
				+ "\" column=\"" + scope.getColumn() + "\"");
			else
				xmlWriter.xmlNode("ItemLocation filename=\"" + scope.getFilename() + "\"");


			if(code != null)
			{
				xmlWriter.xmlOpen("HappenedAt identifier=\"" + code.getText() +"\"");
			
				xmlWriter.xmlNode("HappenedAtLocation" + " filename=\"" + code.getFilename() + "\" line=\"" + code.getLine() 
					+ "\" column=\"" + code.getColumn() + "\"");
				xmlWriter.xmlClose("HappenedAt");
			}
			xmlWriter.xmlClose("Item");
			
		
		}
	} // end class Combo
 
}

