int main()
{
  print( 1 );
}
