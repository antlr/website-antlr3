package org.antlr.java.crossref; 

import java.io.IOException;
import java.util.*;

/** Represents the definition of a CodeBlock.
 */
public class CodeBlockScope extends Scope {
	/** Should debug information be printed?
     * @see CodeProject.printDebug
	 */
	static final boolean printDebug = true;
	/** local fields
	 */
	protected Hashtable variables = null;

	/**
	 * Constructor for CodeBlockScope
	 * @param project CodeProject
	 * @param name String
	 * @param parent Scope
	 */
	public CodeBlockScope(CodeProject project, String name, Scope parent) {
		super(project,name,parent);
	}

	/**
     * Insert variable, method, or codeblock into this scope
	 * @param s Scope
	 */
	public void addScopeMember(Scope s) {
		if(CodeBlockScope.printDebug && CodeProject.printDebug)
			System.out.println("CodeBlockScope:addScopeMember " + "add local scope member "+s);

		if(s instanceof CodeBlockScope)
		{
			if(codeBlocks == null)
				codeBlocks = new ArrayList();
			codeBlocks.add(s);
		} else
		if(s instanceof Variable){
			if ( variables==null ) 
				variables=new Hashtable();
			variables.put(s.getName(),s);
		} else
		if ( s instanceof MethodScope ) 
			project.setMethodScope(s.getFullyQualifiedName(),(MethodScope)s);
		return;
	}

	/**
	 * Method resolveVariable
	 * @param name String
	 * @return Variable
	 */
	public Variable resolveVariable(String name) {
		Variable result = null;
		if ( variables!=null)
			result = (Variable) variables.get(name);
		if(result != null)
			return result;
		if ( parent!=null ) 
			result = parent.resolveVariable(name);
		
		return result;
	}

	/**
	 * System.out.print relevant information
	 */
	public void dump() {
		if ( variables!=null ) {
			Enumeration p = variables.elements();
			System.out.print("CodeBlockScope:dump "); 
			while (p.hasMoreElements()) {
				LocalVariable variable = (LocalVariable)p.nextElement();
				if ( variable.getType()!=null ) {
					System.out.print(" "+variable.getType().getFullyQualifiedName());
				}
				System.out.print(" "+variable.getName());
			}
			System.out.println("");
		}
	}

	/** XML dump()
	 * 
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		if ( variables!=null || refTo != null || refBy != null || codeBlocks != null)
			xmlWriter.xmlOpen("CodeBlock");
		if(variables != null)
		{
			Enumeration p = variables.elements();
			while (p.hasMoreElements()) {
				LocalVariable variable = (LocalVariable)p.nextElement();
				variable.xmlSerialize(xmlWriter);
			}
		}
		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
		if(codeBlocks != null)
			xmlSerializeCodeBlocks(xmlWriter);
		if ( variables!=null || refTo != null || refBy != null || codeBlocks != null)
			xmlWriter.xmlClose("CodeBlock");
	}

	/**
	 * Method addScope
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScope(org.antlr.java.crossref.Scope)
	 */
	public void addScope(Scope s) {
		if(parent != null)
			parent.addScope(s);
		return;		
	}
}
