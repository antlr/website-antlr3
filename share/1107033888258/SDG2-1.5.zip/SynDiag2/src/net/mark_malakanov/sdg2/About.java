package net.mark_malakanov.sdg2;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/About.java,v 1.5 2005/01/29 18:50:59 Mark Exp $
 *
 * Modification Log
 * $Log: About.java,v $
 * Revision 1.5  2005/01/29 18:50:59  Mark
 * new build
 *
 * Revision 1.4  2005/01/03 13:16:47  Mark
 * minor
 *
 * Revision 1.3  2004/12/29 07:35:06  Mark
 * Oracle's proprietory layouts removed
 *
 * Revision 1.2  2004/12/28 07:47:47  Mark
 * CVS keywords added
 *
 *
 */


public class About extends JPanel {
    private ActionMap actionMap1 = new ActionMap();
    private FlowLayout flowLayout1 = new FlowLayout();
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel7 = new JLabel();

    public About() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(flowLayout1);
        this.setBounds(new Rectangle(10, 10, 400, 300));
        this.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        this.setPreferredSize(new Dimension(400, 300));
        jLabel1.setText("Syntax Diagram Generator 2");
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setFont(new Font("Tahoma", 1, 18));
        jLabel1.setSize(new Dimension(300, 20));
        jLabel1.setActionMap(actionMap1);
        jLabel1.setPreferredSize(new Dimension(300, 50));
        jLabel1.setVerticalAlignment(SwingConstants.BOTTOM);
        jLabel6.setText("All rights reserved.");
        jLabel6.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel6.setPreferredSize(new Dimension(300, 16));
        jLabel6.setSize(new Dimension(300, 20));
        jLabel6.setVerticalTextPosition(SwingConstants.TOP);
        jLabel4.setText(" [The \"BSD licence\"] Copyright (c) 2003 Jia Zheng.");
        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel4.setPreferredSize(new Dimension(300, 16));
        jLabel4.setSize(new Dimension(300, 20));
        jLabel3.setText("SDG2 based on SynDiag by Jia Zheng,");
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setPreferredSize(new Dimension(300, 16));
        jLabel3.setSize(new Dimension(300, 20));
        jLabel3.setVerticalTextPosition(SwingConstants.BOTTOM);
        jLabel5.setText("All rights reserved.");
        jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel5.setFont(new Font("Tahoma", 0, 14));
        jLabel5.setPreferredSize(new Dimension(300, 50));
        jLabel5.setSize(new Dimension(300, 20));
        jLabel5.setVerticalAlignment(SwingConstants.TOP);
        jLabel2.setText("[The BSD License] (c) Mark Malakanov, 2004.");
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setFont(new Font("Tahoma", 0, 14));
        jLabel2.setPreferredSize(new Dimension(300, 50));
        jLabel2.setSize(new Dimension(300, 20));
        jLabel2.setVerticalTextPosition(SwingConstants.BOTTOM);
        jLabel2.setVerticalAlignment(SwingConstants.BOTTOM);
        jLabel7.setText("version 2.2. $Revision: 1.5 $  ");
        jLabel7.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel7.setPreferredSize(new Dimension(300, 20));
        jLabel7.setSize(new Dimension(300, 20));
        this.add(jLabel1, null);
        this.add(jLabel7, null);
        this.add(jLabel2, null);
        this.add(jLabel5, null);
        this.add(jLabel3, null);
        this.add(jLabel4, null);
        this.add(jLabel6, null);
    }
}
