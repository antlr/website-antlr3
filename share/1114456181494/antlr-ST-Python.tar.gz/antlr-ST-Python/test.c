char c;
int i;
int foo (char d, int t) {
  int i;
  for (i = 0; i < 3; i = i + 1) {
    x = 3;
    y = 5;
  }
}
