The little grammar d2u.g splits lines and line breaks into separate parts.
Then stringtemplates are used to copy (echo) the line parts to the output.
Line breaks are transformed into the format (unix, dos, mac)
specified on the commandline before writing them to the output.
If no format is specified a conversion to unix style line breaks is done.

How to build and run the d2u example:

Extract the content of the archive d2u.zip.

It should create the following directory layout:

  +- d2u
     +- src
     +- grammar
     
Prerequisites:

1) Java version 1.5 or higher installed
2) Antlr installed
3) antlr jar-archive should be part of the java classpath (see build.xml)
   or environment variable ANTLR_HOME is defined and points to the installation directory of Antlr (see build.xml.antlr_home).
4) At least apache ant version 1.7 or newer correctly installed and working
5) The antlr3 task for antlr has been installed. This usually means
   the ant-antlr3.jar archive has been copied to the apache ant lib directory or is contained in the java classpath

Building and running the example:

1) Go into the d2u directory
2) Type:
   ant run
   
Remarks to the build.xml.antlr_home build file:

The ANTLR_HOME environment variable is a central
element of the build file build.xml.antlr_home.
It is used to add the antlr jar-archive to the classpath.
The pattern defined to reference the Antlr libraries
is using wild cards. Therefore no changes of the buid
file should be necessary if a new version of Antlr
is intalled on your computer. Just let ANTLR_HOME
point to the new installation and you are done.
The relevant excerpt of the build file is listed here:

    <!-- Inquire environment variables -->
    <property environment="envList"/>

    <!-- Get environment variable ANTLR_HOME -->
    <property name="antlrHome" value="${envList.ANTLR_HOME}"/>
    
    <!-- Use wildcards in pattern definition -->
    <!-- to be independent of antlr versions -->
    <patternset id="antlr.libs">
        <include name="antlr-*.jar" />
    </patternset>

    <!-- Looking for archives in ANTLR_HOME -->
    <path id="antlr.path">
        <fileset dir="${antlrHome}" casesensitive="yes">
            <patternset refid="antlr.libs" />
        </fileset>
    </path>
    
The path "antlr.path" is then referenced in the classpath
directive various times.

Another possible point of interest is the jvmarg directive,
which is used in the antlr3 macro definition.
It passes the specified jvm args to the java machine, when Antlr
is executed. In the example below the maximum heap size is set
to 512 Megabytes.

    <jvmarg value="-Xmx512M"/>

The d2u.g grammar is not a aimed to be the basis of full grown
bullet proof tool for the conversion of line break formats.
It works quite well for small files, but when applied to real big
files (some megabytes or larger in size) then it probably
will get slow. This behaviour is owed to the standard mechanism of
Antlr to read the complete input file by the lexer and tokenize it
before invoking the parser. This standard behaviour can of course
be overriden (see the Antlr documentation). 

Running the programm manually for a conversion to mac line breaks, 
given that the antlr-3.2.jar is already part of the classpath:

java -classpath %CLASSPATH%;dist/d2u.jar org.myorg.d2u.Main mac <d2u.stg >tmp.lis

If the antlr jar-archive is not part of the classpath, but the 
environment variable ANTLR_HOME points to the directory, which
contains the very archive, you may proceed as follows:

java -classpath %ANTLR_HOME%/antlr-3.2.jar;dist/d2u.jar org.myorg.d2u.Main mac <d2u.stg >tmp.lis


