class Primitives {
	bool isDefault = 0.Equals(val);
	
	void Main() {
		isDefault = 0.Equals(val);
	}
}
