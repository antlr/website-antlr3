/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc.swing;

import java.util.logging.Logger;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AbstractDocument;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.MutableAttributeSet;

import satc.ListToken;
import satc.MultiStateLexer;
import satc.Syntax;
import satc.TokenFilter;


/**
 *  This class listens for changes in the document and rescan the affected
 *  range. 
 */
public class LexerDocumentListener implements DocumentListener {

	public MultiStateLexer lexer;
        
    /**
     * Gives notification that there was an insert into the document.  The 
     * range given by the DocumentEvent bounds the freshly inserted region.
     *
     * @param e the document event
     */
    public final void insertUpdate( DocumentEvent change) {
		log.fine("**insertUpdate();");
		initForUpdate( change, true);

        boolean nextLineIsDirty = true;
        for (lineIndex = firstLineIdx; lineIndex <= lastLineIdx; lineIndex++) {
            scanLine( doc, lineIndex, lexer, null);
            nextLineIsDirty = updateLine( doc, lineIndex, lexer);
        }   
		lineIndex = scanLinesAfterChange( lineIndex);
		
		fireTokenListChanged( startToken, endToken, firstDamagedToken, lastDamagedToken);

	 	if (Syntax.filesLoaded && Syntax.getReparseOnEdit()) {       
	 		ParserDocumentListener pdl = (ParserDocumentListener) doc.getProperty("parserDocumentListener");        
	 		pdl.updateTree(doc);     
	    }
    }

	/**
	 * Gives notification that a portion of the document has been 
	 * removed.  The range is given in terms of what the view last
	 * saw (that is, before updating sticky positions).
	 *
	 * @param e the document event
	 */
	public final void removeUpdate( DocumentEvent change) {
		log.fine("**removeUpdate();");

		initForUpdate( change, false);

		nextLineIsDirty = true;
		while( lineIndex <= root.getElementCount() & nextLineIsDirty) {
			scanLine( doc, lineIndex, lexer, null);
			nextLineIsDirty = updateLine( doc, lineIndex++, lexer);
		}
    
		fireTokenListChanged( startToken, endToken, firstDamagedToken, lastDamagedToken);

		if (Syntax.filesLoaded && Syntax.getReparseOnEdit()) {       
			ParserDocumentListener pdl = (ParserDocumentListener) doc.getProperty("parserDocumentListener");        
			pdl.updateTree(doc);     
		}
	}

	private void initForUpdate(DocumentEvent change, boolean isInsert) {
		doc = change.getDocument();
		lexer = (MultiStateLexer) doc.getProperty( "lexer");
		root = (AbstractDocument.BranchElement) doc.getDefaultRootElement();
		if (isInsert) {
			firstLineIdx = root.getElementIndex( change.getOffset() - 1) ;
			DocumentEvent.ElementChange ec = change.getChange(root);
			if (ec != null) {
				Element[] added = ec.getChildrenAdded();
				lastLineIdx = firstLineIdx + added.length;
			} else
				lastLineIdx = firstLineIdx;
		} else {
			firstLineIdx = root.getElementIndex( change.getOffset());
			lastLineIdx = firstLineIdx;
		}
		lineIndex = firstLineIdx;
		firstLine = root.getElement( firstLineIdx);
		lastLine = root.getElement( lastLineIdx);	
		startToken = null;			
		endToken = null;			
	}

	private int scanLinesAfterChange( int lineIndex) {
		ListToken tok;
		lastLine = doc.getDefaultRootElement().getElement( lineIndex - 1);
		while( lineIndex <= root.getElementCount() & nextLineIsDirty) {
//			lastLine = doc.getDefaultRootElement().getElement( lineIndex);
		    scanLine( doc, lineIndex, lexer, null);
		    nextLineIsDirty = updateLine( doc, lineIndex++, lexer);
		}
		return lineIndex;
	}

    /**
	 * @param firstToken
	 * @param lastToken
	 */
	private void fireTokenListChanged( 
		ListToken startToken, 
		ListToken endToken,
		ListToken firstDamagedToken, 
		ListToken lastDamagedToken) 
	{
		//TODO proper event notification
		log.fine("firing token list change: ");	
		log.fine("  startToken = " + startToken);	
		log.fine("  endToken = " + endToken);	
		log.fine("  firstDamagedToken = " + firstDamagedToken);	
		log.fine("  lastDamagedToken = " + lastDamagedToken);	
		tokenFilter.tokenListChanged( this, startToken, endToken, firstDamagedToken, lastDamagedToken);	
	} 

    /**
     * Gives notification that an attribute or set of attributes changed.
     *
     * @param e the document event
     */
    public final void changedUpdate( DocumentEvent e) {
		log.fine("**changedUpdate();");
        //nothing
    }
    
    /**
     * Scans the line <code>lineIndex<code/> of the document <code>doc<code/>
     */
    public void scanLine( Document doc, int lineIndex, MultiStateLexer lexer, MultiStateLexer.LexerCallback action) {
		MutableAttributeSet lineAttributes = null;
        try {
			Element line = doc.getDefaultRootElement().getElement( lineIndex);
            if( line == null) return;
			int lineCount = doc.getDefaultRootElement().getElementCount();
			log.fine("scanning line " + lineIndex + "...");
            setLexerLine( doc, lineIndex, lexer);
			ListToken token = null;
			ListToken previousLineLastToken = (ListToken)getAttribute( doc, lineIndex-1, "lastToken");
			
			lineAttributes = (MutableAttributeSet) line.getAttributes();
			
			//
			// Prepare for extra processing of the first line
			//
			ListToken oldToken;
			if (lineIndex == firstLineIdx)
				oldToken = (ListToken) lineAttributes.getAttribute("firstToken");
			else
				oldToken = null;			
			ListToken oldLastToken = null;
			if (lineIndex == firstLineIdx)
				oldLastToken = (ListToken) lineAttributes.getAttribute("lastToken");
				
			//
			// Scan the current line.
			// If this is the first line, try to reuse old tokens
			//			
			boolean isLineStart = true;
			boolean notEnd = true;
			ListToken previousToken;	
			boolean reuseEnable = true;
			startToken = previousToken = previousLineLastToken;		
			while ((token = ((ListToken)lexer.nextToken())).getType() != antlr.ANTLRTokenTypes.EOF
						 || (lineIndex == lineCount-1 && notEnd)) 
			{
				if (lineIndex == firstLineIdx && reuseEnable) {
					if (token.equals( oldToken)) {
						token = oldToken;
						startToken = oldToken;
					} else {
						reuseEnable = false;
						log.finest("oldToken = " + oldToken + ", new token = " + token);
						log.finest("### startToken = " + startToken);
					}
					if (oldToken != null)
						oldToken = (ListToken) oldToken.getHiddenAfter();
				}
				if (startToken == null) startToken = token;


				if (token.getType() == antlr.ANTLRTokenTypes.EOF) 
					notEnd = false;
                if( action != null) {
                    action.action( token);
                }
                // if first token in the line, store it
                if (isLineStart) {
					lineAttributes.addAttribute( "firstToken", token);
					log.finer("first token = " + token);
					isLineStart = false;
                }
                
				token.setHiddenBefore(previousToken);
				if (previousToken != null)
					previousToken.setHiddenAfter(token);
					
                previousToken = token;
            }

			ListToken lineLastToken = previousToken;

			ListToken nextLineFirstToken = null;
			ListToken lastOldTokenEqual = null;
 
			if (lineIndex < lineCount-1) {
				Element nextLine = doc.getDefaultRootElement().getElement( lineIndex+1);
				nextLineFirstToken = (ListToken)nextLine.getAttributes().getAttribute("firstToken");
				if (lineIndex == lastLineIdx) {
					//
					// Try to reuse tokens on the last line
					//
					endToken = nextLineFirstToken; 
					token = lineLastToken;
					oldToken = oldLastToken;
					loop:
					for (; 
						token != null && token.equals(oldToken); 
						token = (ListToken)token.getHiddenBefore()) 
					{
						if (((ListToken)token).equals((ListToken)startToken.getHiddenAfter()))
							break loop;
						lastOldTokenEqual = oldToken;
						oldToken = (ListToken)oldToken.getHiddenBefore();
					}
					
					if (token != null) {
						token.setHiddenAfter( lastOldTokenEqual);
					}
					if (lastOldTokenEqual != null) {
						lastOldTokenEqual.setHiddenBefore( token);
						endToken = lastOldTokenEqual;
					}
					if (lineLastToken.equals( oldLastToken))
						lineLastToken = oldLastToken;
				}


				if (nextLineFirstToken != null) {
					lineLastToken.setHiddenAfter( nextLineFirstToken);
					nextLineFirstToken.setHiddenBefore( lineLastToken);
				}
			}          
           
			lineAttributes.addAttribute( "lastToken", lineLastToken);
			log.finer("last token = " + lineLastToken);
        }
        catch (Exception e) {
//            System.out.println( "-->" + errorLine.toString());
            e.printStackTrace();
        }

    }
    
	public void xcanLine( Document doc, int lineIndex, MultiStateLexer lexer, MultiStateLexer.LexerCallback action) {
		try {
			Element line = doc.getDefaultRootElement().getElement( lineIndex);
			if( line == null) return;
			MutableAttributeSet lineAttributes = (MutableAttributeSet) line.getAttributes();
			ListToken token = (ListToken)lineAttributes.getAttribute("firstToken");
			ListToken lastToken = (ListToken)lineAttributes.getAttribute("lastToken");
			if( token == null) return;

			while( token != lastToken) {
				//TODO: Why null?
				if( token == null) return;
				if( action != null) {
					action.action( token);
				}
				token = (ListToken)token.getHiddenAfter();
			}
		}
		catch (Exception e) {
			System.out.println("error in xcanLine, line " + lineIndex);
			e.printStackTrace();
		}

	}    
    
    /**
    *  Updates the state attribute of the current line. If the attribute has
    *  changed, marks the next line as "dirty".
    */
    private boolean updateLine( Document doc, int lineIndex, MultiStateLexer lexer) {
        Element line = doc.getDefaultRootElement().getElement( lineIndex);
        if( line == null) return false;
        boolean nextLineIsDirty;
        MutableAttributeSet a = (MutableAttributeSet) line.getAttributes();
        String lexerState = lexer.getCurrentState();
        if(((String) line.getAttributes().getAttribute( "lexer")) != lexerState)
            nextLineIsDirty = true;
        else 
            nextLineIsDirty = false;
        a.addAttribute( "lexer", lexerState);
        return nextLineIsDirty;
    }

    /**
    *  Restricts the lexer scan range to the specified line. The starting state
    *  is fetched from the line element attribute list.
    */
    public void setLexerLine( Document doc, int lineIndex, MultiStateLexer lexer) {
        try {
            Element line = doc.getDefaultRootElement().getElement( lineIndex);
            int p0 = line.getStartOffset();
            int p1 = line.getEndOffset();
            
            String state;
            if (lineIndex == 0) state = "mainLexer";
            else {
                Element previousLine = doc.getDefaultRootElement().getElement( lineIndex - 1);
                state = (String) previousLine.getAttributes().getAttribute( "lexer");
            }
            lexer.setRange( p0, p1, state);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	private ListToken startToken;

	private ListToken endToken;

	private TokenFilter tokenFilter;

	private ListToken firstDamagedToken;
	private ListToken lastDamagedToken = null;

	/**
	 * @param tokenFilter
	 */
	public void setTokenFilter( TokenFilter tokenFilter) {
		this.tokenFilter = tokenFilter;		
	}

	public Object getAttribute( Document doc, int lineIndex, String name) {
		if (lineIndex < 0)
			return null;
		Element line = doc.getDefaultRootElement().getElement( lineIndex);
		if( line != null) {
			MutableAttributeSet a = (MutableAttributeSet) line.getAttributes();
			return a.getAttribute( name);
		}
		return null;
	}

	private Document doc;
	private AbstractDocument.BranchElement root;
	private boolean nextLineIsDirty;

	private int firstLineIdx;
	private int lastLineIdx;
	private int lineIndex;
	private Element line;
	private Element firstLine;
	private Element lastLine;
	
	private static Logger log = Logger.getLogger("satc.swing.LexerDocumentListener");
	
}

