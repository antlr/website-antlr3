/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.io.InputStream;
import java.util.HashMap;

import satc.swing.SwingDocumentStream;
import antlr.CharScanner;
import antlr.LexerSharedInputState;
import antlr.Token;
import antlr.TokenStream;
import antlr.TokenStreamSelector;


/**
*  A Lexer using "states" to support multiple-line tokens.
*  The use of states allows lines to be (re)scanned
*  individually (provided that their start state is known,
*  normally after a previous full document scan).
*  <p>
*  In this implementation, each state has its own lexer.
*  This class is a wrapper around ANTLR <code>TokenSteamSelector</code>,
*  with additional support for state switch and with different names.
*/
public class MultiStateLexer implements TokenStream {
    public InputStream inputStream;
    public TokenStreamSelector selector;
    public LexerSharedInputState inputState;
    private String currentState;

    /**
    *  Creates a new multiple state lexer.
    */
    public MultiStateLexer() {
        inputStream = new SwingDocumentStream();
        inputState = new LexerSharedInputState( inputStream);
        selector = new TokenStreamSelector();
    }
    
    /**
    *  Creates a new multiple state lexer.
    */
    public MultiStateLexer( InputStream inputStream) {
        this.inputStream = inputStream;
        inputState = new LexerSharedInputState( inputStream);
        selector = new TokenStreamSelector();
    }

    /**
     *  This method resets the lexer.  The document stream is positioned at the 
     *  begining and the state is set to <code>mainLexer</code>.
     */
    public void reset() {
        try {
            inputStream.reset();
        } catch( Exception e) {
            e.printStackTrace();
        }
        inputState.reset();
        setState("mainLexer");
    }

    /**
     *  Restricts the lexer scan range to start at index <code>p0<code/> and 
     *  end at <code>p1<code/>. The starting state is <code>state<code/>.
     */
    public void setRange( int p0, int p1, String state) {
        try {
            if( inputStream instanceof DocumentStream) 
                ((DocumentStream)inputStream).setRange( p0, p1);
            inputState.reset();
            setState( state);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
    *  Adds a new state to the lexer. The new state is called <code>state</code>
    *  and its associated lexer is <code>lexer</code>.
    */
    public void addStateLexer( CharScanner lexer, String state) {
        selector.addInputStream(lexer, state);
		addSwitchMap( state);
    }
    /**
    *  Returns the name of the current state of the lexer.
    */
    public String getCurrentState() {
        return currentState;
    }
    
    /**
    *  Sets the current state of the lexer.
    */
    public void setState( String state) {
        currentState = state;
        selector.select( state);
		switchMap = getSwitchMap( state); 
//		p("state <= " + currentState);
    }

    /**
     *  Makes the lexer switch to state <code>state</code> when a token of type 
     *  <code>tokenType</code> is encontered.
     */
    public void setSwitch( String switchFrom, int tokenType, String switchTo) {
//		p("set Switch from " + switchFrom + " to " + switchTo + " : " + tokenType);
        getSwitchMap( switchFrom).put( new Integer( tokenType), switchTo);
    }

    /**
    *  Fetches the next token. If necessary switches to a new lexer state.
    */
    public Token nextToken() {
        String nextState;
        if( token != null && (nextState = (String) switchMap.get( new Integer( token.getType()))) != null) {
            setState( nextState);
//            p("switching to ... " + nextState);
        }
        token = null;
        try {
            token = selector.nextToken();
//	if( token.getType() == satc.lang.ANTLRTokenTypes.OPTION_CLOSE)  p("\n!!! OPTION_CLOSE !!! \n");
//	if( currentState.equals("optionsLexer")) p("optionsLexer token : " + token);
        } catch (Exception e) {
            System.out.println("Exception: " + e); 
            System.out.println("Selector: " + selector); 
            e.printStackTrace();
        }
        return token;
    }

    /**
     * Scans the current range of the input executing <code>action<code/> 
     * on each token.
     */
    public void scan( MultiStateLexer.LexerCallback action) {
        try {
            Token token = null;
            while(( token = nextToken()).getType() != antlr.ANTLRTokenTypes.EOF) {
                if( action != null) {
                    action.action( token);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }       
    
    }
    
	private void addSwitchMap( String switchFrom) {
		switchMapMap.put( switchFrom, new HashMap());
//		p("addSwitchMap(  " + switchFrom);
	}
	private HashMap getSwitchMap( String switchFrom) {
//		p("getSwitchMap(  " + switchFrom);
		return (HashMap) switchMapMap.get( switchFrom);
	}
    private Token token;
    private HashMap switchMap;// = new HashMap();
    private HashMap switchMapMap = new HashMap();

    private static void p( String s) { System.out.println( s); }


    /**
     * Interface for a callback lexer action. Classes implementing this interface
     * can be used to add functionality to the document lexer.
     */
    public interface LexerCallback {
        /**
        *  The action to be performed for each new token.
        */
        public void action( Token tok);
        /**
        *  Returns true if this action is currently enabled.
        */
        public boolean isEnabled();
        /**
        *  Enables/disables this action.
        */
        public void setEnabled( boolean en);
    }
}
