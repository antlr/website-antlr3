package net.mark_malakanov.sdg2;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Iterator;
import java.util.Locale;

import javax.imageio.spi.IIORegistry;
import javax.imageio.spi.ImageWriterSpi;

import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/SaveToMultipleFilesDialog.java,v 1.9 2005/01/29 17:53:03 Mark Exp $
 *
 * Modification Log
 * $Log: SaveToMultipleFilesDialog.java,v $
 * Revision 1.9  2005/01/29 17:53:03  Mark
 * fixed drawRect with stroke specified.
 *
 * Revision 1.8  2005/01/25 07:41:23  Mark
 * ajusted
 *
 * Revision 1.7  2005/01/24 05:35:09  Mark
 * Fields ajusted
 *
 * Revision 1.6  2005/01/24 05:12:13  Mark
 * Fields ajusted
 *
 * Revision 1.5  2005/01/24 05:03:31  Mark
 * Field sizes ajusted
 *
 * Revision 1.5  2005/01/24 05:03:31  Mark
 * Field sizes ajusted
 *
 * Revision 1.4  2005/01/24 05:02:44  Mark
 * Modified By Charles.Crichton@comlab.ox.ac.uk to remove references to non-standard libraries.
 *
 * $Log: SaveToMultipleFilesDialog.java,v $
 * Revision 1.9  2005/01/29 17:53:03  Mark
 * fixed drawRect with stroke specified.
 *
 * Revision 1.8  2005/01/25 07:41:23  Mark
 * ajusted
 *
 * Revision 1.7  2005/01/24 05:35:09  Mark
 * Fields ajusted
 *
 * Revision 1.6  2005/01/24 05:12:13  Mark
 * Fields ajusted
 *
 * Revision 1.3  2005/01/03 13:16:48  Mark
 * minor

 * Revision 1.2  2004/12/28 07:47:47  Mark
 * CVS keywords added
 *
 *
 */


public class SaveToMultipleFilesDialog extends JDialog {
    private JTextField htmlDirName = new JTextField();
    private JLabel jLabel1 = new JLabel();
    private JButton jButton1 = new JButton();
    private JTextField htmlFileName = new JTextField();
    private JLabel jLabel2 = new JLabel();
    private JButton jButton2 = new JButton();
    private JComboBox imgFormat = new JComboBox();
    private JLabel jLabel3 = new JLabel();
    private JPanel jPanel1 = new JPanel();
    private JFormattedTextField htmlImgBorder = new JFormattedTextField();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JTextField htmlTitle = new JTextField();
    private JLabel jLabel6 = new JLabel();
    private JTextField htmlHeader = new JTextField();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private ActionMap actionMap1 = new ActionMap();
    private String result;
    private JTextField uniformName = new JTextField();
    private JLabel jLabel7 = new JLabel();
  private FlowLayout flowLayout1 = new FlowLayout();

    public SaveToMultipleFilesDialog() {
        this(null, "", false);
    }

    /**
     *
     * @param parent
     * @param title
     * @param modal
     */
    public SaveToMultipleFilesDialog(Frame parent, String title, boolean modal) {
        super(parent, title, modal);

        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setSize(new Dimension(400, 342));
        this.getContentPane().setLayout(null);
        this.setTitle("Save to Multiple Files");
        this.setModal(true);

        htmlDirName.setText("diagram");
        htmlDirName.setBounds(new Rectangle(120, 75, 220, 25));
        jLabel1.setText("Directory");
        jLabel1.setBounds(new Rectangle(20, 75, 95, 25));
        jLabel1.setLabelFor(htmlDirName);
        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
        jButton1.setText("...");
        jButton1.setBounds(new Rectangle(345, 75, 30, 25));

        htmlFileName.setText("diagram.html");
        htmlFileName.setBounds(new Rectangle(120, 45, 220, 25));
        jLabel2.setText("HTML File");
        jLabel2.setBounds(new Rectangle(20, 45, 95, 25));
        jLabel2.setLabelFor(htmlDirName);
        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);

        jButton2.setText("...");
        jButton2.setBounds(new Rectangle(345, 45, 30, 25));

        imgFormat.setBounds(new Rectangle(240, 105, 100, 25));
        jLabel3.setText("Format of Image Files");
        jLabel3.setBounds(new Rectangle(25, 105, 205, 25));
        jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);

        jPanel1.setBounds(new Rectangle(15, 140, 360, 110));
        jPanel1.setBorder(BorderFactory.createTitledBorder("HTML properties"));
        jPanel1.setLayout(flowLayout1);

        htmlImgBorder.setText("0");
        jLabel4.setText("Image border");
        jLabel4.setLabelFor(htmlImgBorder);
        jLabel4.setSize(new Dimension(90, 15));
        jLabel5.setText("Title");
        jLabel5.setHorizontalAlignment(SwingConstants.TRAILING);
        htmlTitle.setText("Diagram");
        jLabel6.setText("Header");
        htmlHeader.setText("Diagram");
        jButton3.setText("OK");
        jButton3.setBounds(new Rectangle(60, 260, 110, 35));
        jButton3.setActionMap(actionMap1);
        jButton3.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton3_actionPerformed(e);
                }
            });
        jButton4.setText("Cancel");
        jButton4.setBounds(new Rectangle(210, 260, 105, 35));
        jButton4.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton4_actionPerformed(e);
                }
            });
    jPanel1.add(jLabel5, null);
    jPanel1.add(htmlTitle, null);
    jPanel1.add(jLabel6, null);
        jPanel1.add(htmlHeader, null);
    jPanel1.add(jLabel4, null);
        jPanel1.add(htmlImgBorder, null);

        this.getContentPane().add(jLabel7, null);
        this.getContentPane().add(uniformName, null);
        this.getContentPane().add(jButton4, null);
        this.getContentPane().add(jButton3, null);
        this.getContentPane().add(jPanel1, null);
        this.getContentPane().add(jLabel3, null);
        this.getContentPane().add(imgFormat, null);
        this.getContentPane().add(jButton1, null);
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(htmlDirName, null);
        this.getContentPane().add(jButton2, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(htmlFileName, null);

        result = "Cancel";
    this.addWindowListener(new java.awt.event.WindowAdapter() {
        public void windowOpened(WindowEvent e) {
          this_windowOpened(e);
        }
      });
    this.setBounds(new Rectangle(20, 10, 400, 342));
    jLabel6.setPreferredSize(new Dimension(45, 14));
    htmlTitle.setPreferredSize(new Dimension(285, 20));
    htmlImgBorder.setPreferredSize(new Dimension(30, 22));
    jLabel5.setPreferredSize(new Dimension(45, 14));
    htmlHeader.setPreferredSize(new Dimension(285, 20));
        imgFormat.setToolTipText("Only filetypes supported by your environment");
        jButton1.setToolTipText("Select from filesystem");
        jButton2.setToolTipText("Select from filesystem");
        htmlImgBorder.setToolTipText(
            "Width of border around each image on the HTML page");
        htmlHeader.setToolTipText("This will be printed on HTML page");
        htmlTitle.setToolTipText(
            "Title of HTML. This will be shown on the browser header");
        htmlFileName.setToolTipText("HTML file that binds all rule images");
        uniformName.setToolTipText("Press Enter to propagate to other fields");
        jLabel6.setHorizontalAlignment(SwingConstants.TRAILING);
        uniformName.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    uniformName_actionPerformed(e);
                }
            });
        jLabel7.setHorizontalAlignment(SwingConstants.TRAILING);
        jLabel7.setBounds(new Rectangle(10, 10, 105, 25));
        jLabel7.setText("Uniform Name");
        uniformName.setBounds(new Rectangle(120, 10, 220, 25));
        uniformName.setText("Diagram");
        jButton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton2_actionPerformed(e);
                }
            });
        jButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });

        populateFormatList();
    }

    public String getHtmlDirName() {
        return htmlDirName.getText();
    }

    public String getHtmlFileName() {
        return htmlDirName.getText();
    }

    public String getImgFormat() {
        return imgFormat.getSelectedItem().toString();
    }

    public String getHtmlImgBorder() {
        return htmlImgBorder.getText();
    }

    public String getHtmlTitle() {
        return htmlTitle.getText();
    }

    public String getHtmlHeader() {
        return htmlHeader.getText();
    }

    public String getResult() {
        return result;
    }

    private void jButton3_actionPerformed(ActionEvent e) {
        result = "OK";
        setVisible(false);
    }

    private void jButton4_actionPerformed(ActionEvent e) {
        result = "Cancel";
        setVisible(false);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        JFileChooser chooser = new JFileChooser(".");

        int returnVal = chooser.showSaveDialog(null);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            htmlFileName.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void jButton2_actionPerformed(ActionEvent e) {
        JFileChooser chooser = new JFileChooser(".");

        chooser.addChoosableFileFilter(new UniversalFilter( new String[]{"htm","html"},
                "HTML file"));

        int returnVal = chooser.showSaveDialog(null);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            htmlFileName.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void populateFormatList() {
        IIORegistry iior = IIORegistry.getDefaultInstance();
        Iterator spi = iior.getServiceProviders(ImageWriterSpi.class, true);

        while (spi.hasNext()) {
            ImageWriterSpi writerSpi = (ImageWriterSpi) spi.next();
            String fn = writerSpi.getDescription(Locale.US);
            String[] sfxs = writerSpi.getFileSuffixes();

            for (int i = 0; i < sfxs.length; i++) {
                imgFormat.addItem(sfxs[i]);
            }
        }

        imgFormat.setSelectedIndex(0);
    }

    private void uniformName_actionPerformed(ActionEvent e) {
        htmlDirName.setText(uniformName.getText().replace(' ', '_'));
        htmlFileName.setText(uniformName.getText().replace(' ', '_') + ".html");
        htmlHeader.setText(uniformName.getText());
        htmlTitle.setText(uniformName.getText());
    }

    public void setUniformName(String un) {
        uniformName.setText(un);
        uniformName_actionPerformed(null);
    }

  private void this_windowOpened(WindowEvent e) {
    
  }
}
