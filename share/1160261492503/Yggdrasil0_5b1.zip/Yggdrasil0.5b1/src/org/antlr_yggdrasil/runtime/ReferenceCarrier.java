/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

/**
 * @author lgc
 *
 */
public class ReferenceCarrier extends DefaultCarrier {
	private Carrier carrier = null;

	/**
	 * 
	 */
	public ReferenceCarrier() {
	}

	/**
	 * @param pay
	 */
	public ReferenceCarrier(Payload pay) {
		setCarrier(pay.wrap());
	}
	
	public ReferenceCarrier(Carrier c) {
		setCarrier(c);
	}

	/**
	 * @param ref The ref to set.
	 */
	public void setCarrier(Carrier ref) {
		this.carrier = ref;
	}

	/**
	 * @return Returns the referenced Carrier.
	 */
	public Carrier getCarrier() {
		return carrier;
	}
	/* (non-Javadoc)
	 * @see antlr.Carrier#getAttributes()
	 */
	public Payload getAttributes() {
		return carrier.getAttributes();
	}
	
	public String getText() {
		if (carrier.getAttributes() != null) {
			return carrier.getAttributes().getText();
		}
		return null;
	}
	
	public int getType() {
		if (carrier.getAttributes() != null) {
			return carrier.getType();
		}
		
		return -1;
	}
	
	/* (non-Javadoc)
	 * @see antlr.Carrier#setAttributes(antlr.Payload)
	 */
	public void setAttributes(Payload pay) {
		if (carrier == null)
			carrier = new DefaultCarrier(pay);
		else
			carrier.setAttributes(pay);
	}
	
	public void setText(String text) {
		if (carrier.getAttributes() == null) {
			// TODO:  Throw exception here
		}
		
		carrier.setText(text);
	}

	public void setType(int type_) {
		if (carrier.getAttributes() == null) {
			// TODO:  Throw exception here
		}
		
		carrier.setType(type_);
	}

	public Object clone() {
		Carrier replicant = null;
		if (carrier == null)
			replicant = new ReferenceCarrier();
		else
			replicant = new ReferenceCarrier(carrier);
		
		return (Object) replicant;
	}
	
	public Carrier copy() {
		if (carrier == null)
			return null;
		else
			return carrier.copy();
	}
	
	public boolean equals(Carrier c) {
		ReferenceCarrier d = (ReferenceCarrier) c;
		
		if (right != d.right)
			return false;
		
		if (down != d.down)
			return false;
		
		if (type != d.type)
			return false;
		
		if (attributes != d.attributes)
			return false;
		
		if (carrier != d.carrier)
			return false;
		
		return true;
	}
	

}
