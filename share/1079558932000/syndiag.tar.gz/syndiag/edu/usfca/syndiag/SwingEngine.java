package edu.usfca.syndiag;

import java.awt.*;
import javax.swing.*;

public class SwingEngine implements GraphicsEngine{
	Graphics2D g2 = null;
	
	public void setGraphics2D(Graphics2D g2){
		this.g2 = g2;
	}
	
	public void drawLine(int x1, int y1, int x2, int y2){
		g2.drawLine(x1, y1, x2, y2);
	}
	
	public void drawString(String str, int x, int y){
		g2.drawString(str, x, y);
	}
	
	public void drawString(String str, int x, int y, Font f){
		g2.setFont(f);
		g2.drawString(str, x, y);
	}
	
	public void drawOval(int x, int y, int w, int h){
		g2.drawOval(x, y, w, h);
	}
	
	public void drawRect(int x, int y, int w, int h){
		g2.drawRect(x, y, w, h);
	}
	
	public void drawRect(int x, int y, int w, int h, Stroke s){
		g2.setStroke(s);
		g2.drawRect(x, y, w, h);
		g2.setStroke(new BasicStroke());
	}
	
	public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints){
		g2.fillPolygon(xPoints, yPoints, nPoints);
	}
}
