/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using Antlr.StringTemplate;
using Antlr.StringTemplate.Language;

namespace Antlr.StringTemplate.Language {

	using System;
	using System.IO;
	using System.Collections;
	using System.Reflection;

	using AST = antlr.collections.AST;
	using RecognitionException = antlr.RecognitionException;

	/** A single string template expression enclosed in $...; separator=...$
	 *  parsed into an AST chunk to be evaluated.
	 */
	public class ASTExpr : Expr {
		public const String DEFAULT_ATTRIBUTE_NAME = "attr";
		public const String DEFAULT_INDEX_VARIABLE_NAME = "i";

		protected internal AST exprTree = null;

		/** store separator etc... */
		Hashtable options = null;

		public ASTExpr(StringTemplate enclosingTemplate, AST exprTree, Hashtable options) 
			: base (enclosingTemplate) {

			this.exprTree = exprTree;
			this.options = options;
		}

		/** Return the tree interpreted when this template is written out. */
		public AST AST {
			get {
				return exprTree;
			}
		}

		/** To write out the value of an ASTExpr, invoke the evaluator in eval.g
		 *  to walk the tree writing out the values.  For efficiency, don't
		 *  compute a bunch of strings and then pack them together.  Write out directly.
		 */
		public override void Write(StringTemplate self, TextWriter outWriter) {
			if ( exprTree == null || self == null || outWriter == null ) {
				return;
			}
			//Console.WriteLine("evaluating tree: " + exprTree.toStringList());
			StringTemplateLanguageEvaluator eval =
				new StringTemplateLanguageEvaluator(self, this, outWriter);
			try {
				eval.action(exprTree); // eval and write out tree
			}
			catch (RecognitionException re) {
				self.Error("can't evaluate tree: " + exprTree.ToStringList(), re);
			}
		}

		// HELP ROUTINES CALLED BY EVALUATOR TREE WALKER

		public Object ApplyListOfAlternatingTemplates(StringTemplate self,
			Object attributeValue,
			IList templatesToApply) {

			if ( attributeValue == null || templatesToApply == null || templatesToApply.Count==0 ) {
				return null; // do not apply if missing templates or empty value
			}

			//Console.WriteLine("list of templates: " + templatesToApply);
			StringTemplate embedded = null;
			Hashtable argumentContext = null;

			if ( attributeValue is IList ) {
				IList attributeList = (IList) attributeValue;
				IList resultArrayList = new ArrayList(attributeList.Count);

				for (int i = 0; i < attributeList.Count; i++) {
					Object ithValue = attributeList[i];

					if ( ithValue == null ) {
						// weird...a null value in the list; ignore
						continue;
					}

					int templateIndex = i % templatesToApply.Count; // rotate through
					embedded = (StringTemplate) templatesToApply[templateIndex];
					argumentContext = new Hashtable();
					argumentContext[DEFAULT_ATTRIBUTE_NAME] = ithValue;
					argumentContext[DEFAULT_INDEX_VARIABLE_NAME] = i;
					embedded.ArgumentContext = argumentContext;
					evaluateArguments(embedded);
					/*
					Console.WriteLine("applyTemplate(" + embedded.Name + ", args=" + argumentContext+
							" to attribute value " + attributeValue);
					*/
					Object value = embedded.ToString();  // apply template
					resultArrayList.Add(value);
					// can try to save embedded string template one day instead of
					// doing a toString().
				}

				return resultArrayList;
			}
			else {
				/*
				Console.WriteLine("setting attribute " + DEFAULT_ATTRIBUTE_NAME + " in arg context of "+
				embedded.Name+
				" to " + attributeValue);
				*/
				embedded = (StringTemplate) templatesToApply[0];
				argumentContext = new Hashtable();
				argumentContext[DEFAULT_ATTRIBUTE_NAME] = attributeValue;
				argumentContext[DEFAULT_INDEX_VARIABLE_NAME] = 0;
				embedded.ArgumentContext = argumentContext;
				evaluateArguments(embedded);

				return embedded;
			}
		}

		/** Return o.getPropertyName() given o and propertyName.  Special case:
		 *  If the method returns a bool, then you must return NULL if bool is false.
		 *  Otherwise, it will always return an object and IF statements never fail.
		 */
		public Object GetObjectProperty(StringTemplate self, Object o, String propertyName) {
			if ( o == null || propertyName == null ) {
				return null;
			}
			
			Type c = o.GetType();
			Object value = null;

			try {
				PropertyInfo pi = c.GetProperty(propertyName, new Type[0]);

				if (pi != null) {
					value = pi.GetValue(o, null);
				}

				if ( StringTemplate.InDebugMode ) {
					self.Debug(String.Format("Property {0} returned {1} <{2}>", 
						propertyName, (value != null ? value : "null"), 
						(value != null ? value.GetType().Name : "null")));
				}

				String methodName = "Get" + propertyName;
				MethodInfo mi = c.GetMethod(methodName, new Type[0]);

				if (mi != null) {
					value = mi.Invoke(o, null);
				}

				if ( StringTemplate.InDebugMode ) {
					self.Debug(String.Format("Method {0} returned {1} <{2}>", 
						methodName, (value != null ? value : "null"), 
						(value != null ? value.GetType().Name : "null")));
				}

				if ( value != null && value.GetType() == typeof(bool) ) {
					if ( ((bool) value) == false ) {
						value = null; // kill value to imply false in StringTemplate IF statement
					}
				}
			}
			catch (Exception e) {
				self.Error("Can't get property " + propertyName + 
					" from " + c.Name + " instance.", e);
			}
			return value;
		}

		/** For strings or other objects, catenate and return.
		 *  For Int32, add and return Int32.
		 */
		public Object Add(Object a, Object b) {
			if ( a == null ) { // a null value means don't do cat, just return other value
				return b;
			}
			else if ( b == null ) {
				return a;
			}

			if ( a is Int32 && b is Int32 ) {
				return ((Int32) a) + ((Int32) b);
			}

			return a.ToString() + b.ToString();
		}

		/** Call a string template with args and get text result */
		public String GetTemplateText(StringTemplate self,
			String templateName,
			Hashtable argumentContext) {
			StringTemplateGroup group = self.Group;
			StringTemplate embedded = group.GetEmbeddedInstanceOf(self, templateName);
			if ( embedded == null ) {
				self.Error("cannot make emedded instance of " + templateName);
				return null;
			}
			embedded.ArgumentContext = argumentContext;
			String text = embedded.ToString();
			return text;
		}

		/** How to spit out an object.  If it's not a StringTemplate nor a
		 *  List, just do o.ToString().  If it's a StringTemplate,
		 *  do o.write(out).  If it's a ArrayList, do a write(out,
		 *  o.elementAt(i)) for all elements.  Note that if you do
		 *  something weird like set the values of a multivalued tag
		 *  to be vectors, it will effectively flatten it.
		 *
		 *  If self is an embedded template, you might have specified
		 *  a separator arg; used when is a vector.
		 */
		public void WriteAttribute(StringTemplate self, Object o, TextWriter outWriter) {
			Object separator = null;

			if ( options != null ) {
				separator = options["separator"];
			}

			write(self, o, outWriter, separator);
		}

		protected void write(StringTemplate self, Object o, TextWriter outWriter, Object separator) {
			if ( o == null ) {
				return;
			}

			try {
				if ( o is StringTemplate ) {
					((StringTemplate) o).Write(outWriter);
				}
				else if ( o is IList ) {
					IList l = (IList) o;
					IEnumerator e = l.GetEnumerator();
					String separatorString = null;

					if ( separator != null ) {
						separatorString = computeSeparator(self, separator);
					}

					int i = 0;

					while ( e.MoveNext() ) {
						write(self, e.Current, outWriter, separator);

						if ( i++ < l.Count - 1 ) {
							if ( separator != null ) {
								outWriter.Write(separatorString);
							}
						}
					}
				}
				else {
					outWriter.Write(o.ToString());
				}
			}
			catch (IOException io) {
				self.Error("problem writing object: " + o, io);
			}
		}

		/** A separator is normally just a string literal, but is still an AST that
		 *  we must evaluate.  The separator can be any expression such as a template
		 *  include or string cat expression etc...
		 */
		protected String computeSeparator(StringTemplate self, Object separator) {
			if ( separator == null ) {
				return null;
			}

			if ( separator is StringTemplateAST ) {
				StringTemplateAST separatorTree = (StringTemplateAST) separator;
				// must evaluate, writing to a string so we can hand on to it
				ASTExpr e = new ASTExpr(this.EnclosingTemplate, separatorTree, null);
				StringWriter sw = new StringWriter();

				try {
					e.Write(self, sw);
				}
				catch (IOException ioe) {
					self.Error("can't evaluate separator expression", ioe);
				}

				return sw.ToString();
			}
			else {
				// just in case we expand in the future and it's something else
				return separator.ToString();
			}
		}

		protected void evaluateArguments(StringTemplate self) {
			StringTemplateAST argumentsAST = self.ArgumentsAST;

			if ( argumentsAST == null || argumentsAST.getFirstChild() == null ) {
				// return immediately if missing tree or no actual args
				return;
			}

			StringTemplateLanguageEvaluator eval =
				new StringTemplateLanguageEvaluator(self, this, null);
			try {
				// using any initial argument context (such as when attr is set),
				// evaluage the arg list like bold(item=attr).  Since we pass
				// in any existing arg context, that context gets filled with
				// new values.  With bold(item=attr), context becomes:
				// {[attr=...],[item=...]}.
				Hashtable ac = eval.argList(argumentsAST, self.ArgumentContext);
				self.ArgumentContext = ac;
			}
			catch (RecognitionException re) {
				self.Error("can't evaluate tree: " + argumentsAST.ToStringList(), re);
			}
		}
	}
}