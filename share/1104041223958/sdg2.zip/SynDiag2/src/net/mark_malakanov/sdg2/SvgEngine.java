package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */

import edu.usfca.syndiag.*;
import java.awt.*;
import java.io.*;

public class SvgEngine implements GraphicsEngine {

  FileWriter wrtr;
	String title;
  String color;
  String bgColor;
  
  public SvgEngine() {
    title = "antlr svg";
    color = "black";
    bgColor = "white";
    stroke_width = "1";
    stroke_linecap = "inherit";
    stroke_join  = "inherit";
    stroke_dasharray = "0,6,0,6";
    stroke_dashoffset = "0";
    font_name = "arial";
    font_size = "10";
  }
  
  public void init(String title) {
    this.title = title;
  }
  
	public void setWriter( String FileName ) 
  {
    try {
		  this.wrtr = new FileWriter(FileName);
    } catch ( IOException e ) {
      new RuntimeException(e);
    }
  }

  private void println(String s) {
    try {
      wrtr.write(s);
      wrtr.write("\n");
    } catch ( IOException e ) {
      new RuntimeException(e);
    }
  }

  public void setColor(Color c) {
    color = "#" + (new Integer(c.getRGB())).toHexString(6);
  }
  
  public void setColor(String c) {
    color = c;
  }
  
  public void setBgColor(Color c) {
    bgColor = "#" + (new Integer(c.getRGB())).toHexString(6);
  }
  
  public void setBgColor(String c) {
    bgColor = c;
  }
  
	public void beginDraw(Rectangle rect) {
    println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	  println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1 Tiny//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11-tiny.dtd\">");
	  println("<!--======================================================================-->");
	  println("<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.2\" "
        +"width=\"100%\" height=\"100%\""+
        " viewBox=\"0 0 " + String.valueOf(rect.width)+" "+ String.valueOf(rect.width)+"\" >");
    println("<title id=\"antlr to swg\">" + title + "</title>");
		println("<g id=\"svg-body-content\">");
	}

	public void endDraw() {
    try {
      println("</g>");
      println("</svg>");
      wrtr.close();
    } catch ( IOException e ) {
      new RuntimeException(e);
    }
	}

	public void drawLine(int x1, int y1, int x2, int y2){
		println("<line x1=\""+String.valueOf(x1) + "\" y1=\"" +String.valueOf(y1) 
      +"\" x2=\""+String.valueOf(x2) + "\" y2=\"" +String.valueOf(y2)
      +"\" stroke=\"" + color + "\"" 
      +" stroke-width=\""+ stroke_width + "\" />");
	}
	
	public void drawString(String str, int x, int y){
		println("<text x=\""+String.valueOf(x) + "\" y=\"" +String.valueOf(y) 
      +"\" font-size=\"" + font_size 
      +"\" stroke=\"none\""+
      "  fill=\"" + color + "\"" 
      +" name=\""+ font_name +"\">"
      + str + "</text>");
	}
	
  String font_name, font_size;
	public void setFont(Font f){
    font_name = f.getFontName();
    font_size = String.valueOf(f.getSize());
	}

	public void drawString(String str, int x, int y, Font f){
		setFont(f);
		drawString(str, x, y);
	}
	
	public void drawOval(int x, int y, int w, int h){
		//g2.drawOval(x, y, w, h);
		println("<rect x=\""+String.valueOf(x) + "\" y=\"" +String.valueOf(y) 
      +"\" width=\""+String.valueOf(w) + "\" height=\"" +String.valueOf(h)
      +"\" rx=\"14\" ry=\"10\"" 
      +" fill=\""+bgColor+"\"" + " stroke=\"" + color +"\""
      +" stroke-width=\""+ stroke_width + "\" />");
	}
	
	public void drawRect(int x, int y, int w, int h){
		println("<rect x=\""+String.valueOf(x) + "\" y=\"" +String.valueOf(y) 
      +"\" width=\""+String.valueOf(w) + "\" height=\"" +String.valueOf(h)
      +"\" fill=\""+bgColor+"\"" +" stroke=\"" + color +"\"" 
      +" stroke-width=\""+ stroke_width + "\" />");
	}
	
  String stroke;
  String stroke_width;
  String stroke_linecap;
  String stroke_join;
  String stroke_dasharray;
  String stroke_dashoffset;
  public void setStroke(Stroke s) {
    BasicStroke bs = (BasicStroke)s;
    stroke_width = String.valueOf(bs.getLineWidth());
    
    stroke_linecap = "inherit";
    switch (bs.getEndCap()) { //butt | round | square | inherit)
    case BasicStroke.CAP_BUTT : {stroke_linecap = "butt"; break;}
    case BasicStroke.CAP_ROUND : {stroke_linecap = "round"; break;}
    case BasicStroke.CAP_SQUARE : {stroke_linecap = "square"; break;}
    }
    
    stroke_join = "inherit";
    switch (bs.getLineJoin()) { // (miter | round | bevel | inherit)
     case BasicStroke.JOIN_BEVEL : { stroke_join = "bevel"; break; }
     case BasicStroke.JOIN_MITER : { stroke_join = "miter"; break; }
     case BasicStroke.JOIN_ROUND : { stroke_join = "round"; break; }
    }
    
    float[] f = bs.getDashArray();
    stroke_dasharray = f.toString();
    
    stroke_dashoffset = String.valueOf(bs.getDashPhase());
  }
  
	public void drawRect(int x, int y, int w, int h, Stroke s){
		setStroke(s);
    drawRect(x, y, w, h);
	}
	
	public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints){
		String points = "";
    for (int i=0; i<nPoints; i++) {
      points += String.valueOf(xPoints[i])+","+String.valueOf(yPoints[i])+" ";
    }
		println("<polygon "
      +" fill=\""+color+"\"" 
      +" stroke=\"" + color + "\"" 
      +" stroke-width=\""+ stroke_width + "\""
      +" points=\""+ points +"\" />" );
	}

}
