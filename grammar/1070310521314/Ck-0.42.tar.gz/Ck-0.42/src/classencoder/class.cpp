/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include <fstream>

#include "class.hpp"
#include "defs.hpp"
#include "method_info.hpp"

namespace ClassEncoder
{
using namespace std;

//! Default constructor
/*!
 * \param className Name of the class. Output file is named this with .class added.
 */
Class::Class( const std::string &className )
{
    ClassName = className;
}

//! Default destructor
/*!
 * Empty
 */
Class::~Class()
{
}

//! Write classfile to disk.
/*!
 * Writes this classfile to disk going through all the constant pool and attribute entries.
 * \param file the filename to use when writing.
 */
void Class::write( )
{
    string file = ClassName + ".class";
    ofstream classFile( file.c_str(), ios::out | ios::binary );

    // put some default stuff in the constant_pool

    // we do not do any inheritance at this point, tell JVM we inherit from java.lang.Object
    unsigned int utfPos = ConstantPoolEntries.count() + 2;
    u2 super_class = ConstantPoolEntries.add( new Class_info( utfPos ) );
    ConstantPoolEntries.add( new Utf8_info( "java/lang/Object" ) );

    // we're not going to use multiple classes either, just name this class output
    utfPos = ConstantPoolEntries.count() + 2;
    u2 this_class = ConstantPoolEntries.add( new Class_info( utfPos ) );
    ConstantPoolEntries.add( new Utf8_info( ClassName ) );

    //*** START THE REAL WRITING ***
    // u4 magic
    writeu4( classFile, JVM_MAGIC );

    // u2 minor_version
    writeu2( classFile, JVM_MINOR_VER );
    // u2 major_version
    writeu2( classFile, JVM_MAJOR_VER );

    // u2 constant_pool_count;
    writeu2( classFile, ConstantPoolEntries.count() + 1 );
    // cp_info constant_pool[constant_pool_count-1];
    ConstantPoolEntries.write( classFile );

//  u2 access_flags; empty for now
    writeu2( classFile, ACC_SUPER );
//  u2 this_class;
    writeu2( classFile, this_class );
//  u2 super_class;
    writeu2( classFile, super_class );

//  u2 interfaces_count;
//  u2 interfaces[interfaces_count];
    writeu2( classFile, 0 );

//  u2 fields_count;
//  field_info fields[fields_count];
    writeu2( classFile, 0 );

//  u2 methods_count;
//  method_info methods[methods_count];
    writeu2( classFile, Methods.size() );
    for( vector<method_info*>::iterator it = Methods.begin(); it != Methods.end(); ++it )
    {
        (*it)->write( classFile );
    }

//  u2 attributes_count;
//  attribute_info attributes[attributes_count];
    writeu2( classFile, 0 );

    classFile.close();
}

//! Add a new method to this class
/*!
 * Adds a new method_info object containing a method to this class.
 * \param name the name of the method. Note that the constructor always has the specialname <init>
 * \return A pointer to the method_info object. The method_info object will be deleted when this object is deleted or goes out of scope.
 */
method_info *Class::addMethod( const string &name )
{
    method_info *method = new method_info( &ConstantPoolEntries, name );
    Methods.push_back( method );
    return method;
}

} // end namespace
