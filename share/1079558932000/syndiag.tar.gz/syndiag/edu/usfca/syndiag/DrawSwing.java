package edu.usfca.syndiag;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DrawSwing{
	public void draw(AST t){	
        final DrawDemo demo = new DrawDemo();
        demo.init();
        demo.setAST(t);
        final JFrame f = new JFrame("Java 2D(TM) Demo - Draw");

        JScrollPane sp = new JScrollPane(demo);

		f.setContentPane(sp);

		f.setVisible(true);
		
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            	f.setVisible(false);
            	f.dispose();
            	System.exit(0);
            	}
        });

        f.pack();
        f.setSize(new Dimension(750,950));
        f.show();
    }
}
