// $ANTLR 2.7.6 (2005-12-22): "YggdrasilGen.g" -> "YggdrasilCodeGen.java"$

/*
 [The "BSD licence"]
 Copyright (c) 2005-2006 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.generated;
	import org.antlr_yggdrasil.tool.Rule;
	import org.antlr_yggdrasil.tool.Grammar;
	import org.antlr_yggdrasil.tool.GrammarAST;
	import org.antlr_yggdrasil.tool.ErrorManager;
	import org.antlr_yggdrasil.codegen.CodeGenerator;
	import org.antlr_yggdrasil.analysis.Label;
	import org.antlr_yggdrasil.analysis.DFA;
	import org.antlr_yggdrasil.misc.IntSet;
	import org.antlr_yggdrasil.runtime.TypeInfo;
	import org.antlr_yggdrasil.runtime.ArrayInfo;
	import java.util.*;
	import org.antlr.stringtemplate.*;
    import antlr.TokenWithIndex;
    import antlr.CommonToken;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** Walk a grammar and generate code by gradually building up
 *  a bigger and bigger StringTemplate.
 *
 *  Terence Parr
 *  University of San Francisco
 *  June 15, 2004
 */
public class YggdrasilCodeGen extends antlr.TreeParser       implements YggdrasilCodeGenTokenTypes
 {

	protected static final int RULE_BLOCK_NESTING_LEVEL = 0;
	protected static final int OUTER_REWRITE_NESTING_LEVEL = 0;

    protected String currentRuleName = null;
    protected int blockNestingLevel = 0;
	protected int outerAltNum = 0;
    protected StringTemplate currentBlockST = null;

    public void reportError(RecognitionException ex) {
		Token token = null;
		if ( ex instanceof MismatchedTokenException ) {
			token = ((MismatchedTokenException)ex).token;
		}
		else if ( ex instanceof NoViableAltException ) {
			token = ((NoViableAltException)ex).token;
		}
        ErrorManager.syntaxError(
            ErrorManager.MSG_SYNTAX_ERROR,
            token,
            "codegen: "+ex.toString(),
            ex);
    }

    public void reportError(String s) {
        System.out.println("codegen: error: " + s);
    }

    protected CodeGenerator generator;
    protected Grammar grammar;
    protected StringTemplateGroup templates;
    protected StringTemplateGroup userTemplates;
    protected boolean inSynPred = false;
    protected boolean addingAttributes = true;
    protected boolean killChars = false;
    protected boolean isTree = true;

    /** The overall lexer/parser template; simulate dynamically scoped
     *  attributes by making this an instance var of the walker.
     */
    protected StringTemplate recognizerST;

    protected StringTemplate outputFileST;
    protected StringTemplate headerFileST;
    protected StringTemplate factoryFileST;
    protected StringTemplate vpublic;
    protected StringTemplate variables;

    protected String outputOption = "";

	protected StringTemplate getWildcardST(GrammarAST elementAST, GrammarAST ast_suffix, String label) {
		if ( grammar.type==Grammar.LEXER ) {
			StringTemplate retval = templates.getInstanceOf("wildcardChar");
			if (killChars) {
				retval.setAttribute("skip", "true");
			}
			return retval;	
		}
		else
			return templates.getInstanceOf("wildcard");
	}


    protected void init(Grammar g) {
        this.grammar = g;
        this.generator = grammar.getCodeGenerator();
        this.templates = generator.getTemplates();
	vpublic = templates.getInstanceOf("public");
	variables = templates.getInstanceOf("variables");
	factoryFileST = templates.getInstanceOf("factory");
    }

	protected void setAccessorNames(StringTemplate a, String nm) {
		String firstChar = nm.substring(0,1).toUpperCase();
		String uname = firstChar + nm.substring(1);
		a.setAttribute("name", nm);
		a.setAttribute("uname", uname);
	}

	protected String getUname(String nm) {
		String firstChar = nm.substring(0,1).toUpperCase();
		String uname = firstChar + nm.substring(1);

		return uname;
	}

	protected String decodeName(String nm) {
		String firstChar = nm.substring(0,1).toLowerCase();
		String name = firstChar + nm.substring(1);

		return name;
	}

	public StringTemplate getFactoryTemplate() {
		return factoryFileST;
	}

	public void setFactoryTemplate(StringTemplate factory) {
		factoryFileST = factory;
	}

	public void setUserTemplates(StringTemplateGroup lib) {
		userTemplates = lib;
	}

	protected StringTemplate lastValueOf(StringTemplate t, String attr) {
		Object l = t.getAttribute(attr);
		StringTemplate retval = null;

		if (l instanceof StringTemplate.STAttributeList) {
			StringTemplate.STAttributeList ls = (StringTemplate.STAttributeList) l;
			retval = (StringTemplate) ls.get(ls.size() - 1);
		}
		else
			retval = (StringTemplate) l;

		return retval;
	}

	protected StringTemplate addAST(StringTemplate assigned, String dir) {
		StringTemplate tpl = lastValueOf(assigned, "index");
		String uname = (String) tpl.getAttribute("name");
		String typeStr = (String) tpl.getAttribute("type");
		TypeInfo type = grammar.getType(typeStr);
		return addAST(assigned.toString(), dir, type);
	}

	protected StringTemplate addAST(String fetch,
			String dir, TypeInfo type) {
		StringTemplate st = null;

		if (type.isa("Payload")) {
			st = templates.getInstanceOf("instantiatePayload");
		}
		else if (type.isa("Carrier")) {
			st = templates.getInstanceOf("instantiateCarrier");
		}
		else if (type.isa("Queue")) {
			st = templates.getInstanceOf("instantiateQueue");
		}

		st.setAttribute("direction", dir);
		st.setAttribute("var", fetch);

		return st;
	} 

	protected void constructGroup(StringTemplate code, boolean add,
		StringTemplate attr, StringTemplate temp, String direction) {

		StringTemplate assigned = null;
		StringTemplate last = null;
		String fetchAttr = null;
		String typeName = null;
		
		if (attr != null) {
			last = lastValueOf(attr, "index");
			typeName = (String) last.getAttribute("type");
			TypeInfo type = grammar.getType(typeName);
			if (type.isa("Payload")) {
				assigned = templates.getInstanceOf("createAST");
			}
			else {
				assigned = templates.getInstanceOf("createNew");
				assigned.setAttribute("type", typeName);
			}

			assigned.setAttribute("args", temp);

			if (add) {
				fetchAttr = attr.toString();
				StringTemplate tmp = 
					addAST(fetchAttr, direction, type);
				code.setAttribute("addAST", tmp);
			}
			last.setAttribute("value", assigned);

			code.setAttribute("assign", attr);
		}
		else {
			assigned = templates.getInstanceOf("createAST");
			assigned.setAttribute("args", temp);
			assigned.setAttribute("type", typeName);

			last = templates.getInstanceOf("instantiatePayload");
			last.setAttribute("direction", direction);
			last.setAttribute("var", assigned);

			code.setAttribute("addAST", last);
		}	
	} 

	protected String baseType(String type) {
		TypeInfo info = grammar.getTypes().getInfo(type);
		return info.getBaseType();
	}

	protected String strText(GrammarAST s) {
		String str = s.getText();
		return str.substring(1, str.length() -1);
	}

	protected StringTemplate strTemplate(GrammarAST s) {
		String str = strText(s);
		StringTemplate retval = templates.getInstanceOf("targetString");
		retval.setAttribute("str", str);
		return retval;
	}

	protected String findType(String name) {
		TypeInfo info = grammar.getTypes().getInfo(name);

		return info.getName();
	}

	protected void setTypeInfo(String parent, String name, StringTemplate tplt) {
		TypeInfo info = grammar.getTypes().getInfo(parent);
		String type = info.getName();
		String creator = "create" + info.getBaseType();

		tplt.setAttribute("type", type);
		if (templates.isDefined("create" + info.getBaseType())) {
			StringTemplate cr = templates.getInstanceOf(creator);
			cr.setAttribute("type", name);
			tplt.setAttribute("creators", cr);
		}
		else {
			StringTemplate cr = templates.getInstanceOf("defaultCreator");
			cr.setAttribute("type", name);
			tplt.setAttribute("creators", cr);
		}
		tplt.setAttribute("name", name); 
	}
public YggdrasilCodeGen() {
	tokenNames = _tokenNames;
}

	public final void file(AST _t,
		Grammar g,
        StringTemplate rST,
        StringTemplate oST,
        StringTemplate hST
	) throws RecognitionException {
		
		GrammarAST file_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if ( inputState.guessing==0 ) {
					init(g);
						this.recognizerST = rST;
						this.outputFileST = oST;
						this.headerFileST = hST;
					
			}
			{
			_loop3:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_header)) {
					fileheader(_t);
					_t = _retTree;
				}
				else {
					break _loop3;
				}
				
			} while (true);
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				typeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case LEXER_GRAMMAR:
			case PARSER_GRAMMAR:
			case TREE_GRAMMAR:
			case COMBINED_GRAMMAR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			grammar(_t,g);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void fileheader(AST _t) throws RecognitionException {
		
		GrammarAST fileheader_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t7 = _t;
			GrammarAST tmp1_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_header);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp2_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp3_AST_in = (GrammarAST)_t;
			match(_t,LCURLY);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case TOKENS:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				action(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t7;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void typeDecls(AST _t) throws RecognitionException {
		
		GrammarAST typeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t31 = _t;
			GrammarAST tmp4_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop33:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LCURLY||_t.getType()==LITERAL_atomic)) {
					attributeTypeDecl(_t);
					_t = _retTree;
				}
				else {
					break _loop33;
				}
				
			} while (true);
			}
			_t = __t31;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void optionsSpec(AST _t) throws RecognitionException {
		
		GrammarAST optionsSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t13 = _t;
			GrammarAST tmp5_AST_in = (GrammarAST)_t;
			match(_t,OPTIONS);
			_t = _t.getFirstChild();
			{
			int _cnt15=0;
			_loop15:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN)) {
					option(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt15>=1 ) { break _loop15; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt15++;
			} while (true);
			}
			_t = __t13;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammar(AST _t,
		Grammar g
	) throws RecognitionException {
		
		GrammarAST grammar_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		String superClass = (String)g.getOption("superClass");
		outputOption = (String)g.getOption("output");
		recognizerST.setAttribute("superClass", superClass);
		if ( g.type!=Grammar.LEXER ) {
				recognizerST.setAttribute("ASTLabelType", g.getOption("ASTLabelType"));
			}
		if ( g.type!=Grammar.TREE_PARSER ) {
				recognizerST.setAttribute("labelType", g.getOption("TokenLabelType"));
			}
			recognizerST.setAttribute("numRules", grammar.getRules().size());
			outputFileST.setAttribute("numRules", grammar.getRules().size());
			headerFileST.setAttribute("numRules", grammar.getRules().size());
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LEXER_GRAMMAR:
			{
				AST __t57 = _t;
				GrammarAST tmp6_AST_in = (GrammarAST)_t;
				match(_t,LEXER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t57;
				_t = _t.getNextSibling();
				break;
			}
			case PARSER_GRAMMAR:
			{
				AST __t58 = _t;
				GrammarAST tmp7_AST_in = (GrammarAST)_t;
				match(_t,PARSER_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t58;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_GRAMMAR:
			{
				AST __t59 = _t;
				GrammarAST tmp8_AST_in = (GrammarAST)_t;
				match(_t,TREE_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t59;
				_t = _t.getNextSibling();
				break;
			}
			case COMBINED_GRAMMAR:
			{
				AST __t60 = _t;
				GrammarAST tmp9_AST_in = (GrammarAST)_t;
				match(_t,COMBINED_GRAMMAR);
				_t = _t.getFirstChild();
				grammarSpec(_t);
				_t = _retTree;
				_t = __t60;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void tokensSpec(AST _t) throws RecognitionException {
		
		GrammarAST tokensSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate spec = null;
		
		try {      // for error handling
			AST __t67 = _t;
			GrammarAST tmp10_AST_in = (GrammarAST)_t;
			match(_t,TOKENS);
			_t = _t.getFirstChild();
			{
			int _cnt69=0;
			_loop69:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN||_t.getType()==TOKEN_REF)) {
					spec=tokenSpec(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							if (spec != null)
											factoryFileST.setAttribute("cases", spec);
									
					}
				}
				else {
					if ( _cnt69>=1 ) { break _loop69; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt69++;
			} while (true);
			}
			_t = __t67;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  action(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST action_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate act = null;
		
		try {      // for error handling
			AST __t131 = _t;
			GrammarAST tmp11_AST_in = (GrammarAST)_t;
			match(_t,RCURLY);
			_t = _t.getFirstChild();
			code=template(_t);
			_t = _retTree;
			_t = __t131;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void option(AST _t) throws RecognitionException {
		
		GrammarAST option_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t17 = _t;
			GrammarAST tmp12_AST_in = (GrammarAST)_t;
			match(_t,ASSIGN);
			_t = _t.getFirstChild();
			GrammarAST tmp13_AST_in = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			optionValue(_t);
			_t = _retTree;
			_t = __t17;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void optionValue(AST _t) throws RecognitionException {
		
		GrammarAST optionValue_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				GrammarAST tmp14_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				GrammarAST tmp15_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case KEYWORD:
			{
				GrammarAST tmp16_AST_in = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				break;
			}
			case INT:
			{
				GrammarAST tmp17_AST_in = (GrammarAST)_t;
				match(_t,INT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecls(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t20 = _t;
			GrammarAST tmp18_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			case LITERAL_import:
			{
				{
				int _cnt23=0;
				_loop23:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI||_t.getType()==LITERAL_public||_t.getType()==LITERAL_import)) {
						grammarAttributeDecl(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt23>=1 ) { break _loop23; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt23++;
				} while (true);
				}
				if ( inputState.guessing==0 ) {
					recognizerST.setAttribute("variables", variables);
				}
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t20;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void grammarAttributeDecl(AST _t) throws RecognitionException {
		
		GrammarAST grammarAttributeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			StringTemplate decl = null;
			StringTemplate visibility = null;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SEMI:
			case LITERAL_public:
			{
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_public:
				{
					GrammarAST tmp19_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_public);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						visibility = vpublic;
					}
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				attributeVarDecl(_t,variables, visibility);
				_t = _retTree;
				break;
			}
			case LITERAL_import:
			{
				GrammarAST tmp20_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_import);
				_t = _t.getNextSibling();
				GrammarAST tmp21_AST_in = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void attributeVarDecl(AST _t,
		 StringTemplate av, StringTemplate visibility 
	) throws RecognitionException {
		
		GrammarAST attributeVarDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST i1 = null;
		GrammarAST i2 = null;
		GrammarAST n = null;
			StringTemplate v = templates.getInstanceOf("varDecl");
			StringTemplate a = templates.getInstanceOf("varAccessors");
			StringTemplate gType = null;
		
		
		try {      // for error handling
			AST __t41 = _t;
			GrammarAST tmp22_AST_in = (GrammarAST)_t;
			match(_t,SEMI);
			_t = _t.getFirstChild();
			t = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPEN_ELEMENT_OPTION:
			{
				GrammarAST tmp23_AST_in = (GrammarAST)_t;
				match(_t,OPEN_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				i1 = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
						gType = templates.getInstanceOf("genericType");
									gType.setAttribute("type", findType(t.getText()));
									gType.setAttribute("genericArgs", i1.getText());
				}
				{
				_loop44:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ID)) {
						i2 = (GrammarAST)_t;
						match(_t,ID);
						_t = _t.getNextSibling();
						if ( inputState.guessing==0 ) {
							gType.setAttribute("genericArgs", i2.getText());
						}
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				GrammarAST tmp24_AST_in = (GrammarAST)_t;
				match(_t,CLOSE_ELEMENT_OPTION);
				_t = _t.getNextSibling();
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			n = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					if (gType != null) {
								v.setAttribute("type", gType);
								a.setAttribute("type", gType);
							}
							else {
								v.setAttribute("type", findType(t.getText()));
								a.setAttribute("type", findType(t.getText()));
							}
							a.setAttribute("basetype", baseType(t.getText()));
							a.setAttribute("visibility", visibility);
							v.setAttribute("name", n.getText());
							setAccessorNames(a, n.getText());
						
			}
			_t = __t41;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					av.setAttribute("decls", v);
						av.setAttribute("accessors", a);
					
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate[]  ruleAttributeDecls(AST _t) throws RecognitionException {
		 StringTemplate[] codes = null ;
		
		GrammarAST ruleAttributeDecls_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate acts[] = null;
		
		try {      // for error handling
			AST __t27 = _t;
			GrammarAST tmp25_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			{
			_loop29:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ID:
				case LITERAL_new:
				case LITERAL_using:
				{
					if ( inputState.guessing==0 ) {
							if ( codes == null) {
											codes = new StringTemplate[3];
											codes[0] = templates.getInstanceOf("stmtList");
											codes[1] = templates.getInstanceOf("stmtList");
											codes[2] = templates.getInstanceOf("stmtList");
										}
									
					}
					acts=attributeUseDecl(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							codes[0].setAttribute("body", acts[0]); 
										if (acts[1] != null)
											codes[1].setAttribute("body", acts[1]);
						
										codes[2].setAttribute("body", acts[2]);
									
					}
					break;
				}
				case SEMI:
				{
					attributeVarDecl(_t,variables, null);
					_t = _retTree;
					break;
				}
				default:
				{
					break _loop29;
				}
				}
			} while (true);
			}
			_t = __t27;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return codes;
	}
	
	public final StringTemplate[]  attributeUseDecl(AST _t) throws RecognitionException {
		 StringTemplate[] codes = new StringTemplate[3] ;
		
		GrammarAST attributeUseDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST v = null;
		GrammarAST n = null;
		GrammarAST u = null;
			StringTemplate val = null;
			StringTemplate attr = null;
			StringTemplate temp = null;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ID:
			{
				v = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
						temp = templates.getInstanceOf("useAttribute");
							temp.setAttribute("name", v.getText());
							temp.setAttribute("rule", currentRuleName);
							temp.setAttribute("type", grammar.getTypeOf(v.getText()));
							codes[0] = temp;
					
							attr = templates.getInstanceOf("AssignAttributeValue");
							attr.setAttribute("name", getUname(v.getText()));
							attr.setAttribute("type", grammar.getTypeOf(v.getText()));
						
				}
				GrammarAST tmp26_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getNextSibling();
				val=qualifiedId(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
						attr.setAttribute("value", val);
							codes[1] = attr;
					
							temp = templates.getInstanceOf("restoreAttribute");
							temp.setAttribute("name", v.getText());
							temp.setAttribute("rule", currentRuleName);
							codes[2] = temp;
						
				}
				break;
			}
			case LITERAL_new:
			{
				GrammarAST tmp27_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_new);
				_t = _t.getNextSibling();
				n = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
						temp = templates.getInstanceOf("useAttribute");
								temp.setAttribute("name", n.getText());
								temp.setAttribute("rule", currentRuleName);
								temp.setAttribute("type", grammar.getTypeOf(n.getText()));
								codes[0] = temp;
					
								attr = templates.getInstanceOf("AssignAttributeValue");
								attr.setAttribute("name", getUname(n.getText()));
								StringTemplate value = templates.getInstanceOf("createNew");
								String type = grammar.getTypeOf(n.getText());
								value.setAttribute("type", type);
								attr.setAttribute("value", value);
								codes[1] = attr;
						
								temp = templates.getInstanceOf("restoreAttribute");
								temp.setAttribute("name", n.getText());
								temp.setAttribute("rule", currentRuleName);
								codes[2] = temp;
							
				}
				break;
			}
			case LITERAL_using:
			{
				GrammarAST tmp28_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_using);
				_t = _t.getNextSibling();
				u = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
						temp = templates.getInstanceOf("useAttribute");
								temp.setAttribute("name", u.getText());
								temp.setAttribute("rule", currentRuleName);
								temp.setAttribute("type", grammar.getTypeOf(u.getText()));
								codes[0] = temp;
								codes[1] = null;
						
								temp = templates.getInstanceOf("restoreAttribute");
								temp.setAttribute("name", u.getText());
								temp.setAttribute("rule", currentRuleName);
								codes[2] = temp;
							
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return codes;
	}
	
	public final void attributeTypeDecl(AST _t) throws RecognitionException {
		
		GrammarAST attributeTypeDecl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST n = null;
			StringTemplate atype = templates.getInstanceOf("classDecl");
			boolean isNative = false;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_atomic:
			{
				AST __t35 = _t;
				GrammarAST tmp29_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_atomic);
				_t = _t.getFirstChild();
				GrammarAST tmp30_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_native);
				_t = _t.getNextSibling();
				GrammarAST tmp31_AST_in = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				_t = __t35;
				_t = _t.getNextSibling();
				break;
			}
			case LCURLY:
			{
				AST __t36 = _t;
				GrammarAST tmp32_AST_in = (GrammarAST)_t;
				match(_t,LCURLY);
				_t = _t.getFirstChild();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case LITERAL_native:
				{
					GrammarAST tmp33_AST_in = (GrammarAST)_t;
					match(_t,LITERAL_native);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						isNative = true;
					}
					break;
				}
				case ID:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				t = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				n = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					setTypeInfo(t.getText(), n.getText(), atype);
				}
				{
				_loop39:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==SEMI)) {
						attributeVarDecl(_t,atype, vpublic);
						_t = _retTree;
					}
					else {
						break _loop39;
					}
					
				} while (true);
				}
				if ( inputState.guessing==0 ) {
						if (!isNative)
										generator.addType(n.getText(), atype);
								
				}
				_t = __t36;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  idQualifier(AST _t,
		TypeInfo fieldType
	) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST idQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST d = null;
			StringTemplate tail = null;
			StringTemplate index = null;
			String name = null;
			TypeInfo type = null;
			String typeName = null;
		
		
		try {      // for error handling
			d = (GrammarAST)_t;
			match(_t,DOT_TEXT);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					name = d.getText().substring(1);
						typeName = fieldType.getTypeOf(name);
						type = grammar.getType(typeName);
					
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				code=arrayQualifier(_t,name, type);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case ID:
			case SYN_SEMPRED:
			case BANGEDUP:
			case SEMI:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			case GATED_SEMPRED:
			{
				if ( inputState.guessing==0 ) {
						code = templates.getInstanceOf("Attribute");
								code.setAttribute("name", getUname(name));
								code.setAttribute("type", type.getName());
							
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  arrayQualifier(AST _t,
		String name, TypeInfo fieldType
	) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST arrayQualifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
			StringTemplate index = null;
			String typeID = null;
		
		
		try {      // for error handling
			AST __t48 = _t;
			GrammarAST tmp34_AST_in = (GrammarAST)_t;
			match(_t,LBRACKET);
			_t = _t.getFirstChild();
			if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("TableEntry");
							code.setAttribute("name", getUname(name));
							typeID = fieldType.getTypeOf("intrinsic.value");
							code.setAttribute("type", typeID);
						
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					code.setAttribute("contents", strTemplate(s));
				}
				break;
			}
			case ID:
			{
				index=qualifiedId(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					code.setAttribute("contents", index);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			_t = __t48;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  qualifiedId(AST _t) throws RecognitionException {
		StringTemplate index = null; ;
		
		GrammarAST qualifiedId_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST i = null;
		GrammarAST id = null;
			StringTemplate tail = null;
			TypeInfo type = null;
			String name = null;
			String uname = null;
			String typeName = null;
		
		
		try {      // for error handling
			i = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					index = templates.getInstanceOf("qualifiedAttribute");
						name = i.getText().substring(1);
						typeName = grammar.getTypeOf(name);
						type = grammar.getTypeInfoFor(name);
						uname = getUname(name);
					
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				tail=arrayQualifier(_t,name, type);
				_t = _retTree;
				break;
			}
			case 3:
			case ID:
			case SEMI:
			case DOT_TEXT:
			case LITERAL_new:
			case LITERAL_using:
			{
				if ( inputState.guessing==0 ) {
						tail = templates.getInstanceOf("Attribute");
									tail.setAttribute("name", uname);
									tail.setAttribute("type", type.getName());
								
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				index.setAttribute("index", tail);
			}
			{
			_loop53:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					id = _t==ASTNULL ? null : (GrammarAST)_t;
					tail=idQualifier(_t,type);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							index.setAttribute("index", tail);
									String typeID = type.getTypeOf(id.getText().substring(1));
									type = grammar.getType(typeID);
								
					}
				}
				else {
					break _loop53;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				index.setAttribute("type", tail.getAttribute("type"));
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return index;
	}
	
	public final void grammarSpec(AST _t) throws RecognitionException {
		
		GrammarAST grammarSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST name = null;
		GrammarAST cmt = null;
		
		try {      // for error handling
			name = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOC_COMMENT:
			{
				cmt = (GrammarAST)_t;
				match(_t,DOC_COMMENT);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					outputFileST.setAttribute("docComment", cmt.getText());
				}
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_STMT:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						recognizerST.setAttribute("name", name.getText());
						outputFileST.setAttribute("name", name.getText());
						headerFileST.setAttribute("name", name.getText());
					
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				grammarAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case TOKENS:
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKENS:
			{
				tokensSpec(_t);
				_t = _retTree;
				break;
			}
			case RULE:
			case ATTRIBUTE_COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			rules(_t,recognizerST);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t,
		StringTemplate recognizerST
	) throws RecognitionException {
		
		GrammarAST rules_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StringTemplate rST;
		StringTemplate cST;
		
		
		try {      // for error handling
			{
			int _cnt76=0;
			_loop76:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					rST=rule(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						
							    		if ( rST!=null ) {
										recognizerST.setAttribute("rules", rST);
										outputFileST.setAttribute("rules", rST);
										headerFileST.setAttribute("rules", rST);
									}
								
					}
				}
				else if ((_t.getType()==ATTRIBUTE_COLON)) {
					cST=constructorRule(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						
							    			if ( cST!=null ) {
											recognizerST.setAttribute("crules", cST);
											outputFileST.setAttribute("crules", cST);
											headerFileST.setAttribute("crules", cST);
										}
									
					}
				}
				else if ((_t.getType()==RULE)) {
					GrammarAST tmp35_AST_in = (GrammarAST)_t;
					match(_t,RULE);
					_t = _t.getNextSibling();
				}
				else {
					if ( _cnt76>=1 ) { break _loop76; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt76++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  tokenSpec(AST _t) throws RecognitionException {
		 StringTemplate spec = null ;
		
		GrammarAST tokenSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST i = null;
		GrammarAST t2 = null;
		GrammarAST i2 = null;
		GrammarAST c = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp36_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					i = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
							spec = templates.getInstanceOf("buildCase");
									spec.setAttribute("tokenType", t.getText());
									spec.setAttribute("tokenClass", i.getText());
								
					}
					break;
				}
				case 3:
				case ASSIGN:
				case TOKEN_REF:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case ASSIGN:
			{
				AST __t72 = _t;
				GrammarAST tmp37_AST_in = (GrammarAST)_t;
				match(_t,ASSIGN);
				_t = _t.getFirstChild();
				t2 = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case OPEN_ELEMENT_OPTION:
				{
					GrammarAST tmp38_AST_in = (GrammarAST)_t;
					match(_t,OPEN_ELEMENT_OPTION);
					_t = _t.getNextSibling();
					i2 = (GrammarAST)_t;
					match(_t,ID);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
							spec = templates.getInstanceOf("buildCase");
											spec.setAttribute("tokenType", t2.getText());
											spec.setAttribute("tokenClass", i2.getText());
								
					}
					break;
				}
				case KEYWORD:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t72;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return spec;
	}
	
	public final StringTemplate  rule(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST rule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST id = null;
		GrammarAST mod = null;
		
			String r = null;
			String initAction = null;
			StringTemplate b;
			StringTemplate[] decls = null;
			StringTemplate act = null;
			// get the dfa for the BLOCK
			GrammarAST block=rule_AST_in.getFirstChildWithType(BLOCK);
			DFA dfa=block.getLookaheadDFA();
			// init blockNestingLevel so it's block level RULE_BLOCK_NESTING_LEVEL
			// for alts of rule
			blockNestingLevel = RULE_BLOCK_NESTING_LEVEL-1;
			Rule ruleDescr = grammar.getRule(rule_AST_in.getFirstChild().getText());
		
			// For syn preds, we don't want any AST code etc... in there.
			// Save old templates ptr and restore later.  Base templates include Dbg.
			if ( ruleDescr.isSynPred ) {
				inSynPred = true;
			}
		
		
		try {      // for error handling
			AST __t78 = _t;
			GrammarAST tmp39_AST_in = (GrammarAST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			id = (GrammarAST)_t;
			match(_t,ID);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				r=id.getText(); currentRuleName = r;
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case FRAGMENT:
			case LITERAL_public:
			case LITERAL_protected:
			case LITERAL_private:
			{
				mod = _t==ASTNULL ? null : (GrammarAST)_t;
				modifier(_t);
				_t = _retTree;
				break;
			}
			case OPTIONS:
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			case ATTRIBUTE_STMT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE_STMT:
			{
				decls=ruleAttributeDecls(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case RCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RCURLY:
			{
				act=action(_t);
				_t = _retTree;
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			b=block(_t,"ruleBlock", dfa);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
							String description =
								grammar.grammarTreeToString(rule_AST_in.getFirstChildWithType(BLOCK), false);
							description = generator.target.getTargetStringLiteralFromString(description);
							b.setAttribute("description", description);
							/*
							System.out.println("rule "+r+" tokens="+
											   grammar.getRule(r).getAllTokenRefsInAltsWithRewrites());
							System.out.println("rule "+r+" rules="+
											   grammar.getRule(r).getAllRuleRefsInAltsWithRewrites());
							*/
							// do not generate lexer rules in combined grammar
							String stName = null;
							if ( ruleDescr.isSynPred ) {
								stName = "synpredRule";
							}
							else if ( grammar.type==Grammar.LEXER ) {
								if ( r.equals(Grammar.ARTIFICIAL_TOKENS_RULENAME) ) {
									stName = "tokensRule";
								}
								else {
									stName = "lexerRule";
								}
							}
							else {
								if ( !(grammar.type==Grammar.COMBINED &&
									 Character.isUpperCase(r.charAt(0))) )
								{
									stName = "rule";
								}
							}
							code = templates.getInstanceOf(stName);
							if ( code.getName().equals("rule") ) {
								code.setAttribute("emptyRule",
									new Boolean(grammar.isEmptyRule(block)));
							}
							code.setAttribute("ruleDescriptor", ruleDescr);
							String memo = (String)rule_AST_in.getOption("memoize");
							if ( memo==null ) {
								memo = (String)grammar.getOption("memoize");
							}
							if ( memo!=null && memo.equals("true") &&
							     (stName.equals("rule")||stName.equals("lexerRule")) )
							{
						            	code.setAttribute("memoize",
							new Boolean(memo!=null && memo.equals("true")));
						}
							if (act != null)
								code.setAttribute("init", act);
							if (decls != null) {
								code.setAttribute("save", decls[0]);
								code.setAttribute("init", decls[1]);
								code.setAttribute("restore", decls[2]);
							}
						
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_exception:
			{
				exceptionGroup(_t,code);
				_t = _retTree;
				break;
			}
			case EOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			GrammarAST tmp40_AST_in = (GrammarAST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t78;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
				if ( code!=null ) {
							if ( grammar.type==Grammar.LEXER ) {
						    	boolean naked =
						    		r.equals(Grammar.ARTIFICIAL_TOKENS_RULENAME) ||
						    	    (mod!=null&&mod.getText().equals(Grammar.FRAGMENT_RULE_MODIFIER));
						    	code.setAttribute("nakedBlock", new Boolean(naked));
							}
							else {
								String description =
									grammar.grammarTreeToString(rule_AST_in,false);
								code.setAttribute("description", description);
							}
							Rule theRule = grammar.getRule(r);
							code.setAttribute("ruleName", r);
							code.setAttribute("block", b);
							if ( initAction!=null ) {
								code.setAttribute("initAction", initAction);
							}
					}
						inSynPred = false;
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  constructorRule(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST constructorRule_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t85 = _t;
			GrammarAST tmp41_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_COLON);
			_t = _t.getFirstChild();
			GrammarAST tmp42_AST_in = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			{
			int _cnt87=0;
			_loop87:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					attributeItem(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt87>=1 ) { break _loop87; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt87++;
			} while (true);
			}
			_t = __t85;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void modifier(AST _t) throws RecognitionException {
		
		GrammarAST modifier_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LITERAL_protected:
			{
				GrammarAST tmp43_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_protected);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_public:
			{
				GrammarAST tmp44_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_public);
				_t = _t.getNextSibling();
				break;
			}
			case LITERAL_private:
			{
				GrammarAST tmp45_AST_in = (GrammarAST)_t;
				match(_t,LITERAL_private);
				_t = _t.getNextSibling();
				break;
			}
			case FRAGMENT:
			{
				GrammarAST tmp46_AST_in = (GrammarAST)_t;
				match(_t,FRAGMENT);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  block(AST _t,
		String blockTemplateName, DFA dfa
	) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST block_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StringTemplate decision = null;
		if ( dfa!=null ) {
		code = templates.getInstanceOf(blockTemplateName);
		decision = generator.genLookaheadDecision(recognizerST,dfa);
		code.setAttribute("decision", decision);
		code.setAttribute("decisionNumber", dfa.getDecisionNumber());
				code.setAttribute("maxK",dfa.getMaxLookaheadDepth());
				code.setAttribute("maxAlt",dfa.getNumberOfAlts());
		}
		else {
		code = templates.getInstanceOf(blockTemplateName+"SingleAlt");
		}
		blockNestingLevel++;
		code.setAttribute("blockLevel", blockNestingLevel);
		code.setAttribute("enclosingBlockLevel", blockNestingLevel-1);
		StringTemplate alt = null;
		GrammarAST r = null;
		int altNum = 1;
		if ( this.blockNestingLevel==RULE_BLOCK_NESTING_LEVEL )
			{this.outerAltNum=1;}
		
		
		try {      // for error handling
			AST __t90 = _t;
			GrammarAST tmp47_AST_in = (GrammarAST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case OPTIONS:
			{
				optionsSpec(_t);
				_t = _retTree;
				break;
			}
			case ALT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			int _cnt93=0;
			_loop93:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					alt=alternative(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						r=(GrammarAST)_t;
					}
					if ( inputState.guessing==0 ) {
						
						if ( this.blockNestingLevel==RULE_BLOCK_NESTING_LEVEL ) {
							this.outerAltNum++;
						}
								  // add this alt to the list of alts for this block
						code.setAttribute("alts",alt);
						alt.setAttribute("altNum", new Integer(altNum));
						alt.setAttribute("outerAlt",
						new Boolean(blockNestingLevel==RULE_BLOCK_NESTING_LEVEL));
						altNum++;
						
					}
				}
				else {
					if ( _cnt93>=1 ) { break _loop93; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt93++;
			} while (true);
			}
			GrammarAST tmp48_AST_in = (GrammarAST)_t;
			match(_t,EOB);
			_t = _t.getNextSibling();
			_t = __t90;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				blockNestingLevel--;
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void exceptionGroup(AST _t,
		StringTemplate ruleST
	) throws RecognitionException {
		
		GrammarAST exceptionGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			{
			int _cnt96=0;
			_loop96:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_exception)) {
					exceptionSpec(_t,ruleST);
					_t = _retTree;
				}
				else {
					if ( _cnt96>=1 ) { break _loop96; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt96++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  attributeItem(AST _t) throws RecognitionException {
		StringTemplate code = null;
		
		GrammarAST attributeItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			StringTemplate attr = null;
			boolean addToTree = addingAttributes;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			{
				attr=attrLabel(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					addToTree = false;
				}
				break;
			}
			case LABEL_ATTRIBUTE:
			{
				attr=attrAssignInstance(_t);
				_t = _retTree;
				break;
			}
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			code=attributeElement(_t,addToTree, attr);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  alternative(AST _t) throws RecognitionException {
		StringTemplate code=templates.getInstanceOf("alt");
		
		GrammarAST alternative_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		
		String description = grammar.grammarTreeToString(alternative_AST_in, false);
		description = generator.target.getTargetStringLiteralFromString(description);
		code.setAttribute("description", description);
		StringTemplate e;
		GrammarAST elAST = null;
		
		
		try {      // for error handling
			AST __t107 = _t;
			a = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt109=0;
			_loop109:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD||_t.getType()==GATED_SEMPRED)) {
					if ( inputState.guessing==0 ) {
						elAST=(GrammarAST)_t;
					}
					e=element(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						
										if (e != null)
								    			code.setAttribute(
												"elements.{el,line,pos}",
												e,
												new Integer(elAST.getLine()),
												new Integer(elAST.getColumn())
											);
									
					}
				}
				else {
					if ( _cnt109>=1 ) { break _loop109; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt109++;
			} while (true);
			}
			GrammarAST tmp49_AST_in = (GrammarAST)_t;
			match(_t,EOA);
			_t = _t.getNextSibling();
			_t = __t107;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void exceptionSpec(AST _t,
		StringTemplate ruleST
	) throws RecognitionException {
		
		GrammarAST exceptionSpec_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t98 = _t;
			GrammarAST tmp50_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_exception);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RBRACKET:
			{
				arg_decl(_t);
				_t = _retTree;
				break;
			}
			case 3:
			case LITERAL_catch:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop101:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==LITERAL_catch)) {
					exceptionHandler(_t,ruleST);
					_t = _retTree;
				}
				else {
					break _loop101;
				}
				
			} while (true);
			}
			_t = __t98;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  arg_decl(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST arg_decl_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t103 = _t;
			GrammarAST tmp51_AST_in = (GrammarAST)_t;
			match(_t,RBRACKET);
			_t = _t.getFirstChild();
			code=template(_t);
			_t = _retTree;
			_t = __t103;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void exceptionHandler(AST _t,
		StringTemplate ruleST
	) throws RecognitionException {
		
		GrammarAST exceptionHandler_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			StringTemplate act = null;
			StringTemplate arg = null;
		
		
		try {      // for error handling
			AST __t105 = _t;
			GrammarAST tmp52_AST_in = (GrammarAST)_t;
			match(_t,LITERAL_catch);
			_t = _t.getFirstChild();
			arg=arg_decl(_t);
			_t = _retTree;
			act=action(_t);
			_t = _retTree;
			_t = __t105;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				ruleST.setAttribute("exceptions.{decl,action}", arg, act);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  template(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST template_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
		GrammarAST i = null;
		GrammarAST v = null;
		GrammarAST t = null;
		GrammarAST s1 = null;
			StringTemplate attr = null;
			String str = null;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					code = new StringTemplate(userTemplates, strText(s));
				}
				break;
			}
			case ID:
			{
				i = (GrammarAST)_t;
				match(_t,ID);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					code = userTemplates.getInstanceOf(i.getText());
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			{
			_loop142:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ID)) {
					AST __t139 = _t;
					v = _t==ASTNULL ? null :(GrammarAST)_t;
					match(_t,ID);
					_t = _t.getFirstChild();
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case ATTRIBUTE:
					{
						attr=attribute(_t);
						_t = _retTree;
						if ( inputState.guessing==0 ) {
							code.setAttribute(v.getText(), attr);
						}
						break;
					}
					case STRING_LITERAL:
					case TOKEN_REF:
					{
						{
						if (_t==null) _t=ASTNULL;
						switch ( _t.getType()) {
						case TOKEN_REF:
						{
							t = (GrammarAST)_t;
							match(_t,TOKEN_REF);
							_t = _t.getNextSibling();
							if ( inputState.guessing==0 ) {
								str = t.getText();
							}
							break;
						}
						case STRING_LITERAL:
						{
							s1 = (GrammarAST)_t;
							match(_t,STRING_LITERAL);
							_t = _t.getNextSibling();
							if ( inputState.guessing==0 ) {
								str = strText(s1);
							}
							break;
						}
						default:
						{
							throw new NoViableAltException(_t);
						}
						}
						}
						if ( inputState.guessing==0 ) {
							code.setAttribute(v.getText(), str);
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					_t = __t139;
					_t = _t.getNextSibling();
				}
				else {
					break _loop142;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  element(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST element_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST at = null;
		GrammarAST a = null;
		GrammarAST b = null;
		GrammarAST sp = null;
			StringTemplate instantiate = null;
			StringTemplate temp = null;
		
			IntSet elements=null;
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case NOT:
			case WILDCARD:
			{
				at = _t==ASTNULL ? null : (GrammarAST)_t;
				code=atom(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp53_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						
									instantiate = templates.getInstanceOf("instantiateToken");
								 	instantiate.setAttribute("direction", "ROOT");
									code.setAttribute("instantiate", instantiate);
								
					}
					break;
				}
				case BANG:
				{
					GrammarAST tmp54_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
							if ( grammar.type==Grammar.LEXER ) {
											code.setAttribute("skip", "true");
										}
									
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					if ( inputState.guessing==0 ) {
							
									if ( grammar.type!=Grammar.LEXER ) {
										instantiate = templates.getInstanceOf("instantiateToken");
								 		instantiate.setAttribute("direction", "RIGHT");
										code.setAttribute("instantiate", instantiate);
									}
								
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case RULE_REF:
			{
				code=ruleReference(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp55_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
							temp = templates.getInstanceOf("ASTDisable");
										code.setAttribute("before", temp);
										temp = templates.getInstanceOf("ASTRevert");
										code.setAttribute("after", temp);
									
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case CHAR_RANGE:
			{
				AST __t113 = _t;
				GrammarAST tmp56_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				a = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				b = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t113;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("charRangeRef");
							 String low =
							 	generator.target.getTargetCharLiteralFromANTLRCharLiteral(generator,a.getText());
							 String high =
							 	generator.target.getTargetCharLiteralFromANTLRCharLiteral(generator,b.getText());
					code.setAttribute("a", low);
					code.setAttribute("b", high);
					
				}
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case BANGEDUP:
			{
				code=ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				code=treeMatcher(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp57_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
							StringTemplate e = code;
									code = templates.getInstanceOf("statements");
									temp = templates.getInstanceOf("ASTDisable");
									code.setAttribute("body", temp);
									code.setAttribute("body", e);
									temp = templates.getInstanceOf("ASTRevert");
									code.setAttribute("body", temp);
								
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case RCURLY:
			{
				temp=action(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
						if (!inSynPred) {
								code = templates.getInstanceOf("execAction");
								code.setAttribute("action", temp);
							}
						
				}
				break;
			}
			case SEMPRED:
			{
				code=sempred(_t);
				_t = _retTree;
				break;
			}
			case GATED_SEMPRED:
			{
				sp = (GrammarAST)_t;
				match(_t,GATED_SEMPRED);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
					code = templates.getInstanceOf("validateSemanticPredicate");
					sp.outerAltNum = this.outerAltNum;
					code.setAttribute("pred", sp.getText());
							String description =
								generator.target.getTargetStringLiteralFromString(sp.getText());
							code.setAttribute("description", description);
					
				}
				break;
			}
			case SYN_SEMPRED:
			{
				GrammarAST tmp58_AST_in = (GrammarAST)_t;
				match(_t,SYN_SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				GrammarAST tmp59_AST_in = (GrammarAST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
				boolean synPredMatched115 = false;
				if (_t==null) _t=ASTNULL;
				if (((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE))) {
					AST __t115 = _t;
					synPredMatched115 = true;
					inputState.guessing++;
					try {
						{
						labeledItem(_t);
						_t = _retTree;
						}
					}
					catch (RecognitionException pe) {
						synPredMatched115 = false;
					}
					_t = __t115;
inputState.guessing--;
				}
				if ( synPredMatched115 ) {
					code=labeledItem(_t);
					_t = _retTree;
				}
				else if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					code=attributeItem(_t);
					_t = _retTree;
				}
			else {
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  atom(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST atom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST t = null;
		GrammarAST c = null;
		GrammarAST s = null;
		GrammarAST w = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
					grammar.checkRuleReference(t, null, currentRuleName);
							   if ( grammar.type==Grammar.LEXER ) {
								    if ( grammar.getTokenType(t.getText())==Label.EOF ) { code = templates.getInstanceOf("lexerMatchEOF");
									}
								    else {
										code = templates.getInstanceOf("lexerRuleRef");
										code.setAttribute("rule", t.getText());
									}
							   }
							   else {
								   code = templates.getInstanceOf("tokenRef");
								   code.setAttribute("token", t.getText());
								   code.setAttribute("elementIndex", ((TokenWithIndex)t.getToken()).getIndex());
								   generator.generateLocalFOLLOW(t,t.getText(),currentRuleName);
							   }
							   t.code = code;
							
				}
				break;
			}
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							if ( grammar.type==Grammar.LEXER ) {
								code = templates.getInstanceOf("charRef");
								code.setAttribute("char",
								   generator.target.getTargetCharLiteralFromANTLRCharLiteral(generator,c.getText()));
								if (killChars)
									code.setAttribute("skip", "true");
							}
							else { // else it's a token type reference
								code = templates.getInstanceOf("tokenRef");
								code.setAttribute("token",
												  new Integer(grammar.getTokenType(c.getText())));
								code.setAttribute("elementIndex",
												  ((TokenWithIndex)c.getToken()).getIndex());
								generator.generateLocalFOLLOW(c,
									String.valueOf(grammar.getTokenType(c.getText())),
									currentRuleName);
							}
					
				}
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							if ( grammar.type==Grammar.LEXER ) {
								code = templates.getInstanceOf("lexerStringRef");
								code.setAttribute("string",
								   generator.target.getTargetStringLiteralFromANTLRStringLiteral(generator,s.getText()));
								if (killChars)
									code.setAttribute("skip", "true");
							}
							else { // else it's a token type reference
								code = templates.getInstanceOf("tokenRef");
								code.setAttribute("token",
												 new Integer(grammar.getTokenType(s.getText())));
								code.setAttribute("elementIndex", ((TokenWithIndex)s.getToken()).getIndex());
								generator.generateLocalFOLLOW(s,
									String.valueOf(grammar.getTokenType(s.getText())),
									currentRuleName);
							}
						
				}
				break;
			}
			case WILDCARD:
			{
				w = (GrammarAST)_t;
				match(_t,WILDCARD);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
							code = getWildcardST(w,null,null);
							code.setAttribute("elementIndex", ((TokenWithIndex)w.getToken()).getIndex());
							
				}
				break;
			}
			case SET:
			{
				code=set(_t,null);
				_t = _retTree;
				break;
			}
			case NOT:
			{
				code=negatedAtom(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  ruleReference(AST _t) throws RecognitionException {
		StringTemplate code = null;
		
		GrammarAST ruleReference_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST r = null;
		
		try {      // for error handling
			r = (GrammarAST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
				grammar.checkRuleReference(r, null, currentRuleName);
				code = templates.getInstanceOf("ruleRef");
						code.setAttribute("rule", r.getText());
				
						code.setAttribute("elementIndex", ((TokenWithIndex)r.getToken()).getIndex());
						generator.generateLocalFOLLOW(r,r.getText(),currentRuleName);
						r.code = code;
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  labeledItem(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST labeledItem_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			StringTemplate inst = null;
			StringTemplate stTok = null;
			StringTemplate temp = null;
			String dir = "RIGHT";
			StringTemplate last = null;
			StringTemplate getTok = null;
			StringTemplate temp2 = null;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			{
				stTok=attrLabel(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					last = lastValueOf(stTok, "index");
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case NOT:
				case WILDCARD:
				{
					code=atom(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							if ( grammar.type==Grammar.LEXER ) {
											// leave blank for now
										}
										else {
											getTok = templates.getInstanceOf("lastPayload");
											last.setAttribute("value", getTok);
											code.setAttribute("instantiate", stTok);
										}
									
					}
					break;
				}
				case RULE_REF:
				{
					code=ruleReference(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							temp = templates.getInstanceOf("ASTEnable");
										code.setAttribute("before", temp);
										temp = templates.getInstanceOf("ASTRevert");
										code.setAttribute("after", temp);
										getTok = templates.getInstanceOf("getCarrier");
										last.setAttribute("value", getTok);
										code.setAttribute("instantiate", stTok);
									
					}
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case TREE_BEGIN:
				{
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BLOCK:
					case OPTIONAL:
					case CLOSURE:
					case POSITIVE_CLOSURE:
					{
						temp=baseebnf(_t);
						_t = _retTree;
						break;
					}
					case TREE_BEGIN:
					{
						temp=treeMatcher(_t);
						_t = _retTree;
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					if ( inputState.guessing==0 ) {
							code = templates.getInstanceOf("ebnfStmts");
										temp2 = templates.getInstanceOf("preCarrierBlock");
										code.setAttribute("body", temp2);
										code.setAttribute("body", temp);
										temp2 = templates.getInstanceOf("postCarrierBlock");
										code.setAttribute("body", temp2);
										getTok = templates.getInstanceOf("getCarrier");
										last.setAttribute("value", getTok);
										code.setAttribute("body", stTok);
									
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LABEL_ATTRIBUTE:
			{
				stTok=attrAssignInstance(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					last = lastValueOf(stTok, "index");
				}
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SET:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case NOT:
				case WILDCARD:
				{
					code=atom(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							inst = templates.getInstanceOf("instantiateToken");
										code.setAttribute("instantiate", inst);
										getTok = templates.getInstanceOf("lastPayload");
										last.setAttribute("value", getTok);
										code.setAttribute("instantiate", stTok);
									
					}
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case CARET:
					{
						GrammarAST tmp60_AST_in = (GrammarAST)_t;
						match(_t,CARET);
						_t = _t.getNextSibling();
						if ( inputState.guessing==0 ) {
							inst.setAttribute("direction", "ROOT");
						}
						break;
					}
					case 3:
					case ASSIGN_ATTRIBUTE:
					case LABEL_ATTRIBUTE:
					case BLOCK:
					case OPTIONAL:
					case CLOSURE:
					case POSITIVE_CLOSURE:
					case CHAR_RANGE:
					case EPSILON:
					case EOA:
					case SET:
					case SYN_SEMPRED:
					case BANGEDUP:
					case RCURLY:
					case ATTRIBUTE_STMT:
					case STRING_LITERAL:
					case KEYWORD:
					case TOKEN_REF:
					case RULE_REF:
					case LPAREN:
					case SEMPRED:
					case ATTRIBUTE:
					case ATTRIBUTE_GROUP:
					case CURRENT_TREE:
					case TREE_CONSTRUCTOR:
					case NOT:
					case TREE_BEGIN:
					case WILDCARD:
					case GATED_SEMPRED:
					{
						if ( inputState.guessing==0 ) {
							inst.setAttribute("direction", "RIGHT");
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					break;
				}
				case RULE_REF:
				{
					code=ruleReference(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							temp = templates.getInstanceOf("ASTEnable");
										code.setAttribute("before", temp);
										temp = templates.getInstanceOf("ASTRevert");
										code.setAttribute("after", temp);
										getTok = templates.getInstanceOf("lastCarrier");
										code.setAttribute("instantiate", stTok);
									
					}
					break;
				}
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case TREE_BEGIN:
				{
					{
					if (_t==null) _t=ASTNULL;
					switch ( _t.getType()) {
					case BLOCK:
					case OPTIONAL:
					case CLOSURE:
					case POSITIVE_CLOSURE:
					{
						temp=baseebnf(_t);
						_t = _retTree;
						break;
					}
					case TREE_BEGIN:
					{
						temp=treeMatcher(_t);
						_t = _retTree;
						break;
					}
					default:
					{
						throw new NoViableAltException(_t);
					}
					}
					}
					if ( inputState.guessing==0 ) {
							code = templates.getInstanceOf("ebnfStmts");
										temp2 = templates.getInstanceOf("preCarrierBlock");
										code.setAttribute("body", temp2);
										code.setAttribute("body", temp);
										temp = templates.getInstanceOf("postCarrierBlock");
										code.setAttribute("body", temp);
										getTok = templates.getInstanceOf("lastCarrier");
										last.setAttribute("value", getTok);
										code.setAttribute("body", stTok);
										temp = templates.getInstanceOf("removeExcessCarrier");
										code.setAttribute("body", temp);
									
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  ebnf(AST _t) throws RecognitionException {
		StringTemplate code = null;
		
		GrammarAST ebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate temp = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BANGEDUP:
			{
				AST __t151 = _t;
				GrammarAST tmp61_AST_in = (GrammarAST)_t;
				match(_t,BANGEDUP);
				_t = _t.getFirstChild();
				if ( inputState.guessing==0 ) {
						if (grammar.type == Grammar.LEXER)
									killChars = true;
							
				}
				code=baseebnf(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
						StringTemplate e = code;
								if (grammar.type == Grammar.LEXER)
									killChars = false;
								else {
									code = templates.getInstanceOf("statements");
									temp = templates.getInstanceOf("ASTDisable");
									code.setAttribute("body", temp);
									code.setAttribute("body", e);
									temp = templates.getInstanceOf("ASTRevert");
									code.setAttribute("body", temp);
								}
							
				}
				_t = __t151;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				code=baseebnf(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  treeMatcher(AST _t) throws RecognitionException {
		StringTemplate code=templates.getInstanceOf("tree");
		
		GrammarAST treeMatcher_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		StringTemplate el=null;
		GrammarAST elAST=null;
		boolean oldIsTree = isTree;
		isTree = true;
		
		
		try {      // for error handling
			AST __t158 = _t;
			GrammarAST tmp62_AST_in = (GrammarAST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			if ( inputState.guessing==0 ) {
				elAST=(GrammarAST)_t;
			}
			el=rootElement(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
					code.setAttribute("root", el);
			}
			{
			int _cnt160=0;
			_loop160:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==CHAR_RANGE||_t.getType()==EPSILON||_t.getType()==SET||_t.getType()==SYN_SEMPRED||_t.getType()==BANGEDUP||_t.getType()==RCURLY||_t.getType()==ATTRIBUTE_STMT||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==LPAREN||_t.getType()==SEMPRED||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR||_t.getType()==NOT||_t.getType()==TREE_BEGIN||_t.getType()==WILDCARD||_t.getType()==GATED_SEMPRED)) {
					if ( inputState.guessing==0 ) {
						elAST=(GrammarAST)_t;
					}
					el=element(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							if (el != null)
											code.setAttribute("children", el);
									
					}
				}
				else {
					if ( _cnt160>=1 ) { break _loop160; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt160++;
			} while (true);
			}
			if ( inputState.guessing==0 ) {
					if (isTree) {
								el = templates.getInstanceOf("makeNextUp");
								code.setAttribute("children", el);
							}
						
			}
			_t = __t158;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				isTree = oldIsTree;
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  sempred(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST sempred_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
		StringTemplate pred = null;
		
		try {      // for error handling
			AST __t133 = _t;
			s = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			pred=template(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("validateSemanticPredicate");
						        code.setAttribute("pred", pred);
						
			}
			_t = __t133;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  negatedAtom(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST negatedAtom_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST n = null;
		GrammarAST c = null;
		GrammarAST s = null;
		GrammarAST t = null;
		GrammarAST st = null;
			IntSet elements=null;
			StringTemplate instantiate = null;
		
		
		try {      // for error handling
			AST __t118 = _t;
			n = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,NOT);
			_t = _t.getFirstChild();
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						            int ttype=0;
								if ( grammar.type==Grammar.LEXER ) {
								ttype = Grammar.getCharValueFromGrammarCharLiteral(c.getText());
								}
								else {
								ttype = grammar.getTokenType(c.getText());
							}
						            elements = grammar.complement(ttype);
						
				}
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						            int ttype=0;
								if ( grammar.type==Grammar.LEXER ) {
								// TODO: error!
								}
								else {
								ttype = grammar.getTokenType(strText(s));
							}
						            elements = grammar.complement(ttype);
						
				}
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
						           int ttype = grammar.getTokenType(t.getText());
						           elements = grammar.complement(ttype);
						
				}
				break;
			}
			case SET:
			{
				AST __t120 = _t;
				st = _t==ASTNULL ? null :(GrammarAST)_t;
				match(_t,SET);
				_t = _t.getFirstChild();
				{
				int _cnt122=0;
				_loop122:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==CHAR_RANGE||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF)) {
						setElement(_t);
						_t = _retTree;
					}
					else {
						if ( _cnt122>=1 ) { break _loop122; } else {throw new NoViableAltException(_t);}
					}
					
					_cnt122++;
				} while (true);
				}
				_t = __t120;
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					
					// SETs are not precomplemented by buildnfa.g like
					// simple elements.
					elements = st.getSetValue();
					
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						if ( grammar.type==Grammar.LEXER ) {
							code = templates.getInstanceOf("matchCharSet");
						}
						else {
						code = templates.getInstanceOf("matchSet");
						 	code.setAttribute("elementIndex", ((TokenWithIndex)n.getToken()).getIndex());
						 	generator.generateLocalFOLLOW(n,"set",currentRuleName);
					}
					code.setAttribute("s", generator.genSetExpr(templates,elements,1,false));
				
			}
			_t = __t118;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final void setElement(AST _t) throws RecognitionException {
		
		GrammarAST setElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST c = null;
		GrammarAST t = null;
		GrammarAST s = null;
		GrammarAST c1 = null;
		GrammarAST c2 = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case KEYWORD:
			{
				c = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_REF:
			{
				t = (GrammarAST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				s = (GrammarAST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t174 = _t;
				GrammarAST tmp63_AST_in = (GrammarAST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				c2 = (GrammarAST)_t;
				match(_t,KEYWORD);
				_t = _t.getNextSibling();
				_t = __t174;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
	}
	
	public final StringTemplate  attrLabel(AST _t) throws RecognitionException {
		 StringTemplate index = null ;
		
		GrammarAST attrLabel_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST i = null;
		GrammarAST id = null;
			StringTemplate tail = null;
			TypeInfo type = null;
			String name = null;
			String uname = null;
			String typeName = null;
		
		
		try {      // for error handling
			i = (GrammarAST)_t;
			match(_t,ASSIGN_ATTRIBUTE);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					index = templates.getInstanceOf("qualifiedAttribute"); 
						name = i.getText().substring(1);
						typeName = grammar.getTypeOf(name);
						type = grammar.getTypeInfoFor(name);
						uname = getUname(name);
					
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				tail=arrayQualifier(_t,name, type);
				_t = _retTree;
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case SET:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			{
				if ( inputState.guessing==0 ) {
						tail = templates.getInstanceOf("Attribute");
									tail.setAttribute("name", uname);
									tail.setAttribute("type", type.getName());
								
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				index.setAttribute("index", tail);
			}
			{
			_loop146:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					id = _t==ASTNULL ? null : (GrammarAST)_t;
					tail=idQualifier(_t,type);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							index.setAttribute("index", tail);
									String typeID = type.getTypeOf(id.getText().substring(1));
									type = grammar.getType(typeID);
								
					}
				}
				else {
					break _loop146;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return index;
	}
	
	public final StringTemplate  baseebnf(AST _t) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST baseebnf_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		DFA dfa=null;
		GrammarAST b = (GrammarAST)baseebnf_AST_in.getFirstChild();
		GrammarAST eob = (GrammarAST)b.getLastChild(); // loops will use EOB DFA
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				if ( inputState.guessing==0 ) {
					dfa = baseebnf_AST_in.getLookaheadDFA();
				}
				code=block(_t,"block", dfa);
				_t = _retTree;
				break;
			}
			case OPTIONAL:
			{
				if ( inputState.guessing==0 ) {
					dfa = baseebnf_AST_in.getLookaheadDFA();
				}
				AST __t154 = _t;
				GrammarAST tmp64_AST_in = (GrammarAST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				code=block(_t,"optionalBlock", dfa);
				_t = _retTree;
				_t = __t154;
				_t = _t.getNextSibling();
				break;
			}
			case CLOSURE:
			{
				if ( inputState.guessing==0 ) {
					dfa = eob.getLookaheadDFA();
				}
				AST __t155 = _t;
				GrammarAST tmp65_AST_in = (GrammarAST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				code=block(_t,"closureBlock", dfa);
				_t = _retTree;
				_t = __t155;
				_t = _t.getNextSibling();
				break;
			}
			case POSITIVE_CLOSURE:
			{
				if ( inputState.guessing==0 ) {
					dfa = eob.getLookaheadDFA();
				}
				AST __t156 = _t;
				GrammarAST tmp66_AST_in = (GrammarAST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				code=block(_t,"positiveClosureBlock", dfa);
				_t = _retTree;
				_t = __t156;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
						String description = grammar.grammarTreeToString(baseebnf_AST_in, false);
						description = generator.target.getTargetStringLiteralFromString(description);
					code.setAttribute("description", description);
					
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attrAssignInstance(AST _t) throws RecognitionException {
		 StringTemplate index = null ;
		
		GrammarAST attrAssignInstance_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST i = null;
		GrammarAST id = null;
			StringTemplate tail = null;
			TypeInfo type = null;
			String typeName = null;
			String name = null;
		
		
		try {      // for error handling
			i = (GrammarAST)_t;
			match(_t,LABEL_ATTRIBUTE);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					index = templates.getInstanceOf("qualifiedAttribute");
						String s = getUname(i.getText());
						tail = templates.getInstanceOf("Attribute");
						tail.setAttribute("name", s);
						name = i.getText();
						typeName = grammar.getTypeOf(name);
						type = grammar.getTypeInfoFor(name);
						tail.setAttribute("type", type.getName());
						index.setAttribute("index", tail);
					
			}
			{
			_loop149:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					id = _t==ASTNULL ? null : (GrammarAST)_t;
					tail=idQualifier(_t,type);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							index.setAttribute("index", tail);
									String typeID = type.getTypeOf(id.getText().substring(1));
									type = grammar.getType(typeID);
								
					}
				}
				else {
					break _loop149;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return index;
	}
	
	public final StringTemplate  predicatedConstructor(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST predicatedConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate pred = null;
		
		try {      // for error handling
			AST __t135 = _t;
			GrammarAST tmp67_AST_in = (GrammarAST)_t;
			match(_t,SEMPRED);
			_t = _t.getFirstChild();
			pred=template(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("constructionPred");
						        code.setAttribute("pred", pred);
						
			}
			_t = __t135;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attribute(AST _t) throws RecognitionException {
		StringTemplate index = null; ;
		
		GrammarAST attribute_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST a = null;
		GrammarAST id = null;
			StringTemplate tail = null;
			String name = null;
			TypeInfo type = null;
			String typeName = null;
		
		
		try {      // for error handling
			a = (GrammarAST)_t;
			match(_t,ATTRIBUTE);
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
					index = templates.getInstanceOf("qualifiedAttribute");
						name = a.getText().substring(1);
						typeName = grammar.getTypeOf(name);
						type = grammar.getTypeInfoFor(name);
					
			}
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case LBRACKET:
			{
				tail=arrayQualifier(_t,name, type);
				_t = _retTree;
				break;
			}
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			case CHAR_RANGE:
			case EPSILON:
			case EOA:
			case SET:
			case SYN_SEMPRED:
			case BANGEDUP:
			case RCURLY:
			case ATTRIBUTE_STMT:
			case STRING_LITERAL:
			case DOT_TEXT:
			case KEYWORD:
			case TOKEN_REF:
			case RULE_REF:
			case LPAREN:
			case OR:
			case RPAREN:
			case SEMPRED:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CARET:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			case NOT:
			case TREE_BEGIN:
			case WILDCARD:
			case GATED_SEMPRED:
			{
				if ( inputState.guessing==0 ) {
						tail = templates.getInstanceOf("Attribute");
									tail.setAttribute("name", getUname(name));
									tail.setAttribute("type", type.getName());
								
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			if ( inputState.guessing==0 ) {
				index.setAttribute("index", tail);
			}
			{
			_loop166:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==DOT_TEXT)) {
					id = _t==ASTNULL ? null : (GrammarAST)_t;
					tail=idQualifier(_t,type);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
							index.setAttribute("index", tail);
									String typeID = type.getTypeOf(id.getText().substring(1));
									type = grammar.getType(typeID);
								
					}
				}
				else {
					break _loop166;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return index;
	}
	
	public final StringTemplate  rootElement(AST _t) throws RecognitionException {
		 StringTemplate code = null ;
		
		GrammarAST rootElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			boolean addToTree = addingAttributes;
			StringTemplate temp = null;
			StringTemplate instantiate = null;
			StringTemplate last = null;
			StringTemplate attr = null;
		
		
		try {      // for error handling
			{
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ASSIGN_ATTRIBUTE:
			{
				attr=attrLabel(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
						addToTree = false;
							
				}
				break;
			}
			case LABEL_ATTRIBUTE:
			{
				attr=attrAssignInstance(_t);
				_t = _retTree;
				break;
			}
			case SET:
			case STRING_LITERAL:
			case KEYWORD:
			case TOKEN_REF:
			case NOT:
			case WILDCARD:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
			}
			temp=atom(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
				
						if (addToTree) {
							instantiate = templates.getInstanceOf("instantiateRootToken");
							temp.setAttribute("instantiate", instantiate);
							if (attr == null)
								code = temp;
						}
						else
							isTree = false;
				
						if (attr != null) {
							last = lastValueOf(attr, "index");
							code = attr;
							instantiate = templates.getInstanceOf("lastPayload");
							last.setAttribute("value", instantiate);
							code = templates.getInstanceOf("statements");
							code.setAttribute("body", temp);
							code.setAttribute("body", attr);
						}
					
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  set(AST _t,
		String label
	) throws RecognitionException {
		StringTemplate code=null;
		
		GrammarAST set_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
			StringTemplate instantiate = null;
		
		try {      // for error handling
			AST __t170 = _t;
			s = _t==ASTNULL ? null :(GrammarAST)_t;
			match(_t,SET);
			_t = _t.getFirstChild();
			{
			int _cnt172=0;
			_loop172:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==CHAR_RANGE||_t.getType()==STRING_LITERAL||_t.getType()==KEYWORD||_t.getType()==TOKEN_REF)) {
					setElement(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt172>=1 ) { break _loop172; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt172++;
			} while (true);
			}
			_t = __t170;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				
						if ( grammar.type==Grammar.LEXER ) {
							code = templates.getInstanceOf("matchCharSet");
							if (killChars) {
								code.setAttribute("skip", "true");
							}
						}
						else
						{	code = templates.getInstanceOf("matchSet");
							code.setAttribute("elementIndex", ((TokenWithIndex)s.getToken()).getIndex());
							generator.generateLocalFOLLOW(s,"set",currentRuleName);
					}
					        code.setAttribute("s", generator.genSetExpr(templates,s.getSetValue(),1,false));
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attributeGroup(AST _t) throws RecognitionException {
		 StringTemplate code = templates.getInstanceOf("arguments") ;
		
		GrammarAST attributeGroup_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		GrammarAST s = null;
			StringTemplate temp = null;
			boolean addState = addingAttributes;
		
		
		try {      // for error handling
			if ( inputState.guessing==0 ) {
				addingAttributes = false;
			}
			AST __t176 = _t;
			GrammarAST tmp68_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_GROUP);
			_t = _t.getFirstChild();
			{
			_loop178:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case ATTRIBUTE_STMT:
				case LPAREN:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				{
					temp=attributeItem(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						code.setAttribute("body", temp);
					}
					break;
				}
				case STRING_LITERAL:
				{
					s = (GrammarAST)_t;
					match(_t,STRING_LITERAL);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						code.setAttribute("body", strTemplate(s));
					}
					break;
				}
				default:
				{
					break _loop178;
				}
				}
			} while (true);
			}
			_t = __t176;
			_t = _t.getNextSibling();
			if ( inputState.guessing==0 ) {
				addingAttributes = addState;
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attributeBlock(AST _t) throws RecognitionException {
		StringTemplate code = null;
		
		GrammarAST attributeBlock_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate temp = null;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case 3:
			case ASSIGN_ATTRIBUTE:
			case LABEL_ATTRIBUTE:
			case ATTRIBUTE_STMT:
			case LPAREN:
			case ATTRIBUTE:
			case ATTRIBUTE_GROUP:
			case CURRENT_TREE:
			case TREE_CONSTRUCTOR:
			{
				if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("statements");
				}
				{
				_loop181:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						temp=attributeItem(_t);
						_t = _retTree;
						if ( inputState.guessing==0 ) {
							code.setAttribute("body", temp);
						}
					}
					else {
						break _loop181;
					}
					
				} while (true);
				}
				break;
			}
			case SEMPRED:
			{
				code=predicatedConstructor(_t);
				_t = _retTree;
				{
				_loop183:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						temp=attributeItem(_t);
						_t = _retTree;
						if ( inputState.guessing==0 ) {
							code.setAttribute("body", temp);
						}
					}
					else {
						break _loop183;
					}
					
				} while (true);
				}
				{
				GrammarAST tmp69_AST_in = (GrammarAST)_t;
				match(_t,OR);
				_t = _t.getNextSibling();
				temp=attributeBlock(_t);
				_t = _retTree;
				if ( inputState.guessing==0 ) {
					code.setAttribute("altBody", temp);
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attributeStatements(AST _t) throws RecognitionException {
		StringTemplate code = null;
		
		GrammarAST attributeStatements_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		
		try {      // for error handling
			AST __t186 = _t;
			GrammarAST tmp70_AST_in = (GrammarAST)_t;
			match(_t,ATTRIBUTE_STMT);
			_t = _t.getFirstChild();
			code=attributeBlock(_t);
			_t = _retTree;
			_t = __t186;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  attributeElement(AST _t,
		 boolean add, StringTemplate attr 
	) throws RecognitionException {
		 StringTemplate code = templates.getInstanceOf("instantiateAttribute");;
		
		GrammarAST attributeElement_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
			StringTemplate assigned = null;
			StringTemplate temp = null;
			StringTemplate last = null;
			String direction = "RIGHT";
		
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case ATTRIBUTE:
			{
				assigned=attribute(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp71_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						direction = "ROOT";
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				if ( inputState.guessing==0 ) {
						if (add) {
								temp = addAST(assigned, direction);
								code.setAttribute("addAST", temp);
							}
							if (attr != null) {
								last = lastValueOf(attr, "index");
								last.setAttribute("value", assigned);
								code.setAttribute("assign", attr);
							}
							else if (!add) {
								code = assigned;
							}
						
				}
				break;
			}
			case ATTRIBUTE_GROUP:
			{
				temp=attributeGroup(_t);
				_t = _retTree;
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case CARET:
				{
					GrammarAST tmp72_AST_in = (GrammarAST)_t;
					match(_t,CARET);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						direction = "ROOT";
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				if ( inputState.guessing==0 ) {
					constructGroup(code, add, attr, temp, direction);
				}
				break;
			}
			case ATTRIBUTE_STMT:
			{
				code=attributeStatements(_t);
				_t = _retTree;
				break;
			}
			case CURRENT_TREE:
			{
				GrammarAST tmp73_AST_in = (GrammarAST)_t;
				match(_t,CURRENT_TREE);
				_t = _t.getNextSibling();
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case BANG:
				{
					GrammarAST tmp74_AST_in = (GrammarAST)_t;
					match(_t,BANG);
					_t = _t.getNextSibling();
					if ( inputState.guessing==0 ) {
						code = templates.getInstanceOf("killTree");
					}
					break;
				}
				case 3:
				case ASSIGN_ATTRIBUTE:
				case LABEL_ATTRIBUTE:
				case BLOCK:
				case OPTIONAL:
				case CLOSURE:
				case POSITIVE_CLOSURE:
				case CHAR_RANGE:
				case EPSILON:
				case EOA:
				case SET:
				case SYN_SEMPRED:
				case BANGEDUP:
				case RCURLY:
				case ATTRIBUTE_STMT:
				case STRING_LITERAL:
				case KEYWORD:
				case TOKEN_REF:
				case RULE_REF:
				case LPAREN:
				case OR:
				case RPAREN:
				case SEMPRED:
				case ATTRIBUTE:
				case ATTRIBUTE_GROUP:
				case CURRENT_TREE:
				case TREE_CONSTRUCTOR:
				case NOT:
				case TREE_BEGIN:
				case WILDCARD:
				case GATED_SEMPRED:
				{
					if ( inputState.guessing==0 ) {
							code = templates.getInstanceOf("assignTree");
										temp = templates.getInstanceOf("getCarrier");
										attr.setAttribute("value", temp);
										code.setAttribute("instantiate", attr);
									
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				break;
			}
			case LPAREN:
			{
				GrammarAST tmp75_AST_in = (GrammarAST)_t;
				match(_t,LPAREN);
				_t = _t.getNextSibling();
				if ( inputState.guessing==0 ) {
					code = templates.getInstanceOf("statements");
				}
				{
				_loop194:
				do {
					if (_t==null) _t=ASTNULL;
					if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
						temp=attributeItem(_t);
						_t = _retTree;
						if ( inputState.guessing==0 ) {
							code.setAttribute("body", temp);
						}
					}
					else {
						break _loop194;
					}
					
				} while (true);
				}
				GrammarAST tmp76_AST_in = (GrammarAST)_t;
				match(_t,RPAREN);
				_t = _t.getNextSibling();
				break;
			}
			case TREE_CONSTRUCTOR:
			{
				code=treeConstructor(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	public final StringTemplate  treeConstructor(AST _t) throws RecognitionException {
		 StringTemplate code = templates.getInstanceOf("statements") ;
		
		GrammarAST treeConstructor_AST_in = (_t == ASTNULL) ? null : (GrammarAST)_t;
		StringTemplate temp = null;
		
		try {      // for error handling
			AST __t196 = _t;
			GrammarAST tmp77_AST_in = (GrammarAST)_t;
			match(_t,TREE_CONSTRUCTOR);
			_t = _t.getFirstChild();
			temp=attributeItem(_t);
			_t = _retTree;
			if ( inputState.guessing==0 ) {
					code.setAttribute("body", temp);
							temp = templates.getInstanceOf("makeNextDown");
							code.setAttribute("body", temp);
						
			}
			{
			int _cnt198=0;
			_loop198:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ASSIGN_ATTRIBUTE||_t.getType()==LABEL_ATTRIBUTE||_t.getType()==ATTRIBUTE_STMT||_t.getType()==LPAREN||_t.getType()==ATTRIBUTE||_t.getType()==ATTRIBUTE_GROUP||_t.getType()==CURRENT_TREE||_t.getType()==TREE_CONSTRUCTOR)) {
					temp=attributeItem(_t);
					_t = _retTree;
					if ( inputState.guessing==0 ) {
						code.setAttribute("body", temp);
					}
				}
				else {
					if ( _cnt198>=1 ) { break _loop198; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt198++;
			} while (true);
			}
			if ( inputState.guessing==0 ) {
					temp = templates.getInstanceOf("makeNextUp");
							code.setAttribute("body", temp);
						
			}
			_t = __t196;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				if (_t!=null) {_t = _t.getNextSibling();}
			} else {
			  throw ex;
			}
		}
		_retTree = _t;
		return code;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"options\"",
		"\"tokens\"",
		"\"parser\"",
		"ASSIGN_ATTRIBUTE",
		"LABEL_ATTRIBUTE",
		"LEXER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"RANGE",
		"CHAR_RANGE",
		"EPSILON",
		"ALT",
		"EOR",
		"EOB",
		"EOA",
		"CHARSET",
		"SET",
		"ID",
		"LEXER_GRAMMAR",
		"PARSER_GRAMMAR",
		"TREE_GRAMMAR",
		"COMBINED_GRAMMAR",
		"SYN_SEMPRED",
		"\"fragment\"",
		"BANGEDUP",
		"DOC_COMMENT",
		"SEMI",
		"\"header\"",
		"LCURLY",
		"RCURLY",
		"\"lexer\"",
		"\"tree\"",
		"\"grammar\"",
		"ATTRIBUTE_STMT",
		"\"public\"",
		"\"import\"",
		"STRING_LITERAL",
		"\"native\"",
		"\"atomic\"",
		"OPEN_ELEMENT_OPTION",
		"COMMA",
		"CLOSE_ELEMENT_OPTION",
		"DOT_TEXT",
		"LBRACKET",
		"RBRACKET",
		"ASSIGN",
		"\"new\"",
		"\"using\"",
		"KEYWORD",
		"INT",
		"STAR",
		"TOKEN_REF",
		"\"protected\"",
		"\"private\"",
		"BANG",
		"COLON",
		"RULE_REF",
		"ATTRIBUTE_COLON",
		"\"throws\"",
		"\"uses\"",
		"LPAREN",
		"OR",
		"RPAREN",
		"\"exception\"",
		"\"catch\"",
		"SEMPRED",
		"ATTRIBUTE",
		"ATTRIBUTE_GROUP",
		"CARET",
		"CURRENT_TREE",
		"TREE_CONSTRUCTOR",
		"NOT",
		"TREE_BEGIN",
		"QUESTION",
		"PLUS",
		"IMPLIES",
		"WILDCARD",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ATTRIBUTE_PRED",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"ACTION_STRING_LITERAL",
		"ACTION_ESC",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"SRC",
		"INTERNAL_TEXT_REF",
		"GATED_SEMPRED"
	};
	
	}
	
