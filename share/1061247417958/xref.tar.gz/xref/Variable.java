 

import java.util.Vector;

/** Represents the definition of a variable + type.
 */
public class Variable extends Scope {
    protected ClassScope type = null;

    public Variable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    public void setType(ClassScope type) {
        this.type = type;
    }

    public ClassScope getType() {
        return type;
    }
}
