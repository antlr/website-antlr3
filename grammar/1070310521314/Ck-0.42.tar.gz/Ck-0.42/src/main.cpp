/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include <fstream>
#include <iostream>

//#include <antlr/CommonAST.hpp>
//#include <antlr/AST.hpp>
#include "build/CkLexer.hpp"
#include "build/CkParser.hpp"
#include "build/CkChecker.hpp"
#include "build/CkCodeGenerator.hpp"

#include "tools/errorhandler.hpp"
#include "tools/exception.hpp"
#include "tools/argumentparser.hpp"

#include "classencoder/class.hpp"

using namespace std;

//! The main function of the compiler.
/*!
 * This function is responsible for starting the lexer, parser, checker and the codegenerator.
 * It also takes care of command line arguments and their corresponding actions.
 */
int main(int argc, char *argv[])
{
    ArgumentParser args;
    if( !args.parseArguments( argc, argv ) || args.singleArgSet( 'h' ) || args.numArguments() == 0 )
    {
        // print usage list
        cerr << "Ck usage: [OPTIONS] -s source_file\n\n";
        cerr << "\t-o [class name] output has given classname with .class as extension\n";
        cerr << "\t-d turn on debug output\n";
        cerr << "\t-h shows this menu and then quits.\n";
        cerr << "\t-v shows version and then quits.\n";
        return -1;
    }

    if( args.singleArgSet( 'v' ) )
    {
        cerr << "Ck version 1.0.0 by Raymond Bosman and Frederik Holljen\n";
        return -1;
    }

    if( args.argValue( "s" ) == "" )
    {
        cerr << "You must supply a source file with -s\n";
        return -1;
    }

    string outputClass = "output"; // default
    if( args.argValue( "o" ) != "" )
    {
        outputClass = args.argValue( "o" );
    }

    string inputFileName = args.argValue( "s" );
	try
	{
		std::ifstream inputFile( inputFileName.c_str() );
        if( !inputFile.is_open() )
        {
            std::cerr << "Input file " << inputFileName << " could not be found.\n";
            return -1;
        }

        if( args.singleArgSet( 'd' ) )
            std::cout << "Parsing ... " << std::endl;

		CkLexer lexer(inputFile);
		CkParser parser(lexer);

		antlr::ASTFactory ast_factory( "CkASTNodeBase", CkASTNodeBase::factory );

		// initialize and put it in the parser...
		parser.initializeASTFactory(ast_factory);
		parser.setASTFactory(&ast_factory);

		parser.setFilename(inputFileName.c_str());

		// start parsing at the program.
		parser.program();

		// Damn, this line took me a 2 hours.
		// Somehow, when debugging this line causes a segment fault.
        if( args.singleArgSet( 'd' ) )
            std::cout << "parser: " << parser.getAST()->toStringList() << std::endl;

        if( args.singleArgSet( 'd' ) )
            std::cout << "Checking ... " << std::endl;
		// Checker.
		
		CkChecker checker;
		checker.initializeASTFactory(ast_factory);
		checker.setASTFactory(&ast_factory);

		checker.program(parser.getAST());

        // silently quit if there where errors while checking
        if( ErrorHandler::getNumErrors() != 0 )
            return -1;

        if( args.singleArgSet( 'd' ) )
            std::cout << "Generating code ... " << std::endl;
		// Now the code generation
		CkCodeGenerator tparse;
		tparse.initializeASTFactory(ast_factory);
		tparse.setASTFactory(&ast_factory);


        // all is fine, create and set the class we will be writing to.
        Class output( outputClass );
        tparse.setClass( &output );

		tparse.program(parser.getAST());

        output.write();

	}
	catch(antlr::RecognitionException &e)
	{
		ErrorHandler::error (e.getFilename(), e.getLine (), e.getColumn(), e.getMessage());
		return -1;
	}
	catch(antlr::ANTLRException &e)
	{
        cerr << "ANTLR compiler made a booboo. Please file a bug report.\n";
        cerr << "Sorry...\n";
		return -1;
	}
	catch(std::exception& e)
	{
		std::cerr << "exception: " << e.what() << std::endl;
		return -1;
	}
    catch( Exception &e )
    {
        cerr << "The compiler made a booboo. Please file a bug report.\n";
        cerr << e.getError() << "\n";
        cerr << "Sorry...\n";
		return -1;
    }

	return 0;
}
