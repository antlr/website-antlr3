Minimum requirements:

- .Net Framework 1.1
http://microsoft.com/downloads/details.aspx?FamilyId=262D25E3-F589-4842-8157-034D1E7CF3A3&displaylang=en

- J# Redistributable 1.1
http://microsoft.com/downloads/details.aspx?FamilyId=E3CF70A9-84CA-4FEA-9E7D-7D674D2C7CA1&displaylang=en
