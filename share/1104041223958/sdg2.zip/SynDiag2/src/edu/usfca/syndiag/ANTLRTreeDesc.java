// $ANTLR 2.7.2: "antlr.tree.g" -> "ANTLRTreeDesc.java"$

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** A tree grammar describing output of antlr.g's AST representing
 *  ANTLR grammars.
 *
 *  Terence Parr
 *  University of San Francisco
 *  August 19, 2003
 */
public class ANTLRTreeDesc extends antlr.TreeParser       implements ANTLRTreeDescTokenTypes
 {
public ANTLRTreeDesc() {
	tokenNames = _tokenNames;
}

	public final void grammar(AST _t) throws RecognitionException {
		
		AST grammar_AST_in = (AST)_t;
		
		try {      // for error handling
			classDef(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void classDef(AST _t) throws RecognitionException {
		
		AST classDef_AST_in = (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case PARSER:
			{
				AST __t3 = _t;
				AST tmp1_AST_in = (AST)_t;
				match(_t,PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t3;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_PARSER:
			{
				AST __t4 = _t;
				AST tmp2_AST_in = (AST)_t;
				match(_t,TREE_PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t4;
				_t = _t.getNextSibling();
				break;
			}
			case LEXER:
			{
				AST __t5 = _t;
				AST tmp3_AST_in = (AST)_t;
				match(_t,LEXER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t5;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		AST rules_AST_in = (AST)_t;
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					rule(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt8++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		AST rule_AST_in = (AST)_t;
		AST r = null;
		
		try {      // for error handling
			AST __t10 = _t;
			AST tmp4_AST_in = (AST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			r = (AST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			AST __t11 = _t;
			AST tmp5_AST_in = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			block(_t);
			_t = _retTree;
			_t = __t11;
			_t = _t.getNextSibling();
			AST tmp6_AST_in = (AST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t10;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void block(AST _t) throws RecognitionException {
		
		AST block_AST_in = (AST)_t;
		
		try {      // for error handling
			{
			int _cnt14=0;
			_loop14:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					alternative(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt14>=1 ) { break _loop14; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt14++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		AST alternative_AST_in = (AST)_t;
		
		try {      // for error handling
			AST __t16 = _t;
			AST tmp7_AST_in = (AST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt18=0;
			_loop18:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					if ( _cnt18>=1 ) { break _loop18; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt18++;
			} while (true);
			}
			_t = __t16;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		AST element_AST_in = (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case RULE_REF:
			case WILD_CARD:
			{
				atom(_t);
				_t = _retTree;
				break;
			}
			case NOT:
			{
				AST __t20 = _t;
				AST tmp8_AST_in = (AST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				element(_t);
				_t = _retTree;
				_t = __t20;
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_RANGE:
			{
				AST __t21 = _t;
				AST tmp9_AST_in = (AST)_t;
				match(_t,TOKEN_RANGE);
				_t = _t.getFirstChild();
				atom(_t);
				_t = _retTree;
				atom(_t);
				_t = _retTree;
				_t = __t21;
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_RANGE:
			{
				AST __t22 = _t;
				AST tmp10_AST_in = (AST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				AST tmp11_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				AST tmp12_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				_t = __t22;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				ebnf(_t);
				_t = _retTree;
				break;
			}
			case TREE_BEGIN:
			{
				tree(_t);
				_t = _retTree;
				break;
			}
			case SYNPRED:
			{
				AST __t23 = _t;
				AST tmp13_AST_in = (AST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t23;
				_t = _t.getNextSibling();
				break;
			}
			case ACTION:
			{
				AST tmp14_AST_in = (AST)_t;
				match(_t,ACTION);
				_t = _t.getNextSibling();
				break;
			}
			case SEMPRED:
			{
				AST tmp15_AST_in = (AST)_t;
				match(_t,SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				AST tmp16_AST_in = (AST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t) throws RecognitionException {
		
		AST atom_AST_in = (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				AST tmp17_AST_in = (AST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_REF:
			{
				AST tmp18_AST_in = (AST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_LITERAL:
			{
				AST tmp19_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				AST tmp20_AST_in = (AST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case WILD_CARD:
			{
				AST tmp21_AST_in = (AST)_t;
				match(_t,WILD_CARD);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		AST ebnf_AST_in = (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				AST __t25 = _t;
				AST tmp22_AST_in = (AST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t25;
				_t = _t.getNextSibling();
				break;
			}
			case OPTIONAL:
			{
				AST __t26 = _t;
				AST tmp23_AST_in = (AST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t26;
				_t = _t.getNextSibling();
				break;
			}
			case CLOSURE:
			{
				AST __t27 = _t;
				AST tmp24_AST_in = (AST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t27;
				_t = _t.getNextSibling();
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t28 = _t;
				AST tmp25_AST_in = (AST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				block(_t);
				_t = _retTree;
				_t = __t28;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tree(AST _t) throws RecognitionException {
		
		AST tree_AST_in = (AST)_t;
		
		try {      // for error handling
			AST __t30 = _t;
			AST tmp26_AST_in = (AST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			atom(_t);
			_t = _retTree;
			{
			_loop32:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					element(_t);
					_t = _retTree;
				}
				else {
					break _loop32;
				}
				
			} while (true);
			}
			_t = __t30;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"LEXER",
		"PARSER",
		"TREE_PARSER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"TOKEN_RANGE",
		"CHAR_RANGE",
		"NOT",
		"EPSILON",
		"ALT",
		"EOR",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LITERAL",
		"INT",
		"OR",
		"RANGE",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RULE_REF",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"WILD_CARD"
	};
	
	}
	
