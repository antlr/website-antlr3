/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;
import java.util.ArrayList;
import java.util.Iterator;

import org.antlr_yggdrasil.runtime.Carrier;

/**
 * @author lgc
 *
 */
public class TreeBuilder {
	Carrier current = null;
	Carrier[] roots = new Carrier[100];
	Carrier[] anchor = new Carrier[100];
	int[] rootMarkers = new int[100];
	int rootDepth = 0;
	int topRootIndex = 0;
	Carrier end = null;

	Object[] data = null;		// Payloads and Carriers
	short[] codes = null;		// instruction codes
	int [] offsets = null;
	int maxSize;				// array upper bound
	private int len = 0;		// elements in use
	int offsetLen;
	int inset = 1;				// default to start at 0.
	private boolean disabled = false;
	boolean[] activation_record = new boolean[200];
	int activation_index = 0;
	private boolean nextIsDown = false;
	
	private static int increment = 1000;

	public TreeBuilder() {
		data = new Object[getIncrement()];
		codes = new short[getIncrement()];
		
		offsets = new int[100];
		offsetLen = 100;
		
		maxSize = getIncrement();
	}
	
	public TreeBuilder(int size) {
		data = new Payload[size];
		codes = new short[size];
		
		offsets = new int[100];
		offsetLen = 100;
		
		maxSize = size;		
	}
	
	public TreeBuilder(int size, int incr) {
		data = new Payload[size];
		codes = new short[size];
		
		offsets = new int[100];
		offsetLen = 100;
		
		maxSize = size;
		setIncrement(incr);
	}
	
	public void reset() {
		rootDepth = 0;
		topRootIndex = 0;
		len = 0;
		inset = 1;				// default to start at 0.
		disabled = false;
		activation_index = 0;
		nextIsDown = false;
	}

	public static void setIncrement(int increment) {
		TreeBuilder.increment = increment;
	}

	public static int getIncrement() {
		return increment;
	}
	
	void resize() {
		Payload[] nData = new Payload[maxSize + increment];
		short[] nCodes = new short[maxSize + increment];
		System.arraycopy(data, 0, nData, 0, maxSize);
		System.arraycopy(codes, 0, nCodes, 0, maxSize);
		
		data = nData;
		codes = nCodes;
		
		maxSize += increment;
	}
	
	public void addPayload(int code, Payload item) {
		if (isDisabled())
			return;
		
		if (len == maxSize)
			resize();
		
		codes[len] = (byte) (adjust(code) | TreeCodeBlock.NO_CARRIER);
		data[len] = item;
		len++;
	}
	
	protected short adjust(int code) {
		if (nextIsDown== false)
			return (short) code;
		
		code &= ~TreeCodeBlock.RIGHT;
		code |= TreeCodeBlock.DOWN;
		nextIsDown = false;
		
		return (short) code;
	}
	
	public void addCarrier(int code, Carrier item) {
		if (isDisabled())
			return;
		
		if (len == maxSize)
			resize();
		
		codes[len] = adjust(code);
		data[len] = item;
		len++;
	}
	
	public void addReference(int code, ReferenceCarrier ref) {
		if (isDisabled())
			return;
		
		if (len == maxSize)
			resize();
		
		codes[len] = adjust(code | TreeCodeBlock.REFERENCE);
		data[len] = ref;
		len++;		
	}
	
	public void add(ArrayList item) {
		if (isDisabled())
			return;
		
		if (len == maxSize)
			resize();
		
		codes[len] = adjust(TreeCodeBlock.LIST);
		data[len] = item;
		len++;		
	}
	
	public void addUpMarker() {
		codes[len] = TreeCodeBlock.UP;
		len++;
	}

	/**
	 * @param len The len to set.
	 */
	public void setLen(int len) {
		this.len = len;
	}

	/**
	 * @return Returns the len.
	 */
	public int getLen() {
		return len;
	}
	
	public Object getEnd() {
		Object end = data[len];
		data[len] = null;
		len--;
		
		return end;
	}
	
	public void mark() {
		if (isDisabled())
			return;
		
		if (inset == offsetLen) {
			int[] nOffsets = new int[offsetLen + 100];
			System.arraycopy(offsets, 0, nOffsets, 0, offsetLen);
			offsetLen += 100;
			offsets = nOffsets;
		}
		
		rootMarkers[++topRootIndex] = rootDepth;

		offsets[inset] = len;
		inset++;
	}
	
	public void resetMark() {
		for (int i = offsets[inset-1]; i<len; i++)
			data[i] = null;
		
		len = offsets[inset-1];
		
		rootDepth = rootMarkers[topRootIndex];
	}

	public void processFromMark() {
		if (isDisabled())
			return;
		
		int start = offsets[inset-1];
		int code = codes[start];
		
		if ((len == start) || ((len - start == 1) && ((code & TreeCodeBlock.LIST) == 0))) {
			inset--;
			return;
		}
		
		code &= TreeCodeBlock.DOWN;
		if (code == 0)
			code = TreeCodeBlock.RIGHT;
		
		addCarrier(code, buildFromMark());
	}
	
	
	/** tree
	 * Builds the tree specified by codes/data instruction stream.
	 * @return Carrier
	 */
	public Carrier buildFromMark() {
		if (isDisabled())
			return null;
		
		int start = offsets[inset-1];
		int code = codes[start];
		Carrier  carrier = null;
		int startDepth = rootDepth;
		Carrier firstCarrier = null;
		
		if (len == start)
			return null;
		
		if ((code & TreeCodeBlock.LIST) != 0) {
			current = null;
			processList( (ArrayList) data[start], code & TreeCodeBlock.DOWN);
		}
		else {
			if (((code & TreeCodeBlock.ROOT) == TreeCodeBlock.ROOT) && (start != len-1)) {
				short nextCode = codes[start+1];
				if ((nextCode & TreeCodeBlock.ROOT) != TreeCodeBlock.ROOT) {
					nextCode &= ~TreeCodeBlock.RIGHT;
					codes[start+1] = (short) (nextCode | TreeCodeBlock.DOWN);
				}
			}

			if ((code & TreeCodeBlock.NO_CARRIER) != 0)
				current = ( (Payload) data[start]).wrap();
			else if ((code & TreeCodeBlock.REFERENCE) != 0)
				current = ((ReferenceCarrier) data[start]).getCarrier();
			else if (code == TreeCodeBlock.UP) {
				current = roots[rootDepth--];
			}
			else
				current = (Carrier) data[start];
		
			end = current.getLastSibling();
			roots[rootDepth] = end;
			if (start == 0) {
				anchor[0] = current;
			}
		}
		firstCarrier = current;
		
		
		for (int i = start+1; i<len; i++) {
			code = codes[i];
			if ((code & TreeCodeBlock.LIST) != 0) {
				processList( (ArrayList) data[i], code & TreeCodeBlock.DOWN);
				continue;
			}
			
			if ((code & TreeCodeBlock.NO_CARRIER) != 0)
				current = ((Payload) data[i]).wrap();
			else if ((code & TreeCodeBlock.REFERENCE) != 0)
				current = ((ReferenceCarrier) data[i]).getCarrier();
			else
				current = (Carrier) data[i];
			
			switch (code & ~(TreeCodeBlock.NO_CARRIER | TreeCodeBlock.REFERENCE)) {
				case TreeCodeBlock.RIGHT:
					end.setNextSibling(current);
					if ((code & TreeCodeBlock.NO_CARRIER) == 0)
						end = current.getLastSibling();
					else
						end = current;
					break;
					
				case TreeCodeBlock.DOWN:
					roots[++rootDepth] = end;
					anchor[rootDepth] = end;
					end.setFirstChild(current);
					if ((code & TreeCodeBlock.NO_CARRIER) == 0)
						end = current.getLastSibling();
					else
						end = current;
					break;
					
				case TreeCodeBlock.ROOT:
					current.setFirstChild(roots[startDepth]);
					end = roots[startDepth].getLastSibling();
					rootDepth = startDepth;
					anchor[startDepth] = current;
					roots[rootDepth] = current;
					roots[++rootDepth] = end;
					firstCarrier = current;
					break;
					
				case TreeCodeBlock.RIGHTLIST:
					end.setNextSibling(current);
					end = current.getLastSibling();
					break;
					
				case TreeCodeBlock.UP:
					current = roots[rootDepth--];
					end = current;
					break;
					
				default:
					// TODO:  throw exception here
					break;
				
			}
			data[i] = null;
		}
		end = null;
		
		len = start;
		inset--;
		
		if (inset == 0)
			inset = 1;
		
		rootDepth = startDepth;
		
		return firstCarrier;
	}
	
	public void processList(ArrayList v, int direction) {
		Object o = null;
		Iterator iter = v.iterator();
		Carrier c = null;
		Payload p = null;

		if (iter.hasNext()) {
			o = iter.next();
			if (o instanceof ReferenceCarrier) {
				c = ((ReferenceCarrier) o).getCarrier();
			}
			else if(o instanceof Carrier) {
				c = (Carrier) o;
			}
			else {
				p = (Payload) o;
				c = p.wrap();
			}
			if (end != null) {
				if (direction != 0)
					end.setFirstChild(c);
				else
					end.setNextSibling(c);
			}
			else if (roots[rootDepth] == null)
				roots[rootDepth] = c;
			
			end = c;			
		}
		if (current == null)
			current = end;

		while (iter.hasNext()) {
			o = iter.next();
			if (o instanceof ReferenceCarrier) {
				c = ((ReferenceCarrier) o).getCarrier();
			}
			else if(o instanceof Carrier) {
				c = (Carrier) o;
			}
			else {
				p = (Payload) o;
				c = p.wrap();
			}
			if (end != null)
				end.setNextSibling(c);
			else if (roots[rootDepth] == null)
				roots[rootDepth] = c;
			
			end = c;			
		}
		v.clear();
	}
	
	public Object peek() {
		return data[len - 1];
	}

	public Object pop() {
		return data[--len];
	}
	
	// disable() precedes BANGed rules and subrules
	public void disable() {
		activation_record[activation_index++] = isDisabled();
		setDisabled(true);
	}
	
	// activate() precedes) wrap attribute construction phrases
	public void activate() {
		activation_record[activation_index++] = isDisabled();
		setDisabled(false);
	}
	
	// restore construction state
	public void revert() {
		setDisabled(activation_record[--activation_index]);
	}

	public void setNextDown(boolean nextIsDown) {
		this.nextIsDown = nextIsDown;
	}

	public boolean isNextDown() {
		return nextIsDown;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}
	
	public void buildAST(boolean flag) {
		this.disabled = !flag;
	}

	public boolean isDisabled() {
		return disabled;
	}
	
}
