package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;

public class DefaultPayloadFactoryTest extends TestCase {

	public static void main(String[] args) {
		junit.textui.TestRunner.run(DefaultPayloadFactoryTest.class);
	}

	public DefaultPayloadFactoryTest(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/*
	 * Class under test for void DefaultPayloadFactory()
	 */
	public void testDefaultPayloadFactory() {
	}

	/*
	 * Class under test for void DefaultPayloadFactory(int)
	 */
	public void testDefaultPayloadFactoryint() {
	}

	/*
	 * Class under test for void DefaultPayloadFactory(int, Class)
	 */
	public void testDefaultPayloadFactoryintClass() {
	}

	/*
	 * Class under test for Payload createNew(int)
	 */
	public void testCreateNewint() {
	}

	/*
	 * Class under test for Payload createNew(int, String)
	 */
	public void testCreateNewintString() {
	}

	public void testSetDefault() {
	}

	public void testSet() {
	}

}
