/*
 * Created on Oct 30, 2003
 *
 */
 
package org.antlr.java.crossref;

import java.io.IOException;
import java.io.InputStream;
import java.util.Stack;


/** Class that represents a java *.class file.  Uses 
  * KClassFileReader to put information into a KClassinfo.
  * The KClassInfo gets translated into CodeProject Scopes.
 */
public class ClassFile{
	/**
	 * Field project
	 */
	private CodeProject project;
	/**
	 * Filename? unused at present.
	 */
	private String name;
	/**
	 * Field className
	 */
	private String className;
	/**
	 * Stack of Scopes in CodeProject form 
	 * (ClassScope, etc...)
	 */
	private Stack scopeStack = new Stack();
	/**
	 * K representation of classfile
	 */
	private KClassInfo classInfo = null;

	/**
	 * Reader to go from raw file to KClassInfo
	 */
	static  KClassFileReader classFileReader = new KClassFileReader(); 
	
	/**
 * Constructor for ClassFile
 * KClassinfo is populated in constructor.
 * 
 * @param project CodeProject
 * @param in InputStream
 * @param name String
 * @throws KClassFileParseException
 * @throws IOException
 */
public ClassFile(CodeProject project, InputStream in, String name) throws KClassFileParseException, IOException
	{
		this.name = name;
		this.project = project;
		classInfo = new KClassInfo();
		classFileReader.read(in, classInfo);
	}
	/**
	 * Translate KClassinfo into scopes,methods, variables, etc.. 
	 * @throws ClassNotFoundException
	 * @throws KClassFileParseException
	 * @throws IOException
	 */
	public void load() throws ClassNotFoundException, KClassFileParseException, IOException
	{
		className = classInfo.getName();
		String superclassName = classInfo.getSuperClassName();
		//Push fileScope and classScope
		ClassScope classScope = createClassScope(className);
		short result = (short) (KAccessFlags.INTERFACE & classInfo.getAccessFlags());
		if(result != 0)
			classScope.setInterface(true);
		if(superclassName != null && !superclassName.equals("java/lang/Object"))
			handleSuperClass(superclassName.replace('/', '.'), classScope);
		fillSourceFileAndLocation(classScope);
		handleMethods(classInfo.getMethods());
		handleFields(classInfo.getFields());
		handleInnerClasses(classInfo.getInnerClasses());
		handleInterfaces(classInfo.getInterfaces());
		
		//Pop fileScope and classScope
		scopeStack.pop();scopeStack.pop();
		return;
	}
	/** Translates a list of interfaces into CodeProject
	 * ClassScopes with isInterface = true;
	 * @param strings
	 */
	private void handleInterfaces(String[] strings) 
	{
		ClassScope cs = (ClassScope) scopeStack.peek();
		for (int i = 0; i < strings.length; i++) 
		{
			String string = strings[i];
			ClassScope si = project.getOrPredefClassScope(string.replace('/', '.'));
			si.setInterface(true);
			cs.addImplementedInterface(si);
		}
		return;
	}
	/** No action.
	 * @param innerClassInfo
	 */
	private void handleInnerClasses(KInnerClassInfo[] innerClassInfo) 
	{
		// No info 
		return;
	}
	/** 
	 * @param superclassName
	 * @param classScope
	 */
	private void handleSuperClass(String superclassName, ClassScope classScope) {
		ClassScope spClass = project.getOrPredefClassScope(superclassName);
		classScope.addSuperClass(spClass);
	}
	/**
	 * @param fieldInfo 
	 */
	private void handleFields(KFieldInfo[] fieldInfo) {
		String signature;
		ClassScope typeVar;
		ClassScope cs = (ClassScope) scopeStack.peek();
		KFieldInfo fi = null;
		FieldVariable fv = null;
		KCodeInfo ci = null;
		String temp;
		for (int i = 0; i < fieldInfo.length; i++) {
			fi = fieldInfo[i];
			fv = new  FieldVariable(project, fi.getName(), cs);
			fv.setLocation(classInfo.getSourceFile(), Location.CLASSFILE);
			cs.addScopeMember(fv);
			handleTypeSignature(fv, fi.getSignature());
			//want to handle? fi.getConstantValue();
		}

		
	}
	/**
	 * @param fv
	 * @param signature 
	 */
	private void handleTypeSignature(FieldVariable fv, String signature) {
		String temp = signature.replace('/', '.');
		ClassScope typeVar = null;
		while(temp.charAt(0) == '[') temp = temp.substring(1);
		if(temp.charAt(0) == 'L')
			typeVar = project.getOrPredefClassScope(temp.substring(1, temp.length() - 1));
		fv.setType(typeVar);
		return;
	}
	/** Constructor names = "init".
	 * 
	 * @param methodInfo KMethodInfo[]
	 */
	private void handleMethods(KMethodInfo[] methodInfo) {
		String signature,methodName;
		ClassScope cs = (ClassScope) scopeStack.peek();
		KMethodInfo mi = null;
		MethodScope ms = null;
		KCodeInfo ci = null;
		for (int i = 0; i < methodInfo.length; i++) {
			mi = methodInfo[i];
			methodName = mi.getName();
			//XML does not like "<anything>" in a tag
			if(methodName.charAt(0) == '<')
				methodName = methodName.substring(1, methodName.length()-1);
			//"<init>" is the code for a constructor 
			//the class name is prefered by this tool
			if(methodName.equals("init"))
				methodName = className;
			ms = new  MethodScope(project, methodName, cs);
			ms.setLocation(classInfo.getSourceFile(), Location.CLASSFILE);
			ms.setSignature(mi.getSignature());
			cs.addScopeMember(ms);
			//done in  cs.addScopeMember(ms);
			//			project.setMethodScope(ms.getFullyQualifiedName(), ms);
			ci = mi.getCodeInfo();
			handleCode(ci);
		}
		return;
	}
	/** No action. Do nothing with the local method information
	 * @param ci
	 */
	private void handleCode(KCodeInfo ci) {
		// do nothing with the local method information
		return;
	}
	/**
	 * @param classScope
	 */
	private void fillSourceFileAndLocation(Scope classScope) {
			classScope.setLocation(classInfo.getSourceFile(), Location.CLASSFILE);
				
		return;
	}
	/**
	 * @param tempName 
	 * @return ClassScope
	 */
	private ClassScope createClassScope(String tempName) {
		String packageName = null;
		String className = null;
		PackageScope packageScope = null;
		FileScope fileScope = null;
		ClassScope classScope = null;
		String fileName = classInfo.getSourceFile();
		
		//Conform to defs.g way of defining ClassScope
		String input = tempName.replace('/', '.');
		int lastDot = input.lastIndexOf(".");
		if ( lastDot<=0 ) 
			className = input;
		else
		{
			className   = input.substring(lastDot+1,input.length());
			packageName = input.substring(0,lastDot);
		}
		if(packageName != null)
		{
			project.mkPackageScopes(packageName);
			packageScope = project.getPackageScope(packageName);
		}
		fileScope = new FileScope(project,fileName,null);
		scopeStack.push(fileScope);
		String fullName = null;
		if(packageScope != null)
		{
			fullName = new String(packageName + "." + fileName);
			fileScope.setPackageScope(packageScope);
		}
		else
			fullName = fileName;
			
		project.setFileScope(fullName, fileScope);
		scopeStack.push(fileScope);
		classScope = new ClassScope(project, className, fileScope);
		fileScope.addScope(classScope);
		scopeStack.push(classScope);
		
		
		return classScope;
	}
        


}
