// Yggdrasil generated type class


public class Payload1 extends PayloadToken {
	private Integer foo = null;
	
	public Payload1(int type, String txt) {
		super(type, txt);
	}

	public Integer getFoo() {
		return foo;
	}

	public void setFoo(Integer tmp_) {
		foo = (Integer) tmp_;
	}

}
