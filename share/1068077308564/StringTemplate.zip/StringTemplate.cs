/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.IO;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Text;

using Antlr.StringTemplate.Language;

using antlr;
using antlr.collections;

namespace Antlr.StringTemplate {

	/** A <TT>StringTemplate</TT> is a "document" with holes in it where you can stick
	 *  values.  <TT>StringTemplate</TT> breaks up your template into chunks of text and
	 *  attribute expressions, which are by default enclosed in angle brackets:
	 * <TT>&lt;</TT><em>attribute-expression</em><TT>&gt;</TT>.  <TT>StringTemplate</TT>
	 * ignores everything outside of attribute expressions, treating it as just text to spit
	 * out when you call <TT>StringTemplate.ToString()</TT>.
	 *
	 *  <P><TT>StringTemplate</TT> is not a "system" or "engine" or "server"; it's a lib
	rary with two classes of interest: <TT>StringTemplate</TT> and <TT>StringTemplat
	eGroup</TT>.  You can directly create a <TT>StringTemplate</TT> in Java code or
	you can load a template from a file.
	<P>
	A StringTemplate describes an output pattern/language like an exemplar.
	 *  <p>
	 *  StringTemplate and associated code is released under the BSD licence.  See
	 *  source.  <br><br>
	 *  Copyright (c) 2003 Terence Parr<br><br>

	 *  A particular instance of a template may have a set of attributes that
	 *  you set programmatically.  A template refers to these single or multi-
	 *  valued attributes when writing itself out.  References within a
	 *  template conform to a simple language with attribute references and
	 *  references to other, embedded, templates.  The references are surrounded
	 *  by user-defined start/stop strings (default of <...>, but $...$ works
	 *  well when referencing attributes in HTML to distinguish from tags).
	 *
	 *  <p>StringTemplateGroup is a self-referential group of StringTemplate
	 *  objects kind of like a grammar.  It is very useful for keeping a
	 *  group of templates together.  For example, jGuru.com's premium and
	 *  guest sites are completely separate sets of template files organized
	 *  with a StringTemplateGroup.  Changing "skins" is a simple matter of
	 *  switching groups.  Groups know where to load templates by either
	 *  looking under a rootDir you can specify for the group or by simply
	 *  looking for a resource file in the current class path.  If no rootDir
	 *  is specified, template files are assumed to be resources.  So, if
	 *  you reference template foo() and you have a rootDir, it looks for
	 *  file rootDir/foo.st.  If you don't have a rootDir, it looks for
	 *  file foo.st in the CLASSPATH.  note that you can use org/antlr/misc/foo()
	 *  (qualified template names) as a template ref.
	 *
	 *  <p>IStringTemplateErrorListener is an interface you can implement to
	 *  specify where StringTemplate reports errors.  Setting the listener
	 *  for a group automatically makes all associated StringTemplate
	 *  objects use the same listener.  For example,
	 *
	 *  <font size=2><pre>
	 *  StringTemplateGroup group = new StringTemplateGroup("loutSyndiags");
	 *  group.setErrorListener(
	 *     new IStringTemplateErrorListener() {
	 *        public void Error(String msg, Exception e) {
	 *           Console.Error.WriteLine("StringTemplate error: "+
	 *               msg+((e != null)?": " + e.getMessage():""));
	 *        }
	 *    }
	 *  );
	 *  </pre></font>
	 *
	 *  <p>IMPLEMENTATION
	 *
	 *  <p>A StringTemplate is both class and instance like in Self.  Given
	 *  any StringTemplate (even one with attributes filled in), you can
	 *  get a new "blank" instance of it.
	 *
	 *  <p>When you define a template, the string pattern is parsed and
	 *  broken up into chunks of either String or attribute/template actions.
	 *  These are typically just attribute references.  If a template is
	 *  embedded within another template either via setAttribute or by
	 *  implicit inclusion by referencing a template within a template, it
	 *  inherits the attribute scope of the enclosing StringTemplate instance.
	 *  All StringTemplate instances with the same pattern point to the same
	 *  list of chunks since they are immutable there is no reason to have
	 *  a copy in every instance of that pattern.  The only thing that differs
	 *  is that every StringTemplate Java object can have its own set of
	 *  attributes.  Each chunk points back at the original StringTemplate
	 *  Java object whence they were constructed.  So, there are multiple
	 *  pointers to the list of chunks (one for each instance with that
	 *  pattern) and only one back ptr from a chunk to the original pattern
	 *  object.  This is used primarily to get the grcoup of that original
	 *  so new templates can be loaded into that group.
	 *
	 *  <p>To write out a template, the chunks are walked in order and asked to
	 *  write themselves out.  String chunks are obviously just written out,
	 *  but the attribute expressions/actions are evaluated in light of the
	 *  attributes in that object and possibly in an enclosing instance.
	 */
	public class StringTemplate {
		public const String VERSION = "1.0.2";

		static bool inDebugMode = false;

		/** track probable issues like setting attribute that is not referenced. */
		static bool inLintMode = false;

		protected IList referencedAttributes = null;

		/** What's the name of this template? */
		protected String name = "anonymous";

		private static int templateCounter = 0;

		[MethodImpl(MethodImplOptions.Synchronized)]
		private static int getNextTemplateCounter() {
			templateCounter++;
			return templateCounter;
		}

		protected int templateID = getNextTemplateCounter();

		/** Enclosing instance if I'm embedded within another template.
		 *  IF-subtemplates are considered embedded as well.
		 */
		protected StringTemplate enclosingInstance = null;

		/** If this template is an embedded template such as when you apply
		 *  a template to an attribute, then the arguments passed to this
		 *  template represent the argument context--a set of values
		 *  computed by walking the argument assignment list.  For example,
		 *  <name:bold(item=name, foo="x")> would result in an
		 *  argument context of {[item=name], [foo="x"]} for this
		 *  template.  This template would be the bold() template and
		 *  the enclosingInstance would point at the template that held
		 *  that <name:bold(...)> template call.  When you want to get
		 *  an attribute value, you first check the attributes for the
		 *  'self' template then the arg context then the enclosingInstance
		 *  like resolving varables in pascal-like language with nested
		 *  procedures.
		 *
		 *  With multi-valued attributes such as <faqList:briefFAQDisplay()>
		 *  attribute "i" is set automatically.
		 */
		protected Hashtable argumentContext = null;

		public StringTemplateAST ArgumentsAST {
			get {
				return argumentsAST;
			}
			set {
				this.argumentsAST = value;
			}
		}

		/** If this template is embedded in another template, the arguments
		 *  must be evaluated just before each application when applying
		 *  template to a list of values.  The "attr" attribute must change
		 *  with each application so that $names:bold(item=attr)$ works.  If
		 *  you evaluate once before starting the application loop then attr
		 *  has a single fixed value.  Eval.g saves the AST rather than evaluating
		 *  before invoking applyListOfAlternatingTemplates().  Each iteration
		 *  of a template application to a multi-valued attribute, these args
		 *  are re-evaluated with an initial context of {[attr=...], [i=...]}.
		 */
		protected StringTemplateAST argumentsAST = null;

		/** What group originally defined the prototype for this template?
		 *  This affects the set of rules I can refer to.
		 */
		protected StringTemplateGroup group;

		/** Where to report errors */
		IStringTemplateErrorListener listener = null;

		/** The original, immutable pattern/language (not really used again after
		 *  initial "compilation", setup/parsing).
		 */
		protected String pattern;

		/** Map an attribute name to its value(s).  These values are set by outside
		 *  code via st.setAttribute(name, value).  StringTemplate is like self in
		 *  that a template is both the "class def" and "instance".  When you
		 *  create a StringTemplate or setTemplate, the text is broken up into chunks
		 *  (i.e., compiled down into a series of chunks that can be evaluated later).
		 *  You can have multiple
		 */
		protected IDictionary attributes;

		/** A list of alternating string and ASTExpr references.
		 *  This is compiled to when the template is loaded/defined and walked to
		 *  write out a template instance.
		 */
		protected IList chunks;

		protected static StringTemplateGroup defaultGroup =
			new StringTemplateGroup("defaultGroup");

		/** Create a blank template with no pattern and no attributes */
		public StringTemplate() {
			group = defaultGroup; // make sure has a group even if default
			if ( inDebugMode ) Debug("new StringTemplate():" + this.TemplateID);
		}

		public StringTemplate(IDictionary initialValues) : this() {
			if ( inDebugMode ) Debug("new StringTemplate(initialValues):" + this.TemplateID);
			attributes = initialValues;

			if ( attributes == null ) {
				attributes = new Hashtable();
			}
		}

		/** Create an anonymous template.  It has no name just
		 *  chunks (which point to this anonymous template) and attributes.
		 */
		public StringTemplate(String template) : this(null, template) {
			if ( inDebugMode ) Debug("new StringTemplate(template):" + TemplateID);
		}

		/** Create an anonymous template with no name, but with a group */
		public StringTemplate(StringTemplateGroup group, String template) : this() {
			if ( inDebugMode ) Debug("new StringTemplate(group, [" + template + "]):" + TemplateID);
		
			if ( group != null ) {
				this.Group = group;
			}

			this.Template = template;
		}

		/** Make the 'to' template look exactly like the 'from' template
		 *  except for the attributes.  This is like creating an instance
		 *  of a class in that the executable code is the same (the template
		 *  chunks), but the instance data is blank (the attributes).  Do
		 *  not copy the enclosingInstance pointer since you will want this
		 *  template to eval in a context different from the examplar.
		 */
		private void dup(StringTemplate from, StringTemplate to) {
			if ( inDebugMode ) {
				Debug("dup template ID " + from.TemplateID + " to get " + to.TemplateID);
			}

			to.pattern = from.pattern;
			to.chunks = from.chunks;
			to.name = from.name;
			to.group = from.group;
			to.listener = from.listener;
		}

		/** Return a copy of the template only; no hash tables */
		public StringTemplate GetInstanceOf() {
			return GetInstanceOfWithAttributes(null);
		}

		/** Make an instance of this template; it contains an exact copy of
		 *  everything (except the attributes and enclosing instance pointer).
		 *  So the new template refers to the previously compiled chunks of this
		 *  template but does not have any attribute values.
		 */
		public StringTemplate GetInstanceOfWithAttributes(IDictionary initialValues) {
			if ( inDebugMode ) Debug("GetInstanceOfWithAttributes(" + this.Name + ")");
			StringTemplate t = new StringTemplate(initialValues);
			dup(this, t);
			return t;
		}

		public StringTemplate EnclosingInstance {
			set {
				this.enclosingInstance = value;
			}
		}

		public Hashtable ArgumentContext {
			get {
				return this.argumentContext;
			}
			set {
				this.argumentContext = value;
			}
		}

		public String Name {
			get {
				return name;
			}
			set {
				this.name = value;
			}
		}

		public StringTemplateGroup Group {
			get {
				return group;
			}
			set {
				this.group = value;
			}
		}

		public String Template {
			get {
				return this.pattern;
			}
			set {
				this.pattern = value;
				breakTemplateIntoChunks();
			}
		}

		public IStringTemplateErrorListener ErrorListener {
			get {
				if ( listener == null ) {
					return group.ErrorListener;
				}

				return listener;
			}
			set {
				this.listener = value;
			}
		}

		public void Reset() {
			attributes = new Hashtable(); // just throw out table and make new one
		}

		public void RemoveAttribute(String name) {
			attributes.Remove(name);
		}

		/** Set an attribute for this template.  If you set the same
		 *  attribute more than once, you get a multi-valued attribute.
		 *  If you send in a StringTemplate object as a value, it's
		 *  enclosing instance (where it will inherit values from) is
		 *  set to 'this'.  This would be the normal case, though you
		 *  can set it back to null after this call if you want.
		 *  If you send in a List plus other values to the same
		 *  attribute, they all get flattened into one List of values.
		 *  If you send in an array, it is converted to a List.  Works
		 *  with arrays of objects and arrays of {int, float, double}.
		 */
		public void SetAttribute(String name, Object value) {
			if ( inDebugMode ) Debug( this.Name + ".setAttribute(" + name + ", " + value + ")");

			if ( value == null ) {
				return;
			}

			if ( attributes == null ) {
				attributes = new Hashtable();
			}

			// get exactly in this scope (no enclosing)
			Object o = this.attributes[name];

			if ( o != null ) { // it's a multi-value attribute
				//Console.WriteLine("exists: " + name + "=" + o);
				ArrayList v = null;

				if ( o is ArrayList ) { // already a List
					v = (ArrayList) o;

					if ( value is IList ) {
						// flatten incoming list into existing
						// (do nothing if same List to avoid trouble)
						IList v2 = (IList) value;

						for (int i = 0; v != v2 && i < v2.Count; i++) {
							// Console.WriteLine("flattening " + name + "[" + i+"]=" + v2.elementAt(i) + " into existing value");
							v.Add(v2[i]);
						}
					}
					else {
						v.Add(value);
					}
				}
				else {
					// second attribute, must convert existing to ArrayList
					v = new ArrayList(); // make list to hold multiple values
					rawSetAttribute(name, v); // make it pt to list now
					v.Add(o);  // add previous single-valued attribute

					if ( value is IList ) {
						// flatten incoming list into existing
						IList v2 = (IList) value;

						for (int i = 0; i < v2.Count; i++) {
							v.Add(v2[i]);
						}
					}
					else {
						v.Add(value);
					}
				}
			}
			else {
				rawSetAttribute(name, value);
			}
		}

		protected void rawSetAttribute(String name, Object value) {
			if ( inDebugMode ) {
				Debug(this.Name + ".rawSetAttribute(" + name + ", " + value + ")");
			}
		
			if ( value == null ) {
				return;
			}

			if ( value is StringTemplate ) {
				((StringTemplate)value).EnclosingInstance = this;
			}

			attributes[name] = value;
		}

		public Object GetAttribute(String name) {
			return Get(this, name);
		}

		/// <summary>
		/// Write template output to the given TextWriter.
		/// </summary>
		/// <remarks>
		/// Walk the chunks, asking them to write themselves out according
		/// to attribute values of 'this.attributes'.  This is like evaluating or
		/// interpreting the StringTemplate as a program using the
		/// attributes.  The chunks will be identical (point at same list)
		/// for all instances of this template.
		/// </remarks>
		/// <param name="outWriter"></param>
		public void Write(TextWriter outWriter) {
			for (int i = 0; chunks != null && i < chunks.Count; i++) {
				Expr a = (Expr) chunks[i];
				a.Write(this, outWriter);
			}

			if ( inLintMode ) {
				this.CheckForTrouble();
			}
		}

		/// <summary>
		/// Resolve an attribute reference.
		/// </summary>
		/// <remarks>
		/// Resolve an attribute reference.  It can be in three possible places:
		/// 1. the attribute list for the current template
		/// 2. if self is an embedded template, somebody invoked us possibly
		///    with arguments--check the argument context
		/// 3. if self is an embedded template, the attribute list for the enclosing
		///    instance
		/// </remarks>
		/// <param name="self"></param>
		/// <param name="attribute"></param>
		/// <returns></returns>
		public static Object Get(StringTemplate self, String attribute) {
			if ( self == null ) {
				return null;
			}

			if ( inDebugMode ) self.Debug("get(" + self.Name + ":" + self.TemplateID + ", " + attribute + ")");
			if ( inDebugMode ) self.Debug("self.attributes=" + self.attributes);

			if ( inLintMode ) {
				self.trackAttributeReference(attribute);
			}

			// is it here?
			if ( self.attributes != null ) {
				Object o = self.attributes[attribute];

				if ( o != null ) {
					if ( inDebugMode ) {
						self.Debug("found it in self: " + o);
					}

					return o;
				}
			}

			// nope, check argument context in case embedded
			Hashtable argContext = self.ArgumentContext;

			if ( argContext != null && argContext[attribute] != null ) {
				if ( inDebugMode ) {
					self.Debug("found it in arg context: " + argContext[attribute]);
				}

				return argContext[attribute];
			}

			// nope, check enclosingInstance if embedded
			if ( self.enclosingInstance != null ) {
				return Get(self.enclosingInstance, attribute);
			}

			if ( inDebugMode ) {
				self.Debug("couldn't find " + attribute + " in " + self.Name);
			}

			return null;
		}

		/** Walk a template, breaking it into a list of
		 *  chunks: Strings and expressions.
		 */
		protected void breakTemplateIntoChunks() {
			// Console.WriteLine("breakTemplateIntoChunks(" + group.getTagStart() + "," + group.getTagStop() + "): " + pattern);
			if ( chunks == null ) {
				chunks = new ArrayList();
			}

			StringBuilder chunk = new StringBuilder(100);
			int cp = 0;
			int sz = pattern.Length;
			char ts = group.DelimiterStart[0];
			int tslen = group.DelimiterStart.Length;
			char tstop = group.DelimiterStop[0];
			int tstoplen = group.DelimiterStop.Length;
			String ifStart = group.DelimiterStart + "if"; // <if(foo)> etc...
			String ifStop = ")" + group.DelimiterStop;
			int islen = ifStart.Length;

			parseTemplate:
				while ( cp<sz ) {  // for each char in template
					// STRING CHUNK
					if ( pattern[cp]!=ts ) {
						// scarf String chunk and add to overall chunks list
						while ( cp<sz && pattern[cp]!=ts ) {
							chunk.Append(pattern[cp]);
							cp++;
						}
						StringRef sr = new StringRef(this, chunk.ToString());
						chunks.Add(sr);
						chunk.Length = 0;
					}
						// IF CHUNK
					else if ( pattern[cp]==ts &&
						String.Compare(pattern, cp, ifStart, 0, islen) == 0 ) {
						cp = parseIfChunk(cp, sz);
					}
						// ATTRIBUTE EXPRESSION CHUNK
					else if ( pattern[cp]==ts && // try to be efficient
						String.Compare(pattern, cp, group.DelimiterStart, 0, tslen) == 0 ) {
						cp = parseAttributeExpressionChunk(cp, sz);
					}
						// JUNK
					else {
						cp++; // unknown; just skip
					}
				}
		}

		protected int parseAttributeExpressionChunk(int cp, int sz) {
			StringBuilder stat = new StringBuilder(100);
			char ts = group.DelimiterStart[0];
			int tslen = group.DelimiterStart.Length;
			char tstop = group.DelimiterStop[0];
			int tstoplen = group.DelimiterStop.Length;
			cp += tslen;			// ignore the delim start
			bool matchingExpr = true;
			while ( matchingExpr && cp < sz) {
				if ( pattern[cp]==tstop &&
					String.Compare(pattern, cp, group.DelimiterStop, 0, tstoplen) == 0 ) {
					matchingExpr = false;
				}
				else if ( pattern[cp]=='"' ) {
					// scarf entire string before continuing to look for end tag
					cp++;
					stat.Append( '"' );
					while ( pattern[cp]!='"' ) {
						if ( pattern[cp]=='\\' ) {
							stat.Append( pattern[cp] );
							cp++; // Allow escaped quote
						}
						stat.Append( pattern[cp] );
						cp++;
					}
					stat.Append( '"' );
					cp++; // skip last quote
				}
				else if ( pattern[cp]=='{' ) {
					// scarf entire anonymous before continuing to look for end delimiter
					// we'll deal with stuff within later in a nested fashion
					cp++;
					stat.Append( '{' );
					while ( pattern[cp]!='}' ) {
						if ( pattern[cp]=='\\' ) {
							stat.Append( pattern[cp] );
							cp++; // Allow escaped }
						}
						stat.Append( pattern[cp] );
						cp++;
					}
					stat.Append( '}' );
					cp++; // skip last curly
				}
				else {
					stat.Append( pattern[cp] );
					cp++;
				}
			}

			if ( cp>=sz ) {
				Error("end delimiter '" + group.DelimiterStop + "' not found in template for delimiter starting at index " + cp);
				return sz;
			}

			cp += group.DelimiterStop.Length; // ignore the delim stop
			ASTExpr a = parseAction(stat.ToString());

			if ( a != null ) {
				chunks.Add(a);
			}

			return cp;
		}

		/** Go get the if-chunk, nested template, and endif-chunk.  Leave
		 *  the parsing of if-chunk to parser, but get the pieces.  We can't
		 *  have ANTLR parse this as start/stop char are variables, making it
		 *  slow (would have to use semantic predicates on each char etc...).
		 *
		 *  The <endif> has to be tracked with a stack nowadays since
		 *  I've expanded what an expression can be:
		 *
		 *  <if(x != y)> foo <endif>
		 *
		 *  The subtemplates of conditionals are precompiled when I create
		 *  the embedded subtemplate at end of method.
		 */
		protected int parseIfChunk(int cp, int sz) {
			StringBuilder ifchunk = new StringBuilder(100);
			StringBuilder chunk = new StringBuilder(1024);
			char ts = group.DelimiterStart[0];
			String ifStop = group.DelimiterStop;
			int istoplen = ifStop.Length;
			char istop = ifStop[0];

			// grab the conditional expression from the IF action
			cp += group.DelimiterStart.Length;	// ignore the delim start
			int endIFtag = pattern.IndexOf(ifStop, cp);

			if ( endIFtag >= sz ) {
				Error("end not found for IF action in template starting at index " + cp);
				return sz;
			}

			// we have the tag now
			ifchunk.Append(pattern.Substring(cp, endIFtag - cp));
			cp = endIFtag;
			cp += group.DelimiterStop.Length; // jump over the delim stop

			// strip exactly one newline if immediately following <if(var)>
			if ( pattern[cp]=='\n' ) {
				cp++;
			}
			int endifIndex = findEndif(cp, sz);
			if ( endifIndex>=sz ) {
				return sz;
			}

			// got it end, add to chunk
			chunk.Append(pattern.Substring(cp, endifIndex - cp));
			cp = endifIndex; // jump past end of endif

			if ( pattern[cp-1] == '\n' ) {  // remove a \n before endif
				chunk.Length = chunk.Length - 1;
			}

			cp += "<endif>".Length;

			// cp points to char following endif now.
			if ( inDebugMode ) {
				Debug("conditional " + ifchunk.ToString() + ", chunk='"+
					chunk.ToString() + "'");
			}

			ConditionalExpr c = (ConditionalExpr) parseAction(ifchunk.ToString());

			if ( c != null ) {
				// create and precompile a subtemplate
				StringTemplate subtemplate =
					new StringTemplate(group, chunk.ToString());
				subtemplate.EnclosingInstance = this;
				subtemplate.Name = "subtemplate";
				c.SubTemplate = subtemplate;
				chunks.Add(c);
			}

			return cp;
		}

		/** Return the index of the appropriately nested <endif> for current IF.
		 *  The cp comes in at the first char beyond the <if(expr)> action.
		 */
		private int findEndif(int cp, int sz) {
			char ts = group.DelimiterStart[0];
			int level = 0;
			String ifStart = group.DelimiterStart + "if("; // "<if("
			int islen = ifStart.Length;
			String endif =
				group.DelimiterStart + "endif" + group.DelimiterStop;
			int endiflen = endif.Length;
			// grab conditional chunk. Scarf til endif @ level 0
			while ( cp<sz ) {
				if ( pattern[cp]==ts ) {
					if ( String.Compare(pattern, cp, endif, 0, endiflen) == 0 ) {
						if ( level==0 ) {
							// found matching <endif>, return index
							return cp;
						}
						// else, a nested one; drop level by one and continue
						level--;
						cp += endiflen;
					}
					else if ( String.Compare(pattern, cp, ifStart, 0, islen) == 0 ) {
						// found another IF, jump over and bump nesting level
						cp += islen;
						int e = pattern.IndexOf(group.DelimiterStop, cp);
						if ( e>=sz ) {
							Error("end of IF not found for IF action in template starting at index " + cp);
							return sz;
						}
						cp = e;
						level++;
					}
				}
				cp++;
			}

			Error("endif not found for IF action in template starting at index " + cp);

			return sz;
		}

		private ASTExpr parseAction(String action) {
			StringTemplateLanguageLexer lexer =
				new StringTemplateLanguageLexer(new StringReader(action.ToString()));
			StringTemplateLanguageParser parser =
				new StringTemplateLanguageParser(lexer, this);
			parser.setASTNodeClass(typeof(Antlr.StringTemplate.Language.StringTemplateAST).FullName);
			ASTExpr a = null;
			try {
				Hashtable options = parser.action();
				AST tree = parser.getAST();
				if ( tree != null ) {
					if ( tree.Type == StringTemplateLanguageParser.CONDITIONAL ) {
						a = new ConditionalExpr(this, tree);
					}
					else {
						a = new ASTExpr(this, tree, options);
					}
				}
			}
			catch (RecognitionException re) {
				Error("Can't parse chunk: " + action.ToString(), re);
			}
			catch (TokenStreamException tse) {
				Error("Can't parse chunk: " + action.ToString(), tse);
			}
			return a;
		}

		public int TemplateID {
			get {
				return templateID;
			}
		}

		public IDictionary Attributes {
			get {
				return this.attributes;
			}
			set {
				this.attributes = value;
			}
		}

		/// <summary>
		/// Get a list of the strings and subtemplates and attribute refs in a template.
		/// </summary>
		public IList Chunks {
			get {
				return chunks;
			}
		}

		// U T I L I T Y  R O U T I N E S

		public void Error(String msg) {
			this.Error(msg, null);
		}

		public void Warning(String msg) {
			if ( this.ErrorListener != null ) {
				this.ErrorListener.Warning(msg);
			}
			else {
				Console.Error.WriteLine("StringTemplate: warning: " + msg);
			}
		}

		public void Debug(String msg) {
			if ( this.ErrorListener != null ) {
				this.ErrorListener.Debug(msg);
			}
			else {
				Console.Error.WriteLine("StringTemplate: debug: " + msg);
			}
		}

		public void Error(String msg, Exception e) {
			if ( this.ErrorListener != null ) {
				this.ErrorListener.Error(msg, e);
			}
			else {
				if ( e != null ) {
					Console.Error.WriteLine("StringTemplate: error: " + msg + ": " + e.Message);
				}
				else {
					Console.Error.WriteLine("StringTemplate: error: " + msg);
				}
			}
		}

		/** Make StringTemplate check your work as it evaluates templates.
		 *  Problems are sent to error listener.   Currently warns when
		 *  you set attributes that are not used.
		 */
		public static bool InLintMode{
			get {
				return inLintMode;
			}
			set {
				inLintMode = value;
			}
		}

		/** DEBUG MODE IS PRETTY MUCH USELESS AT THE MOMENT! */
		public static bool InDebugMode {
			get {
				return inDebugMode;
			}
			set {
				inDebugMode = true;
			}
		}

		/** Indicates that 'name' has been referenced in this template. */
		protected void trackAttributeReference(String name) {
			if ( referencedAttributes == null ) {
				referencedAttributes = new ArrayList();
			}
			referencedAttributes.Add(name);
		}

		/// <summary>
		/// Executed after evaluating a template.  For now, checks for setting of attributes not reference.
		/// </summary>
		public void CheckForTrouble() {
			// we have table of set values and list of values referenced
			// compare, looking for SET BUT NOT REFERENCED ATTRIBUTES
			if ( attributes == null ) {
				return;
			}

			// if in names and not in referenced attributes, trouble
			foreach ( String name in attributes.Keys ) {
				if ( referencedAttributes != null &&
					!referencedAttributes.Contains(name) ) {
					Warning(this.Name + ": set but not used: " + name);
				}
			}
			// can do the reverse, but will have lots of false warnings :(
		}

		public String ToDebugString() {
			return chunks.ToString();
		}

		public override String ToString() {
			StringWriter buf = new StringWriter();

			try {
				Write(buf);
			}
			catch (IOException io) {
				Console.Error.WriteLine("Got IOException writing to StringWriter????");
			}

			return buf.ToString();
		}
	}
}