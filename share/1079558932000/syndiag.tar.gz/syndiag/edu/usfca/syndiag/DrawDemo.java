package edu.usfca.syndiag;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class DrawDemo extends JPanel {
	AST t = null;

    public void init() {
        setBackground(Color.white);
    }

    public void setAST(AST t){
    	this.t = t;
    }
   
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
		Dimension d = getSize();
        g2.setBackground(getBackground());
        g2.clearRect(0, 0, d.width, d.height);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);        
		
		SwingEngine swing = new SwingEngine();
		swing.setGraphics2D(g2);
		DefaultSyntaxDiagramGenerator diagramGen =
                new DefaultSyntaxDiagramGenerator(swing);
		Draw draw = new Draw();
		draw.setDiagGen(diagramGen);

		if(t==null)return;
    	try{
    		draw.grammar(t);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	int width = ((GrammarAST)t).getWidth();
    	int height = ((GrammarAST)t).getHeight();
    	setPreferredSize(new Dimension(width, height));
    	revalidate();
    }
    
}
