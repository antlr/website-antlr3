/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.io.*;

/**
 * Class to provide InputStream functionality from a portion of a document.
 * Currently only Swing Documents are targeted, but the class is
 * general enough to allow the use of SATC with other text frameworks.
 */
public abstract class DocumentStream extends InputStream {
    
    /**
     * Attaches this input stream to a document.
     * The class of the document is not specified to keep SATC 
     * independent of Swing text framework.
     */
    public abstract void setDocument( Object doc);
    
    /**
     * Restricts the stream to a range of the document.
     */ 
    public abstract void setRange( int p0, int p1);


    /**
     * Reads the next byte of data from this input stream. The value 
     * byte is returned as an <code>int</code> in the range 
     * <code>0</code> to <code>255</code>. If no byte is available 
     * because the end of the stream has been reached, the value 
     * <code>-1</code> is returned. This method blocks until input data 
     * is available, the end of the stream is detected, or an exception 
     * is thrown. 
     * <p>
     * A subclass must provide an implementation of this method. 
     *
     * @return     the next byte of data, or <code>-1</code> if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     */
    public abstract int read() throws IOException ; 
    
    /**
     * Resets the input stream.
     */
    public abstract void reset();
    
}

