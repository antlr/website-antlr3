/*
 Copyright 2009 Robert Baruch (autophile@gmail.com)
 
 This file is part of Unicode2Lexer.
 
 Unicode2Lexer is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Unicode2Lexer is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Unicode2Lexer.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.*;
import java.util.*;

public class Unicode2Lexer {

	static class Line
	{
		public int codePoint;
		public String description;
		public String generalCategory;
		
		public Line(String cp, String de, String gc)
		{
			codePoint = Integer.parseInt(cp, 16);
			
			// Why new String? Because the input strings come from
			// String.split, which only returns internal references
			// to the original line. In other words, after creating
			// a Line, the GC will not be able to garbage-collect
			// the original text line. So you end up storing the entire
			// file in memory.
			
			description = new String(de);
			generalCategory = new String(gc);
		}
	}
	
	static Vector<Line> lines = new Vector<Line>();
	static Hashtable<String, Vector<Line> > categories = new Hashtable<String, Vector<Line> >();
	
	static void generateUnicodeClassLexerRules()
	{
		// Organize lines into categories
		
		for (Line line : lines)
		{
			// ANTLR 3 doesn't handle Unicode > 0xFFFE.
    		
			if (line.codePoint > 0xFFFE)
				continue;
			
			Vector<Line> cat = categories.get(line.generalCategory);
			if (cat == null)
			{
				cat = new Vector<Line>();				
				categories.put(line.generalCategory, cat);
			}
			cat.add(line);			
		}
		
		// For each category, output a lexical rule
		
		for (String category : categories.keySet())
		{
			System.out.println("fragment\nUnicodeCategory" + category + ":");
			Vector<Line> lines = categories.get(category);
			int start = -1;
			int end = 0;
			boolean firstAlt = true;
			
			for (Line line : lines)
			{
				if (start == -1)
				{
					start = line.codePoint;
					end = start;
					continue;
				}
				int codePoint = line.codePoint;
				if (codePoint != end + 1)
				{
					// Note that if the name in the line ends with Last>, then
					// the previous name ended in First>, and the two entries
					// describe a range.
					
					if (!line.description.endsWith("Last>"))
					{
						// Output the current range and start a new range
						printRange(start, end, firstAlt);
						firstAlt = false;
						start = codePoint;
					}
				}
				end = codePoint;
			}
			printRange(start, end, firstAlt); // the last range
			System.out.println("    ;\n\n");
		}
	}
	
	static void printRange(int start, int end, boolean firstAlt)
	{
		if (!firstAlt)
			System.out.print("    | ");
		else
			System.out.print("      ");
		System.out.print(String.format("'\\u%04X'", start));
		if (end == start)
			System.out.println();
		else if (end == start + 1)
			System.out.println(String.format("\n    | '\\u%04X'", end));
		else
			System.out.println(String.format("..'\\u%04X'", end));
	}

    public static void main(String args[]) throws Exception 
	{
		if (args.length == 0)
		{
			System.out.println("Usage: Unicode2Lexer <path-for-UnicodeData.txt>");
			System.exit(1);
		}
		
		BufferedReader in = new BufferedReader(new FileReader(new File(args[0])));
		String line;
		
		while ( (line = in.readLine()) != null)
		{
			String[] tokens = line.split(";", -1);
			String codePoint = tokens[0];
			String description = tokens[1];
			String generalCategory = tokens[2];
			String combiningClass = tokens[3];
			String bidiCategory = tokens[4];
			String decomposition = tokens[5];
			String decimalValue = tokens[6];
			String digitValue = tokens[7];
			String numericValue = tokens[8];
			String mirrored = tokens[9];
			String unicode1name = tokens[10];
			String uppercaseMapping = tokens[11];
			String lowercaseMapping = tokens[12];
			String titlecaseMapping = tokens[13];
			
			lines.add(new Line(codePoint, description, generalCategory));
		}
		
		in.close();
		
		generateUnicodeClassLexerRules();
		
    }
}