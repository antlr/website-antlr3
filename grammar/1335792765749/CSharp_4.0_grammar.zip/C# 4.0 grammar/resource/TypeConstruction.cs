class TypeConstruction {

	void Main() {
		Route route = new Route (from, to);
		
		DomRegion expectedRegion = new DomRegion(
				beginLine: 11,
				beginColumn: 5,
				endLine: 11,
				endColumn: 5
			);
	}
}
