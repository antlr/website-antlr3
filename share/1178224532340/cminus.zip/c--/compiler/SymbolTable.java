import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.HashMap;
import java.util.Vector;
import java.util.Map;

public class SymbolTable{
	HashMap functions = new HashMap();
	
	Vector scopes ;
	Vector frames = new Vector();
	
	HashMap globals = new HashMap();

    public void reset_globals(){
        globals=new HashMap();
        scopes=null;
        frames=new Vector();
    }

    int max_var_num=0;
    int max_label_num=0;

    public int next_label(){
        max_label_num++;
        return max_label_num;
    }
	
    public int next_var(){
        max_var_num++;
        return max_var_num;
    }
	
	public void declare_function(String name, String return_type, Vector params, CommonTree pointer){
		functions.put(name,new Function(name,return_type, params, pointer));
	}
	
	public void enter_block(){
		scopes.add(new HashMap());
	}
	
	public void exit_block(){
		scopes.remove(scopes.size()-1);
	}
	
	public void enter_frame(){
		scopes=new Vector();
		frames.add(scopes);
		scopes.add(new HashMap());
	}
	
    public void enter_frame(String name){
        enter_frame();
        Function fcn=get_function(name);
        enter_frame();
		for(int i=0;i<fcn.params.size();i++){
			FunctionParam p=(FunctionParam)fcn.params.get(i);
            if(p.mode=="scalar"){
                declare_variable(p.name,p.type,true);
            }else{
                declare_array(p.name,p.type,1);
            }
        }
    }

	public void enter_frame(Function fcn, Vector params){	
		enter_frame();
		
		for(int i=0;i<fcn.params.size();i++){
			FunctionParam p=(FunctionParam)fcn.params.get(i);
			if (p.mode=="scalar"){
				declare_variable(p.name,p.type,true);
				set_value(p.name,(Integer)params.get(i),true);
			}else{
				reference_variable(p.name,(Variable)params.get(i));
			}
		}
	}
	
	public void exit_frame(){
		frames.remove(frames.size()-1);
		if (frames.size() > 0){
			scopes=(Vector)frames.get(frames.size()-1);
		}
	}
	
	public Function get_function(String name){
		Function fcn=(Function)functions.get(name);
		if (fcn==null) {
			Main.print_err("No such function: "+name);
		}
		return fcn;
	}
	
	public Variable get_variable(String name){
		if(scopes!=null){
			for(int i=(scopes.size()-1); i>=0; i--){
				Map vars = (Map)scopes.get(i);
				Variable v = (Variable)vars.get(name);
				if (v != null){
					return v;
				}
			}
		}
		Variable v = (Variable)globals.get(name);
		if (v != null){
			return v;
		}
		Main.print_err("Undeclared variable '"+name+"'");
		return null;
	}

    public void test_declared(String name){
        is_declared(name);
    }
    public void test_assign(String name){
        Variable v=get_variable(name);
        if(v!=null && v.read_only){
            Main.print_err("Attempted to assign a value to the read only variable '"+name+"'");
        }

    }

    public boolean is_declared(String name){
        Variable v=get_variable(name);
        return v!=null;
    }
	
	public int get_value(String name){
		Variable v=get_variable(name);
		if (v != null){
			if ( v.mode.equals("scalar")){
				return v.get_value();
			}
		}
		return -1;
	}
	
	public int get_value(String name,Integer index){
		Variable v=get_variable(name);
		
		if (v != null){
			return v.get_value(index);
		}
		
		return -1;
	}
	
	public void set_value(String name, Integer value,Boolean force){
		Variable v=get_variable(name);
		if (v != null){
            if (force){
                v.force_set_value(value);
            }else{
                v.set_value(value);

            }
		}
	}
	
	public void set_value(String name, Integer value){
		Variable v=get_variable(name);
		if (v != null){
			v.set_value(value);
		}
	}
	
	public void set_value(String name, Integer value, Integer index){
		Variable v=get_variable(name);
		if (v != null){
			v.set_value(value,index);
		}
	}
	
    public void declare_variable(String name,String type){
        declare_variable(name,type,false);
    }

	public void declare_variable(String name,String type, Boolean read_only){
		Map vars=get_vars();
    	Variable v = (Variable)vars.get(name);
    	if ( v!=null ) {
      		Main.print_err("Variable '"+name+"' already declared");
   		}else{
   			vars.put(name,new Variable(name,type,next_var(),read_only));
		}
	}
	
	private Map get_vars(){
		Map vars;
		if (scopes==null){
			vars=(Map)globals;
		}else{
			vars =(Map)scopes.get(scopes.size()-1);
		}
		return vars;
	}
	
	public void declare_array(String name,String type,Integer size){
		Map vars=get_vars();
        max_var_num++;
		
    	Variable v = (Variable)vars.get(name);
    	if ( v!=null ) {
      			Main.print_err("Variable '"+name+"' already declared");
   		}else{
   			vars.put(name,new Variable(name,type,size,max_var_num));
		}
	}
	
	public void reference_variable(String name,Variable v){
		Map vars=get_vars();
		v.name=name;
		vars.put(name,v);
	}
}
