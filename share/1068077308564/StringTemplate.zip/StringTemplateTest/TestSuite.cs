using System;
using System.Reflection;

namespace StringTemplateTest {
	/// <summary>
	/// Summary description for TestSuite.
	/// </summary>
	public abstract class TestSuite {
		public String testName = null;

		int failures = 0, successes=0;

		public void assertTrue(bool test) {
			if ( !test ) {
				throw new FailedAssertionException();
			}
		}

		public void runTest(String name) {
			testName = name;
			// look up and run.
			Type c = this.GetType();
			// System.out.println("this.class is "+this.getClass().getName());
			MethodInfo m = null;

			try {
				m = c.GetMethod(name);
				Console.WriteLine("TEST: " + name);
				m.Invoke(this, null);
				successes++;
			}
			catch (TargetInvocationException tie) {
				failures++;
				Console.Error.WriteLine("cannot exec test "+name);
				Console.Error.WriteLine(tie.InnerException.ToString());
			}
		}

		public abstract void runTests();

		public int getFailures() {
			return failures;
		}

		public int getSuccesses() {
			return successes;
		}
	}
}
