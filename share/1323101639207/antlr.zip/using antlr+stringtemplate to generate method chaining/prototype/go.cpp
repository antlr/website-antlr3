#include <mario.h>

int main(int argc, char *argv[])
{
    mario* m=new mario();

    m->pipe_a(123)->pipe_b()->pipe_c();

    delete m;
    return 0;
}
