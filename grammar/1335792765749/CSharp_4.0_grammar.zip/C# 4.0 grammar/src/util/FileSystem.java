package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class FileSystem {

	private FileSystem() {
		// utility class
	}
	
	public static String readTextFile(String fullPathFilename) throws IOException {
		StringBuilder sb = new StringBuilder(1024);

		char[] chars = new char[1024];

		BufferedReader reader = new BufferedReader(new FileReader(fullPathFilename));
		try {
			int numRead = 0;
			while ((numRead = reader.read(chars)) > -1) {
				sb.append(chars, 0, numRead);
			}
		} finally {
			reader.close();
		}

		return sb.toString();
	}

	public static void writeTextFile(String contents, String fullPathFilename) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(fullPathFilename));
		try {
			writer.write(contents);
		} finally {
			writer.close();
		}
	}
	

	public static List<String> findAllFiles(final File dir) {
		List<String> allFiles = new LinkedList<String>();

		File[] files = dir.listFiles();
		for (File f : files) {
			if (f.isDirectory()) {
				allFiles.addAll(findAllFiles(f));
			}
			if (f.isFile() && f.getName().endsWith(".cs")) {
				allFiles.add(f.getAbsolutePath());
			}
		}

		return allFiles;
	}
}
