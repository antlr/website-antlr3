import org.antlr_yggdrasil.runtime.PayloadFactory;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.PayloadToken;
import java.util.HashMap;

public class TESTFactory implements PayloadFactory {
	public static final int Wb=79;
	public static final int Qa=49;
	public static final int Pc=98;
	public static final int Cb=60;
	public static final int Qc=99;
	public static final int Pb=73;
	public static final int V=29;
	public static final int Jc=92;
	public static final int Uc=103;
	public static final int Cc=85;
	public static final int Ub=78;
	public static final int U=28;
	public static final int Tc=102;
	public static final int Nb=71;
	public static final int Ac=83;
	public static final int La=45;
	public static final int D=11;
	public static final int Nc=96;
	public static final int R=25;
	public static final int Wc=104;
	public static final int Ca=36;
	public static final int Ab=58;
	public static final int Lb=69;
	public static final int Q=24;
	public static final int Xc=105;
	public static final int Pa=48;
	public static final int Na=47;
	public static final int Yc=106;
	public static final int Wa=54;
	public static final int Yb=81;
	public static final int Za=57;
	public static final int Hb=65;
	public static final int W=30;
	public static final int Bc=84;
	public static final int Zb=82;
	public static final int WS=4;
	public static final int Fa=39;
	public static final int Ha=41;
	public static final int Kb=68;
	public static final int Fb=63;
	public static final int A=8;
	public static final int Sa=51;
	public static final int Kc=93;
	public static final int Ia=42;
	public static final int X=31;
	public static final int Db=61;
	public static final int C=10;
	public static final int Ua=53;
	public static final int L=19;
	public static final int Ka=44;
	public static final int Da=37;
	public static final int J=17;
	public static final int Fc=88;
	public static final int Sc=101;
	public static final int Rb=75;
	public static final int O=22;
	public static final int Ga=40;
	public static final int P=23;
	public static final int I=16;
	public static final int Aa=34;
	public static final int F=13;
	public static final int Ra=50;
	public static final int Sb=76;
	public static final int S=26;
	public static final int Ec=87;
	public static final int Ma=46;
	public static final int K=18;
	public static final int Dc=86;
	public static final int B=9;
	public static final int Gb=64;
	public static final int Ib=66;
	public static final int M=20;
	public static final int Gc=89;
	public static final int ML_COMMENT=6;
	public static final int Rc=100;
	public static final int Jb=67;
	public static final int T=27;
	public static final int Eb=62;
	public static final int SL_COMMENT=5;
	public static final int Hc=90;
	public static final int Mb=70;
	public static final int Ic=91;
	public static final int H=15;
	public static final int Ya=56;
	public static final int G=14;
	public static final int Ja=43;
	public static final int Lc=94;
	public static final int COMMENT=7;
	public static final int Xb=80;
	public static final int N=21;
	public static final int Z=33;
	public static final int Ta=52;
	public static final int Mc=95;
	public static final int Ba=35;
	public static final int EOF=-1;
	public static final int Bb=59;
	public static final int Tb=77;
	public static final int Tokens=108;
	public static final int Qb=74;
	public static final int Ob=72;
	public static final int Y=32;
	public static final int Ea=38;
	public static final int Xa=55;
	public static final int Oc=97;
	public static final int E=12;
	public static final int Zc=107;
	HashMap<String, Integer> typeMap = new HashMap<String, Integer>();

	public TESTFactory() {
		typeMap.put("Wb", new Integer(79));
		typeMap.put("Qa", new Integer(49));
		typeMap.put("Pc", new Integer(98));
		typeMap.put("Cb", new Integer(60));
		typeMap.put("Qc", new Integer(99));
		typeMap.put("Pb", new Integer(73));
		typeMap.put("V", new Integer(29));
		typeMap.put("Jc", new Integer(92));
		typeMap.put("Uc", new Integer(103));
		typeMap.put("Cc", new Integer(85));
		typeMap.put("Ub", new Integer(78));
		typeMap.put("U", new Integer(28));
		typeMap.put("Tc", new Integer(102));
		typeMap.put("Nb", new Integer(71));
		typeMap.put("Ac", new Integer(83));
		typeMap.put("La", new Integer(45));
		typeMap.put("D", new Integer(11));
		typeMap.put("Nc", new Integer(96));
		typeMap.put("R", new Integer(25));
		typeMap.put("Wc", new Integer(104));
		typeMap.put("Ca", new Integer(36));
		typeMap.put("Ab", new Integer(58));
		typeMap.put("Lb", new Integer(69));
		typeMap.put("Q", new Integer(24));
		typeMap.put("Xc", new Integer(105));
		typeMap.put("Pa", new Integer(48));
		typeMap.put("Na", new Integer(47));
		typeMap.put("Yc", new Integer(106));
		typeMap.put("Wa", new Integer(54));
		typeMap.put("Yb", new Integer(81));
		typeMap.put("Za", new Integer(57));
		typeMap.put("Hb", new Integer(65));
		typeMap.put("W", new Integer(30));
		typeMap.put("Bc", new Integer(84));
		typeMap.put("Zb", new Integer(82));
		typeMap.put("WS", new Integer(4));
		typeMap.put("Fa", new Integer(39));
		typeMap.put("Ha", new Integer(41));
		typeMap.put("Kb", new Integer(68));
		typeMap.put("Fb", new Integer(63));
		typeMap.put("A", new Integer(8));
		typeMap.put("Sa", new Integer(51));
		typeMap.put("Kc", new Integer(93));
		typeMap.put("Ia", new Integer(42));
		typeMap.put("X", new Integer(31));
		typeMap.put("Db", new Integer(61));
		typeMap.put("C", new Integer(10));
		typeMap.put("Ua", new Integer(53));
		typeMap.put("L", new Integer(19));
		typeMap.put("Ka", new Integer(44));
		typeMap.put("Da", new Integer(37));
		typeMap.put("J", new Integer(17));
		typeMap.put("Fc", new Integer(88));
		typeMap.put("Sc", new Integer(101));
		typeMap.put("Rb", new Integer(75));
		typeMap.put("O", new Integer(22));
		typeMap.put("Ga", new Integer(40));
		typeMap.put("P", new Integer(23));
		typeMap.put("I", new Integer(16));
		typeMap.put("Aa", new Integer(34));
		typeMap.put("F", new Integer(13));
		typeMap.put("Ra", new Integer(50));
		typeMap.put("Sb", new Integer(76));
		typeMap.put("S", new Integer(26));
		typeMap.put("Ec", new Integer(87));
		typeMap.put("Ma", new Integer(46));
		typeMap.put("K", new Integer(18));
		typeMap.put("Dc", new Integer(86));
		typeMap.put("B", new Integer(9));
		typeMap.put("Gb", new Integer(64));
		typeMap.put("Ib", new Integer(66));
		typeMap.put("M", new Integer(20));
		typeMap.put("Gc", new Integer(89));
		typeMap.put("ML_COMMENT", new Integer(6));
		typeMap.put("Rc", new Integer(100));
		typeMap.put("Jb", new Integer(67));
		typeMap.put("T", new Integer(27));
		typeMap.put("Eb", new Integer(62));
		typeMap.put("SL_COMMENT", new Integer(5));
		typeMap.put("Hc", new Integer(90));
		typeMap.put("Mb", new Integer(70));
		typeMap.put("Ic", new Integer(91));
		typeMap.put("H", new Integer(15));
		typeMap.put("Ya", new Integer(56));
		typeMap.put("G", new Integer(14));
		typeMap.put("Ja", new Integer(43));
		typeMap.put("Lc", new Integer(94));
		typeMap.put("COMMENT", new Integer(7));
		typeMap.put("Xb", new Integer(80));
		typeMap.put("N", new Integer(21));
		typeMap.put("Z", new Integer(33));
		typeMap.put("Ta", new Integer(52));
		typeMap.put("Mc", new Integer(95));
		typeMap.put("Ba", new Integer(35));
		typeMap.put("EOF", new Integer(-1));
		typeMap.put("Bb", new Integer(59));
		typeMap.put("Tb", new Integer(77));
		typeMap.put("Tokens", new Integer(108));
		typeMap.put("Qb", new Integer(74));
		typeMap.put("Ob", new Integer(72));
		typeMap.put("Y", new Integer(32));
		typeMap.put("Ea", new Integer(38));
		typeMap.put("Xa", new Integer(55));
		typeMap.put("Oc", new Integer(97));
		typeMap.put("E", new Integer(12));
		typeMap.put("Zc", new Integer(107));
	}

	public Payload createNew(int tokenType) {
		return createNew(tokenType, "" + tokenType);
	}
	
	public Payload createNew(Payload typeID, Payload name) {
		Payload pay = createNew(typeID.getText(), name.getText());
		return pay;
	}
	
	public Payload createNew(String typeID, Payload text) {
		return createNew(typeID, text.getText());
	}
	
	public Payload createNew(Payload token, String text) {
		return createNew(token.getText(), text);
	}
		
	public Payload createNew (String typeID, String text) {
		int type = typeMap.get(typeID).intValue();
		
		return createNew(type, text);
	}

	public Payload createNew(int tokenType, String text) {
		switch (tokenType) {
			case A:
				return new Payload1(tokenType, text);

			case B:
				return new PayloadToken(tokenType, text);

			case C:
				return new Payload2(tokenType, text);

			case F:
				return new PayloadToken(tokenType, text);

	
			default:
				return new PayloadToken(tokenType, text);

		}
	}
}
