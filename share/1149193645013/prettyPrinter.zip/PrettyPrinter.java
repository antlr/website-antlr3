/* Main class for ANTLr pretty printer
 * ANTLRBase Copyright 2006 Warp IV Technologies
 * Author:  Loring Craymer
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.*;

import antlr.RecognitionException;
import antlr.collections.AST;

public class PrettyPrinter {
	boolean acting = true;
	boolean opting = true;
	boolean commenting = true;
	boolean documenting = true;
	boolean usingArgs = true;
	boolean excepting = true;
	boolean throwing = true;
	
	String inFile = null;
	String path = null;
	String outFile = "default.g";
	ANTLRBaseTree tree = null;

	public PrettyPrinter() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
public static void main(String[] args) {
		
	File file = null;
	
	PrettyPrinter printer = new PrettyPrinter();
    
	// Use a try/catch block for parser exceptions
	try {
		// if we have at least one command-line argument
		if (args.length > 0 ) {
			System.err.println("Parsing...");
			// for each directory/file specified on the command line
			for(int i=0; i< args.length;i++) {
				if ( args[i].equals("-path") ) {
					i++;
					printer.path = args[i];
				}
				else if (args[i].equals("-file")) { // file name
					i++;
					printer.outFile = args[i];
				}
				else
					printer.setArg(args[i]);
			}
			
			file = new File(printer.inFile);
			printer.doFile(file, args);
		}
		else {
			System.err.println("Usage: java BisonReader" +
				" [-o directory] " +
				"<file name>");
		}
	}
	catch(Exception e) {
		System.err.println("exception: "+e);
		e.printStackTrace(System.err);   // so we can get stack trace
	}
}

// This method decides what action to take based on the type of
//   file we are looking at
public void doFile(File f, String[] args)
						  throws Exception {
	System.err.println("   "+f.getAbsolutePath());
	// parseFile(f.getName(), new FileInputStream(f));
	parseFile(f.getName(), new BufferedReader(new FileReader(f)), path);
}

// Here's where we do the real work...
public void parseFile(String f, Reader r, String path)
		throws Exception {
	try {
		// Create a scanner that reads from the input stream passed to us
		ANTLRLexer lexer = new ANTLRLexer(r);
		lexer.setFilename(f);

		// Create a parser that reads from the scanner
		ANTLRBase parser = new ANTLRBase(lexer);
		parser.setFilename(f);

		// start parsing at the compilationUnit rule
		parser.grammar();
		
		// do something with the tree
		doTreeAction(f, parser.getAST());
	}
	catch (Exception e) {
		System.err.println("parser exception: "+e);
		e.printStackTrace();   // so we can get stack trace		
	}
}

public void doTreeAction(String f, AST t) {
	if ( t==null )
		return;
	
	tree = new ANTLRBaseTree();
	initTree(f);
	try {
		tree.grammar(t);
	}
	catch (RecognitionException e) {
		System.err.println(e.getMessage());
		e.printStackTrace();
	}

}

protected void initTree(String f) {
	tree.setFileName(f);
	tree.setPath(path);
	
	tree.setActing(acting);
	tree.setCommenting(commenting);
	tree.setDocumenting(documenting);
	tree.setExcepting(excepting);
	tree.setOpting(opting);
	tree.setThrowing(throwing);
	tree.setUsingArgs(usingArgs);
	tree.setPath(path);
	
	tree.initOut(outFile);
}
	
	protected void setArg(String opt) {
		if (opt.charAt(0) == '+')
			return;
		else if (opt.charAt(0) != '-') {
			inFile = opt;
			return;
		}
			
		switch (opt.charAt(1)) {
		case 'a':
			acting = false;
			break;
			
		case 'c':
			commenting = false;
			break;
			
		case 'd':
			documenting = false;
			break;
			
		case 'e':
			excepting = false;
			break;
			
		case 'o':
			opting = false;
			break;
			
		case 't':
			throwing = false;
			break;
			
		case 'u':
			usingArgs = false;
			break;
		}
	}

}
