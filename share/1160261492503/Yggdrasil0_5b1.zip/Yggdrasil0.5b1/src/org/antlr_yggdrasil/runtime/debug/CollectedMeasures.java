/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime.debug;

import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;

import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.RecognitionException;
import org.antlr_yggdrasil.runtime.Token;

/**
 * @author Loring Craymer
 *
 */
public class CollectedMeasures extends Vector<BlankMeteredEventListener> implements ANTLRMetrics, TreeInstrumentation {

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#LT(int, org.antlr_yggdrasil.runtime.Token)
	 */
	public void LT(int i, Token t) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.LT(i, t);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#LT(int, int, java.lang.String, int)
	 */
	public void LT(int i, int ID, String text, int type) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.LT(i, ID, text, type);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#beginBacktrack(int)
	 */
	public void beginBacktrack(int level) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.beginBacktrack(level);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#beginResync()
	 */
	public void beginResync() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.beginResync();
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#commence()
	 */
	public void commence() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.commence();
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#consumeHiddenToken(org.antlr_yggdrasil.runtime.Token)
	 */
	public void consumeHiddenToken(Token t) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.consumeHiddenToken(t);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#consumeNode(int, java.lang.String, int)
	 */
	public void consumeNode(int ID, String text, int type) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.consumeNode(ID, text, type);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#consumeToken(org.antlr_yggdrasil.runtime.Token)
	 */
	public void consumeToken(Payload t) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.consumeToken(t);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#endBacktrack(int, boolean)
	 */
	public void endBacktrack(int level, boolean successful) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.endBacktrack(level, successful);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#endResync()
	 */
	public void endResync() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.endResync();
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#enterAlt(int)
	 */
	public void enterAlt(int alt) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.enterAlt(alt);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#enterDecision(int)
	 */
	public void enterDecision(int decisionNumber) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.enterDecision(decisionNumber);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#enterRule(java.lang.String)
	 */
	public void enterRule(String ruleName) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.enterRule(ruleName);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#enterSubRule(int)
	 */
	public void enterSubRule(int decisionNumber) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.enterSubRule(decisionNumber);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#exitDecision(int)
	 */
	public void exitDecision(int decisionNumber) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.exitDecision(decisionNumber);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#exitRule(java.lang.String)
	 */
	public void exitRule(String ruleName) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.exitRule(ruleName);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#exitSubRule(int)
	 */
	public void exitSubRule(int decisionNumber) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.exitSubRule(decisionNumber);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#location(int, int)
	 */
	public void location(int line, int pos) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.location(line, pos);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#mark(int)
	 */
	public void mark(int marker) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.mark(marker);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#recognitionException(org.antlr_yggdrasil.runtime.RecognitionException)
	 */
	public void recognitionException(RecognitionException e) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.recognitionException(e);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#rewind(int)
	 */
	public void rewind(int marker) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.rewind(marker);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#rewind()
	 */
	public void rewind() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.rewind();
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#semanticPredicate(boolean, java.lang.String)
	 */
	public void semanticPredicate(boolean result, String predicate) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.semanticPredicate(result, predicate);
		}
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.ANTLRMetrics#terminate()
	 */
	public void terminate() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.terminate();
		}
	}

	public void addPayload(int code, Payload item) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.addPayload(code, item);
		}
	}

	public void addCarrier(int code, Carrier item) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.addCarrier(code, item);
		}

	}

	public void add(ArrayList item) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.add(item);
		}
	}

	public void processFromMark() {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.processFromMark();
		}
	}

	public void processList(ArrayList v, int direction) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.processList(v, direction);
		}
	}

	public void setNextDown(boolean nextIsDown) {
		Iterator<BlankMeteredEventListener> iter = this.iterator();
		while (iter.hasNext()) {
			BlankMeteredEventListener l = iter.next();
			l.setNextDown(nextIsDown);
		}
	}
}
