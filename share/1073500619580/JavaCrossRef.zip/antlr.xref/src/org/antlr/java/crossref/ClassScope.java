package org.antlr.java.crossref; 

import java.io.IOException;
import java.util.*;


/** Scope representing a Java class.
 */
public class ClassScope extends Scope {

	/**
	 * Should debug information be printed?
     * @see CodeProject.printDebug
	 */
	final static boolean printDebug = false;
	
	/**
	 * interface or class?
	 */
	protected boolean isInterface = false;

    /** My immediate superclass in type hierarchy. */
    protected Vector superClasses = null;

    /** My list of interfaces I implement. */
    protected Vector implementedInterfaces = null;

    /** My immediate subclasse(s) in type hierarchy; unqualified name
     *  to ClassScope.
     */
    protected Hashtable subClasses = null;

    /** Lexically nested classes */
    protected Hashtable classes;

    /** List of methods in this class; overloaded methods distinguished by signature*/
    protected Hashtable methods = new Hashtable(51);

    /** List of fields (instance/class variables) */
    protected Hashtable fields = new Hashtable(51);

    /**
     * Constructor for ClassScope
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public ClassScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /** Look up a method name.  If unqualified, it must exist in
     *  class hierarchy.
     * @param name String
     * @param signature String
     * @return MethodScope
     */
    public MethodScope resolveMethod(String name, String signature) {
		MethodScope ms = null;
        if ( name.indexOf('.')>0 ) {
            return null;
        }
        if(ClassScope.printDebug && CodeProject.printDebug)
        	System.out.println("CodeProject:MethodScope " + "resolve method "+name);
       ArrayList arrayList = (ArrayList)methods.get(name);
        if ( arrayList!=null ) 
        {	boolean found = false;
        	for (Iterator iter = arrayList.iterator(); iter.hasNext();) {
				MethodScope element = (MethodScope) iter.next();
				if(element.matchSignature(signature))
				{
					ms = element;
					break;
				}
			}
        	if(ms != null)
       		{
	            if(ClassScope.printDebug && CodeProject.printDebug)
					System.out.println("CodeProject:MethodScope " + "in this class");
        	    return ms;
       		}
        }
        // not here?  check superclass
        for (int i = 0; superClasses!=null && i < superClasses.size(); i++) {
            ClassScope sup = (ClassScope)superClasses.elementAt(i);
			if(ClassScope.printDebug && CodeProject.printDebug)
	            System.out.println("CodeProject:MethodScope " + "checking superclass "+sup.getFullyQualifiedName());
            ms = sup.resolveMethod(name, signature);
            if ( ms!=null ) {
                return ms;
            }
        }
		if(ClassScope.printDebug && CodeProject.printDebug)
	        System.out.println("CodeProject:MethodScope " + "unresolved");
        return null;
    }
	/** Given a simple typename or qualified type name, find the ClassScope 
	 * @param name String
	 * @return ClassScope
	 */
	public ClassScope resolveClass(String name) {
		ClassScope cs = null;
		if(name == null )
			return null;
		if(classes != null)
			cs = (ClassScope) classes.get(name);
		if(cs != null)
			return cs;
		
		return super.resolveClass(name);
	}

    /**
     * Given simple name, not qualified (no periods), find Field
     * @param name String
     * @return FieldVariable
     */
    public FieldVariable resolveField(String name) {
        if ( name.indexOf('.')>0 ) {
            return null;
        }
		if(ClassScope.printDebug && CodeProject.printDebug)
	        System.out.println("CodeProject:resolveField " + "resolve field "+name);
        FieldVariable f = (FieldVariable)fields.get(name);
        if ( f!=null ) {
			if(ClassScope.printDebug && CodeProject.printDebug)
	            System.out.println("CodeProject:resolveField " + "in this class, type is "+
                               f.getType().getFullyQualifiedName());
            return f;
        }
        // not here?  check superclass
        for (int i = 0; superClasses!=null && i < superClasses.size(); i++) {
            ClassScope sup = (ClassScope)superClasses.elementAt(i);
			if(ClassScope.printDebug && CodeProject.printDebug)
	            System.out.println("CodeProject:resolveField " + "checking superclass "+sup.getFullyQualifiedName());
            f = sup.resolveField(name);
            if ( f!=null ) {
                return f;
            }
        }
		if(ClassScope.printDebug && CodeProject.printDebug)
	        System.out.println("CodeProject:resolveField " + "unresolved");
        return null;
    }

    /**
     * Method resolveVariable
     * @param name String
     * @return Variable
     */
    public Variable resolveVariable(String name) {
        Variable f = resolveField(name);
        if ( f!=null ) {
            return f;
        }
        return null;
        /*  debating about the usefulness of this section
        // is it a package name?
        PackageScope ps = project.getPackageScope(name);
        return ps;
        */
    }

    /** If this is a class, not an interface, return single super class 
     * @return ClassScope
     */
    public ClassScope getSuperClass() {
        if ( isInterface ) {
            return null;
        }
        if ( superClasses!=null ) {
            return (ClassScope)superClasses.elementAt(0);
        }
        return null;
    }

    /**
     * Add Scope to "Scope hiearchy".  Inform Codeproject of 
     * the unique fully qualifed name.
     * @param s Scope
     */
    public void addScope(Scope s) {
        if ( s==null ) {
            return;
        }

		if(ClassScope.printDebug && CodeProject.printDebug)
	        System.out.println("CodeProject:addScoped " +s);

        if ( classes==null ) {
            classes = new Hashtable();
        }
        project.setClassScope(s.getFullyQualifiedName(), (ClassScope)s);
        classes.put(s.getName(),s);
    }

    /**
     * Insert variable, method, or codeblock into this scope
     * @param s Scope
     */
    public void addScopeMember(Scope s) {
		//if(ClassScope.printDebug && CodeProject.printDebug)
        //	 System.out.println("CodeProject:addScopeMember " + s);
        if ( s instanceof FieldVariable ) {
            fields.put(s.getName(),s);
            // set type
        }
        else if ( s instanceof MethodScope ) {
//            project.setMethodScope(s.getName(),(MethodScope)s);
			project.setMethodScope(s.getFullyQualifiedName(),(MethodScope)s);
			String name = s.getName();
			ArrayList arrayList = (ArrayList) methods.get(name);
			if(arrayList == null){
				ArrayList myList = new ArrayList();
				myList.add(s);
				methods.put(name, myList);
			}
			else
				arrayList.add(s);
//            methods.put(s.getName(),s);
        } else if ( s instanceof CodeBlockScope ) {
        	//only done in refs.g 
        	//name is not important
        	//just need for output to xml file
			if(codeBlocks == null)
				codeBlocks = new ArrayList();
			codeBlocks.add(s);
        }

    }

    /** If this is an interface, add to list.
     *  If this is a class, only add one superclass.
     *  Bug: this is not enforced.  Look to fix JFO
     * @param scope ClassScope
     */
    public void addSuperClass(ClassScope scope) {
        if ( scope==null || superClasses != null) {
            // undefined scope? do nothing.
            return;
        }
        if ( superClasses==null ) {
            superClasses = new Vector();
        }
        superClasses.addElement(scope);
        scope.addSubClass(this);
    }

    /**
     * Method addImplementedInterface
     * @param scope ClassScope
     */
    public void addImplementedInterface(ClassScope scope) {
        if ( scope==null ) {
            // undefined scope? do nothing.
            return;
        }
        if ( implementedInterfaces==null ) {
            implementedInterfaces = new Vector();
        }
        implementedInterfaces.addElement(scope);
        scope.addSubClass(this);
    }

    /**
     * Method addSubClass
     * @param scope ClassScope
     */
    public void addSubClass(ClassScope scope) {
        if ( subClasses==null ) {
            subClasses = new Hashtable();
        }
        subClasses.put(scope.getFullyQualifiedName(), scope);
    }

    // GETTER/SETTER

    /**
     * Get "inner" classes, different from subclasses.
     * @return Hashtable
     */
    public Hashtable getClasses() {
        return classes;
    }

    /**
     * Method setClasses
     * @param classes Hashtable
     */
    public void setClasses(Hashtable classes) {
        this.classes = classes;
    }

    /**
     * Get subClass of the class hierarchy
     * @return Hashtable
     */
    public Hashtable getSubClasses() {
        return subClasses;
    }

    /**
     * Method getSuperClasses
     * @return Vector
     */
    public Vector getSuperClasses() {
        return superClasses;
    }

    /**
     * Method getMethods
     * @return Hashtable
     */
    public Hashtable getMethods() {
        return methods;
    }

    /**
     * Lookup name of field in the local list of fields.
     * @param name String
     * @return FieldVariable
     */
    public FieldVariable getField(String name) {
        return (FieldVariable)fields.get(name);
    }

    /**
     * Method setMethods
     * @param methods Hashtable
     */
    public void setMethods(Hashtable methods) {
        this.methods = methods;
    }

    /**
     * Method setInterface
     * @param t boolean
     */
    public void setInterface(boolean t) {
        isInterface = t;
    }

	/**
	 * return this, I represent a Class!
	 * @return ClassScope
	 */
	public ClassScope getNearestClass() {
		return this;
	}
	/**
	 * return this, I represent a Class!
	 * @return Scope
	 */
	public Scope getNearestClassOrMethodScope(){
		return this;
	}
	
    /**
     * System.out.print all relevant information.  
     */
    public void dump() {
        tab();
        System.out.print("ClassScope:dump " + "class "+getName());
        if ( superClasses!=null ) {
            System.out.print(" extends");
            for (int i = 0; i < superClasses.size(); i++) {
                ClassScope sup = (ClassScope)superClasses.elementAt(i);
                System.out.print(" "+sup.getFullyQualifiedName());
            }
        }
        if ( implementedInterfaces!=null ) {
            System.out.print(" implements");
            for (int i = 0; i < implementedInterfaces.size(); i++) {
                ClassScope sup = (ClassScope)implementedInterfaces.elementAt(i);
                System.out.print(" "+sup.getFullyQualifiedName());
            }
        }
        System.out.println();
        tabIndent++;
        Enumeration keys = null;
        if ( classes!=null ) {
            keys = classes.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                ClassScope cs = (ClassScope)classes.get(name);
                cs.dump();
            }
        }
        keys = fields.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            FieldVariable fs = (FieldVariable)fields.get(name);
            fs.dump();
        }
        if ( methods!=null ) {
            keys = methods.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                ArrayList arrayList = (ArrayList)  methods.get(name);
                for (Iterator iter = arrayList.iterator(); iter.hasNext();) {
					MethodScope element = (MethodScope) iter.next();
					element.dump();
				}
            }
        }
        tabIndent--;
    }

    /**
     * Method toString
     * @return String
     */
    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("Class ");
        s.append(getFullyQualifiedName());
        s.append("\n");
        // System.out.println("package: "+packages);
        // System.out.println("classes: "+classes);
        Enumeration keys = null;
        if ( classes!=null ) {
            keys = classes.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                ClassScope cs = (ClassScope)classes.get(name);
                s.append(cs);
            }
        }
        if ( methods!=null ) {
            keys = methods.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
				ArrayList arrayList = (ArrayList)  methods.get(name);
				for (Iterator iter = arrayList.iterator(); iter.hasNext();) {
					MethodScope element = (MethodScope) iter.next();
					s.append(element);
				}
				s.append("\n");
            }
        }
        return s.toString();
    }

	/** XML dump()
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		StringBuffer s = new StringBuffer();
		if(isInterface)
			s.append("Interface ");
		else
			s.append("Class ");
		s.append("name=\"" + getName() + "\"");
		//out the superClasses
		if (superClasses!=null && 0 < superClasses.size())
		{
			ClassScope sup = (ClassScope)superClasses.elementAt(0);
			if(sup.getFullyQualifiedName().compareTo("java.lang.Object") != 0)
				s.append(" superClassName=\"" + sup.getFullyQualifiedName()+ "\"");
		}
		xmlWriter.xmlOpen(s.toString());
		s.delete(0, s.length());
		//out the location
		if(loc != null)
		  loc.xmlSerialize(xmlWriter);
		//out the implemented interfaces
		if ( implementedInterfaces!=null ) {
			xmlWriter.xmlOpen("ImplementedInterfaces");
			for (int i = 0; i < implementedInterfaces.size(); i++) {
				ClassScope implInt = (ClassScope)implementedInterfaces.elementAt(i);
				xmlWriter.xmlNode("ImplementedInterface name=\"" + implInt.getFullyQualifiedName() + "\"");
			}
			xmlWriter.xmlClose("ImplementedInterfaces");
		}
		//out the subClasses
		Enumeration keys = null;
		if ( subClasses!=null ) {
			xmlWriter.xmlOpen("SubClasses");
			keys = subClasses.keys();
			while (keys.hasMoreElements()) {
				String name = (String)keys.nextElement();
				xmlWriter.xmlNode("SubClass name=\"" + name + "\"");
			}
			xmlWriter.xmlClose("SubClasses");
		}
		//out the innerClasses
		if(classes != null)
		{
			keys = classes.keys();
			while (keys.hasMoreElements()) 
			{
				String name = (String)keys.nextElement();
				ClassScope cs = (ClassScope)classes.get(name);
				cs.xmlSerialize(xmlWriter);
			}
		}

		//out the methods
		if(methods != null && methods.size() > 0)
		{
			xmlWriter.xmlOpen("Methods");
			keys = methods.keys();
			while (keys.hasMoreElements()) {
				String str = (String) keys.nextElement();
				

				ArrayList arrayList = (ArrayList)  methods.get(str);
				for (Iterator iter = arrayList.iterator(); iter.hasNext();) {
					MethodScope element = (MethodScope) iter.next();
					element.xmlSerialize(xmlWriter);
				}
			}
			xmlWriter.xmlClose("Methods");
		}
		
		//out the fields
		if(fields != null  && fields.size() > 0){
			xmlWriter.xmlOpen("Fields");
			keys = fields.keys();
			while (keys.hasMoreElements()) {
				s.delete(0, s.length());
				String str = (String) keys.nextElement();
				FieldVariable f = (FieldVariable) fields.get(str);
				f.xmlSerialize(xmlWriter);
			}
			xmlWriter.xmlClose("Fields");
		}
		//out the references
		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);

		if(isInterface)
			xmlWriter.xmlClose("Interface");
		else
			xmlWriter.xmlClose("Class");
	}

	/**
	 * @return boolean
	 */
	public boolean isInterface() {
		return isInterface;
	}


}
