package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 */

import edu.usfca.syndiag.*;
import java.awt.Font;
import java.io.*;

public class HtmlSyntaxDiagramGenerator implements SyntaxDiagramGenerator {
	Writer wrtr;
  String imgPath;
  String ext;
  String borderWidth;
  String htmlTitle;
  String htmlHeader;
  
	public HtmlSyntaxDiagramGenerator(Writer wrtr, String imgPath, String ext,
    String htmlTitle, String htmlHeader, String borderWidth){
		this.wrtr = wrtr;
    this.imgPath = imgPath;
    this.ext = ext;
    this.htmlTitle = htmlTitle;
    this.htmlHeader = htmlHeader;
    this.borderWidth = borderWidth;
    
    try {
      this.wrtr.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n");
      this.wrtr.write("<HTML>\n");
      this.wrtr.write("<HEAD>\n");
      this.wrtr.write("   <meta name=\"generator\" content=\"Syntax Diagram Generator 2, [BSD license] (c) Mark Malakanov, 2004\">\n");
      this.wrtr.write("   <meta name=\"description\" content=\"Syntax Diagram\">\n");
      this.wrtr.write("   <META NAME=\"resource-type\" CONTENT=\"document\">\n");
      this.wrtr.write("   <META NAME=\"distribution\" CONTENT=\"global\">\n");
      this.wrtr.write("   <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=iso-8859-1\">\n");
      this.wrtr.write("   <TITLE>"+htmlTitle+"</TITLE>\n");
      this.wrtr.write("</HEAD>\n");
      this.wrtr.write("\n");
      this.wrtr.write("<BODY>\n");
      this.wrtr.write("<CENTER>\n");
      this.wrtr.write("<H1>"+htmlHeader+"</H1>\n");
      this.wrtr.write("</CENTER>\n");
      this.wrtr.write("\n");
      
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
	}
	
	public void drawArrow(int x1, int y1, int x2, int y2){
    }
    
    public void drawDFConnLine(int x1, int y1, int x2, int y2){
    }
    	 	
    public void drawFUConnLine(int x1, int y1, int x2, int y2){
    }    

    public void drawDBConnLine(int x1, int y1, int x2, int y2){
    }

    public void drawBUConnLine(int x1, int y1, int x2, int y2){
    }
	
	public void drawBackConnLine(int x1, int y1, int x2, int y2, int h){
	}

	public void drawForwardConnLine(int x1, int y1, int x2, int y2, int h){
	}	

	public void drawDotRect(int x, int y, int w, int h){
    }
    
	public void drawLeftRangeRect(int x, int y, int w, int h){
	}

	public void drawRightRangeRect(int x, int y, int w, int h){
	}
	
	public void drawText(String str, Font f, int x, int y){
	}
	
	public void drawRule(int x1, int y1, int x2, int y2, int w, int s){
	}
	
	public void drawBlock(int[] connPoint1, int[] connPoint2, int[] leftConnPoint, int[] rightConnPoint, int i){
	}
	
	public void drawOptional(int[] connPoint1, int[] connPoint2, int h){
	}

	public void drawClosure(int[] connPoint1, int[] connPoint2, int h){
	}
	
	public void drawPClosure(int[] connPoint1, int[] connPoint2, int h){
	}
	
  int origX;
  int origY;
	public void drawRuleRef(int x, int y, int w, int h, String str, Font f)
  {
    try {
      wrtr.write(" <area coords=\""
         +(x-origX)+","+(y-origY)+","+((x-origX)+w)+","+((y-origY)+h)
         +"\" href=\"#"+str+"\" alt=\""+str+"\">");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
	}
	
	public void drawNot(int x, int y, int w, int h, String str, Font f){
    }
	
	public void drawRange(int x, int y, int w, int h, String str, int pos){
	}
	
	public void drawTokenRef(int x, int y, int w, int h, String str, Font f){
	}
	
	public void drawL(int x, int y, int w, int h, String str, Font f){
	}

 
	public void beginRule(String str, int x, int y) {
    origX = x-60;
    origY = y-20;
    try {
      wrtr.write("<IMG name=\""+str+"\" src=\""+imgPath+"/"+str+"."+ext
                 +"\" border=\""+borderWidth+"\" usemap=\"#map_"+str+"\"><p>\n");
      wrtr.write("<map name=\"map_"+str+"\">\n");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
	public void continueRule(String str, int x, int y) {
    
  }
  public void endRule(int x1, int y1, int x2, int y2, int w, int s){
    try {
      wrtr.write("</map>\n");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public void close() {
    try {
      this.wrtr.write("</BODY>\n");
      this.wrtr.write("</HTML>\n");
      wrtr.flush();
      wrtr.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

}

