package org.antlr.java.crossref;



/** Manage the various code projects such as JDK, Resin, Lucene,
 *  Tomcat, and definitions/references within them.
 */
public class CodeRepositoryManager {
}
