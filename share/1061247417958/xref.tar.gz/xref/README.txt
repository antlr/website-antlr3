          Java Cross-Referencing Tool "head start"

This code is a first experiment into a Java cross referencing tool (uses
ANTLR 2.7.2).  It is not finished and I can't even remember what state it is
in.  Literally it may not compile.  I suspect it requires some internal jGuru
code to compile/run.  Also note that the java.g stuff might be out of sync
with the latest at the antlr.org site; though I think I used this to make
the improvements for the antlr.org site.

Anyway, hopefully it will head you in the right direction.

Also note that I don't like the way I was mixing the scope tracking within the
symbol table entries themselves.  Please see

http://www.cs.usfca.edu/~parrt/course/652/lectures/symtab.html

for how I think about them now.

You can use this software for anything you like. :)

Terence Parr
University of San Francisco
parrt@cs.usfca.edu
