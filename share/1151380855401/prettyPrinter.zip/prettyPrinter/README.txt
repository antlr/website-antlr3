This is a minimally tested pretty printer for antlr.  It seems to process antlr.g correctly in the default case (nothing stripped) and with actions removed.

Required command line arguments:
<input file>

Optional arguments:
-file <output file>		// defaults to "dummy.g"
-path <output path>		// defaults to null (current directory)
-a			Strip actions
-c			Strip comments (excluding doc comments)
-d			Strip doc comments
-e			Strip exceptions
-o			Strip options sections
-t			Strip throws specifications
-u			Strip arguments

At this point, I have only checked the -a option and the file/path options.

FILES:
ANTLRBase.g		generates ANTLRLexer.java, ANTLRBase.java, and the ANTLRBaseTokens files
ANTLRBaseTree.g		generates ANTLRBaseTree.java and the ANTLRBaseTreeTokens files
PrettyPrinter.java	main class

