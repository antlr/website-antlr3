package examples.files;
import javax.swing.text.*; 
import java.io.*;
import java.awt.*;
import java.awt.event.*;   
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.util.*;
import javax.swing.undo.*;
import satc.*;
public class Test extends JFrame { 
/*
    private SyntaxTextArea textArea;
    private JTabbedPane tabbedPane;
*/

    private String unicode = "���";

    public Test() {
        setTitle("Test Syntax Highlight");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(
            screenSize.width/8,
            screenSize.height/8,
            3*screenSize.width/4,
            3*screenSize.height/4
        );
/*
        addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e) {
                System.exit(0);
            };
        });
*/
        getContentPane().add( getTabbedPane());
    }

    /**
     * Starts the application.
     */
    public static void main(String[] args) {
        try {
	        UIManager.setLookAndFeel(
	            UIManager.getCrossPlatformLookAndFeelClassName()
            );
            Test frame = new Test();
            frame.setVisible(true);
        } catch( Throwable exception) {
            exception.printStackTrace();
        }
    }

    public JTabbedPane getTabbedPane() {
        if( tabbedPane == null) {
            tabbedPane = new JTabbedPane(3);
            JTextArea textArea = new JTextArea();
        }
        return tabbedPane;
    }

    protected JTextArea createTextArea() {
        textArea = new JTextArea();
        textArea.setFont( new Font( "MonoSpaced", Font.PLAIN, 12));
        return textArea;
    }

    public void openFile( File f, JTextArea textArea) {
        System.out.println( "Opening file " + f.toString() + " ...");
        try {
             BufferedReader in = new BufferedReader( new FileReader( f));
         	 textArea.read( in, "SyntaxUtilities.getTypeForFile( f)");
         } catch( Exception e) {
             e.printStackTrace();
        }
    }
    
    private JTabbedPane tabbedPane;
    private JTextArea textArea;


}
