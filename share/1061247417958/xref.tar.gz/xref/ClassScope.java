 

import java.util.*;

public class ClassScope extends Scope {
    protected boolean isInterface = false;

    /** My immediate superclass in type hierarchy. */
    protected Vector superClasses = null;

    /** My list of interfaces I implement. */
    protected Vector implementedInterfaces = null;

    /** My immediate subclasse(s) in type hierarchy; unqualified name
     *  to ClassScope.
     */
    protected Hashtable subClasses = null;

    /** Lexically nested classes */
    protected Hashtable classes;

    /** List of methods in this class; overloaded methods not distinguished */
    protected Hashtable methods = new Hashtable(51);

    /** List of fields (instance/class variables) */
    protected Hashtable fields = new Hashtable(51);

    public ClassScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /** Look up a method name.  If unqualified, it must exist in
     *  class hierarchy.
     */
    public MethodScope resolveMethod(String name) {
        if ( name.indexOf('.')>0 ) {
            return null;
        }
        System.out.println("resolve method "+name);
        MethodScope ms = (MethodScope)methods.get(name);
        if ( ms!=null ) {
            System.out.println("in this class");
            return ms;
        }
        // not here?  check superclass
        for (int i = 0; superClasses!=null && i < superClasses.size(); i++) {
            ClassScope sup = (ClassScope)superClasses.elementAt(i);
            System.out.println("checking superclass "+sup.getFullyQualifiedName());
            ms = sup.resolveMethod(name);
            if ( ms!=null ) {
                return ms;
            }
        }
        System.out.println("unresolved");
        return null;
    }

    public FieldVariable resolveField(String name) {
        if ( name.indexOf('.')>0 ) {
            return null;
        }
        System.out.println("resolve field "+name);
        FieldVariable f = (FieldVariable)fields.get(name);
        if ( f!=null ) {
            System.out.println("in this class, type is "+
                               f.getType().getFullyQualifiedName());
            return f;
        }
        // not here?  check superclass
        for (int i = 0; superClasses!=null && i < superClasses.size(); i++) {
            ClassScope sup = (ClassScope)superClasses.elementAt(i);
            System.out.println("checking superclass "+sup.getFullyQualifiedName());
            f = sup.resolveField(name);
            if ( f!=null ) {
                return f;
            }
        }
        System.out.println("unresolved");
        return null;
    }

    public Variable resolveVariable(String name) {
        Variable f = resolveField(name);
        if ( f!=null ) {
            return f;
        }
        return null;
        /*
        // is it a package name?
        PackageScope ps = project.getPackageScope(name);
        return ps;
        */
    }

    /** If this is a class not interface, return single super class */
    public ClassScope getSuperClass() {
        if ( isInterface ) {
            return null;
        }
        if ( superClasses!=null ) {
            return (ClassScope)superClasses.elementAt(0);
        }
        return null;
    }

    public void addScope(Scope s) {
        if ( s==null ) {
            return;
        }

        System.out.println("Add scope "+s);

        if ( classes==null ) {
            classes = new Hashtable();
        }
        project.setClassScope(s.getFullyQualifiedName(), (ClassScope)s);
        classes.put(s.getName(),s);
    }

    public void addScopeMember(Scope s) {
        // System.out.println("Add scope member "+s);
        if ( s instanceof FieldVariable ) {
            fields.put(s.getName(),s);
            // set type
        }
        else if ( s instanceof MethodScope ) {
            project.setMethodScope(s.getName(),(MethodScope)s);
            methods.put(s.getName(),s);
        }
    }

    /** Add list of interfaces if this is interface, or single class scope
     *  if class
     */
    public void addSuperClass(ClassScope scope) {
        if ( scope==null ) {
            // undefined scope? do nothing.
            return;
        }
        if ( superClasses==null ) {
            superClasses = new Vector();
        }
        superClasses.addElement(scope);
        scope.addSubClass(this);
    }

    public void addImplementedInterface(ClassScope scope) {
        if ( scope==null ) {
            // undefined scope? do nothing.
            return;
        }
        if ( implementedInterfaces==null ) {
            implementedInterfaces = new Vector();
        }
        implementedInterfaces.addElement(scope);
        scope.addSubClass(this);
    }

    protected void addSubClass(ClassScope scope) {
        if ( subClasses==null ) {
            subClasses = new Hashtable();
        }
        subClasses.put(scope.getName(), scope);
    }

    // GETTER/SETTER

    public Hashtable getClasses() {
        return classes;
    }

    public void setClasses(Hashtable classes) {
        this.classes = classes;
    }

    public Hashtable getSubClasses() {
        return subClasses;
    }

    public Vector getSuperClasses() {
        return superClasses;
    }

    public Hashtable getMethods() {
        return methods;
    }

    public FieldVariable getField(String name) {
        return (FieldVariable)fields.get(name);
    }

    public void setMethods(Hashtable methods) {
        this.methods = methods;
    }

    public void setInterface(boolean t) {
        isInterface = t;
    }

    public void dump() {
        tab();
        System.out.print("class "+getName());
        if ( superClasses!=null ) {
            System.out.print(" extends");
            for (int i = 0; i < superClasses.size(); i++) {
                ClassScope sup = (ClassScope)superClasses.elementAt(i);
                System.out.print(" "+sup.getFullyQualifiedName());
            }
        }
        if ( implementedInterfaces!=null ) {
            System.out.print(" implements");
            for (int i = 0; i < implementedInterfaces.size(); i++) {
                ClassScope sup = (ClassScope)implementedInterfaces.elementAt(i);
                System.out.print(" "+sup.getFullyQualifiedName());
            }
        }
        System.out.println();
        tabIndent++;
        Enumeration keys = null;
        if ( classes!=null ) {
            keys = classes.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                ClassScope cs = (ClassScope)classes.get(name);
                cs.dump();
            }
        }
        keys = fields.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            FieldVariable fs = (FieldVariable)fields.get(name);
            fs.dump();
        }
        if ( methods!=null ) {
            keys = methods.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                MethodScope ms = (MethodScope)methods.get(name);
                ms.dump();
            }
        }
        tabIndent--;
    }

    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("Class ");
        s.append(getFullyQualifiedName());
        s.append("\n");
        // System.out.println("package: "+packages);
        // System.out.println("classes: "+classes);
        Enumeration keys = null;
        if ( classes!=null ) {
            keys = classes.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                ClassScope cs = (ClassScope)classes.get(name);
                s.append(cs);
            }
        }
        if ( methods!=null ) {
            keys = methods.keys();
            while (keys.hasMoreElements()) {
                String name = (String)keys.nextElement();
                MethodScope ms = (MethodScope)methods.get(name);
                s.append(ms);
            }
        }
        return s.toString();
    }
}
