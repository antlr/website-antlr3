package org.antlr.java.crossref;

import java.io.IOException;

/**
 * Filename, line, column, type of file.
 */
public class Location {
	/**
	 * Field SOURCEFILE
	 */
	public final static int SOURCEFILE = 0;
	/**
	 * Field CLASSFILE
	 */
	public final static int CLASSFILE = 1;
	/**
	 * Field JARFILE
	 */
	public final static int JARFILE = 2;
	public final static int XMLFILE = 3;
	/**
	 * Field UNKNOWN
	 */
	public final static int UNKNOWN = 4;
	
	
	/**
	 * Field line
	 */
	private int line;
	/**
	 * Field column
	 */
	private int column;
	/**
	 * Field type
	 */
	private int type;	 //one of the predefined file types, above
	/**
	 * Field filename
	 */
	private String filename;
	/**
	 * Constructor for Location
	 * @param filename String
	 * @param type int
	 */
	public Location(String filename, int type)
	{
		this.filename = filename;
		this.type = type;
	}
	/**
	 * Constructor for Location
	 * @param filename String
	 * @param type int
	 * @param line int
	 * @param column int
	 */
	public Location(String filename, int type, int line, int column)
	{
		this.filename = filename;
		this.type = type;
		this.line = line;
		this.column = column;
	}
	/**
	 * Method toString
	 * @return String
	 */
	public String toString()
	{
		if(type == SOURCEFILE)
			return "filename=\"" + filename + "\" filetype=\"" + typeToString() + "\"" 
			+ " line=\"" +  line + "\" column=\"" + column + "\"";
		return "filename=\"" + filename + "\" filetype=\"" + typeToString() + "\""; 		 
	}
	/**
	 * @return int
	 */
	public int getColumn() {
		return column;
	}

	/**
	 * @param column
	 */
	public void setColumn(int column) {
		this.column = column;
	}

	/**
	 * @return String
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return int
	 */
	public int getLine() {
		return line;
	}

	/**
	 * @param line
	 */
	public void setLine(int line) {
		this.line = line;
	}

	/**
	 * @return String
	 */
	public String getType() {
		return typeToString();
	}

	/**
	 * @param type
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * Method typeToString
	 * @return String
	 */
	private final String typeToString(){
		String ret = null;
		switch(type)
		{
			case SOURCEFILE :
				ret = "Java";
				break;
			case JARFILE :
				ret = "Jar";
				break;
			case CLASSFILE :
				ret = "Class";
				break;
			case XMLFILE :
				ret = "XML";
				break;
			case UNKNOWN:
			default :
			ret = "UNKNOWN";
				break;
		}
		return ret;
	}
	/**
	 * Method typeToInt
	 * @param strType String
	 * @return int
	 */
	public static int typeToInt(String strType){
		int ret = -1;
		//Don't know why this is happening
		if(strType == null)
			ret = UNKNOWN;
		else if(strType.equals("Java"))
			ret = SOURCEFILE;
		else if(strType.equals("Jar"))
			ret = JARFILE;
		else if(strType.equals("Class"))
			ret = CLASSFILE;
		else if(strType.equals("XML"))
			ret = XMLFILE;
		return ret;
	}
	/**
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		xmlWriter.xmlNode("Location " + toString());
		
	}

}
