package org.antlr.java.crossref;
/** 
 */
public class DebugStack extends java.util.Stack {
	/**
	 * Field printDebug
	 */
	final static boolean printDebug = false;
	/**
	 * Constructor for DebugStack
	 */
	public DebugStack() {
		super();
	}
	/**
	 * Method push
	 * @param x Object
	 * @return Object
	 */
	public Object push(Object x){
//		if(DebugStack.printDebug && CodeProject.printDebug)
		if(DebugStack.printDebug)
		  System.out.println("DebugStack:push " + x);
		
		return super.push(x);
	}
	/**
	 * Method pop
	 * @return Object
	 */
	public Object pop(){
//		if(DebugStack.printDebug && CodeProject.printDebug)
		if(DebugStack.printDebug)
		  System.out.println("DebugStack:pop ");
		
		return super.pop();
	}
	

}
