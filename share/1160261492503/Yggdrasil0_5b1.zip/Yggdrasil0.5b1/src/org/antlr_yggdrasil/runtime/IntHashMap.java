package org.antlr_yggdrasil.runtime;

/** A HashMap optimized for int->int mappings.  Used for memoization. */
public class IntHashMap {
	public static int DEFAULT_NUM_BUCKETS = 11;
	public static int DEFAULT_BUCKET_SIZE = 5; // num of key/value pairs
	public static int DEFAULT_NOT_FOUND_VALUE = -1;

	/** array of int arrays that hold key/value pairs in alternating
	 *  positions so that ith key is at data[i*2] and value is data[i*2+1].
	 */
	protected int[/*buckets*/][/*key/values*/] buckets;

	/** How many key/value pairs in each bucket? */
	protected int[/*buckets*/] bucketSize;

	/** How many key value pairs are there? */
	protected int n = 0;

	/** Users can specify what to return when a key is not found in the
	 *  map.  get(unknown) returns this value then.
	 */
	protected int notFoundValue=DEFAULT_NOT_FOUND_VALUE;

	public IntHashMap() {
		this(DEFAULT_NUM_BUCKETS);
	}

	public IntHashMap(int numBuckets) {
		buckets = new int[numBuckets][];
		bucketSize = new int[numBuckets];
	}

	public void setNotFoundValue(int v) {
		notFoundValue = v;
	}

	public int size() {
		return n;
	}

	private int hash(int h) {
		h += ~(h << 9);
		h ^=  (h >>> 14);
		h +=  (h << 4);
		h ^=  (h >>> 10);
		if ( h<0 ) {
			h = -h;
		}
		return h;
	}

	public int get(int key) {
		//System.out.println("get "+key);
		int bucketIndex = hash(key) % buckets.length;
		//int bucketIndex = ((101 * key + 31) % 2147483647) % buckets.length;
		int[] thisBucket = buckets[bucketIndex];
		int thisBucketSize = bucketSize[bucketIndex];
		// search thisBucket for key
		for (int i = 0; i < thisBucketSize; i+=2) {
			if ( thisBucket[i]==key ) {
				return thisBucket[i + 1];
			}
		}
		return notFoundValue;
	}

	public void put(int key, int value) {
		//System.out.println("put "+key+"->"+value);
		int bucketIndex = hash(key) % buckets.length;
		//int bucketIndex = ((101 * key + 31) % 2147483647) % buckets.length;
		int[] thisBucket = buckets[bucketIndex];
		int thisBucketSize = bucketSize[bucketIndex];
		// see if we can find it before adding
		for (int i = 0; i < thisBucketSize; i+=2) {
			if ( thisBucket[i]==key ) {
				// found it; replace value; key is the same
				thisBucket[i+1] = value;
				return;
			}
		}
		// not there, must add but first ensure we have room
		if ( thisBucket==null ) { // bucket unused previously?
			buckets[bucketIndex] = new int[DEFAULT_BUCKET_SIZE*2];
			thisBucket = buckets[bucketIndex];
		}
		else if ( thisBucketSize*2 == thisBucket.length ) { // overflow?
			buckets[bucketIndex] = new int[thisBucket.length*2]; // make 2x as big
			System.arraycopy(thisBucket, 0, buckets[bucketIndex], 0, thisBucket.length);
			thisBucket = buckets[bucketIndex];
		}
		// now we can add key/value pair to the end
		int i = thisBucketSize * 2;
		thisBucket[i] = key;
		thisBucket[i+1] = value;
		bucketSize[bucketIndex]++;
		n++;

		// compute load
		/*
		int x = 0;
		int empty=0;
		for (int j = 0; j < bucketSize.length; j++) {
			int s = bucketSize[j];
			if ( s==0 ) {
				empty++;
			}
			x+=s;
		}
		System.out.println("load: empty="+empty+"/"+buckets.length+", total "+n);
		*/
		//System.out.println("load "+n+"/"+buckets.length+"="+((float)n/buckets.length));
	}

	public void clear() {
		for (int i = 0; i < buckets.length; i++) {
			buckets[i] = null;
		}
	}
}
