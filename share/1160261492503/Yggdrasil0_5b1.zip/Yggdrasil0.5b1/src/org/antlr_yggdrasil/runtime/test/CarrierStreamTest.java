/**
 * 
 */
package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.CarrierStream;
import org.antlr_yggdrasil.runtime.DefaultCarrier;
import org.antlr_yggdrasil.runtime.DefaultPayload;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.TreeBuilder;
import org.antlr_yggdrasil.runtime.TreeCodeBlock;
import java.util.Vector;

/**
 * @author Loring Craymer
 *
 */
public class CarrierStreamTest extends TestCase {
	protected final Carrier up = new DefaultCarrier(new DefaultPayload(TreeCodeBlock.UP, "UP"));
	CarrierStream stream;
	TreeBuilder builder;

	/**
	 * @param name
	 */
	public CarrierStreamTest(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		builder = new TreeBuilder();

		Carrier[] carrier = new Carrier[20];
		for (int i=0; i<20; i++) {
			carrier[i] = new DefaultCarrier(new DefaultPayload(i, "p" + i));
		}
		
		for (int i=0; i<3; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		builder.addCarrier(TreeCodeBlock.DOWN, carrier[3]);
		for (int i=4; i<7; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		builder.addCarrier(TreeCodeBlock.UP, up);
		builder.addCarrier(TreeCodeBlock.RIGHT, carrier[7]);
		builder.addCarrier(TreeCodeBlock.DOWN, carrier[8]);
		for (int i=9; i<11; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		builder.addCarrier(TreeCodeBlock.UP, up);
		builder.addCarrier(TreeCodeBlock.RIGHT, carrier[11]);
		builder.addCarrier(TreeCodeBlock.DOWN, carrier[12]);
		for (int i=13; i<15; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);

		builder.addCarrier(TreeCodeBlock.UP, up);
		builder.addCarrier(TreeCodeBlock.RIGHT, carrier[16]);
		builder.addCarrier(TreeCodeBlock.DOWN, carrier[17]);
		for (int i=18; i<20; i++)
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
		
		Carrier root = builder.buildFromMark();
		stream = new CarrierStream(root);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CarrierStreamTest.class);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
		stream = null;
	}
	
	/**
	 * This should be in TreeBuilderTest, but CarrierStream provides the tools
	 * for testing
	 */
	public final void testRootConstruction() {
		Carrier[] carrier = new Carrier[20];
		Vector<Payload> payloads = new Vector<Payload>();
		for (int i=0; i<20; i++) {
			carrier[i] = new DefaultCarrier(new DefaultPayload(i, "p" + i));
		}
		
		for (int i=0; i<3; i++) {
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
			payloads.add((DefaultPayload) carrier[i].getAttributes());
		}
		
		builder.addCarrier(TreeCodeBlock.DOWN, carrier[3]);
		payloads.add(CarrierStream.DOWN);
		payloads.add((DefaultPayload) carrier[3].getAttributes());
		for (int i=4; i<7; i++) {
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
			payloads.add(carrier[i].getAttributes());
		}
	
		builder.addCarrier(TreeCodeBlock.ROOT, carrier[7]);
		payloads.add(0, (Payload) CarrierStream.DOWN);
		payloads.add(0, carrier[7].getAttributes());
		payloads.add(CarrierStream.UP);
		
		for (int i=9; i<11; i++) {
			builder.addCarrier(TreeCodeBlock.RIGHT, carrier[i]);
			payloads.add(carrier[i].getAttributes());
		}		
		
		Carrier root = builder.buildFromMark();
		stream = new CarrierStream(root);

		for (int i=0; i<payloads.size(); i++) {
			System.out.println(payloads.elementAt(i).toString());
			System.out.println(stream.LT(1).toString());
			assertTrue(stream.next().equals(payloads.elementAt(i)));			
		}
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#reset()}.
	 */
	public final void testReset() {
		Payload pay0 = stream.next();
		Payload pay1 = stream.next();
		
		stream.reset();
		assertTrue(pay0.equals(stream.next()));
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#LT(int)}.
	 */
	public final void testLT() {
		Payload[] payloads = new Payload[20];
		Payload[] pays = new Payload[20];
		
		for (int i=0; i<20; i++)
			payloads[i] = stream.LT(i+1);
		
		for (int i=0; i<20; i++) {
			pays[i] = stream.next();
		}
		
		for (int i=0; i<20; i++) {
			assertTrue(pays[i].equals(payloads[i]));
		}
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#getTreeSource()}.
	 */
	public final void testGetTreeSource() {
		Payload p = stream.LT(1);
		Carrier root = stream.getTreeSource();
		
		assertTrue(root.getAttributes().equals(p));
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#toString(java.lang.Object, java.lang.Object)}.
	 */
	public final void testToStringObjectObject() {
//		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#consume()}.
	 */
	public final void testConsume() {
		Payload p = stream.LT(2);
		
		stream.consume();
		assertTrue(p.equals(stream.next()));
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#LA(int)}.
	 */
	public final void testLA() {
		Payload[] payloads = new Payload[20];
		
		for (int i=0; i<20; i++)
			payloads[i] = stream.LT(i+1);
		
		for (int i=0; i<20; i++) {
			assertTrue(payloads[i].getType() == stream.LA(i+1));
		}
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#mark()}.
	 */
	public final void testMark() {
		stream.seek(9);
		stream.mark();
		Payload p = stream.LT(1);
		Payload n = stream.next();
		stream.next();
		stream.rewind();
		Payload t = stream.LT(1);
		assertTrue(n.equals(stream.next()));
		
		stream.next();
		stream.mark();
		p = stream.LT(1);
		n = stream.next();
		stream.next();
		stream.rewind();
		assertTrue(n.equals(stream.next()));
		
		stream.next();
		stream.mark();
		p = stream.LT(1);
		n = stream.next();
		stream.next();
		stream.rewind();
		assertTrue(n.equals(stream.next()));
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#index()}.
	 */
	public final void testIndex() {
		stream.next();
		stream.next();
		
		assertTrue(stream.index() == 2);
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#rewind(int)}.
	 */
	public final void testRewindInt() {
		// TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#rewind()}.
	 */
	public final void testRewind() {
		// TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#release(int)}.
	 */
	public final void testRelease() {
//		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#seek(int)}.
	 */
	public final void testSeek() {
		Payload[] payloads = new Payload[20];
		Payload[] pays = new Payload[20];
		
		for (int i=0; i<20; i++)
			payloads[i] = stream.LT(i+1);
		
		for (int i=0; i<20; i++) {
			stream.seek(i+1);
			pays[i] = stream.LT(1);
		}
		
		for (int i=0; i<20; i++) {
//			System.out.println(i);
			assertTrue(payloads[i].equals(pays[i]));
		}
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#size()}.
	 */
	public final void testSize() {
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#hasNext()}.
	 */
	public final void testHasNext() {
		assertTrue(stream.hasNext());
		stream = new CarrierStream(null);
		assertTrue(stream.hasNext() == false);
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#next()}.
	 */
	public final void testNext() {
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#remove()}.
	 */
	public final void testRemove() {
//		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#setCursor(org.antlr_yggdrasil.runtime.Carrier)}.
	 */
	public final void testSetCursor() {
		// TODO
	}

	/**
	 * Test method for {@link org.antlr_yggdrasil.runtime.CarrierStream#getCursor()}.
	 */
	public final void testGetCursor() {
		// TODO
	}

}
