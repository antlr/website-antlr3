/**	This class defines the class holding for ASN.1 modules and basic Types		*/

package	parseasn;
import java.lang.* ;
import java.io.* ;
import java.util.* ;
import parseasn.*;
import java.math.*;
import java.lang.reflect.*;

// To hold all the parsed Modules
class ASNModules {
	ArrayList module_list;
	
	// Default Constructor 
	ASNModules(){
		module_list = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts = "";
		Iterator i = module_list.iterator();
		while(i.hasNext()){
			ts += i.next();
		}
		return ts;
	}
		
	public void	add(ASNModule module){
		module_list.add(module);
	}
}
//*********************************************
// Definition of each Module
//*********************************************
class ASNModule	{

	AsnModuleIdentifier	moduleIdentifier; // Name of Module
	ArrayList exportSymbolList ;
	ArrayList importSymbolList ;
	ArrayList importSymbolFromModuleList ;
	AsnTypes asnTypes ;
	ArrayList asnValues	;
	boolean	tag;
	boolean	extensible;
	String tagDefault;
	boolean	exported;
	boolean	imported;
	
	// Default Constructor
	ASNModule(){
		exportSymbolList = new ArrayList();
		importSymbolList = new ArrayList();
		importSymbolFromModuleList = new ArrayList();
		asnTypes =	new	AsnTypes();
		asnValues	= new ArrayList();
		tagDefault ="";
	}
	
	// To String Method
	public String toString(){
		String ts = "";
		Iterator ii;
		ts += "MODULE NAME ::= \n" ;
		ts += moduleIdentifier + "\n";
		ts += "IMPORT SYMBOL LIST"+ "\n";
		ii = importSymbolList.iterator();
		while(ii.hasNext()){
			ts += ii.next() + "\n";
		}
		ts += "IMPORT SYMBOLS FROM MODULE \n";
		ii = importSymbolFromModuleList.iterator();
		while(ii.hasNext()){
			ts += ii.next() + "\n";
		}
		ts += "EXPORT SYMBOL LIST \n";
		ii = exportSymbolList.iterator();
		while(ii.hasNext()){
			ts += ii.next() + "\n";
		}
		ts += "ASN TYPES LIST \n";
			ts += asnTypes + "\n";
			
		ts += "ASN VALUES LIST \n";
		ii = asnValues.iterator();
		while(ii.hasNext()){
			ts += ii.next() + "\n";
		}
	return ts ;
	}
} 
//*********************************************
// Definition of ASN ModuleIdentifier
//*********************************************
class AsnModuleIdentifier	{
	public String name;
	AsnOidComponentList	componentList;
	// Default Constructor
	AsnModuleIdentifier	() {
		componentList =	new	AsnOidComponentList();
	}
	// toString	Implementation
	public String toString() {
		String ts =	"" ;
		ts = name +	"  ";
		if(componentList!=null)
			ts += componentList;
	return ts;
	}
}
//*********************************************
// Definition of OID_Component_LIST
//*********************************************
class AsnOidComponentList {
	boolean isDefinitive;
	AsnDefinedValue defval;
	ArrayList components ;
	
	// Default Constructor
	AsnOidComponentList() {
		components = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts = "";
		if(isDefinitive)
			ts += defval;
		if(components!=null){
			Iterator i = components.iterator();
			while(i.hasNext()){
				ts += (i.next());
			}
		}
	return ts;
	}
}
//*********************************************
// Definition of OID_Component
//*********************************************
class AsnOidComponent {
		
	boolean	nameForm;
	boolean	numberForm;
	boolean	nameAndNumberForm;
	boolean isDefinedValue;
	AsnDefinedValue defval;
	Integer	num;
	public String name;

	// Default Constructor
	AsnOidComponent() {
		name ="";
		num = null;
	}

	// toString	Implementation
	public String toString() {
		String ts =	"";
		if(numberForm){
			ts += num +	"\t"; 
		}
		else if(nameForm){
			ts	+= name;
			if(nameAndNumberForm){
				ts += "(" +	num	+ ")\t";	
			}
		}
		else if(isDefinedValue){
			ts += defval;
		}
	return ts;
	}
}
//*********************************************
// Definition of Symbols From Module List
//*********************************************
class SymbolsFromModule {
	ArrayList symbolList ;
	String modref;
	boolean isOidValue;
	boolean isDefinedValue;
	AsnOidComponentList cmplist;
	AsnDefinedValue	defval;
	
	// Default Constructor
	SymbolsFromModule(){
		symbolList = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts = "Following SYMBOLS ::\n" ;
		Iterator s = symbolList.iterator() ;
		if(s!=null){
			while(s.hasNext()){
				ts += s.next() + "\n";
			}
		}
		ts += "ARE IMPORTED FROM \n";
		ts += modref;
		if(isOidValue)
			ts += cmplist;
		if(isDefinedValue)
			ts += defval;
			
	return ts;
	}
}
//*********************************************
// Definition of Basic Type
//*********************************************
class AsnTypes {
		
	ArrayList		anys	;
	ArrayList		bitStrings ;
	ArrayList		booleans ;
	ArrayList		characterStrings ;
	ArrayList		choices	;
	ArrayList		enums ;
	ArrayList		integers ;
	ArrayList		nulls ;
	ArrayList		objectIdentifiers ;
	ArrayList		octetStrings ;
	ArrayList		reals ;
	ArrayList		sequenceSets ;
	ArrayList		sequenceSetsOf ;
	ArrayList		externals;
	ArrayList		relativeOids;
	ArrayList		selections;
	ArrayList		embeddeds;
	ArrayList		taggeds	;
	ArrayList		defineds ;
	ArrayList		macroOperations	;
	ArrayList		macroErrors	;
	ArrayList		macroObjectTypes;
	

	// Default Constructor
	AsnTypes() {
		anys				= new ArrayList();
		bitStrings 			= new ArrayList();
		booleans 			= new ArrayList();
		characterStrings 	= new ArrayList();
		choices				= new ArrayList();
		enums 				= new ArrayList();
		integers 			= new ArrayList();
		nulls 				= new ArrayList();
		objectIdentifiers 	= new ArrayList();
		octetStrings		= new ArrayList();
		reals				= new ArrayList();
		sequenceSets		= new ArrayList();
		sequenceSetsOf 		= new ArrayList();
		externals 			= new ArrayList();
		relativeOids		= new ArrayList();
		selections			= new ArrayList();
		taggeds				= new ArrayList();
		defineds 			= new ArrayList();
		macroOperations		= new ArrayList();
		macroErrors			= new ArrayList();
		macroObjectTypes	= new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts = "";
		// Define the method
	return ts;
	}
}

//*********************************************
// Definition of Any Type
//*********************************************
class AsnAny {
		
	public String name;
	boolean	isDefinedBy;
	String definedByType;
	final String BUILTINTYPE = "ANY";
	
	// Default Constructor
	AsnAny() {
		name = "";
		isDefinedBy	= false;
		definedByType =	"";
	}
	
	public String toString() {
		   return name;
	}
}
//*********************************************
// Definition of BIT STRING	Type
//*********************************************
class AsnBitString {
	public String name;
	AsnNamedNumberList namedNumberList;
	AsnConstraint constraint;
	final String BUILTINTYPE = "BIT	STRING";

	// Default Constructor	
	AsnBitString() {
		name="";
	}
	
	// toString	definition
	public String toString(){
		String ts =	"";
		ts += (name+ "\t::=\t" + BUILTINTYPE + "\n {");		  
		if(namedNumberList!=null){		
				Iterator nl	= namedNumberList.namedNumbers.iterator();
				while(nl.hasNext()){
						ts += nl.next();
				}
		}
		ts += "}";
		if(constraint!=null){
			ts += constraint ;
		}
	return ts;
	}
}
//*********************************************
// Definition of Character String
//*********************************************	

class AsnCharacterString {
		
	public String name;
	boolean isUCSType;	// Is Unrestricted Character String Type
	String stringtype ;
	AsnConstraint constraint;
	final String BUILTINTYPE = "CHARACTER STRING";
	
	// Default Constructor
	AsnCharacterString() {
			name="";
			stringtype = "";
	}
	public String toString() {
		String ts =	"";
		ts += name+	"\t" + stringtype ;
		if(constraint!=null){
			ts += constraint ;	
		}
	return ts ;
	}
}

//*********************************************
// Definition of Boolean
//*********************************************	
class AsnBoolean {
		
	public String name;
	final String BUILTINTYPE = "BOOLEAN";
	
	// Default Constructor
	AsnBoolean() {
		name="";

	}
	// toString	definition
	
	public String toString() {
		String ts =	"";
		ts += name + "\t::=\t" + BUILTINTYPE ;
	return ts ;				 
	}						
}
//*********************************************
// Definition of Choice
//*********************************************	
class AsnChoice	{
	public String name;
	AsnElementTypeList elementTypeList;
	final String BUILTINTYPE = "CHOICE";
	
	// Default Constructor
	AsnChoice()	{
		name="";
	}
	public String toString() {
		String ts =	"";
		ts += name + "\t::=\t" + BUILTINTYPE + "\t {";
		if(elementTypeList!=null){
			Iterator e = elementTypeList.elements.iterator();
			while(e.hasNext()){
				ts += e.next();
			}
		}
		ts += "}" ;
	return ts ;
	}		
} 
//*********************************************
// Definition of ENUMERATED
//*********************************************	
class AsnEnum {
	public String name;
	public String snaccName;	// specifically added for snacc code generation
	AsnNamedNumberList namedNumberList;
	final String BUILTINTYPE = "ENUMERATED";

	// Default Constructor
	AsnEnum() {
		name="";
		snaccName = "";
	}
	public String toString() {
		String ts =	"";
		ts += name + "\t::=" + BUILTINTYPE + "\t{" ;
		if(namedNumberList!=null){		
				Iterator nl	= namedNumberList.namedNumbers.iterator();
				while(nl.hasNext()){
						ts += nl.next();
				}
		}
	ts +="}";
	return ts;
	}
}
//*********************************************
// Definition of EMBEDDED PDV TYPE
//*********************************************	
class AsnEmbedded {
	public String name;
	final String BUILTINTYPE = "EMBEDDED PDV";
	
	// Default Constructor
	AsnEmbedded(){
	}
	
	public String toString() {
		String ts =	"";
		ts += BUILTINTYPE;
	return ts;
	}
} 
//*********************************************
// Definition of EXTERNAL
//*********************************************	
class AsnExternal {
	public String name;
	final String BUILTINTYPE = "EXTERNAL";
	// Default Constructor
	AsnExternal(){
	}

	public String toString() {
		String ts =	"";
		ts += BUILTINTYPE;
	return ts;
	}
} 
//*********************************************
// Definition of INTEGER
//*********************************************	
class AsnInteger {
		
	public String name;
	AsnNamedNumberList namedNumberList ;
	AsnConstraint constraint;
	final String BUILTINTYPE = "INTEGER";
	
	// Default Constructor
	AsnInteger() {
		name="";
	}
	
	//toString() definition
	public String toString() {
		String ts =	"";
		ts	+= name	+ "\t::=" +	BUILTINTYPE	+ "\t" ;
		if(namedNumberList!=null){		
			Iterator nl	= namedNumberList.namedNumbers.iterator();
			while(nl.hasNext()){
					ts += nl.next();
			}
		}
		if(constraint!=null){
			ts += constraint ;
		}
	return ts;
	}
}
//*********************************************
// Definition of NULL
//*********************************************	
class AsnNull {
		
	public String name;
	final String BUILTINTYPE = "NULL";
	
	// Default Constructor
	AsnNull() {
		name="";
	}
	
	//toString() definition
	public String toString() {
		String ts =	"";
		ts += name + "\t::=\t" + BUILTINTYPE ;
	return ts ;
	}
}
				
//*********************************************
// Definition of ObjectIdentifier
//*********************************************	
class AsnObjectIdentifier {
		
	public String name;
	final String BUILTINTYPE = "OBJECT IDENTIFIER";
	
	// Default Constructor
	AsnObjectIdentifier() {
		name="";
	}

	//toString() definition
	public String toString() {
		String ts =	"";
		ts += name + "\t::=\t" + BUILTINTYPE;
	return ts;
	}
}
//*********************************************
// Definition of Octet String
//*********************************************	
class AsnOctetString {
		
	public String name;
	AsnConstraint constraint;
	final String BUILTINTYPE = "OCTET STRING";

	// Default Constructor
	AsnOctetString() {
		name="";
	}
	
	//toString Definition
	public String toString() {
		String ts =	"";
		ts += name + "\t::=" + BUILTINTYPE+	"\t";
		if(constraint!=null){
			ts += constraint ;
		}
	return ts;
	}
}
//*********************************************
// Definition of Real
//*********************************************	
class AsnReal {
		
	public String name;
	final String BUILTINTYPE = "REAL";

	// Default Constructor
	AsnReal() {
		name="";
	}
	
	// toString	Definition
	public String toString() {
		 String	ts = "";
		 ts	+= name	+ "\t::=\t"	+ BUILTINTYPE ;
	return ts;
	}		 
}
//*********************************************
// Definition of RELATIVE OID TYPE
//*********************************************	
class AsnRelativeOid {
	public String name;
	final String BUILTINTYPE = "RELATIVE-OID";
	
	// Default Constructor
	AsnRelativeOid() {
	}
	
	public String toString() {
		String ts =	"";
		ts += BUILTINTYPE;
	return ts;
	}
} 
//*********************************************
// Definition of Sequence  & Set 
//*********************************************
class AsnSequenceSet {
		
	public String name;			   // Name of Sequence
	AsnElementTypeList elementTypeList;
	boolean	isSequence;
	final String BUILTINTYPE = "SEQUENCE";
	final String BUILTINTYPE1 =	"SET";
	
	// Default Constructor
	AsnSequenceSet() {
		name = "";
		isSequence = false;
	}

	// toString	definition
	
	public String toString() {
		String ts =	"";
		ts += (name);
		if(isSequence)
			ts += "\t::=" +	BUILTINTYPE	+ "\t";
		else
			ts += "\t::=" +	BUILTINTYPE1 + "\t";
		
		ts +="{" ;
		
		if(elementTypeList!=null){
			Iterator e = elementTypeList.elements.iterator();
			while(e.hasNext()){
				ts += e.next();
			}
		}
		ts += "}";
	return ts;
	}		
} // End Class

//*********************************************
// Definition of Sequence  & Set OF	Elements
//*********************************************
class AsnSequenceOf	{
		
	public String name;	  // Refers	to assignment name
	AsnConstraint constraint;
	Object typeReference; // Refers	to typeReference after OF KW
	boolean	isSequenceOf; // Differntiates between SEQUENCE	OF and SET OF types
	boolean	isDefinedType;
	boolean isSizeConstraint;
	String typeName;	// Name	of the defined type
	final String BUILTINTYPE = "SEQUENCE OF";
	final String BUILTINTYPE1 =	"SET OF";
	
	// Default Constructor
	AsnSequenceOf()	{
		name = "";
		constraint = null;
		typeReference = null;
		isSequenceOf = false;
		isDefinedType = false;
		isSizeConstraint = false;
		typeName = "";
		
	}
	
	// toString	definition
	public String toString() {
		String ts =	"";			
		ts += name + "\t::=\t";
		if(isSequenceOf){
			ts += ("SEQUENCE\t");
			if(constraint!=null)
					ts += (constraint);			  
			ts += ("\tOF\t");
		}else {
			ts += ("SET\t");
			if(constraint!=null)
					ts += (constraint);			  
			ts += ("\tOF\t");
		}
		if(isDefinedType){
			ts += (typeName);
		} else {
			ts += (typeReference.getClass().getName());	  // Print builtinType Class Name 
		}
	return ts;
	}
} 
//*********************************************
// Definition of Tagged	Type
//*********************************************
class AsnTaggedType	{
		
	public String name;
	AsnTag tag;
	String tagDefault ;
	Object typeReference;  // Type Reference
	boolean	isDefinedType; // Distinguish between builtin and defined types
	String typeName;	   // Name of defined type
	
	// Default Constructor
	AsnTaggedType()	{
		name="";
		tagDefault = "";
		typeReference =	null;
		isDefinedType =	false;
		typeName = "";
	}
	
	//toString() definition
	
	public String toString() {
		String ts =	"";
		ts += name;
		ts += ("\t"	+ tag +	"\t" + tagDefault+"\t" );
		if(isDefinedType){
			ts += (typeName);
		}
		else{		
			ts += (typeReference.getClass().getName());
		}
	return ts;
	}
}

//*********************************************
// Definition of Selection Type
//*********************************************
class AsnSelectionType {
	public String name;
	String selectionID;
	Object type;
	
	// Default Constructor
	AsnSelectionType(){
	}
	
	// toString Method
	public String toString(){
		String ts = "";
		//Define To String Method
	return ts;
	}
}

/* Causing infinite recursion
//*********************************************
// Definition of TypeAndConstraint
//*********************************************
class AsnTypeAndConstraint {
	Object type;
	AsnConstraint constraint;
	
	AsnTypeAndConstraint(){
	}
	//Define To String Method
}
*/
//*********************************************
// Definition of Tag
//*********************************************
class AsnTag {
	String clazz;
	AsnClassNumber classNumber;
	
	// Default Constructor
	AsnTag() {
		clazz =	"";
	}

	//toString() definition
	public String toString() {
		String ts =	"";
		ts += ("[");
		if(clazz!= ""){
				ts += (clazz);
		}
		if(classNumber!=null){
				ts += (classNumber);
		}
		ts += ("]");
	return ts;
	}
}
//*********************************************
// Definition of Class_Number
//*********************************************
class AsnClassNumber	{
	Integer	num;
	public String name;
	
	// Default Constructor
	AsnClassNumber() {
	}
	
	//toString definition
	public String toString() {
		String ts =	"";
		if(num!=null){
			ts += (num);
		}else {
			ts += (name);
		}
	return ts;
	}
}		

//*********************************************
// Definition of Defined Type
//*********************************************
class AsnDefinedType {
		
	public String name;
	boolean	isModuleReference;
	String moduleReference;
	String typeReference;
	AsnConstraint constraint;
	
	// Default Constructor
	AsnDefinedType() {
		name="";
		moduleReference	="";
		typeReference =	"";			
		isModuleReference =	false;
	}
	// toString() Definition
	
	public String toString() {
		String ts =	"";
		if(isModuleReference){
			ts += (moduleReference+	"."	+ typeReference);
		} else {
			ts += (typeReference);
		}
		if(constraint!=null){
			ts += constraint;
		}
	
	return ts;
	}
}

//*********************************************
// Definition of MACRO OPERATION
//*********************************************
class OperationMacro  {
	public String name;
	String argumentTypeIdentifier;	// Argument NamedType identifier
	Object argumentType;			// Holds the argument Type
	public String argumentName;		// Argument	Type Name 
	String resultTypeIdentifier;		// Result NamedType identifier 
	Object resultType;				// Holds the resultType
	String resultName;				// Result Type Name
	boolean	isArgumentName;			
	boolean	isResult;
	boolean	isLinkedOperation;		
	boolean	isResultName;
	boolean	isErrors;			
	ArrayList errorList 	;	
	ArrayList linkedOpList	;		
	
	// Default Constructors
	OperationMacro(){
		errorList 	= new ArrayList();	
		linkedOpList	= new ArrayList();		
	}
	
	// toString() definition
	
	public String toString() {
		String ts =	"";
		ts += (name	+ "\t::=\t OPERATION");
		if(isArgumentName)
				ts += ("ARGUMENT\t\t" +	argumentName);
		if(isResult){
				ts += ("RESULT\t\t"	+ resultName);
		}
		if(isLinkedOperation){
			ts += ("LINKED OPERATION\t"	);
			Iterator e = linkedOpList.iterator();
			if(e.hasNext()){
				while(e.hasNext())
						ts += (e.next());
			}
			ts += ("}");
		}
		if(isErrors){
			ts += ("ERRORS\t{");			  
			Iterator e = errorList.iterator();
			if(e.hasNext()){
				while(e.hasNext())
					ts += e.next();
			}
			ts += ("}");
		}
	return ts ;	   
	}
	
	// Get the first linked operationName
	public String get_firstLinkedOpName(){
		Object obj = linkedOpList.get(0);
		if((AsnValue.class).isInstance(obj)){
			return "isValue";
		}
		else if((AsnDefinedType.class).isInstance(obj)){
			return ((AsnDefinedType)obj).typeReference;
		}else {
			String nameoftype = null;
			try {
				Field nameField;
				Class c = obj.getClass();
				nameField = c.getField("name");
				nameoftype = (String)nameField.get(obj);
			}catch(Exception e){
				e.printStackTrace(System.err);		
			}
		return nameoftype;
		}	
	}
} 
//*********************************************
// Definition of Macro ERROR
//*********************************************	
class ErrorMacro {
	public String name;
	String parameterName;
	boolean	isParameter;
	Object typeReference;
	boolean	isDefinedType;			// Type	is Defined or builtin type
	String typeName;				// Name	of the Defined Type
	
	// Default Constructor
	ErrorMacro() {
	}
		
	// toString	Method Definition
	
	public String toString() {
		String ts =	"";
		ts += (name	+ "\t::=\tERROR");				
		if(isParameter){
			if(parameterName!=""){
				ts += ("PARAMETER\t" + parameterName);
			} else {
				ts += ("PARAMETER\t" );
				if(isDefinedType)
					ts += (typeName);
				else
					ts += (typeReference.getClass().getName());
			}
		}
	return ts;
	}
}

//*********************************************
// Definition of OBJECT-TYPE Macro
//*********************************************
class ObjectType {

	String accessPart;	String statusPart;
	ArrayList elements ;
	AsnValue value;
	Object type;
	final String BUILTINTYPE = "OBJECT-TYPE";
	
	// Default Constructor
	ObjectType(){
		elements = new ArrayList();
	}
	
	public String toString() {
		String ts =	"";
		ts += ("AccessPart is "	+ accessPart);
	return ts;
	}
}

//*********************************************
// Definition of Element Type List
//*********************************************
class AsnElementTypeList {
	ArrayList elements;
	
	// Default Constructor
	AsnElementTypeList(){
		elements = new ArrayList();
	}
	
	public String toString() {
		String ts =	"";
	
	return ts;
	}
}
//*********************************************
// Definition of Element Type
//*********************************************
class AsnElementType {

	boolean	isOptional;			boolean	isDefault;
	boolean	isComponentsOf;		boolean	isTagDefault;
	boolean	isTag;				boolean	isDefinedType;			// Element type	is defined Type
	AsnTag tag;					AsnValue value;
	String typeTagDefault;	
	public String name;			// type
	Object typeReference;		// type	Reference
	String typeName;			// If defined type then	typeName
	
	// Default Constructor
	AsnElementType() {
		isOptional = false;
	}
	
	// toString() Method Definition
	
	public String toString() {
		String ts =	"";
		if(isComponentsOf){
				ts += ("\tCOMPONENTS	OF\t");
		} else {
			ts += (name);
			if(isTag){		
				ts += ("\t");
				ts += (tag);  
			}
			if(isTagDefault){		
				ts += ("\t");
				ts += (typeTagDefault);		  
			}
		}
		if(isDefinedType){				
			ts += ("\t");
			ts += (typeName);
		} else {
			ts += (typeReference.getClass().getName());
		}
		if(isOptional){
				ts += ("\tOPTIONAL");
		}
		if(isDefault){
				ts += ("\tDEFAULT\t");
				ts += (value);
		}
	return ts;
	}		
}

//*********************************************
// Definition of Named Number List
//*********************************************
class AsnNamedNumberList {
	ArrayList namedNumbers;
	
	// Default Constructor
	AsnNamedNumberList() {
		namedNumbers = new ArrayList();
	}
	
	// Return the total number of elements in the list
	public int count(){
		return namedNumbers.size();
	}
}
//*********************************************
// Definition of NamedNumber
//*********************************************
class AsnNamedNumber {
	public String name;
	boolean	isSignedNumber;
	AsnSignedNumber	signedNumber ;
	AsnDefinedValue	definedValue ;
	
	// Default Constructor
	AsnNamedNumber() {
		name ="";
	}
	
	// toString() Method Definition
	
	public String toString() {
		String ts =	"";
		ts += (name	+ "\t(");
		
		if(isSignedNumber){
			ts += (signedNumber);
		} else{
			ts += (definedValue);
		}
		ts += (")");
	return ts;		
	}
} 
// New Definition of Constraints
//*********************************************
// Definition of AsnConstraint
//*********************************************
class AsnConstraint{
	boolean isSignedNumber;		boolean isDefinedValue; 
	boolean isColonValue;		boolean isElementSetSpecs; 
	boolean isExceptionSpec;	boolean isAdditionalElementSpec;
	boolean isCommaDotDot;
	AsnSignedNumber signedNumber;
	AsnDefinedValue definedValue;
	AsnValue value;
	Object type;
	ElementSetSpec elemSetSpec,addElemSetSpec;
	
	// Default Constructor
	AsnConstraint(){
	}
	
	// toString() method
	public String toString(){
		String ts = "";
		if(isElementSetSpecs)
			ts += elemSetSpec;
		else if(isAdditionalElementSpec)
			ts += addElemSetSpec ;
		if(isExceptionSpec){
			ts += " !"	;
			if(isSignedNumber)
				ts += signedNumber;
			else if(isDefinedValue)
				ts += definedValue;
		// ??????? Type to returned as string also ???????
			else if(isColonValue)
				ts += value ;
		}
	return ts;
	}

	// Return the total intersection elements in the element
	// Spec list
	public int sz_elemSS_IntsectList(){
		return elemSetSpec.intersectionList.size();
	}

	// Return the first intersection element
	public Intersection get_elemSS_firstIntsectElem(){
		return (Intersection)elemSetSpec.intersectionList.get(0);
	}
	
	// Return the required intersection element
	public Intersection get_elemSS_IntsectElem(int i){
		return (Intersection)elemSetSpec.intersectionList.get(i);
	}
	
	// Return if All Except Constraint Elements exists
	public	boolean elemSS_isAllExcept(){
		if(elemSetSpec.isAllExcept)
			return true;
		else
			return false;
	}
	
	// Return AllExcept Constraint Elements
	public ConstraintElements elemSS_allExceptConstraintElem(){
		return elemSetSpec.allExceptCnselem	;
	}
	
	// Returns first constraint Element in the first Intersection
	// List
	public ConstraintElements get_elemSS_firstConstraintElem(){
		Intersection intersect = get_elemSS_firstIntsectElem();
		return (ConstraintElements)intersect.cnsElemList.get(0);
	}

	// Returns Number of Constraint Elements in the 
	// specified IntersectionList
	public int sz_elemSS_intersectionConstraintElems(int i){
		Intersection intersect = get_elemSS_IntsectElem(i);
		if(intersect!=null)
			return intersect.cnsElemList.size();
		else
			return -1;
	}
	// Returns specified Constraint Elements in the specified IntersectionList
	public ConstraintElements get_elemSS_intersectionConstraintElems
							(int intersectElem ,int constraintElem){
		Intersection intersect = get_elemSS_IntsectElem(intersectElem);
		return (ConstraintElements)intersect.cnsElemList.get(constraintElem);
	}
	
	//---------For additionalElementSetSpecs
	// Return the total intersection elements in the add element
	// Spec list
	public int sz_addElemSS_IntsectList(){
		return addElemSetSpec.intersectionList.size();
	}

	// Return the first additional intersection element
	public Intersection get_addElemSS_firstIntsectElem(){
		return (Intersection)addElemSetSpec.intersectionList.get(0);
	}
	
	// Return the required additional intersection element
	public Intersection get_addElemSS_IntsectElem(int i){
		return (Intersection)addElemSetSpec.intersectionList.get(i);
	}
	
	// Return if All Except additional Constraint Elements exists
	public	boolean addElemSS_isAllExcept(){
		if(addElemSetSpec.isAllExcept)
			return true;
		else
			return false;
	}
	
	// Return AllExcept additional Constraint Elements
	public ConstraintElements addElemSS_allExceptConstraintElem(){
		return addElemSetSpec.allExceptCnselem	;
	}
	
	// Returns first additional constraint Element in the first Intersection
	// List
	public ConstraintElements get_addElemSS_firstConstraintElem(){
		Intersection intersect = get_addElemSS_firstIntsectElem();
		return (ConstraintElements)intersect.cnsElemList.get(0);
	}

	// Returns Number of additional Constraint Elements in the 
	// specified IntersectionList
	public int sz_addElemSS_intersectionConstraintElems(int i){
		Intersection intersect = get_addElemSS_IntsectElem(i);
		if(intersect!=null)
			return intersect.cnsElemList.size();
		else
			return -1;
	}
	// Returns specified additional Constraint Elements in the specified IntersectionList
	public ConstraintElements get_addElemSS_intersectionConstraintElems
							(int intersectElem ,int constraintElem){
		Intersection intersect = get_addElemSS_IntsectElem(intersectElem);
		return (ConstraintElements)intersect.cnsElemList.get(constraintElem);
	}
	
} // End AsnConstraint

//-------------------------------------------------------
class ElementSetSpec {
	boolean isAllExcept;
	ConstraintElements allExceptCnselem;
	ArrayList intersectionList ;
	
	// Default Constructor
	ElementSetSpec(){
		intersectionList = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts ="";
		Iterator e = intersectionList.iterator();
		if(e!=null){
			while(e.hasNext()){
				ts += e.next() ;
				ts += "|" ;
			}
		}
		if(isAllExcept){
			ts += "ALL EXCEPT  " + allExceptCnselem;
		}
	return ts ;
	}
}

//-------------------------------------------------------
class Intersection {
	boolean isInterSection;
	boolean isExcept;
	ArrayList cnsElemList ;
	ArrayList exceptCnsElem ;	
	
	// Default Constructor
	Intersection(){
		cnsElemList = new ArrayList();
		exceptCnsElem = new ArrayList();	
	}
		
	// toString Method
	public String toString(){
		String ts = "";
		Iterator e = cnsElemList.iterator();
		Iterator i = exceptCnsElem.iterator();
		while(e.hasNext()){	
			ts += "\t" + e.next();
		}
		if(isExcept){
			ts += "EXCEPT" ;
			while(i.hasNext()){
				ts += "\t" + i.next();
			}
		}
	return ts;		
	}
}
//*********************************************
// Definition of Constraint_Elements
//*********************************************
class ConstraintElements {
	
	boolean isValue;			boolean isValueRange;
	boolean isSizeConstraint;	boolean isElementSetSpec; 	
	boolean isIncludeType;		boolean isPatternValue; 	
	boolean isWithComponent;	boolean isWithComponents;	
	boolean isMinKw;			boolean isMaxKw;
	boolean isLEndLess;			boolean isUEndLess;
	boolean isTypeConstraint;	boolean isAlphabetConstraint;
	
	AsnConstraint constraint;
	AsnValue value,lEndValue,uEndValue;
	ElementSetSpec elespec;
	Object type;
	ArrayList typeConstraintList ;
		
	ConstraintElements(){
		typeConstraintList = new ArrayList();
	}	
	
	//toString definition
	public String toString(){
		String ts = "";
		if(isValue){
			ts += value;
		}
		else if(isValueRange){
			ts += lEndValue + ".." + uEndValue;
		}
		else if(isSizeConstraint){
			ts += constraint ;
		}
		else if(isElementSetSpec){
			ts += elespec;
		}
		else if(isPatternValue){
			ts += "PATTERN" + value;
		}		
		else if(isWithComponent){
			ts += "WITH COMPONENT " + constraint;
		}
		else if(isWithComponents){
			Iterator e = typeConstraintList.iterator();
			ts += "WITH COMPONENTS" + "\t";
			while(e.hasNext()){
				ts += e.next();
			}
		}
		else if(isAlphabetConstraint){
			ts +="FROM" + constraint;
		}
	return ts ;			
	}
}
class NamedConstraint {
	String name; 	
	boolean isConstraint;
	boolean isPresentKw;
	boolean isAbsentKw;		
	boolean isOptionalKw;
	AsnConstraint constraint;
	
	NamedConstraint(){
	}
	
	public String toString() {
		String ts = "";
		ts += name ;
		if(isConstraint){
			ts += constraint;
		}
		if(isPresentKw)
			ts += "\t" + "PRESENT";
		if(isAbsentKw)
			ts += "\t" + "ABSENT";
		if(isOptionalKw)
			ts += "\t"+ "OPTIONAL";
	return ts ;			
	}
}
//*********************************************
// Definition of Value
//*********************************************
class AsnValue {
		
	public String name;
	String typeName;			boolean	isTrueKW;
	boolean	isFalseKW;			boolean	isNullKW;
	boolean	isPlusInfinity;		boolean	isMinusInfinity;
	boolean	isCString;			boolean	isSignedNumber;
	boolean	isDefinedValue;		boolean isBStrOrOstrValue;
	boolean isCStrValue;		boolean isSequenceValue;
	boolean isSequenceOfValue;	boolean isEnumIntValue;
	boolean isAsnOIDValue;		boolean isChoiceValue;
	String bStr, cStr, hStr, enumIntVal;
	AsnBitOrOctetStringValue bStrValue;
	AsnCharacterStringValue cStrValue;
	AsnSequenceValue seqval;	
	AsnSequenceOfValue seqOfVal;
	AsnChoiceValue chval;
	AsnDefinedValue	definedValue;
	AsnSignedNumber	signedNumber;
	AsnOidComponentList oidval;
	
	//Default Constructor	
	AsnValue() {
	}
		
	// toString() Method Definition
	
	public String toString() {
		String ts =	"";
		if(name != null && typeName!= null){
			ts += (name	+"\t" +	typeName);
		}
		if(isTrueKW){
			ts += ("\tTRUE");
		}
		else if(isFalseKW){
			ts += ("\tFALSE");
		}
		else if(isNullKW){
			ts += ("\tNULL");
		}
		else if(isPlusInfinity){
			ts += ("\tplusInfinity");
		}
		else if(isMinusInfinity){
			ts += ("\tminusInfinity");
		}
		else if(isCString){
			ts += ("\t"	+ cStr);
		}
		else if(isBStrOrOstrValue){
			ts += ("\t"	+ bStrValue);
		}
		else if(isCStrValue){
			ts+= ("\t" + cStrValue);
		}
		else if(isSequenceValue){
			ts +=("\t" + seqval);
		}
		else if(isChoiceValue){
			ts +=("\t" + chval);
		}
		else if(isEnumIntValue){
			ts +=("\t" + enumIntVal);
		}
		else if(isSignedNumber){
			ts += signedNumber;
		}
		else if(isAsnOIDValue){
			ts += oidval;
		}
		else if(isSequenceOfValue){
			ts += seqOfVal;
		}
		else if(isDefinedValue){
			ts += (definedValue);
		}
		else{
			ts += ("Unknown	Value");
		}
	return ts;
	}
} 
//*********************************************
// Definition of AsnBitStringOrOctetStringValue
//*********************************************
class AsnBitOrOctetStringValue  {
	boolean isHString;
	boolean isBString;
	String bhStr;
	ArrayList idlist ;	
	
	//Default Constructor
	AsnBitOrOctetStringValue()  {
		idlist = new ArrayList();	
	}
	
	public String toString() {
		String ts = "";
		if(isHString ||isBString)
			ts += bhStr;
		else{
			if(idlist!=null){
				Iterator e = idlist.iterator();
				while(e.hasNext()){
					ts += e.next();
				}
			}
		}
	return ts;
	}
}
//*********************************************
// Definition of AsnCharacterStringValue
//*********************************************
class AsnCharacterStringValue  {
		
	boolean isTuple;	boolean isQuadruple;
	boolean isCharDefList;	String cStr;
	ArrayList charDefsList ;	
	ArrayList tupleQuad ;
	
	//Default Constructor
	AsnCharacterStringValue()  {
		charDefsList = new ArrayList();	
		tupleQuad = new ArrayList();
	}
		
	public String toString() {
		String ts = "";
		if (isTuple || isQuadruple){
			Iterator i = tupleQuad.iterator();
			while(i.hasNext()){
				ts+=i.next() + "\n" ;
			}
		}
		else if(isCharDefList){
			Iterator i = charDefsList.iterator();
			while(i.hasNext()){
				ts += i.next();
			}
		}
	return ts;
	}
}
// Class CharDef 
class CharDef {

	boolean isCString; 		boolean isTuple;
	boolean isQuadruple;	boolean isDefinedValue;
	AsnDefinedValue defval;	String cStr;
	ArrayList tupleQuad ;	
	
	// Default Constructor
	CharDef(){
		tupleQuad = new ArrayList();	
	}
	
	public String toString() {
		String ts = "";
		if(isCString){
			ts += ("\t"	+ cStr);
		}
		else if (isTuple || isQuadruple){
			Iterator i = tupleQuad.iterator();
			while(i.hasNext()){
				ts+=i.next() + "\n" ;
			}
		}
		else if (isDefinedValue){
			ts += ("\t"	+ defval);
		}
	return ts ;
	}
}
//*********************************************
// Definition of AsnSequenceValue
//*********************************************
class AsnSequenceValue{
	boolean isValPresent;
	ArrayList namedValueList ;
	
	// Default Constructor
	AsnSequenceValue(){
		namedValueList = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts ="";
		Iterator i = namedValueList.iterator();
		while(i.hasNext()){
			ts += i.next();
		}
	return ts;
	}
}
//*********************************************
// Definition of AsnSequenceOfValue
//*********************************************
class AsnSequenceOfValue{
	boolean isValPresent;
	ArrayList valueList ;
	
	// Default Constructor
	AsnSequenceOfValue(){
		valueList = new ArrayList();
	}
	
	// toString Method
	public String toString(){
		String ts ="";
		Iterator i = valueList.iterator();
		while(i.hasNext()){
			ts += i.next();
		}
	return ts;
	}
}	
//*********************************************
// Definition of ChoiceValue
//*********************************************
class AsnChoiceValue {
	public String name;
	AsnValue value;
	
	// Default Constructor
	AsnChoiceValue() {
	}
	
	// toString Method
	public String toString(){
		String ts ="";
		ts += name;
		ts += "\t" + ":" + value;
	return ts;
	}
}
//*********************************************
// Definition of SignedNumber
//*********************************************
class AsnSignedNumber {
	boolean	positive;
	BigInteger num;
	
	// Default Constructor
	AsnSignedNumber() {
		positive = true;
	}
	
	// toString() Method Definition
	public String toString() {
		String ts =	"";
		if(num!=null){		
			ts += (num);
		}
		else{
			ts += ("Signed Number is Null");
		}
	return ts;
	}		
} 
//*********************************************
// Definition of NamedValue
//*********************************************
class AsnNamedValue	{
	public String name;
	AsnValue value;
	
	// Default Constructor
	AsnNamedValue() {
	}
	
	public String toString() {
		String ts =	"";
		ts += name;
		ts += ("\t"	+ value);
	return ts;
	}
	
	public String toString(boolean name){
		String ts ="";
		if(name){
			ts += name;
		}
		else {
			ts += value;
		}
	return ts;
	}
}
//*********************************************
// Definition of Defined Value
//*********************************************
class AsnDefinedValue {
		
	boolean	isDotPresent;
	String moduleIdentifier;
	public String name;
	
	// Default Constructor
	AsnDefinedValue() {
		boolean	dotpresent = false;
	}

	// toString() Method Definition
	public String toString() {
		String ts =	"";
		if(isDotPresent){
			ts += (moduleIdentifier	+ "." +	name) ;
		} else {
			ts += name;
		}
	return ts;
	}
} 
