#ifndef _MARIO_H_
#define _MARIO_H_

#include <iostream>                             \

class mario
{
  private:
    int data;
    
  public:
    mario* pipe_a(int par);
    mario* pipe_b();
    mario* pipe_c();
    mario();
    ~mario();
};


#endif /* _MARIO_H_ */
