package edu.usfca.syndiag;

import antlr.collections.*;
import antlr.*;

public class GrammarAST extends BaseAST {
    Token token = null;
    GrammarAST enclosingBlock = null;
    String enclosingRule = null;
    int len = 0;
    int[] dim = {0, 0};
    int[] blockDim = {0, 0};
    int[] location = {0, 0};
    int[] blockPoint = {0, 0};
    int deltaX = 50;
    int deltaY = 35;
	int[] leftConnPoint = {0, 0};
	int[] rightConnPoint = {0, 0};
	int[] BlockLeftConnPoint = {0, 0};
	int[] BlockRightConnPoint = {0, 0};
	int signal = 0;
  String text;
	
    public GrammarAST getEnclosingBlock() {
        return enclosingBlock;
    }

    public void initialize(int i, String s) {
        token = new CommonToken(i,s);
        text = s;
    }

    public void initialize(AST ast) {
    }

    public void initialize(Token token) {
        this.token = token;
    }

    public String getText() {
        if ( token!=null ) {
            return token.getText();
        }
        return "";
    }

    public void setType(int type) {
        token.setType(type);
    }

    public int getType() {
        if ( token!=null ) {
            return token.getType();
        }
        return -1;
    }

    public int getLine() {
        if ( token!=null ) {
            return token.getLine();
        }
        return 0;
    }

    public void setEnclosingBlock(GrammarAST enclosingBlock) {
        this.enclosingBlock = enclosingBlock;
    }

    public void setEnclosingRule(String rule) {
        this.enclosingRule = rule;
    }

    public String getEnclosingRule() {
        return enclosingRule;
    }

    public GrammarAST getLastChild() {
        if ( this.getType()!=ANTLRTokenTypes.ALT ) {
            return null;
        }
        // the last child of any ALT is EOB node pointing at enclosing block
        GrammarAST[] kids = getChildrenAsArray();
        return kids[getNumberOfChildren()-1];
    }

    public GrammarAST getLastSibling() {
        GrammarAST t = this;
        GrammarAST last = null;
        while ( t!=null ) {
            last = t;
            t = (GrammarAST)t.getNextSibling();
        }
        return last;
    }

    public GrammarAST[] getChildrenAsArray() {
        AST t = getFirstChild();
        GrammarAST[] array = new GrammarAST[getNumberOfChildren()];
        int i = 0;
        while ( t!=null ) {
            array[i] = (GrammarAST)t;
            t = t.getNextSibling();
            i++;
        }
        return array;
    }
    
    public void setDim(int w, int h){
        this.dim[0] = w;
        this.dim[1] = h;
    }
    
    public int getWidth(){
    	return this.dim[0];
    }
    
    public int getHeight(){
    	return this.dim[1];
    }
	public int[] getDim(){
		return this.dim;
	}
	
    public void setBlockDim(int w, int h){
        this.blockDim[0] = w;
        this.blockDim[1] = h;
    }
    
    public int getBlockWidth(){
    	return this.blockDim[0];
    }
    
    public int getBlockHeight(){
    	return this.blockDim[1];
    }
	
	public int[] getBlockDim(){
		return this.blockDim;
	}        
    
	public void setLoc(int x, int y){
		this.location[0] = x;
		this.location[1] = y;
	}
	
	public int getX(){
		return this.location[0];
	}
	
	public int getY(){
		return this.location[1];
	}

    public int[] getLoc(){
    	return this.location;
    } 
    
	public void setBlockLoc(int x, int y){
		this.blockPoint[0] = x;
		this.blockPoint[1] = y;
	}
	
	public int getBlockX(){
		return this.blockPoint[0];
	}
	
	public int getBlockY(){
		return this.blockPoint[1];
	}
	
    public int[] getBlockLoc(){
    	return this.blockPoint;
    } 

    public void setLeftConnPoint(int x, int y){
    	this.leftConnPoint[0] = x;
    	this.leftConnPoint[1] = y;
    }

    public void setRightConnPoint(int x, int y){
    	this.rightConnPoint[0] = x;
    	this.rightConnPoint[1] = y;
    }
    
    public int[] getLeftConnPoint(){
    	return this.leftConnPoint;
    }
    
    public int[] getRightConnPoint(){
    	return this.rightConnPoint;
    }
    
    public void setBlockLeftConnPoint(int x, int y){
    	this.BlockLeftConnPoint[0] = x;
    	this.BlockLeftConnPoint[1] = y;
    }
    
    public int[] getBlockLeftConnPoint(){
    	return this.BlockLeftConnPoint;
    }

    public void setBlockRightConnPoint(int x, int y){
    	this.BlockRightConnPoint[0] = x;
    	this.BlockRightConnPoint[1] = y;
    }
    
    public int[] getBlockRightConnPoint(){
    	return BlockRightConnPoint;
    }
    
    public void setSignal(int signal){
    	this.signal = signal;
    }
}
