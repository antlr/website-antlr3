package edu.usfca.syndiag;

import java.awt.event.*;
import java.io.StringReader;
import java.util.StringTokenizer;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ANTLRLexer lexer = new ANTLRLexer(System.in);
        ANTLRParser parser = new ANTLRParser(lexer);
        parser.setASTNodeClass("edu.usfca.syndiag.GrammarAST");
        parser.grammar();
        AST grammarTree = parser.getAST();
        // System.out.println(grammarTree.toStringList());

        // print((GrammarAST)grammarTree);


		// walk the tree caculate the dimension of each item
		SetDimension sd = new SetDimension();
		sd.grammar(grammarTree);

		// if wrap
		if (args.length == 1){
			if (args[0].equals("-wrap")){
				// walk the tree find those too long sequence and alternative
				// lap them, make a new rule
				AdjustDimension ad = new AdjustDimension();
				ad.grammar(grammarTree);
				
				// caculate the dimension for the new tree
				sd.grammar(grammarTree);
			}
		}
				
		// caculate and set the location for the new tree
		SetLocation sl = new SetLocation();
		sl.grammar(grammarTree);
        
        // draw
        DrawSwing swing = new DrawSwing();
        swing.draw(grammarTree);
    }

    public static void print(GrammarAST t) {
        System.out.println(toString(t));
    }

    public static String toString(GrammarAST t) {
        String s = null;
        try {
            s = new ANTLRTreePrinter().toString((AST)t);
        }
        catch (Exception e) {
            System.err.println("Problems printing tree: "+t);
            e.printStackTrace(System.err);
        }
        return s;
    }


}
