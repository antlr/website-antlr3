/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "constantpool.hpp"

namespace ClassEncoder
{
using namespace std;

//! Default constructor
/*!
 * Initialises the pool count and the pool stack.
 */
ConstantPool::ConstantPool()
{
    ConstantPoolCount = 0;
    // push a dummy element in front since position 0 is reserved.
    // This is to avoid stupid of by one bugs in conjunction with the position references in the pool
    Entries.push_back( new Utf8_info( "dummy" ) );
}

//! Destructor
/*!
 * Deletes all the objects in the constant pool.
 */
ConstantPool::~ConstantPool()
{
    // delete constant_pool items
    vector<cp_info*>::iterator it = Entries.begin();
    while( it != Entries.end() )
    {
        delete (*it);
        ++it;
    }
    Entries.clear();
    ConstantPoolCount = 0;
}

//! Add an entry to the constant pool
/*!
 * \param entry Pointer to the object to add to the pool.
 * \return The position in the constant pool of the added object.
 */
unsigned int ConstantPool::add( cp_info *entry )
{
    Entries.push_back( entry );
    return ++ConstantPoolCount;
}

//! Write constant pool entries to stream
/*!
 * \param stream Stream to write to.
 */
void ConstantPool::write( ofstream &stream ) const
{
    vector<cp_info*>::const_iterator it = Entries.begin();
    ++it; // skip dummy
    while( it != Entries.end() )
    {
        (*it)->write( stream );
        ++it;
    }
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void cp_info::write( ofstream &stream ) const
{
    writeu1( stream, tag );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Class_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, name_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Methodref_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, class_index );
    writeu2( stream, name_and_type_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void InterfaceMethodref_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, class_index );
    writeu2( stream, name_and_type_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Fieldref_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, class_index );
    writeu2( stream, name_and_type_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void NameAndType_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, name_index );
    writeu2( stream, descriptor_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void String_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, string_index );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Integer_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu4( stream, bytes );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Float_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu4( stream, bytes );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Long_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu4( stream, high_bytes );
    writeu4( stream, low_bytes );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 */
void Double_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu4( stream, high_bytes );
    writeu4( stream, low_bytes );
}

//! Write entry to stream.
/*!
 * \param stream Stream to write to.
 * \todo Currently we write the pure ascii stream to the file. If we want to use non ascii characters we must implement UTF8 encoding.
 */
void Utf8_info::write( ofstream &stream ) const
{
    cp_info::write( stream );
    writeu2( stream, length );
    /* TODO: UTF8 encoding */
    writeu1Array( stream, bytes.c_str(), length );
}

} // end namespace
