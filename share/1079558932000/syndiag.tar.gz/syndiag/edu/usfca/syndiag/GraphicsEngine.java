package edu.usfca.syndiag;

import java.awt.*;
import javax.swing.*;

public interface GraphicsEngine{
	public void drawLine(int x1, int y1, int x2, int y2);
	public void drawString(String str, int x, int y);
	public void drawString(String str, int x, int y, Font f);
	public void drawOval(int x, int y, int w, int h);
	public void drawRect(int x, int y, int w, int h);
	public void drawRect(int x, int y, int w, int h, Stroke s);
	public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints);
}
