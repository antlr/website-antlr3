/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef ERRORHANDLER_HPP
#define ERRORHANDLER_HPP

#include <string>

//! Error handler class
/*!
 * This class has static error functions used by the parser and the checker to report errors.
 */
class ErrorHandler
{
public:

	static void error ( int lineNumber, const std::string &message);
	static void error (const std::string &file, const int &line, const int &column,
                       const std::string &msg);
    //! Get the total number of errors
    static int getNumErrors() { return TotalErrors; }

private:
	static int TotalErrors;
};


#endif // ERRORHANDLER_HPP
