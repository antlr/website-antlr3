#define DEBUG

#if DEBUG || CODE_ANALYSIS
	npsgfg
#endif
