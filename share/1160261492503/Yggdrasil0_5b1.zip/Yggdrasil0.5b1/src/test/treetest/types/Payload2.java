// Yggdrasil generated type class


public class Payload2 extends PayloadToken {
	private Integer bar = null;
	
	public Payload2(int type, String txt) {
		super(type, txt);
	}

	public Integer getBar() {
		return bar;
	}

	public void setBar(Integer tmp_) {
		bar = (Integer) tmp_;
	}

}
