package antlr;

import antlr.*;
import antlr.collections.*;
import java.util.*;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

//------------------------------------------------------------------------------
// keep the visit state of the traversal
class VisitState
{
  AST currentNode;
  AST siblingAlreadyVisited;
  AST childAlreadyVisited;
  /**
   * constructor
   * @param siblingNodeVisited
   */
  VisitState(AST theCurrentNode, AST theChildAlreadyVisited, AST theSiblingAlreadyVisited)
  {
    currentNode            = theCurrentNode;
    siblingAlreadyVisited  = theSiblingAlreadyVisited;
    childAlreadyVisited    = theChildAlreadyVisited;
  }
}
//------------------------------------------------------------------------------
class BackTrackState
{
  // the sentence up to the backtrack point
  StringBuffer sentence           = new StringBuffer();
  // the nodes visited stack (path) up to the backtrack point
  java.util.Stack callStack       = null;
  // state of local variables to the function
  boolean rootASTHasBeenVisited   = false;
  boolean visitSiblings           = true;
  boolean visitChildren           = true;
  AST     lastChildNodeVisited    = null;
  AST     lastSiblingNodeVisited  = null;
  AST     rootAST                 = null;
  // number of times a solution has been found for this backtrack point
  int     numberOfSolutionsFound  = 0;
}
//------------------------------------------------------------------------------
// counter to keep track of the number of times a rule has been called
class IntegerCounter
{
  int counter = 0;
}
//------------------------------------------------------------------------------
public class AntlrGrammarGraph implements ANTLRTokenTypes
{
  //----------------------------------------------------------------------------
  // static to GrammarGraph
  private static ASTFactory   astFactory   = new ASTFactory();
  public static java.util.List ruleName    = new LinkedList(); // all rule names
  public static Map  parserRules           = new TreeMap(); // all parser rules
  public static Map  lexerMap              = new TreeMap(); // all lexer rules
  public static Map  currentMap            = null;          // active map - either parser or lexer map 
  public static Map  tokenRef              = new TreeMap(); // list of tokens to use 
  public static Map  ruleRef               = new TreeMap(); // rules overriding rules in text
  public static Set  showCallsWhenRuleIsCalled = new HashSet();  
  //----------------------------------------------------------------------------
  // local to instance
  public int  maxNumberOfIterations = 2;                  // *,+ max iterations allowed
  public boolean traceIsOn          = false;              // flag to show if tracing must be done
  public StringBuffer sentence      = new StringBuffer(); // current constructed sentance
  public Map ruleCalledCount        = new HashMap();      // number of times rule has been called
  public int timesCalled            = 0;                  // number of tmes sentences has been generated
  //----------------------------------------------------------------------------
  // stack of current solutions
  private java.util.Stack callStack = new java.util.Stack();
  //----------------------------------------------------------------------------
  // stack of places in the graph where there are more than one solution
  private java.util.Stack backtrackStack     = new java.util.Stack();
  //============================================================================
  private void showRuleCallsInCallStack()
  {
    int max = callStack.size();
    for (int i = 0; i < max; i++)
    {
      AST node = ((VisitState)callStack.get(i)).currentNode;
      if (node.getType() == RULE_REF)
      {
        System.out.print(node.getText()+"->");
      }
    }
    System.out.println();
  }
  public void clearRulesCountMap()
  {
    ruleCalledCount.clear();
  }
  /**
   * Show the number of times all called rules has been called
   */
  public void showRulesCalledCount()
  {
    int mapSize = ruleName.size();
    int i       = 0;
    for (i = 0; i < mapSize; i++) 
    {
      String aRuleName = (String)(ruleName.get(i));
      IntegerCounter rule = (IntegerCounter)(ruleCalledCount.get(aRuleName));
      if (rule != null)
      {
        System.out.println("RULE : " + aRuleName + " CALLED : " + rule.counter + " TIMES");
      }
    }
    
  }
  /**
   * Return the number of backtrack points in the backtrack stack
   * @return 
   */
  public int getNumberOfBackTrackPoints()
  {
    return backtrackStack.size();
  }
  /**
   * trace message only printed when trace is on
   * @param msg
   */
  private void trace(String msg)
  {
    if(traceIsOn)
    {
      System.out.print(msg);
    }
  }
  /**
   * strip leading and trailing quotes from string
   * @param string
   */
  private String stripQuotesFromString(String string)
  {
    return string.substring(1,string.length() - 1);
  }
  /**
   * If there are alternative solutions return true else return false
   * @return 
   */
  public boolean thereAreMoreSentences()
  {
    return backtrackStack.size() > 0;
  }
  /**
   * traverse the AST and transform the tree for
   * + ,* and ?
   * (A)* => ()|(A)|(AA)...maxNumberOfIterations times
   * (A)+ => (A)|(AA)...maxNumberOfIterations times
   * (A)? => ()|(A)
   * @param rootAST
   */
  private void prepareASTForSentenceGeneration(AST rootAST, String ruleName)
  {
    {
      int ruleType = rootAST.getType();
      AST child    = null;
      AST sibling  = null;
      // if rule ref check for loops as alg could get stuck in loops.
      if (ruleType == STAR)
      {
        // change type to OR but leave the text
        //
        rootAST.setType(OR);
        rootAST.setText("or*"+ruleName);
        AST opt1 = rootAST.getFirstChild();
        // create the empty node
        AST opt3 = astFactory.create(OPTIONS, "options");
        rootAST.addChild(opt3);
        for (int i = 1; i < maxNumberOfIterations;i++)
        {
          opt3 = astFactory.create(OPTIONS, "options");
          rootAST.addChild(opt3);
          for (int j = 0; j < i + 1; j++)
          {
            opt3.addChild(astFactory.dupTree(opt1));  
          }
        }
        
      }
      else
      if (ruleType == PLUS)
      {
        // change type to OR but leave the text
        rootAST.setType(OR);
        rootAST.setText("or+"+ruleName);
        AST opt1 = rootAST.getFirstChild();
        
        for (int i = 1; i < maxNumberOfIterations;i++)
        {
          AST opt3 = astFactory.create(OPTIONS, "options");
          rootAST.addChild(opt3);
          for (int j = 0; j < i + 1; j++)
          {
            opt3.addChild(astFactory.dupTree(opt1));  
          }
        }
      }
      else
      if (ruleType == QUESTION)
      {
        // change type to OR but leave the text
        rootAST.setType(OR);
        rootAST.setText("or?"+ruleName);
        // create the empty node
        AST opt3 = astFactory.create(OPTIONS, "options");
        rootAST.addChild(opt3);
      }
      {
        // visit all the children of the current node
        child = rootAST.getFirstChild();
        if (child !=  null) 
        {
          prepareASTForSentenceGeneration(child,ruleName);   
        }
        // visit the siblings of the current node
        sibling = rootAST.getNextSibling();
        if (sibling != null)
        {
          prepareASTForSentenceGeneration(sibling,ruleName);
        }
      }  
    } 
   
  }
  /**
   * Go through all the rules and prepare every rule for sentence generation
   */
  public void prepareRulesForForSentenceGeneration()
  {
    int mapSize = ruleName.size();
    int i       = 0;
    for (i = 0; i < mapSize; i++) 
    {
      String aRuleName = (String)(ruleName.get(i));
      AST rule = (AST)(parserRules.get(aRuleName));
      if (rule != null)
      {
        prepareASTForSentenceGeneration(rule,aRuleName);
      }
    }
    
  }
  /**
   * if the previous node in the path is an OR then the siblings
   * should not be visited
   */
  private boolean mustIVisitSiblings(AST rootAST)
  {
    if(callStack.size() == 0)
    {
      return false;
    }
    VisitState prevNode = (VisitState)callStack.peek();
    if (prevNode.currentNode.getType() == OR)
    {
      boolean rootASTisInSiblingList = false;
      AST node = prevNode.currentNode;
      // if rootAST is in prevNode sibling list then return true
      // else return false
      while (node != null && !rootASTisInSiblingList)
      {
        if (node == rootAST) 
        {
          rootASTisInSiblingList = true;
        }
        node = node.getNextSibling();
      }
      if (rootASTisInSiblingList)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    else
    {
      return true;
    }
  }
  /**
   * get the next child sibling to visit. If the last child visited is not defined then 
   * visit the first child. else return the sibling of the last visited child
   * @param parent
   * @param lastChildVisited
   * @return 
   */
  private AST childSiblingToVisit(AST parent, AST lastChildVisited)
  {
    AST result = null;
    
    if (lastChildVisited == null)
    {
      return  parent.getFirstChild();
    }
  
    // make sure that this lastChildVisited is in fact a child of the parent
    boolean lastChildVisitedIsAChild = false;
    AST node = parent.getFirstChild();
    
    while (node != null) 
    {
      if (node == lastChildVisited)
      {
        lastChildVisitedIsAChild = true;
        break;
      }
      node = node.getNextSibling();  
    }
    
    if (lastChildVisitedIsAChild) 
    {
      if (parent.getType() == OR)
      {
        result = lastChildVisited.getNextSibling();
      } 
    }
    else 
    {
      result = parent.getFirstChild();
    }
    return result;
  }
  /**
   * Return the number of times that the cycle at the top of the callStack
   * is in the callStack. The start of the cycle is defined by rootAST
   * @param rootAST
   * @return 
   */
  private boolean thereIsAnotherCycleInCallStack(AST rootAST) throws Exception
  {
    boolean result             = false;
    int startOfLastCycle       = locationOfLastOccurenceOf(rootAST);
    int checkForLoopAtPosition = 0;
    
    if (startOfLastCycle == -1)
    {
      throw new Exception("thereIsAnotherCycleInCallStack - AST is not in callStack");
    }
    
    // check for a loop in the callStack starting 
    // from the bottom of the callStack up to the 
    // start of the last cycle
    for (checkForLoopAtPosition = 0;
         checkForLoopAtPosition < startOfLastCycle - 1 && !result;
         checkForLoopAtPosition++)
    {
      if (((VisitState)callStack.get(checkForLoopAtPosition)).currentNode == rootAST)
      {
        // possable start of an occurence of the loop at tos
        int i = 0;
        // callStack contains VisitState objects
        while (((VisitState)callStack.get(checkForLoopAtPosition + i)).currentNode ==
               ((VisitState)callStack.get(startOfLastCycle + i)).currentNode && 
               startOfLastCycle + i < callStack.size() - 1)
        {
          i++;
        }
        if (startOfLastCycle + i == callStack.size() - 1)
        {
          result = true;
        }
      }
    }
    return result;
  }
  /**
   * Find if the rootNode is in callStack. callStack contains instances of
   * VisitState objects. rootNode has not been pushed onto the callStack yet
   * @param rootNode
   * @return 
   */
  private int nodeIsInCallStack(AST rootAST)
  {
    int result = -1;
    int     max    = callStack.size();
    
    for (int i = 0; i < max && result == -1; i++)
    {
      VisitState visitState = (VisitState)callStack.get(i);
      if (visitState.currentNode == rootAST)
      {
        result = i;
      }
    }
    return result;
  }
  /**
   * return the location of the last occurence of the rootAST in the stack
   * @param rootAST
   * @return 
   */
  private int locationOfLastOccurenceOf(AST rootAST)
  {
    int result = -1;
    int max    = callStack.size() - 1;
    
    for (int i = max; i >= 0 && result == -1; i--)
    {
      VisitState visitState = (VisitState)callStack.get(i);
      if (visitState.currentNode == rootAST)
      {
        result = i;
      }
    }
    return result;
  }
  /**
   * Build a text description of the loop in the path
   * @param loopStartLocation
   * @return 
   */
  private StringBuffer constuctPathDescription(int loopStartLocation, AST callFrom)
  {
    StringBuffer pathString = new StringBuffer();
    for (int i = loopStartLocation; i < callStack.size(); i++)
      {
        if (((VisitState)callStack.get(i)).currentNode.getType() == RULE_REF)
          {
            pathString.append(((VisitState)callStack.get(i)).currentNode.getText() + "->");  
          }
       }
     pathString.append(callFrom.getText());
     return pathString;
  }
  /**
   * Check if we are in a loop. If so check if there are potential solutions 
   * that can lead to exsiting the loop.
   * @param rootAST
   * @return 
   */
  private boolean noSolutionInThisPath(AST rootAST) throws Exception
  {
    boolean result        = false;    
    int loopStartLocation = -1;
    AST callFrom          = rootAST;
    
    if (rootAST.getType() == RULE_REF)
    {
    //
    // the graph consist of a number of connected adags. these connections
    // is via the first child of a RULE_REF node and can make the whole
    // graph into a dag. so check for cycles in the path
    //
      rootAST = rootAST.getFirstChild();
      if (rootAST == null)
      {
        // throw exception - RULE_REF does not refer to a rule. This implies
        // that the rules references has not been connected up to the
        // rule definitions or that there is no rule definition for the
        // rule reference.
      }
      else
      {
        // callStack contains VisitState objects
        loopStartLocation = nodeIsInCallStack(rootAST);
        if (loopStartLocation != -1)
        {
        // there is a cycle in the graph and I now need to check if the
        // cycle can be avoided
          if (backtrackStack.size() > 0 &&
              ((BackTrackState)backtrackStack.peek()).callStack.size() >= 
                locationOfLastOccurenceOf(rootAST))
          {
            // there are alternative path in the loop - so the
            // cycle can potentially be resolved
            if (thereIsAnotherCycleInCallStack(rootAST))
            {
              // backtrack to alt solution
              // check if alt solutions have any child nodes to go to
              AST backTrackNode = ((BackTrackState)backtrackStack.peek()).rootAST;
              AST childNode     = ((BackTrackState)backtrackStack.peek()).lastChildNodeVisited;
              int solutionFound = ((BackTrackState)backtrackStack.peek()).numberOfSolutionsFound;
              AST alternativeSolution = childSiblingToVisit(backTrackNode,childNode);
              if (alternativeSolution != null)
              {
                result = true;
              }
              else
              {
              // if a solution has already been found for this backtrack point
              // then you are at the last option here in the code
                if (solutionFound > 0)
                {
                  result = true;
                }
                else
                { 
                  result = true;
                  // ignore loop and backtrack out of loop
                  // throw new Exception("loop :" + constuctPathDescription(loopStartLocation, callFrom));  
                }
              }
            }
            else
            {
              // go into loop and try and find solutions inside loop
              result = false;          
            }
          }
          else
          {
            // no the path is unique and leads to a cycle
            // throw exception and abort function as there are
            // no finite solutions to the graph (taking into account that
            // * and + is bounded and rewritten as OR graphs
            throw new Exception("loop :" + constuctPathDescription(loopStartLocation, callFrom));
          }
        }  
      }
    }
    else
    {
      // not a rule_ref so the node cannot lead to a loop in the graph
      result = false;
    }
    return result;
  }
  /**
   * If the rootAST is a mu and there is a rule string defined in the 
   * ruleRef map then use that defined string as the result of the rule and
   * return false else a rule ref has not been defined and return true
   * @param rootAST
   * @return 
   */
  private boolean ruleRefNotDefinedForRule(AST rootAST, AST lastSiblingNodeVisited)
  {
    boolean result = true;
    if (rootAST.getType() == RULE_REF)
    {
      String ruleStr = (String)ruleRef.get(rootAST.getText());
      if (ruleStr != null)
      {
        if (lastSiblingNodeVisited == null)
        {
          trace("");
          result = false;
          sentence.append(ruleStr);
        }
        else
        {
          result = false;
        }
      }
    }
    return result;
  }
  /**
   * try to generate a sentence of the grammer graph 
   * @param rootAST
   */
  public void createSentenceOfGrammarForNodeWithBacktracking (AST rootAST) throws Exception
  {
    boolean justPOPedORNode             = false;
    boolean rootASTHasBeenVisited       = false;
    boolean visitSiblings               = true;
    boolean visitChildren               = true;
    int     solutionsAlreadyFound       = 0;
    AST     lastChildNodeVisited        = null;
    AST     lastSiblingNodeVisited      = null;

      timesCalled++;
      sentence = new StringBuffer();
      try
      {
      if (backtrackStack.size() != 0)
      {
        trace("|1 POP-BTS|");
        // these are alt solutions to the problem
        // pop the last backtrack point, restore system state and
        // search new solutions
        BackTrackState backTrackState = (BackTrackState)backtrackStack.pop();
        
        sentence               = backTrackState.sentence;
        callStack              = backTrackState.callStack;
        rootASTHasBeenVisited  = backTrackState.rootASTHasBeenVisited;
        visitSiblings          = backTrackState.visitSiblings;
        visitChildren          = backTrackState.visitChildren;
        lastChildNodeVisited   = backTrackState.lastChildNodeVisited;
        lastSiblingNodeVisited = backTrackState.lastSiblingNodeVisited;
        solutionsAlreadyFound  = backTrackState.numberOfSolutionsFound;
        rootAST                = backTrackState.rootAST;
      }
      
      while (rootAST != null) 
      {
         //depth first left to right traversal of graph
          if (!rootASTHasBeenVisited) {
            if (rootAST.getType() == RULE_REF || rootAST.getType() == STRING_LITERAL || rootAST.getType() == TOKEN_REF) 
            {
              trace(rootAST.getText() + "->" );
            }
            // build up the sentence of the path
            if (rootAST.getType() == STRING_LITERAL || rootAST.getType() == TOKEN_REF) 
            {
              String text = rootAST.getText();
              if (rootAST.getType() == STRING_LITERAL) 
              {
                text = stripQuotesFromString(text) + " ";
              }
              else if (rootAST.getType() == TOKEN_REF)
              {
                text = (String)tokenRef.get(rootAST.getText());
                if (text == null) 
                {
                  text = rootAST.getText() + " ";               
                }
              }
              sentence.append(text);
            }
          }
          if (noSolutionInThisPath(rootAST))
          {
            if (backtrackStack.size() != 0)
            {
              do
              {
                trace("|2 POP-BTS|");
              // these are alt solutions to the problem
              // pop the last backtrack point, restore system state and
              // search new solutions
                BackTrackState backTrackState = (BackTrackState)backtrackStack.pop();
        
                sentence               = backTrackState.sentence;
                callStack              = backTrackState.callStack;
                rootASTHasBeenVisited  = backTrackState.rootASTHasBeenVisited;
                visitSiblings          = backTrackState.visitSiblings;
                visitChildren          = backTrackState.visitChildren;
                lastChildNodeVisited   = backTrackState.lastChildNodeVisited;
                lastSiblingNodeVisited = backTrackState.lastSiblingNodeVisited;
                solutionsAlreadyFound  = backTrackState.numberOfSolutionsFound;
                rootAST                = backTrackState.rootAST;
              }
              while (backtrackStack.size() > 0 && 
                    childSiblingToVisit(rootAST, lastChildNodeVisited)== null);
            }
            else
            {
            // stuck in the loop with no option to get out
            // throw an exception
            throw new Exception("trying to backtrack and backtrack stack is empty");
            }
          }
          if (visitChildren &&
              rootAST.getFirstChild() != null && 
              childSiblingToVisit(rootAST, lastChildNodeVisited) != null &&
              ! justPOPedORNode &&
              ruleRefNotDefinedForRule(rootAST, lastSiblingNodeVisited))
          {
            // visit child
            if (rootAST.getType() == OR && 
              childSiblingToVisit(rootAST,lastChildNodeVisited) != null) 
            {
              trace("|3 PUSH-BTP|");
              // put a backtrack point at the or node  
              BackTrackState backTrackState          = new BackTrackState();
              backTrackState.sentence                = new StringBuffer();
              backTrackState.sentence.append(sentence);
              backTrackState.callStack               = (java.util.Stack)callStack.clone();
              backTrackState.rootASTHasBeenVisited   = rootASTHasBeenVisited;
              backTrackState.visitSiblings           = visitSiblings;
              backTrackState.visitChildren           = visitChildren;
              // lastChildNodeVisited is the last option in the sibling list of an OR node
              // then a null will be returned and the code will go into an infinate loop
              // as the next option will start again at the beginning of the sibling list
              // for the OR node.
              backTrackState.lastChildNodeVisited    = childSiblingToVisit(rootAST, lastChildNodeVisited);
              backTrackState.lastSiblingNodeVisited  = lastSiblingNodeVisited;
              backTrackState.numberOfSolutionsFound  = solutionsAlreadyFound;
              backTrackState.rootAST                 = rootAST; 
              backtrackStack.push(backTrackState);
            } 
            // Keep track of all rule calls count
            if (rootAST.getType() == RULE_REF)
            {
              if(showCallsWhenRuleIsCalled.contains(rootAST.getText()))
              {
                showRuleCallsInCallStack();
              }
              IntegerCounter counter = (IntegerCounter)ruleCalledCount.get(rootAST.getText());
              if(counter == null)
              {
                ruleCalledCount.put(rootAST.getText(), new IntegerCounter());
              }
              else
              {
                counter.counter++;
              }
            }
            callStack.push(new VisitState(rootAST, childSiblingToVisit(rootAST, lastChildNodeVisited), null));
            rootAST = childSiblingToVisit(rootAST, lastChildNodeVisited);
            rootASTHasBeenVisited = false;
            lastChildNodeVisited = null;
          }
          else
          if (visitSiblings && mustIVisitSiblings(rootAST) &&
              rootAST.getNextSibling() != null && 
              rootAST.getNextSibling() != lastSiblingNodeVisited)
          {
            // visit siblings
            justPOPedORNode = false;
            callStack.push(new VisitState(rootAST, lastChildNodeVisited, rootAST.getNextSibling()));
            rootAST = rootAST.getNextSibling();
            rootASTHasBeenVisited = false;
            lastSiblingNodeVisited = null;
          } 
          else 
          {
            // backttracking
            if (callStack.size() > 0) 
            {
              trace("<"+rootAST.getText()+">");
              //
              // there are nodes to backtrack to
              //
              VisitState visitState   = (VisitState)callStack.pop();
              lastChildNodeVisited    = visitState.childAlreadyVisited;
              lastSiblingNodeVisited  = visitState.siblingAlreadyVisited;
              rootAST                 = visitState.currentNode;
              rootASTHasBeenVisited   = true;
              //
              // if the node is a OR node and there are more optional
              // child nodes unvisited then there are more solutions
              //
              if (rootAST.getType() == OR)
              {
                justPOPedORNode = true;
              }
              else
              {
                justPOPedORNode = false;
              }
              if (rootAST.getType() == OR && 
                backtrackStack.size() > 0 &&
                callStack.size() == ((BackTrackState)backtrackStack.peek()).callStack.size())
              {
                // remove OR backtrack point as there are no more solutions here
                if (childSiblingToVisit(rootAST,lastChildNodeVisited) == null)
                {
                  trace("|4 POP-BTS|");
                  // propagate the soluction count backwards to the 
                  // previous backtrack point as you need to know what solutions
                  // have been found in other backtrack points
                  BackTrackState backTrackState = (BackTrackState)backtrackStack.pop();
                  if (backtrackStack.size() > 0)
                  {
                    ((BackTrackState)backtrackStack.peek()).numberOfSolutionsFound += 
                      backTrackState.numberOfSolutionsFound;
                  }
                }
                else
                {
                  //a solution has been found for this OR node so inc the counter
                  ((BackTrackState)backtrackStack.peek()).numberOfSolutionsFound++;
                }
              } 
            }
            else
            {
              // nothing to backtrack to 
              lastChildNodeVisited    = null;
              lastSiblingNodeVisited  = null;
              rootAST                 = null;
              rootASTHasBeenVisited   = true;
            }
          }
      }
      }
      catch (Exception e)
      {
        // clear variables and report the error
  
        sentence = new StringBuffer();
        callStack.clear();
        backtrackStack.clear();
        
        throw e;
      }
  }
    
  /**
   * Check root and sibligs to create sentences of the grammar
   * @param rootAST
   */
  public void testCreateSentenceOfGrammar (AST rootAST)
  {
    AST node = rootAST;
    callStack.clear();
    while (node != null)
    {
      testCreateSentenceOfGrammarForNode(node);
      node = node.getNextSibling();
    }
  }
  /**
   *  traverse the ast and generate a sentence of 
   *  the grammer represented by rootAst
   * @param rootAST
   */
  private void testCreateSentenceOfGrammarForNode (AST rootAST)
  {
    {
      int ruleType = rootAST.getType();
      AST child    = null;
      
      if (ruleType == TOKEN_REF)
      {
        // see if there is a token defined for the ref
        String token = (String)tokenRef.get(rootAST.getText());
        if (token == null) 
        {
          // generate the token string
          //System.out.println(rootAST.getText() + " ");
          if (sentence.length() % 80 ==0) 
          {
            sentence.append("\n");
          }
          sentence.append(rootAST.getText() + " ");
        }
        else
        {
          //System.out.println(token + " ");
          if (sentence.length() % 80 ==0) 
          {
            sentence.append("\n");
          }
          sentence.append(token);
          
        }
      }
      else
      if (ruleType == STRING_LITERAL)
      {
        // generate the token string
        String stringLiteral = rootAST.getText();
        // strip off the " at begin and end of the string
        stringLiteral = stringLiteral.substring(1,stringLiteral.length() - 1);

        //System.out.println(stringLiteral + " ");
        if (sentence.length() % 80 ==0) 
        {
          sentence.append("\n");
        }
        sentence.append(stringLiteral + " ");
      }
      else
      if (ruleType == RULE_REF)
      {
        // add the rule to the called rules
        // if the current name is in the path already then I am going into a loop
        //System.out.print(rootAST.getText() + "->");
        if (callStack.search(rootAST.getText())== -1)
          {
          callStack. push(rootAST.getText());
          // first child contains grammer def of rule
          child = rootAST.getFirstChild();
          if (child != null) {
            testCreateSentenceOfGrammarForNode(child); 
          } 
          else 
          {
            //System.out.println("RULE = " + rootAST.getText() + " ");  
          }
          callStack.pop();
          }
        else
          {
            //System.out.println("Loop in grammar graph :" + rootAST.getText());
            if (sentence.length() % 80 ==0) 
            {
              sentence.append("\n");
            }
            sentence.append("<"+rootAST.getText()+">");
          }
        //System.out.println("|");
      } 
      else 
      if (ruleType == LPAREN)
      {
        // first child contains the sub rules
        child = rootAST.getFirstChild();
        testCreateSentenceOfGrammarForNode(child); 
      }
      else
      if (ruleType == OR)
      {
        // any one of the children
        int childCount = rootAST.getNumberOfChildren();
        int i          = 0;
        child          = rootAST.getFirstChild();
        
        // pick alternative at random to traverse        
        double pickChild = Math.random() * childCount;
        for (i = 0; i < pickChild - 1; i++) 
        {
         child = child.getNextSibling();
        }
        testCreateSentenceOfGrammarForNode(child); 
      }
      else
      if (ruleType == STAR)
      {
        // zero or more iterations of children
        child = rootAST.getFirstChild();
        // pick random number of iterations up to 2 times
        double r = Math.random() * 2;
        int i = 0; 
        for (i = 0; i < r; i++) 
          {
          testCreateSentenceOfGrammarForNode(child); 
          }
      }
      else
      if (ruleType == PLUS)
      {
        // one or more iteration of children
        child = rootAST.getFirstChild();
        testCreateSentenceOfGrammarForNode(child); 
        // pick random number of iterations
        double r = Math.random() * 2;
        int i = 0;
        for (i = 0; i < r; i++) 
        {
          testCreateSentenceOfGrammarForNode(child); 
        }
      }
      else
      if (ruleType == QUESTION)
      {
        // child is optional
        child = rootAST.getFirstChild();
        // pick random path
        double r = Math.random();
        if (r < 0.5) 
        {
          testCreateSentenceOfGrammarForNode(child); 
        }
      }
      else
      if (ruleType == ALTERNATIVE)
      {
        // multiple possable children
        child = rootAST.getFirstChild();
        while (child != null)
        {
          testCreateSentenceOfGrammarForNode(child); 
          child = child.getNextSibling();
        }
      }
      else
      {
        // visit all the children of the current node
        child = rootAST.getFirstChild();
        while (child != null)
        {
         testCreateSentenceOfGrammarForNode(child); 
          child = child.getNextSibling();
        }
      }  
    } 
  }
  /**
   * Generate an NFA for the given subtree
   * @param rootAST
   */
  private void visitChildrenAndLinkUpRules (AST rootAST) throws Exception
  {
    {
      if (rootAST.getType() == RULE_REF)
      {
      // if this am a rule call then check in parserRules for the rule 
      // if the rule is found then link the child link to the subtree returned by 
      // the parserRules map
        String name = rootAST.getText();
        AST    rule = (AST)(parserRules.get(name));
        if (rule != null) 
        {
          rootAST.setFirstChild(rule);
        }
        else
        {
        // throw exception as grammer as rule refereneces with undefined rules
          throw new Exception("RULE_REF " + rootAST.getText() + " used without the rule been defined");
        }
      } 
      else 
      {
      AST child = rootAST.getFirstChild();
      while (child != null)
      {
        visitChildrenAndLinkUpRules(child); 
        child = child.getNextSibling();
      }
      }  
    } 
  }
  
  // link up the rule calls in the parser rules map to form a NFA
  public void connectRulesIntoAnANFAGraph() throws Exception
  {
    int mapSize = ruleName.size();
    int i       = 0;
    for (i = 0; i < mapSize; i++) 
    {
      String aRuleName = (String)(ruleName.get(i));
      AST rule = (AST)(parserRules.get(aRuleName));
      if (rule != null)
      {
        visitChildrenAndLinkUpRules(rule);
      }
    }
  }
  /**
   * Constructor
   */
  public AntlrGrammarGraph()
  {
  }
}