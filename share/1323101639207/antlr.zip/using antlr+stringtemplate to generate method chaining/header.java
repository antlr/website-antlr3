import java.io.*;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;

public class header {
    public static void main(String args[]) throws Exception {
        pipeLexer lex = new pipeLexer(new ANTLRFileStream(args[0]));
        CommonTokenStream tokens = new CommonTokenStream(lex);

        pipeParser parser = new pipeParser(tokens);
        pipeParser.starting_return r = parser.starting(); // launch parsing
        if ( r!=null ) System.out.println("parser tree: "+((CommonTree)r.tree).toStringTree());

        System.out.println("---------------");
        
        // walker
        try
        {
            CommonTreeNodeStream nodes = new CommonTreeNodeStream((CommonTree)r.tree);
//            nodes.setTokenStream(tokens);
            decl walker = new decl(nodes);
            walker.starting();
        }
        catch (RecognitionException e) { 
            System.err.println(e); 
        }

    }
}