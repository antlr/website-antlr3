# $ANTLR 2.7.2a2 (20020112-1): "calc.g" -> "CalcTreeWalker.py"$

from  antlr import TreeParser
from antlr import Token
from antlr.collections import AST
from antlr import RecognitionException
from antlr import ANTLRException
from antlr import NoViableAltException
from antlr import MismatchedTokenException
from antlr import SemanticException
from antlr.collections.impl import BitSet
from antlr import ASTPair
from antlr.collections.impl import ASTArray



_tokenNames = [
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"PLUS",
	"SEMI",
	"STAR",
	"INT",
	"WS",
	"LPAREN",
	"RPAREN",
	"DIGIT"
]

class CalcTreeWalker(antlr.TreeParser, CalcParserTokenTypes):
	def __init__(self):
		self.tokenNames = self._tokenNames;
	
	def expr(self, _t = None	):
		
		
		 expr_AST_in = _t
		i = None

			a=0
			b=0
			r=0;
		
		
		try:      # for error handling
			if not _t: _t=ASTNULL
			if (_t.getType() == PLUS) :
				AST __t20 = _t;
				tmp1_AST_in = ()_t
				self.match(_t,PLUS)
				_t = _t.getFirstChild()
				a=self.expr(_t)
				_t = _retTree
				b=self.expr(_t)
				_t = _retTree
				_t = __t20
				_t = _t.getNextSibling()
r = a+b
			elif (_t.getType() == STAR) :
				AST __t21 = _t;
				tmp2_AST_in = ()_t
				self.match(_t,STAR)
				_t = _t.getFirstChild()
				a=self.expr(_t)
				_t = _retTree
				b=self.expr(_t)
				_t = _retTree
				_t = __t21
				_t = _t.getNextSibling()
r = a*b
			elif (_t.getType() == INT) :
				i = ()_t
				self.match(_t,INT)
				_t = _t.getNextSibling();
r = float(i.getText())
			else:
				raise NoViableAltException(_t)
			
		except RecognitionException, ex:
			reportError(ex)
			if not _t: _t = _t.getNextSibling()
		_retTree = _t
		return r
	
	

