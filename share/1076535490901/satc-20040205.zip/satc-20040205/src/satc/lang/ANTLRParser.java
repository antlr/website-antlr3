// $ANTLR 2.7.2: "ANTLRParser.g" -> "ANTLRParser.java"$

package satc.lang;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;
import satc.antlr.DocParser;

public class ANTLRParser extends DocParser       implements ANTLRTokenTypes
 {

	public void insert( String key) {
		System.out.println("key = " + key);
	}

	public void insertActionFirst( Token a) {
		System.out.println("insert in action first: " + a);

	}
	public void insertActionLast( Token a) {
		System.out.println("insert in action last: " + a);
	}
	public void insertHeader( Token h) {
		System.out.println("insert in header: " + h);

	}


protected ANTLRParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected ANTLRParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public ANTLRParser(TokenStream lexer) {
  this(lexer,1);
}

public ANTLRParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void start() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST start_AST = null;
		
		try {      // for error handling
			grammar();
			astFactory.addASTChild(currentAST, returnAST);
			start_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = start_AST;
	}
	
	public final void grammar() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST grammar_AST = null;
		
		try {      // for error handling
			header_();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop4:
			do {
				if ((LA(1)==LITERAL_class||LA(1)==ACTION)) {
					classDef();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop4;
				}
				
			} while (true);
			}
			match(Token.EOF_TYPE);
			if ( inputState.guessing==0 ) {
				grammar_AST = (AST)currentAST.root;
				grammar_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(GRAMMAR,"grammar")).add(grammar_AST)) ;
				currentAST.root = grammar_AST;
				currentAST.child = grammar_AST!=null &&grammar_AST.getFirstChild()!=null ?
					grammar_AST.getFirstChild() : grammar_AST;
				currentAST.advanceChildToEnd();
			}
			grammar_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = grammar_AST;
	}
	
	public final void header_() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header__AST = null;
		Token  h = null;
		AST h_AST = null;
		Token  n = null;
		AST n_AST = null;
		Token  a = null;
		AST a_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_header:
			{
				h = LT(1);
				h_AST = astFactory.create(h);
				astFactory.makeASTRoot(currentAST, h_AST);
				match(LITERAL_header);
				{
				switch ( LA(1)) {
				case STRING_LITERAL:
				{
					n = LT(1);
					n_AST = astFactory.create(n);
					astFactory.addASTChild(currentAST, n_AST);
					match(STRING_LITERAL);
					break;
				}
				case ACTION:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				a = LT(1);
				a_AST = astFactory.create(a);
				astFactory.addASTChild(currentAST, a_AST);
				match(ACTION);
				header__AST = (AST)currentAST.root;
				break;
			}
			case EOF:
			case LITERAL_class:
			case ACTION:
			{
				header__AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = header__AST;
	}
	
	public final void classDef() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST classDef_AST = null;
		Token  a = null;
		AST a_AST = null;
		Token  id = null;
		AST id_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ACTION:
			{
				a = LT(1);
				a_AST = astFactory.create(a);
				astFactory.addASTChild(currentAST, a_AST);
				match(ACTION);
				break;
			}
			case LITERAL_class:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(LITERAL_class);
			id = LT(1);
			id_AST = astFactory.create(id);
			astFactory.addASTChild(currentAST, id_AST);
			match(ID);
			match(LITERAL_extends);
			{
			switch ( LA(1)) {
			case LITERAL_Lexer:
			{
				AST tmp4_AST = null;
				tmp4_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp4_AST);
				match(LITERAL_Lexer);
				break;
			}
			case LITERAL_Parser:
			{
				AST tmp5_AST = null;
				tmp5_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp5_AST);
				match(LITERAL_Parser);
				break;
			}
			case LITERAL_TreeParser:
			{
				AST tmp6_AST = null;
				tmp6_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp6_AST);
				match(LITERAL_TreeParser);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
			{
			switch ( LA(1)) {
			case LITERAL_options:
			{
				optionsSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_tokens:
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			case ACTION:
			case ID:
			case BANG:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_tokens:
			{
				tokensSpec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			case ACTION:
			case ID:
			case BANG:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				AST tmp8_AST = null;
				tmp8_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp8_AST);
				match(ACTION);
				break;
			}
			case LITERAL_protected:
			case LITERAL_public:
			case LITERAL_private:
			case ID:
			case BANG:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			rules();
			astFactory.addASTChild(currentAST, returnAST);
			{
			if ((LA(1)==ACTION)) {
				AST tmp9_AST = null;
				tmp9_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp9_AST);
				match(ACTION);
			}
			else if ((LA(1)==EOF||LA(1)==LITERAL_class||LA(1)==ACTION)) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			classDef_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = classDef_AST;
	}
	
	public final void optionsSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST optionsSpec_AST = null;
		Token  idi = null;
		AST idi_AST = null;
		Token  ide = null;
		AST ide_AST = null;
		
		try {      // for error handling
			AST tmp10_AST = null;
			tmp10_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp10_AST);
			match(LITERAL_options);
			AST tmp11_AST = null;
			tmp11_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp11_AST);
			match(LCURLY);
			{
			_loop22:
			do {
				boolean synPredMatched17 = false;
				if (((LA(1)==LITERAL_importVocab))) {
					int _m17 = mark();
					synPredMatched17 = true;
					inputState.guessing++;
					try {
						{
						match(LITERAL_importVocab);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched17 = false;
					}
					rewind(_m17);
					inputState.guessing--;
				}
				if ( synPredMatched17 ) {
					AST tmp12_AST = null;
					tmp12_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp12_AST);
					match(LITERAL_importVocab);
					match(EQUAL);
					idi = LT(1);
					idi_AST = astFactory.create(idi);
					astFactory.addASTChild(currentAST, idi_AST);
					match(ID);
				}
				else {
					boolean synPredMatched19 = false;
					if (((LA(1)==LITERAL_exportVocab))) {
						int _m19 = mark();
						synPredMatched19 = true;
						inputState.guessing++;
						try {
							{
							match(LITERAL_exportVocab);
							}
						}
						catch (RecognitionException pe) {
							synPredMatched19 = false;
						}
						rewind(_m19);
						inputState.guessing--;
					}
					if ( synPredMatched19 ) {
						AST tmp14_AST = null;
						tmp14_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp14_AST);
						match(LITERAL_exportVocab);
						match(EQUAL);
						ide = LT(1);
						ide_AST = astFactory.create(ide);
						astFactory.addASTChild(currentAST, ide_AST);
						match(ID);
					}
					else if ((_tokenSet_2.member(LA(1)))) {
						{
						{
						AST tmp16_AST = null;
						tmp16_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp16_AST);
						match(_tokenSet_2);
						}
						}
					}
					else {
						break _loop22;
					}
					}
				} while (true);
				}
				AST tmp17_AST = null;
				tmp17_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp17_AST);
				match(RCURLY);
				optionsSpec_AST = (AST)currentAST.root;
			}
			catch (RecognitionException ex) {
				if (inputState.guessing==0) {
					reportError(ex);
					consume();
					consumeUntil(_tokenSet_3);
				} else {
				  throw ex;
				}
			}
			returnAST = optionsSpec_AST;
		}
		
	public final void tokensSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST tokensSpec_AST = null;
		
		try {      // for error handling
			AST tmp18_AST = null;
			tmp18_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp18_AST);
			match(LITERAL_tokens);
			AST tmp19_AST = null;
			tmp19_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp19_AST);
			match(ACTION);
			tokensSpec_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = tokensSpec_AST;
	}
	
	public final void rules() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rules_AST = null;
		
		try {      // for error handling
			{
			int _cnt26=0;
			_loop26:
			do {
				if ((_tokenSet_5.member(LA(1)))) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt26>=1 ) { break _loop26; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt26++;
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				rules_AST = (AST)currentAST.root;
				rules_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(RULES,"rules")).add(rules_AST)) ;
				currentAST.root = rules_AST;
				currentAST.child = rules_AST!=null &&rules_AST.getFirstChild()!=null ?
					rules_AST.getFirstChild() : rules_AST;
				currentAST.advanceChildToEnd();
			}
			rules_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		returnAST = rules_AST;
	}
	
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rule_AST = null;
		Token  p1 = null;
		AST p1_AST = null;
		Token  p2 = null;
		AST p2_AST = null;
		Token  p3 = null;
		AST p3_AST = null;
		Token  a = null;
		AST a_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_protected:
			{
				p1 = LT(1);
				p1_AST = astFactory.create(p1);
				astFactory.addASTChild(currentAST, p1_AST);
				match(LITERAL_protected);
				break;
			}
			case LITERAL_public:
			{
				p2 = LT(1);
				p2_AST = astFactory.create(p2);
				astFactory.addASTChild(currentAST, p2_AST);
				match(LITERAL_public);
				break;
			}
			case LITERAL_private:
			{
				p3 = LT(1);
				p3_AST = astFactory.create(p3);
				astFactory.addASTChild(currentAST, p3_AST);
				match(LITERAL_private);
				break;
			}
			case ID:
			case BANG:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case BANG:
			{
				AST tmp20_AST = null;
				tmp20_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp20_AST);
				match(BANG);
				break;
			}
			case ID:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp21_AST = null;
			tmp21_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp21_AST);
			match(ID);
			{
			switch ( LA(1)) {
			case EXCL:
			{
				AST tmp22_AST = null;
				tmp22_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp22_AST);
				match(EXCL);
				break;
			}
			case ACTION:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ACTION:
			{
				a = LT(1);
				a_AST = astFactory.create(a);
				astFactory.addASTChild(currentAST, a_AST);
				match(ACTION);
				break;
			}
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(COLON);
			block();
			astFactory.addASTChild(currentAST, returnAST);
			match(SEMI);
			rule_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = rule_AST;
	}
	
	public final void block() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST block_AST = null;
		
		try {      // for error handling
			alternative();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop34:
			do {
				if ((LA(1)==OR)) {
					match(OR);
					alternative();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop34;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				block_AST = (AST)currentAST.root;
				block_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OR,"block")).add(block_AST)) ;
				currentAST.root = block_AST;
				currentAST.child = block_AST!=null &&block_AST.getFirstChild()!=null ?
					block_AST.getFirstChild() : block_AST;
				currentAST.advanceChildToEnd();
			}
			block_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = block_AST;
	}
	
	public final void alternative() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alternative_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case EXCL:
			{
				AST tmp26_AST = null;
				tmp26_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp26_AST);
				match(EXCL);
				break;
			}
			case SEMI:
			case LPAREN:
			case RPAREN:
			case OR:
			case DOT:
			case ID:
			case CHAR_LITERAL:
			case STRING_LITERAL:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop38:
			do {
				if ((_tokenSet_8.member(LA(1)))) {
					element();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop38;
				}
				
			} while (true);
			}
			alternative_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		returnAST = alternative_AST;
	}
	
	public final void element() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST element_AST = null;
		
		try {      // for error handling
			elementNoOptionSpec();
			astFactory.addASTChild(currentAST, returnAST);
			element_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_10);
			} else {
			  throw ex;
			}
		}
		returnAST = element_AST;
	}
	
	public final void elementNoOptionSpec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST elementNoOptionSpec_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case DOT:
			case ID:
			case CHAR_LITERAL:
			case STRING_LITERAL:
			{
				terminal();
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case EXCL:
				{
					AST tmp27_AST = null;
					tmp27_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp27_AST);
					match(EXCL);
					break;
				}
				case SEMI:
				case LPAREN:
				case RPAREN:
				case OR:
				case DOT:
				case ID:
				case CHAR_LITERAL:
				case STRING_LITERAL:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				elementNoOptionSpec_AST = (AST)currentAST.root;
				break;
			}
			case LPAREN:
			{
				ebnf();
				astFactory.addASTChild(currentAST, returnAST);
				elementNoOptionSpec_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_10);
			} else {
			  throw ex;
			}
		}
		returnAST = elementNoOptionSpec_AST;
	}
	
	public final void terminal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST terminal_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CHAR_LITERAL:
			{
				AST tmp28_AST = null;
				tmp28_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp28_AST);
				match(CHAR_LITERAL);
				terminal_AST = (AST)currentAST.root;
				break;
			}
			case ID:
			{
				AST tmp29_AST = null;
				tmp29_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp29_AST);
				match(ID);
				terminal_AST = (AST)currentAST.root;
				break;
			}
			case STRING_LITERAL:
			{
				AST tmp30_AST = null;
				tmp30_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp30_AST);
				match(STRING_LITERAL);
				terminal_AST = (AST)currentAST.root;
				break;
			}
			case DOT:
			{
				AST tmp31_AST = null;
				tmp31_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp31_AST);
				match(DOT);
				terminal_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		returnAST = terminal_AST;
	}
	
	public final void ebnf() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ebnf_AST = null;
		Token  lp = null;
		AST lp_AST = null;
		Token  aa = null;
		AST aa_AST = null;
		Token  ab = null;
		AST ab_AST = null;
		
		try {      // for error handling
			lp = LT(1);
			lp_AST = astFactory.create(lp);
			match(LPAREN);
			{
			if ((LA(1)==ACTION||LA(1)==COLON)) {
				{
				switch ( LA(1)) {
				case ACTION:
				{
					aa = LT(1);
					aa_AST = astFactory.create(aa);
					astFactory.addASTChild(currentAST, aa_AST);
					match(ACTION);
					break;
				}
				case COLON:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp32_AST = null;
				tmp32_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp32_AST);
				match(COLON);
			}
			else if ((LA(1)==ACTION)) {
				ab = LT(1);
				ab_AST = astFactory.create(ab);
				astFactory.addASTChild(currentAST, ab_AST);
				match(ACTION);
				AST tmp33_AST = null;
				tmp33_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp33_AST);
				match(COLON);
			}
			else if ((_tokenSet_12.member(LA(1)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			block();
			astFactory.addASTChild(currentAST, returnAST);
			match(RPAREN);
			{
			switch ( LA(1)) {
			case SEMI:
			case LPAREN:
			case RPAREN:
			case STAR:
			case PLUS:
			case OR:
			case QUESTION:
			case DOT:
			case EXCL:
			case ID:
			case CHAR_LITERAL:
			case STRING_LITERAL:
			{
				{
				switch ( LA(1)) {
				case QUESTION:
				{
					AST tmp35_AST = null;
					tmp35_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp35_AST);
					match(QUESTION);
					break;
				}
				case STAR:
				{
					AST tmp36_AST = null;
					tmp36_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp36_AST);
					match(STAR);
					break;
				}
				case PLUS:
				{
					AST tmp37_AST = null;
					tmp37_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp37_AST);
					match(PLUS);
					break;
				}
				case SEMI:
				case LPAREN:
				case RPAREN:
				case OR:
				case DOT:
				case EXCL:
				case ID:
				case CHAR_LITERAL:
				case STRING_LITERAL:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case EXCL:
				{
					AST tmp38_AST = null;
					tmp38_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp38_AST);
					match(EXCL);
					break;
				}
				case SEMI:
				case LPAREN:
				case RPAREN:
				case OR:
				case DOT:
				case ID:
				case CHAR_LITERAL:
				case STRING_LITERAL:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case IMPLIES:
			{
				AST tmp39_AST = null;
				tmp39_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp39_AST);
				match(IMPLIES);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			ebnf_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_10);
			} else {
			  throw ex;
			}
		}
		returnAST = ebnf_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"MLC_STAR",
		"MLC_CLOSE",
		"MLC_WORD",
		"MLC_WS",
		"\"charVocabulary\"",
		"\"importVocab\"",
		"\"exportVocab\"",
		"\"testLiterals\"",
		"\"warnWhenFollowAmbig\"",
		"\"filter\"",
		"\"true\"",
		"\"false\"",
		"\"k\"",
		"OPTION_EQUAL",
		"OPTION_CLOSE",
		"OPTION_WORD",
		"OPTION_WS",
		"SL_COMMENT",
		"SEMI",
		"\"options\"",
		"\"tokens\"",
		"\"header\"",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"\"returns\"",
		"\"throws\"",
		"\"exception\"",
		"\"catch\"",
		"NEWLINE",
		"TAB",
		"BLANK",
		"MLC_OPEN",
		"TREE_BEGIN",
		"LPAREN",
		"RPAREN",
		"LBRACK",
		"RBRACK",
		"LCURLY",
		"ACTION",
		"RCURLY",
		"COLON",
		"COMMA",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"OR",
		"QUESTION",
		"DOT",
		"EQUAL",
		"EXCL",
		"TILDE",
		"DIV",
		"RANGE",
		"MINUS",
		"MOD",
		"GT",
		"LT",
		"MARKER",
		"ARG",
		"XID",
		"BAND",
		"AT",
		"SHARP",
		"GRAVE",
		"BACK",
		"DOLLAR",
		"ID",
		"CHAR_LITERAL",
		"STRING_LITERAL",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"INT",
		"\"grammar\"",
		"\"rule\"",
		"\"rules\"",
		"BANG"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 562950087639042L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { -1125899906842640L, 33554431L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 562980034969600L, 16793600L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 562980018192384L, 16793600L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 30064771072L, 16793600L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 562980152410114L, 16793600L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 35184376283136L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 576478344489467904L, 114688L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 144150372452139008L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 720628716941606912L, 114688L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 3026471726155300864L, 114688L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 3026471726151106560L, 114688L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	
	}
