package org.antlr_yggdrasil.runtime;

/** A DFA implemented as a set of transition tables.
 *
 *  There are at most 32767 states (16-bit signed short).
 *  Could get away with byte sometimes but would have to generate different
 *  types and the simulation code too.  For a point of reference, the Java
 *  lexer's Tokens rule DFA has 326 states roughly.
 */
public class DFA2 {
    short[] min;
    short[] max;
    short[] accept;
    short[] special;
    short[][] transition;

	public int predict(IntStream input) {
		/*
		s = 0;
		c = read();
		while (accept[s] < 1) {
			s' = special[s];
			if (s'<0) { // normal state
				if (c>=min[s] && c<=max[s]) {
					s = transition[s][c-min[s]];
					if ( s<0 ) {
						throw error;
					}
					c = read();
					continue;
				}
				throw noviablealt;
			}
			else {
				s = specialTransition(s, c);
			}
			c = read();
		}
		return accept[s];
		*/
		return 0;
	}

	public int specialTransition(int state, int symbol) {
		return 0;
	}
}
