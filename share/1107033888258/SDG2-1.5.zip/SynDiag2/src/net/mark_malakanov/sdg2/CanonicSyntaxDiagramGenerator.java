package net.mark_malakanov.sdg2;
/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/CanonicSyntaxDiagramGenerator.java,v 1.1 2005/01/03 13:16:47 Mark Exp $
 *
 * Modification Log
 * $Log: CanonicSyntaxDiagramGenerator.java,v $
 * Revision 1.1  2005/01/03 13:16:47  Mark
 * minor
 *
 *
 */

import edu.usfca.syndiag.DefaultSyntaxDiagramGenerator;
import edu.usfca.syndiag.GraphicsEngine;
import edu.usfca.syndiag.SetDimension;
import java.awt.Font;

public class CanonicSyntaxDiagramGenerator extends DefaultSyntaxDiagramGenerator  {
  public CanonicSyntaxDiagramGenerator() {
  }

public CanonicSyntaxDiagramGenerator(GraphicsEngine engine){
		super(engine);
	}
  
public void drawTokenRef(int x, int y, int w, int h, String str){
		engine.drawOval(x, y, w, h);
		drawText(str, new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE), x+14, y+15);
	}

public void drawNot(int x, int y, int w, int h, String str){
		  engine.drawOval(x, y, w, h);
    	drawText(str, new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE), x+6, y+15);
    }

public void drawRuleRef(int x, int y, int w, int h, String str){
		engine.drawRect(x, y, w, h);
		drawText(str, new Font("Monospaces", Font.ITALIC, SetDimension.ELEMENT_FONT_SIZE), x+10, y+15);
	}

public void drawL(int x, int y, int w, int h, String str){
		engine.drawOval(x, y, w, h);
    drawText(str, new Font("Monospaces", Font.PLAIN, SetDimension.ELEMENT_FONT_SIZE), x+14, y+15);
	}
	
}