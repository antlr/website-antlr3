package net.mark_malakanov.sdg2;


/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/Main.java,v 1.7 2005/01/25 07:59:53 Mark Exp $
 *
 * Modification Log
 * $Log: Main.java,v $
 * Revision 1.7  2005/01/25 07:59:53  Mark
 * "save" menu items grayed
 *
 * Revision 1.6  2005/01/24 05:34:52  Mark
 * bug fixed. Form did not show when no parameters provided.
 *
 * Revision 1.5  2005/01/03 13:16:48  Mark
 * minor
 *
 * Revision 1.4  2004/12/30 01:53:28  Mark
 * resizing of width added
 *
 * Revision 1.3  2004/12/29 20:38:32  Mark
 * SdgBody separated with GUI. Multifile output command line params added.
 *
 * Revision 1.2  2004/12/28 07:47:47  Mark
 * CVS keywords added
 *
 *
 */
import antlr.collections.*;

import edu.usfca.syndiag.*;

import java.awt.*;

import java.io.*;

import javax.swing.*;


public class Main {
    static boolean isBlind = false;
    static boolean toWrap = false;
    static boolean isStandardInput = false;
    static boolean isStandardOutput = false;
    static String diagramWidth;
    static String diagramAltWidth;
    static int diagramWidthInt;
    static int diagramAltWidthInt;
    static String saveToFileName;
    static String saveToImageType;
    static String saveToHtmlName;
    static String saveToHtmlDirName;
    static String saveToHtmlTitle;
    static String saveToHtmlHeader;
    static String saveToHtmlImgBorder;
    static String inputFileName;
    static String grammarName;
    static String uniformName;
    static String diagramStyle;
    SdgBody sdgBody;

    public static void print(GrammarAST t) {
        System.out.println(toString(t));
    }

    public static String toString(GrammarAST t) {
        String s = null;

        try {
            s = new ANTLRTreePrinter().toString((AST) t);
        } catch (Exception e) {
            System.err.println("Problems printing tree: " + t);
            e.printStackTrace(System.err);
        }

        return s;
    }

    public static void parseArgs(String[] args) {
        saveToImageType = "png";
        diagramStyle = "Canonical";

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-width")) {
                toWrap = true;
                diagramWidth = args[++i];
            } else if (args[i].equals("-altwidth")) {
                diagramAltWidth = args[++i];
            } else if (args[i].equals("-diagramstyle")) {
                diagramStyle = args[++i];
            }else if (args[i].equals("-save")) {
                saveToFileName = args[++i];
            } else if (args[i].equals("-savehtml")) {
                saveToHtmlName = args[++i];
            } else if (args[i].equals("-savehtmltitle")) {
                saveToHtmlTitle = args[++i];
            } else if (args[i].equals("-savehtmlheader")) {
                saveToHtmlHeader = args[++i];
            } else if (args[i].equals("-savehtmldir")) {
                saveToHtmlDirName = args[++i];
            } else if (args[i].equals("-saveimgtype")) {
                saveToImageType = args[++i];
            } else if (args[i].equals("-saveimgborder")) {
                saveToHtmlImgBorder = args[++i];
            } else if (args[i].equals("-blind")) {
                isBlind = true;
            } else if (args[i].equals("-i")) {
                isStandardInput = true;
            } else if (args[i].equals("-o")) {
                isStandardOutput = true;
            } else if (args[i].equals("-help")) {
                printUsage();
            } else if (args[i].equals("--help")) {
                printUsage();
            } else if (args[i].equals("-?")) {
                printUsage();
            } else {
                inputFileName = args[i];
            }
        }

        if (((inputFileName == null) && (!isStandardInput)) &&
                ((saveToFileName != null) || (saveToHtmlName != null) ||
                (saveToHtmlDirName != null) || (saveToHtmlTitle != null) ||
                (saveToHtmlHeader != null))) {
            System.err.println(
                "Error: Input is not specified when -save, -savehtmldir, -savehtmltitle or -savehtmlheader are.");
            printUsage();
        }

        if (inputFileName != null) {
            isStandardInput = false;

            String[] s1 = inputFileName.split("([\\/\\\\])");
            String[] s2 = s1[s1.length - 1].split("\\.");
            grammarName = s2[0];
        }

        if (isStandardInput) {
            grammarName = "std input";
        }

        if (saveToFileName != null) {
            isStandardOutput = false;
        }

        if (saveToHtmlName != null) {
            isStandardOutput = false;

            String[] s1 = saveToHtmlName.split("([\\/\\\\])");
            String[] s2 = s1[s1.length - 1].split("\\.");
            uniformName = s2[0];
        }

        if ((saveToHtmlName != null) && (saveToHtmlDirName == null)) {
            saveToHtmlDirName = uniformName.replace(' ', '_');
        }

        if ((saveToHtmlName != null) && (saveToHtmlTitle == null)) {
            saveToHtmlTitle = uniformName;
        }

        if ((saveToHtmlTitle != null) && (saveToHtmlHeader == null)) {
            saveToHtmlHeader = saveToHtmlTitle;
        }

        if ((saveToHtmlName == null) &&
                ((saveToHtmlDirName != null) || (saveToHtmlTitle != null) ||
                (saveToHtmlHeader != null))) {
            System.err.println(
                "Error: -savehtml is not specified when -savehtmldir, -savehtmltitle or -savehtmlheader are.");
            printUsage();
        }

        if (diagramWidth != null) {
            diagramWidthInt = new Integer(diagramWidth).intValue();
        }

        if (diagramAltWidth != null) {
            diagramAltWidthInt = new Integer(diagramAltWidth).intValue();
        }

        if ((diagramWidth != null) && (diagramAltWidth == null)) {
            diagramAltWidthInt = diagramWidthInt - 300;
        }

        if (toWrap && ((diagramWidthInt < 600) || (diagramAltWidthInt < 300))) {
            System.err.println(
                "Error: -width must be more 599; -altwidth must be more 299.");
            printUsage();
        }

        if ((diagramWidth == null) && (diagramAltWidth != null)) {
            System.err.println(
                "Error: -width is not specified when -altwidth is.");
            printUsage();
        }
        
        diagramStyle = diagramStyle.toLowerCase();
        if ( diagramStyle.startsWith("c") ) {
          diagramStyle = "Canonical";
        } else if ( diagramStyle.startsWith("h") ) {
          diagramStyle = "Heretical";
        } else {
            System.err.println(
                "Error: -diagramstyle must be \"c[anonical]\" or \"h[eretical]\".");
            printUsage();
        }
            
    }

    public static void printUsage() {
        System.out.println(
            "Usage: java edu.usfca.syndiag.Main [-wrap] [-blind] \\");
        System.out.println(
            "[-save image.ext] [-savehtml file.html [-savehtmldir dir] [-savehtmltitle \"html Title\"] \\");
        System.out.println(
            "[-savehtmlheader \"html Header\"] [-saveimgborder 0] [-saveimgtype ext] [-i] [-diagramstyle style] [input.g]");
        System.exit(0);
    }

    public static void main(String[] args) throws Exception {
        SwingForm swing = null;
        SdgBody sdgBody = new SdgBody();

        parseArgs(args);
        
        sdgBody.diagramWidth = diagramWidthInt;
        sdgBody.diagramAltWidth = diagramAltWidthInt;
        sdgBody.diagramStyle = diagramStyle;
        
        
        InputStream inStr = null;

        if (inputFileName != null) {
            inStr = new FileInputStream(inputFileName);
        } else if (isStandardInput) {
            inStr = System.in;
        }

        if (!isBlind) {
           swing = new SwingForm(sdgBody);
           swing.createForm();
           swing.frm.setTitle("SDG2");
        }

        if (inStr != null) {
            if (isBlind) {
                sdgBody.load(inStr);
            } else {
                swing.frm.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                sdgBody.load(inStr);
                
                swing.menuItemSaveAs.setEnabled(true);
                swing.menuItemSaveAsHTML.setEnabled(true);
                swing.menuItemSetWidth.setEnabled(true);
                swing.menuItemDiagStyle.setEnabled(true);
                    
                swing.draw(sdgBody.grammarTree);
                swing.frm.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                swing.frm.setTitle("SDG2: " + grammarName);
            }

            if (saveToFileName != null) {
                sdgBody.saveAsFile(sdgBody.grammarTree, saveToFileName);
            }

            if (saveToHtmlName != null) {
                if (!isBlind) {
                    ProgressMonitor progressMonitor;
                    progressMonitor = new ProgressMonitor(swing.frm,
                            "Saving multiple files", "", 0, 0);
                    progressMonitor.setMillisToDecideToPopup(10);
                    progressMonitor.setMillisToPopup(0);

                    sdgBody.saveAsHTMLandFilesInBkg(saveToHtmlDirName,
                        saveToHtmlName, saveToImageType, saveToHtmlTitle,
                        saveToHtmlHeader, saveToHtmlImgBorder, progressMonitor);
                } else {
                    sdgBody.saveAsHTMLandFiles(saveToHtmlDirName,
                        saveToHtmlName, saveToImageType, saveToHtmlTitle,
                        saveToHtmlHeader, saveToHtmlImgBorder, null);
                } //else
            } //if

            if (isBlind) {
                System.exit(0);
            }
        } //if (inStr != null)
    } //main
}
