// $ANTLR : "E.g" -> "ELexer.java"$

package satc.lang; 

import java.io.InputStream;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.TokenStreamRecognitionException;
import antlr.CharStreamException;
import antlr.CharStreamIOException;
import antlr.ANTLRException;
import java.io.Reader;
import java.util.Hashtable;
import antlr.CharScanner;
import antlr.InputBuffer;
import antlr.ByteBuffer;
import antlr.CharBuffer;
import antlr.Token;
import antlr.CommonToken;
import antlr.RecognitionException;
import antlr.NoViableAltForCharException;
import antlr.MismatchedCharException;
import antlr.TokenStream;
import antlr.ANTLRHashString;
import antlr.LexerSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.SemanticException;

public class ELexer extends antlr.CharScanner implements ETokenTypes, TokenStream
 {

public ELexer() {
    this((LexerSharedInputState) null); 
}
public ELexer(InputStream in) {
	this(new ByteBuffer(in));
}
public ELexer(Reader in) {
	this(new CharBuffer(in));
}
public ELexer(InputBuffer ib) {
	this(new LexerSharedInputState(ib));
}
public ELexer(LexerSharedInputState state) {
	super(state);
	caseSensitiveLiterals = true;
	setCaseSensitive(true);
	literals = new Hashtable();
	literals.put(new ANTLRHashString("pre_generate", this), new Integer(64));
	literals.put(new ANTLRHashString("until", this), new Integer(84));
	literals.put(new ANTLRHashString("define", this), new Integer(284));
	literals.put(new ANTLRHashString("reverse", this), new Integer(212));
	literals.put(new ANTLRHashString("also", this), new Integer(80));
	literals.put(new ANTLRHashString("unlock", this), new Integer(286));
	literals.put(new ANTLRHashString("variable", this), new Integer(131));
	literals.put(new ANTLRHashString("start_of_test", this), new Integer(163));
	literals.put(new ANTLRHashString("swap", this), new Integer(127));
	literals.put(new ANTLRHashString("sort_by_field", this), new Integer(215));
	literals.put(new ANTLRHashString("HEX", this), new Integer(111));
	literals.put(new ANTLRHashString("with", this), new Integer(272));
	literals.put(new ANTLRHashString("session", this), new Integer(162));
	literals.put(new ANTLRHashString("new_time", this), new Integer(161));
	literals.put(new ANTLRHashString("result", this), new Integer(85));
	literals.put(new ANTLRHashString("bits", this), new Integer(25));
	literals.put(new ANTLRHashString("count", this), new Integer(197));
	literals.put(new ANTLRHashString("flush", this), new Integer(296));
	literals.put(new ANTLRHashString("illegal", this), new Integer(113));
	literals.put(new ANTLRHashString("TRUE", this), new Integer(17));
	literals.put(new ANTLRHashString("MIN_INT", this), new Integer(23));
	literals.put(new ANTLRHashString("append", this), new Integer(244));
	literals.put(new ANTLRHashString("read_lob", this), new Integer(293));
	literals.put(new ANTLRHashString("specman", this), new Integer(273));
	literals.put(new ANTLRHashString("wait", this), new Integer(83));
	literals.put(new ANTLRHashString("clear", this), new Integer(188));
	literals.put(new ANTLRHashString("import", this), new Integer(281));
	literals.put(new ANTLRHashString("break", this), new Integer(48));
	literals.put(new ANTLRHashString("spawn_check", this), new Integer(275));
	literals.put(new ANTLRHashString("weight", this), new Integer(107));
	literals.put(new ANTLRHashString("init", this), new Integer(63));
	literals.put(new ANTLRHashString("str_empty", this), new Integer(251));
	literals.put(new ANTLRHashString("task", this), new Integer(138));
	literals.put(new ANTLRHashString("text", this), new Integer(106));
	literals.put(new ANTLRHashString("continue", this), new Integer(49));
	literals.put(new ANTLRHashString("deep_compare_physical", this), new Integer(243));
	literals.put(new ANTLRHashString("do_print", this), new Integer(71));
	literals.put(new ANTLRHashString("ERROR_BREAK_RUN", this), new Integer(94));
	literals.put(new ANTLRHashString("network", this), new Integer(126));
	literals.put(new ANTLRHashString("for", this), new Integer(37));
	literals.put(new ANTLRHashString("check", this), new Integer(88));
	literals.put(new ANTLRHashString("else", this), new Integer(52));
	literals.put(new ANTLRHashString("bit_wise_xor", this), new Integer(237));
	literals.put(new ANTLRHashString("is", this), new Integer(33));
	literals.put(new ANTLRHashString("time", this), new Integer(12));
	literals.put(new ANTLRHashString("in_file", this), new Integer(47));
	literals.put(new ANTLRHashString("insert", this), new Integer(191));
	literals.put(new ANTLRHashString("forcible", this), new Integer(134));
	literals.put(new ANTLRHashString("of", this), new Integer(56));
	literals.put(new ANTLRHashString("range", this), new Integer(115));
	literals.put(new ANTLRHashString("str_expand_dots", this), new Integer(253));
	literals.put(new ANTLRHashString("and", this), new Integer(30));
	literals.put(new ANTLRHashString("byte", this), new Integer(11));
	literals.put(new ANTLRHashString("try_enclosing_unit", this), new Integer(78));
	literals.put(new ANTLRHashString("str_lower", this), new Integer(257));
	literals.put(new ANTLRHashString("interface", this), new Integer(146));
	literals.put(new ANTLRHashString("as", this), new Integer(282));
	literals.put(new ANTLRHashString("key_index", this), new Integer(224));
	literals.put(new ANTLRHashString("key", this), new Integer(186));
	literals.put(new ANTLRHashString("bin", this), new Integer(246));
	literals.put(new ANTLRHashString("keeping", this), new Integer(178));
	literals.put(new ANTLRHashString("write", this), new Integer(292));
	literals.put(new ANTLRHashString("prev", this), new Integer(180));
	literals.put(new ANTLRHashString("procedure", this), new Integer(151));
	literals.put(new ANTLRHashString("exists", this), new Integer(198));
	literals.put(new ANTLRHashString("like", this), new Integer(59));
	literals.put(new ANTLRHashString("resize", this), new Integer(194));
	literals.put(new ANTLRHashString("uint", this), new Integer(9));
	literals.put(new ANTLRHashString("set_config", this), new Integer(266));
	literals.put(new ANTLRHashString("var", this), new Integer(28));
	literals.put(new ANTLRHashString("hdl_path", this), new Integer(75));
	literals.put(new ANTLRHashString("hold", this), new Integer(136));
	literals.put(new ANTLRHashString("str_exactly", this), new Integer(252));
	literals.put(new ANTLRHashString("emit", this), new Integer(155));
	literals.put(new ANTLRHashString("post_generate", this), new Integer(65));
	literals.put(new ANTLRHashString("first_index", this), new Integer(199));
	literals.put(new ANTLRHashString("start", this), new Integer(87));
	literals.put(new ANTLRHashString("unique", this), new Integer(218));
	literals.put(new ANTLRHashString("fast_delete", this), new Integer(190));
	literals.put(new ANTLRHashString("finalize", this), new Integer(69));
	literals.put(new ANTLRHashString("WARNING", this), new Integer(97));
	literals.put(new ANTLRHashString("DEC", this), new Integer(109));
	literals.put(new ANTLRHashString("output_from_check", this), new Integer(278));
	literals.put(new ANTLRHashString("delay", this), new Integer(142));
	literals.put(new ANTLRHashString("initial", this), new Integer(145));
	literals.put(new ANTLRHashString("str_split", this), new Integer(261));
	literals.put(new ANTLRHashString("max_index", this), new Integer(207));
	literals.put(new ANTLRHashString("open", this), new Integer(290));
	literals.put(new ANTLRHashString("instance", this), new Integer(61));
	literals.put(new ANTLRHashString("function", this), new Integer(129));
	literals.put(new ANTLRHashString("tick_start", this), new Integer(159));
	literals.put(new ANTLRHashString("isqrt", this), new Integer(233));
	literals.put(new ANTLRHashString("unit", this), new Integer(58));
	literals.put(new ANTLRHashString("get_keep", this), new Integer(271));
	literals.put(new ANTLRHashString("str_split_all", this), new Integer(262));
	literals.put(new ANTLRHashString("bit_wise_xnor", this), new Integer(240));
	literals.put(new ANTLRHashString("radix", this), new Integer(108));
	literals.put(new ANTLRHashString("sort", this), new Integer(214));
	literals.put(new ANTLRHashString("first", this), new Integer(79));
	literals.put(new ANTLRHashString("last", this), new Integer(204));
	literals.put(new ANTLRHashString("bit_wise_and", this), new Integer(235));
	literals.put(new ANTLRHashString("at_least", this), new Integer(104));
	literals.put(new ANTLRHashString("do_pack", this), new Integer(73));
	literals.put(new ANTLRHashString("max_value", this), new Integer(208));
	literals.put(new ANTLRHashString("computed", this), new Integer(283));
	literals.put(new ANTLRHashString("write_lob", this), new Integer(294));
	literals.put(new ANTLRHashString("any", this), new Integer(158));
	literals.put(new ANTLRHashString("str_len", this), new Integer(256));
	literals.put(new ANTLRHashString("down", this), new Integer(39));
	literals.put(new ANTLRHashString("each", this), new Integer(42));
	literals.put(new ANTLRHashString("matching", this), new Integer(45));
	literals.put(new ANTLRHashString("not", this), new Integer(29));
	literals.put(new ANTLRHashString("transition", this), new Integer(102));
	literals.put(new ANTLRHashString("soft", this), new Integer(179));
	literals.put(new ANTLRHashString("extend", this), new Integer(60));
	literals.put(new ANTLRHashString("packing", this), new Integer(121));
	literals.put(new ANTLRHashString("all", this), new Integer(55));
	literals.put(new ANTLRHashString("state", this), new Integer(287));
	literals.put(new ANTLRHashString("in", this), new Integer(32));
	literals.put(new ANTLRHashString("item", this), new Integer(100));
	literals.put(new ANTLRHashString("no_collect", this), new Integer(103));
	literals.put(new ANTLRHashString("set_check", this), new Integer(92));
	literals.put(new ANTLRHashString("count_only", this), new Integer(118));
	literals.put(new ANTLRHashString("str_pad", this), new Integer(259));
	literals.put(new ANTLRHashString("global", this), new Integer(105));
	literals.put(new ANTLRHashString("write_config", this), new Integer(268));
	literals.put(new ANTLRHashString("file", this), new Integer(16));
	literals.put(new ANTLRHashString("high", this), new Integer(122));
	literals.put(new ANTLRHashString("drive", this), new Integer(135));
	literals.put(new ANTLRHashString("ERROR_AUTOMATIC", this), new Integer(95));
	literals.put(new ANTLRHashString("that", this), new Integer(89));
	literals.put(new ANTLRHashString("a", this), new Integer(34));
	literals.put(new ANTLRHashString("detach", this), new Integer(173));
	literals.put(new ANTLRHashString("str_match", this), new Integer(258));
	literals.put(new ANTLRHashString("verilog", this), new Integer(130));
	literals.put(new ANTLRHashString("delete", this), new Integer(189));
	literals.put(new ANTLRHashString("pack", this), new Integer(119));
	literals.put(new ANTLRHashString("when", this), new Integer(62));
	literals.put(new ANTLRHashString("top", this), new Integer(217));
	literals.put(new ANTLRHashString("str_insensitive", this), new Integer(254));
	literals.put(new ANTLRHashString("line", this), new Integer(46));
	literals.put(new ANTLRHashString("get_symbol", this), new Integer(279));
	literals.put(new ANTLRHashString("TRANSPORT", this), new Integer(144));
	literals.put(new ANTLRHashString("before", this), new Integer(181));
	literals.put(new ANTLRHashString("bit_wise_or", this), new Integer(236));
	literals.put(new ANTLRHashString("ERROR_CONTINUE", this), new Integer(96));
	literals.put(new ANTLRHashString("appendf", this), new Integer(245));
	literals.put(new ANTLRHashString("str_chop", this), new Integer(250));
	literals.put(new ANTLRHashString("BIN", this), new Integer(110));
	literals.put(new ANTLRHashString("IGNORE", this), new Integer(98));
	literals.put(new ANTLRHashString("print_line", this), new Integer(72));
	literals.put(new ANTLRHashString("add_file_type", this), new Integer(297));
	literals.put(new ANTLRHashString("spawn", this), new Integer(274));
	literals.put(new ANTLRHashString("deep_copy", this), new Integer(241));
	literals.put(new ANTLRHashString("library", this), new Integer(147));
	literals.put(new ANTLRHashString("product", this), new Integer(222));
	literals.put(new ANTLRHashString("reset_soft", this), new Integer(184));
	literals.put(new ANTLRHashString("declarative_item", this), new Integer(150));
	literals.put(new ANTLRHashString("locker", this), new Integer(15));
	literals.put(new ANTLRHashString("get_config", this), new Integer(267));
	literals.put(new ANTLRHashString("to", this), new Integer(40));
	literals.put(new ANTLRHashString("unpack", this), new Integer(120));
	literals.put(new ANTLRHashString("case", this), new Integer(53));
	literals.put(new ANTLRHashString("force", this), new Integer(152));
	literals.put(new ANTLRHashString("step", this), new Integer(41));
	literals.put(new ANTLRHashString("split", this), new Integer(216));
	literals.put(new ANTLRHashString("max", this), new Integer(206));
	literals.put(new ANTLRHashString("normal", this), new Integer(117));
	literals.put(new ANTLRHashString("ranges", this), new Integer(114));
	literals.put(new ANTLRHashString("code", this), new Integer(128));
	literals.put(new ANTLRHashString("bit_wise_nor", this), new Integer(239));
	literals.put(new ANTLRHashString("true", this), new Integer(169));
	literals.put(new ANTLRHashString("bool", this), new Integer(13));
	literals.put(new ANTLRHashString("to_string", this), new Integer(265));
	literals.put(new ANTLRHashString("eventually", this), new Integer(172));
	literals.put(new ANTLRHashString("FALSE", this), new Integer(18));
	literals.put(new ANTLRHashString("fail", this), new Integer(171));
	literals.put(new ANTLRHashString("cover", this), new Integer(99));
	literals.put(new ANTLRHashString("do", this), new Integer(36));
	literals.put(new ANTLRHashString("dut_error", this), new Integer(90));
	literals.put(new ANTLRHashString("list", this), new Integer(185));
	literals.put(new ANTLRHashString("end_of_test", this), new Integer(164));
	literals.put(new ANTLRHashString("sync", this), new Integer(82));
	literals.put(new ANTLRHashString("abs", this), new Integer(228));
	literals.put(new ANTLRHashString("outf", this), new Integer(227));
	literals.put(new ANTLRHashString("change", this), new Integer(165));
	literals.put(new ANTLRHashString("cycle", this), new Integer(170));
	literals.put(new ANTLRHashString("tick_end", this), new Integer(160));
	literals.put(new ANTLRHashString("do_unpack", this), new Integer(74));
	literals.put(new ANTLRHashString("sys", this), new Integer(157));
	literals.put(new ANTLRHashString("or_all", this), new Integer(221));
	literals.put(new ANTLRHashString("then", this), new Integer(51));
	literals.put(new ANTLRHashString("all_indicies", this), new Integer(195));
	literals.put(new ANTLRHashString("close", this), new Integer(295));
	literals.put(new ANTLRHashString("bytes", this), new Integer(26));
	literals.put(new ANTLRHashString("quit", this), new Integer(68));
	literals.put(new ANTLRHashString("cross", this), new Integer(101));
	literals.put(new ANTLRHashString("or", this), new Integer(31));
	literals.put(new ANTLRHashString("if", this), new Integer(50));
	literals.put(new ANTLRHashString("exec", this), new Integer(174));
	literals.put(new ANTLRHashString("wire", this), new Integer(133));
	literals.put(new ANTLRHashString("MAX_INT", this), new Integer(21));
	literals.put(new ANTLRHashString("index", this), new Integer(44));
	literals.put(new ANTLRHashString("ignore", this), new Integer(112));
	literals.put(new ANTLRHashString("run", this), new Integer(66));
	literals.put(new ANTLRHashString("add", this), new Integer(187));
	literals.put(new ANTLRHashString("push", this), new Integer(193));
	literals.put(new ANTLRHashString("string", this), new Integer(14));
	literals.put(new ANTLRHashString("system", this), new Integer(276));
	literals.put(new ANTLRHashString("str_join", this), new Integer(255));
	literals.put(new ANTLRHashString("str_upper", this), new Integer(264));
	literals.put(new ANTLRHashString("return", this), new Integer(86));
	literals.put(new ANTLRHashString("copy", this), new Integer(70));
	literals.put(new ANTLRHashString("keep", this), new Integer(177));
	literals.put(new ANTLRHashString("from", this), new Integer(38));
	literals.put(new ANTLRHashString("get_indicies", this), new Integer(200));
	literals.put(new ANTLRHashString("read", this), new Integer(291));
	literals.put(new ANTLRHashString("value", this), new Integer(141));
	literals.put(new ANTLRHashString("release", this), new Integer(153));
	literals.put(new ANTLRHashString("date_time", this), new Integer(280));
	literals.put(new ANTLRHashString("bit_wise_nand", this), new Integer(238));
	literals.put(new ANTLRHashString("only", this), new Integer(81));
	literals.put(new ANTLRHashString("default", this), new Integer(54));
	literals.put(new ANTLRHashString("get_enclosing_unit", this), new Integer(77));
	literals.put(new ANTLRHashString("hex", this), new Integer(248));
	literals.put(new ANTLRHashString("extract", this), new Integer(67));
	literals.put(new ANTLRHashString("event", this), new Integer(154));
	literals.put(new ANTLRHashString("expect", this), new Integer(91));
	literals.put(new ANTLRHashString("as_a", this), new Integer(27));
	literals.put(new ANTLRHashString("UNDEF", this), new Integer(20));
	literals.put(new ANTLRHashString("strobe", this), new Integer(137));
	literals.put(new ANTLRHashString("rise", this), new Integer(166));
	literals.put(new ANTLRHashString("driver", this), new Integer(139));
	literals.put(new ANTLRHashString("and_all", this), new Integer(219));
	literals.put(new ANTLRHashString("apply", this), new Integer(196));
	literals.put(new ANTLRHashString("int", this), new Integer(8));
	literals.put(new ANTLRHashString("quote", this), new Integer(249));
	literals.put(new ANTLRHashString("ipow", this), new Integer(232));
	literals.put(new ANTLRHashString("last_index", this), new Integer(205));
	literals.put(new ANTLRHashString("high_big_endian", this), new Integer(123));
	literals.put(new ANTLRHashString("ilog", this), new Integer(231));
	literals.put(new ANTLRHashString("consume", this), new Integer(175));
	literals.put(new ANTLRHashString("pop", this), new Integer(192));
	literals.put(new ANTLRHashString("fall", this), new Integer(167));
	literals.put(new ANTLRHashString("disconnect", this), new Integer(140));
	literals.put(new ANTLRHashString("average", this), new Integer(220));
	literals.put(new ANTLRHashString("on", this), new Integer(156));
	literals.put(new ANTLRHashString("using", this), new Integer(43));
	literals.put(new ANTLRHashString("machine", this), new Integer(288));
	literals.put(new ANTLRHashString("get_unit", this), new Integer(76));
	literals.put(new ANTLRHashString("net", this), new Integer(132));
	literals.put(new ANTLRHashString("output_from", this), new Integer(277));
	literals.put(new ANTLRHashString("INERTIAL", this), new Integer(143));
	literals.put(new ANTLRHashString("mode", this), new Integer(116));
	literals.put(new ANTLRHashString("struct", this), new Integer(57));
	literals.put(new ANTLRHashString("select", this), new Integer(182));
	literals.put(new ANTLRHashString("str_sub", this), new Integer(263));
	literals.put(new ANTLRHashString("low_big_endian", this), new Integer(125));
	literals.put(new ANTLRHashString("sum", this), new Integer(223));
	literals.put(new ANTLRHashString("low", this), new Integer(124));
	literals.put(new ANTLRHashString("while", this), new Integer(35));
	literals.put(new ANTLRHashString("read_config", this), new Integer(269));
	literals.put(new ANTLRHashString("is_a_permutation", this), new Integer(202));
	literals.put(new ANTLRHashString("even", this), new Integer(230));
	literals.put(new ANTLRHashString("min_index", this), new Integer(210));
	literals.put(new ANTLRHashString("odd", this), new Integer(229));
	literals.put(new ANTLRHashString("package", this), new Integer(148));
	literals.put(new ANTLRHashString("div_round_up", this), new Integer(234));
	literals.put(new ANTLRHashString("sim", this), new Integer(168));
	literals.put(new ANTLRHashString("str_replace", this), new Integer(260));
	literals.put(new ANTLRHashString("size", this), new Integer(213));
	literals.put(new ANTLRHashString("MAX_UINT", this), new Integer(22));
	literals.put(new ANTLRHashString("min", this), new Integer(209));
	literals.put(new ANTLRHashString("files", this), new Integer(289));
	literals.put(new ANTLRHashString("type", this), new Integer(24));
	literals.put(new ANTLRHashString("bit", this), new Integer(10));
	literals.put(new ANTLRHashString("set_keep", this), new Integer(270));
	literals.put(new ANTLRHashString("lock", this), new Integer(285));
	literals.put(new ANTLRHashString("NULL", this), new Integer(19));
	literals.put(new ANTLRHashString("dec", this), new Integer(247));
	literals.put(new ANTLRHashString("has", this), new Integer(201));
	literals.put(new ANTLRHashString("min_value", this), new Integer(211));
	literals.put(new ANTLRHashString("is_all_iterations", this), new Integer(183));
	literals.put(new ANTLRHashString("alias", this), new Integer(149));
	literals.put(new ANTLRHashString("deep_compare", this), new Integer(242));
	literals.put(new ANTLRHashString("out", this), new Integer(226));
	literals.put(new ANTLRHashString("ERROR", this), new Integer(93));
	literals.put(new ANTLRHashString("is_empty", this), new Integer(203));
	literals.put(new ANTLRHashString("gen", this), new Integer(176));
	literals.put(new ANTLRHashString("key_exists", this), new Integer(225));
}

public Token nextToken() throws TokenStreamException {
	Token theRetToken=null;
tryAgain:
	for (;;) {
		Token _token = null;
		int _ttype = Token.INVALID_TYPE;
		setCommitToPath(false);
		resetText();
		try {   // for char stream error handling
			try {   // for lexical error handling
				switch ( LA(1)) {
				case 'A':  case 'B':  case 'C':  case 'D':
				case 'E':  case 'F':  case 'G':  case 'H':
				case 'I':  case 'J':  case 'K':  case 'L':
				case 'M':  case 'N':  case 'O':  case 'P':
				case 'Q':  case 'R':  case 'S':  case 'T':
				case 'U':  case 'V':  case 'W':  case 'X':
				case 'Y':  case 'Z':  case 'a':  case 'b':
				case 'c':  case 'd':  case 'e':  case 'f':
				case 'g':  case 'h':  case 'i':  case 'j':
				case 'k':  case 'l':  case 'm':  case 'n':
				case 'o':  case 'p':  case 'q':  case 'r':
				case 's':  case 't':  case 'u':  case 'v':
				case 'w':  case 'x':  case 'y':  case 'z':
				{
					mID(true);
					theRetToken=_returnToken;
					break;
				}
				case '\t':
				{
					mTAB(true);
					theRetToken=_returnToken;
					break;
				}
				case ' ':
				{
					mBLANK(true);
					theRetToken=_returnToken;
					break;
				}
				case '\n':  case '\r':
				{
					mNEWLINE(true);
					theRetToken=_returnToken;
					break;
				}
				case '[':
				{
					mLBRACK(true);
					theRetToken=_returnToken;
					break;
				}
				case ']':
				{
					mRBRACK(true);
					theRetToken=_returnToken;
					break;
				}
				case ':':
				{
					mCOLON(true);
					theRetToken=_returnToken;
					break;
				}
				case '(':
				{
					mLPAREN(true);
					theRetToken=_returnToken;
					break;
				}
				case ')':
				{
					mRPAREN(true);
					theRetToken=_returnToken;
					break;
				}
				case '~':
				{
					mTILDE(true);
					theRetToken=_returnToken;
					break;
				}
				case '{':
				{
					mLCURLY(true);
					theRetToken=_returnToken;
					break;
				}
				case '}':
				{
					mRCURLY(true);
					theRetToken=_returnToken;
					break;
				}
				case ';':
				{
					mSEMI(true);
					theRetToken=_returnToken;
					break;
				}
				case ',':
				{
					mCOMMA(true);
					theRetToken=_returnToken;
					break;
				}
				case '+':
				{
					mPLUS(true);
					theRetToken=_returnToken;
					break;
				}
				case '*':
				{
					mSTAR(true);
					theRetToken=_returnToken;
					break;
				}
				case '%':
				{
					mMOD(true);
					theRetToken=_returnToken;
					break;
				}
				case '^':
				{
					mBXOR(true);
					theRetToken=_returnToken;
					break;
				}
				case '?':
				{
					mQUESTION(true);
					theRetToken=_returnToken;
					break;
				}
				case '@':
				{
					mAT(true);
					theRetToken=_returnToken;
					break;
				}
				case '\'':
				{
					mACC(true);
					theRetToken=_returnToken;
					break;
				}
				case '`':
				{
					mACC2(true);
					theRetToken=_returnToken;
					break;
				}
				case '"':
				{
					mSTRING_LITERAL(true);
					theRetToken=_returnToken;
					break;
				}
				case '#':
				{
					mDIRECTIVE(true);
					theRetToken=_returnToken;
					break;
				}
				case '$':
				{
					mSYSTASK(true);
					theRetToken=_returnToken;
					break;
				}
				default:
					if ((LA(1)=='=') && (LA(2)=='=') && (LA(3)=='=')) {
						mEQEQEQ(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='!') && (LA(2)=='=') && (LA(3)=='=')) {
						mNEQEQ(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='.') && (LA(2)=='.')) {
						mSLICE(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='<') && (LA(2)=='<')) {
						mSHL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='>') && (LA(2)=='>')) {
						mSHR(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='<') && (LA(2)=='=')) {
						mLE(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='>') && (LA(2)=='=')) {
						mGE(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='=') && (LA(2)=='=') && (true)) {
						mEQEQ(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='!') && (LA(2)=='=') && (true)) {
						mNEQ(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='!') && (LA(2)=='~')) {
						mNMATCH(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='|') && (LA(2)=='|')) {
						mLOR(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='&') && (LA(2)=='&')) {
						mLAND(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='=') && (LA(2)=='>')) {
						mSPD1(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='0') && (LA(2)=='B'||LA(2)=='b')) {
						mB_INT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='0') && (LA(2)=='O'||LA(2)=='o')) {
						mO_INT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='0') && (_tokenSet_0.member(LA(2)))) {
						mH_INT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='0') && (LA(2)=='C'||LA(2)=='c')) {
						mCHAR_LITERAL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='-'||LA(1)=='/') && (LA(2)=='-'||LA(2)=='/')) {
						mSL_COMMENT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='/') && (LA(2)=='*')) {
						mMLC_OPEN(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='.') && (true)) {
						mDOT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='!') && (true)) {
						mEXCL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='-') && (true)) {
						mMINUS(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='/') && (true)) {
						mDIV(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='>') && (true)) {
						mGT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='<') && (true)) {
						mLT(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='|') && (true)) {
						mBOR(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='&') && (true)) {
						mBAND(true);
						theRetToken=_returnToken;
					}
					else if (((LA(1) >= '0' && LA(1) <= '9')) && (true)) {
						mD_INT_OR_SIZED(true);
						theRetToken=_returnToken;
					}
				else {
					if (LA(1)==EOF_CHAR) {uponEOF(); _returnToken = makeToken(Token.EOF_TYPE);}
				else {consume(); continue tryAgain;}
				}
				}
				if ( _returnToken==null ) continue tryAgain; // found SKIP token
				_ttype = _returnToken.getType();
				_returnToken.setType(_ttype);
				return _returnToken;
			}
			catch (RecognitionException e) {
				if ( !getCommitToPath() ) {consume(); continue tryAgain;}
				throw new TokenStreamRecognitionException(e);
			}
		}
		catch (CharStreamException cse) {
			if ( cse instanceof CharStreamIOException ) {
				throw new TokenStreamIOException(((CharStreamIOException)cse).io);
			}
			else {
				throw new TokenStreamException(cse.getMessage());
			}
		}
	}
}

	public final void mID(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ID;
		int _saveIndex;
		
		{
		switch ( LA(1)) {
		case 'a':  case 'b':  case 'c':  case 'd':
		case 'e':  case 'f':  case 'g':  case 'h':
		case 'i':  case 'j':  case 'k':  case 'l':
		case 'm':  case 'n':  case 'o':  case 'p':
		case 'q':  case 'r':  case 's':  case 't':
		case 'u':  case 'v':  case 'w':  case 'x':
		case 'y':  case 'z':
		{
			matchRange('a','z');
			break;
		}
		case 'A':  case 'B':  case 'C':  case 'D':
		case 'E':  case 'F':  case 'G':  case 'H':
		case 'I':  case 'J':  case 'K':  case 'L':
		case 'M':  case 'N':  case 'O':  case 'P':
		case 'Q':  case 'R':  case 'S':  case 'T':
		case 'U':  case 'V':  case 'W':  case 'X':
		case 'Y':  case 'Z':
		{
			matchRange('A','Z');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		{
		_loop718:
		do {
			switch ( LA(1)) {
			case 'a':  case 'b':  case 'c':  case 'd':
			case 'e':  case 'f':  case 'g':  case 'h':
			case 'i':  case 'j':  case 'k':  case 'l':
			case 'm':  case 'n':  case 'o':  case 'p':
			case 'q':  case 'r':  case 's':  case 't':
			case 'u':  case 'v':  case 'w':  case 'x':
			case 'y':  case 'z':
			{
				matchRange('a','z');
				break;
			}
			case 'A':  case 'B':  case 'C':  case 'D':
			case 'E':  case 'F':  case 'G':  case 'H':
			case 'I':  case 'J':  case 'K':  case 'L':
			case 'M':  case 'N':  case 'O':  case 'P':
			case 'Q':  case 'R':  case 'S':  case 'T':
			case 'U':  case 'V':  case 'W':  case 'X':
			case 'Y':  case 'Z':
			{
				matchRange('A','Z');
				break;
			}
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			case '8':  case '9':
			{
				matchRange('0','9');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop718;
			}
			}
		} while (true);
		}
		_ttype = testLiteralsTable(_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mTAB(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = TAB;
		int _saveIndex;
		
		match('\t');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBLANK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BLANK;
		int _saveIndex;
		
		match(' ');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNEWLINE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NEWLINE;
		int _saveIndex;
		
		{
		if ((LA(1)=='\r') && (LA(2)=='\n')) {
			match("\r\n");
		}
		else if ((LA(1)=='\r') && (true)) {
			match('\r');
		}
		else if ((LA(1)=='\n')) {
			match('\n');
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		if ( inputState.guessing==0 ) {
			newline();
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLBRACK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LBRACK;
		int _saveIndex;
		
		match('[');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mRBRACK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = RBRACK;
		int _saveIndex;
		
		match(']');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mDOT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DOT;
		int _saveIndex;
		
		match('.');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSLICE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SLICE;
		int _saveIndex;
		
		match("..");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mCOLON(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COLON;
		int _saveIndex;
		
		match(':');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLPAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LPAREN;
		int _saveIndex;
		
		match('(');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mRPAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = RPAREN;
		int _saveIndex;
		
		match(')');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mTILDE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = TILDE;
		int _saveIndex;
		
		match('~');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mEXCL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = EXCL;
		int _saveIndex;
		
		match('!');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLCURLY(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LCURLY;
		int _saveIndex;
		
		match('{');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mRCURLY(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = RCURLY;
		int _saveIndex;
		
		match('}');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSEMI(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SEMI;
		int _saveIndex;
		
		match(';');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mCOMMA(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COMMA;
		int _saveIndex;
		
		match(',');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mPLUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = PLUS;
		int _saveIndex;
		
		match('+');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mMINUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = MINUS;
		int _saveIndex;
		
		match('-');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSTAR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = STAR;
		int _saveIndex;
		
		match('*');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mDIV(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DIV;
		int _saveIndex;
		
		match('/');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mMOD(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = MOD;
		int _saveIndex;
		
		match('%');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSHL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SHL;
		int _saveIndex;
		
		match("<<");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSHR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SHR;
		int _saveIndex;
		
		match(">>");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mGT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = GT;
		int _saveIndex;
		
		match(">");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LT;
		int _saveIndex;
		
		match("<");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LE;
		int _saveIndex;
		
		match("<=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mGE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = GE;
		int _saveIndex;
		
		match(">=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mEQEQ(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = EQEQ;
		int _saveIndex;
		
		match("==");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNEQ(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NEQ;
		int _saveIndex;
		
		match("!=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mEQEQEQ(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = EQEQEQ;
		int _saveIndex;
		
		match("===");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNEQEQ(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NEQEQ;
		int _saveIndex;
		
		match("!==");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNMATCH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NMATCH;
		int _saveIndex;
		
		match("!~");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBXOR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BXOR;
		int _saveIndex;
		
		match('^');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBOR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BOR;
		int _saveIndex;
		
		match('|');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBAND(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BAND;
		int _saveIndex;
		
		match('&');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLOR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LOR;
		int _saveIndex;
		
		match("||");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLAND(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LAND;
		int _saveIndex;
		
		match("&&");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSPD1(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SPD1;
		int _saveIndex;
		
		match("=>");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mQUESTION(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = QUESTION;
		int _saveIndex;
		
		match('?');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mAT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = AT;
		int _saveIndex;
		
		match('@');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mACC(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ACC;
		int _saveIndex;
		
		match('\'');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mACC2(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ACC2;
		int _saveIndex;
		
		match('`');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mESC(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ESC;
		int _saveIndex;
		
		match('\\');
		{
		switch ( LA(1)) {
		case 'n':
		{
			match('n');
			break;
		}
		case 'r':
		{
			match('r');
			break;
		}
		case 't':
		{
			match('t');
			break;
		}
		case 'f':
		{
			match('f');
			break;
		}
		case '"':
		{
			match('"');
			break;
		}
		case '\\':
		{
			match('\\');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSTRING_LITERAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = STRING_LITERAL;
		int _saveIndex;
		
		match('"');
		{
		_loop767:
		do {
			if ((LA(1)=='\\')) {
				mESC(false);
			}
			else if ((_tokenSet_1.member(LA(1)))) {
				{
				match(_tokenSet_1);
				}
			}
			else {
				break _loop767;
			}
			
		} while (true);
		}
		match('"');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mDEC(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DEC;
		int _saveIndex;
		
		{
		matchRange('0','9');
		}
		{
		_loop771:
		do {
			switch ( LA(1)) {
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			case '8':  case '9':
			{
				matchRange('0','9');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop771;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mBIN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BIN;
		int _saveIndex;
		
		{
		matchRange('0','1');
		}
		{
		_loop775:
		do {
			switch ( LA(1)) {
			case '0':  case '1':
			{
				matchRange('0','1');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop775;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mOCT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = OCT;
		int _saveIndex;
		
		{
		matchRange('0','7');
		}
		{
		_loop779:
		do {
			switch ( LA(1)) {
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			{
				matchRange('0','7');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop779;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mHEX(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = HEX;
		int _saveIndex;
		
		{
		switch ( LA(1)) {
		case '0':  case '1':  case '2':  case '3':
		case '4':  case '5':  case '6':  case '7':
		case '8':  case '9':
		{
			matchRange('0','9');
			break;
		}
		case 'a':  case 'b':  case 'c':  case 'd':
		case 'e':  case 'f':
		{
			matchRange('a','f');
			break;
		}
		case 'A':  case 'B':  case 'C':  case 'D':
		case 'E':  case 'F':
		{
			matchRange('A','F');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		{
		_loop783:
		do {
			switch ( LA(1)) {
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			case '8':  case '9':
			{
				matchRange('0','9');
				break;
			}
			case 'a':  case 'b':  case 'c':  case 'd':
			case 'e':  case 'f':
			{
				matchRange('a','f');
				break;
			}
			case 'A':  case 'B':  case 'C':  case 'D':
			case 'E':  case 'F':
			{
				matchRange('A','F');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop783;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mD_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = D_INT;
		int _saveIndex;
		
		mDEC(false);
		{
		switch ( LA(1)) {
		case 'K':
		{
			match('K');
			break;
		}
		case 'M':
		{
			match('M');
			break;
		}
		default:
			{
			}
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mB_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = B_INT;
		int _saveIndex;
		
		{
		if ((LA(1)=='0') && (LA(2)=='b')) {
			match("0b");
		}
		else if ((LA(1)=='0') && (LA(2)=='B')) {
			match("0B");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mBIN(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mO_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = O_INT;
		int _saveIndex;
		
		{
		if ((LA(1)=='0') && (LA(2)=='o')) {
			match("0o");
		}
		else if ((LA(1)=='0') && (LA(2)=='O')) {
			match("0O");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mOCT(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mH_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = H_INT;
		int _saveIndex;
		
		{
		if ((LA(1)=='0') && (LA(2)=='h')) {
			match("0h");
		}
		else if ((LA(1)=='0') && (LA(2)=='H')) {
			match("0H");
		}
		else if ((LA(1)=='0') && (LA(2)=='x')) {
			match("0x");
		}
		else if ((LA(1)=='0') && (LA(2)=='X')) {
			match("0X");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mHEX(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mSIZED_D_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SIZED_D_INT;
		int _saveIndex;
		
		{
		int _cnt794=0;
		_loop794:
		do {
			if (((LA(1) >= '0' && LA(1) <= '9'))) {
				matchRange('0','9');
			}
			else {
				if ( _cnt794>=1 ) { break _loop794; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt794++;
		} while (true);
		}
		{
		if ((LA(1)=='\'') && (LA(2)=='d')) {
			match("'d");
		}
		else if ((LA(1)=='\'') && (LA(2)=='D')) {
			match("'D");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mDEC(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mSIZED_B_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SIZED_B_INT;
		int _saveIndex;
		
		{
		int _cnt798=0;
		_loop798:
		do {
			if (((LA(1) >= '0' && LA(1) <= '9'))) {
				matchRange('0','9');
			}
			else {
				if ( _cnt798>=1 ) { break _loop798; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt798++;
		} while (true);
		}
		{
		if ((LA(1)=='\'') && (LA(2)=='b')) {
			match("'b");
		}
		else if ((LA(1)=='\'') && (LA(2)=='B')) {
			match("'B");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mBIN(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mSIZED_O_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SIZED_O_INT;
		int _saveIndex;
		
		{
		int _cnt802=0;
		_loop802:
		do {
			if (((LA(1) >= '0' && LA(1) <= '9'))) {
				matchRange('0','9');
			}
			else {
				if ( _cnt802>=1 ) { break _loop802; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt802++;
		} while (true);
		}
		{
		if ((LA(1)=='\'') && (LA(2)=='o')) {
			match("'o");
		}
		else if ((LA(1)=='\'') && (LA(2)=='O')) {
			match("'O");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mOCT(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mSIZED_H_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SIZED_H_INT;
		int _saveIndex;
		
		{
		int _cnt806=0;
		_loop806:
		do {
			if (((LA(1) >= '0' && LA(1) <= '9'))) {
				matchRange('0','9');
			}
			else {
				if ( _cnt806>=1 ) { break _loop806; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt806++;
		} while (true);
		}
		{
		if ((LA(1)=='\'') && (LA(2)=='h')) {
			match("'h");
		}
		else if ((LA(1)=='\'') && (LA(2)=='H')) {
			match("'H");
		}
		else if ((LA(1)=='\'') && (LA(2)=='x')) {
			match("'x");
		}
		else if ((LA(1)=='\'') && (LA(2)=='X')) {
			match("'X");
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		}
		mHEX(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mD_INT_OR_SIZED(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = D_INT_OR_SIZED;
		int _saveIndex;
		
		boolean synPredMatched813 = false;
		if ((((LA(1) >= '0' && LA(1) <= '9')) && (_tokenSet_2.member(LA(2))) && (_tokenSet_3.member(LA(3))))) {
			int _m813 = mark();
			synPredMatched813 = true;
			inputState.guessing++;
			try {
				{
				{
				int _cnt811=0;
				_loop811:
				do {
					if (((LA(1) >= '0' && LA(1) <= '9'))) {
						matchRange('0','9');
					}
					else {
						if ( _cnt811>=1 ) { break _loop811; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
					}
					
					_cnt811++;
				} while (true);
				}
				{
				if ((LA(1)=='\'') && (LA(2)=='d')) {
					match("'d");
				}
				else if ((LA(1)=='\'') && (LA(2)=='D')) {
					match("'D");
				}
				else {
					throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
				}
				
				}
				}
			}
			catch (RecognitionException pe) {
				synPredMatched813 = false;
			}
			rewind(_m813);
			inputState.guessing--;
		}
		if ( synPredMatched813 ) {
			mSIZED_D_INT(false);
		}
		else {
			boolean synPredMatched818 = false;
			if ((((LA(1) >= '0' && LA(1) <= '9')) && (_tokenSet_2.member(LA(2))) && (_tokenSet_4.member(LA(3))))) {
				int _m818 = mark();
				synPredMatched818 = true;
				inputState.guessing++;
				try {
					{
					{
					int _cnt816=0;
					_loop816:
					do {
						if (((LA(1) >= '0' && LA(1) <= '9'))) {
							matchRange('0','9');
						}
						else {
							if ( _cnt816>=1 ) { break _loop816; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
						}
						
						_cnt816++;
					} while (true);
					}
					{
					if ((LA(1)=='\'') && (LA(2)=='b')) {
						match("'b");
					}
					else if ((LA(1)=='\'') && (LA(2)=='B')) {
						match("'B");
					}
					else {
						throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
					}
					
					}
					}
				}
				catch (RecognitionException pe) {
					synPredMatched818 = false;
				}
				rewind(_m818);
				inputState.guessing--;
			}
			if ( synPredMatched818 ) {
				mSIZED_B_INT(false);
			}
			else {
				boolean synPredMatched823 = false;
				if ((((LA(1) >= '0' && LA(1) <= '9')) && (_tokenSet_2.member(LA(2))) && (_tokenSet_5.member(LA(3))))) {
					int _m823 = mark();
					synPredMatched823 = true;
					inputState.guessing++;
					try {
						{
						{
						int _cnt821=0;
						_loop821:
						do {
							if (((LA(1) >= '0' && LA(1) <= '9'))) {
								matchRange('0','9');
							}
							else {
								if ( _cnt821>=1 ) { break _loop821; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
							}
							
							_cnt821++;
						} while (true);
						}
						{
						if ((LA(1)=='\'') && (LA(2)=='h')) {
							match("'h");
						}
						else if ((LA(1)=='\'') && (LA(2)=='H')) {
							match("'H");
						}
						else {
							throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
						}
						
						}
						}
					}
					catch (RecognitionException pe) {
						synPredMatched823 = false;
					}
					rewind(_m823);
					inputState.guessing--;
				}
				if ( synPredMatched823 ) {
					mSIZED_H_INT(false);
				}
				else {
					boolean synPredMatched828 = false;
					if ((((LA(1) >= '0' && LA(1) <= '9')) && (_tokenSet_2.member(LA(2))) && (_tokenSet_6.member(LA(3))))) {
						int _m828 = mark();
						synPredMatched828 = true;
						inputState.guessing++;
						try {
							{
							{
							int _cnt826=0;
							_loop826:
							do {
								if (((LA(1) >= '0' && LA(1) <= '9'))) {
									matchRange('0','9');
								}
								else {
									if ( _cnt826>=1 ) { break _loop826; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
								}
								
								_cnt826++;
							} while (true);
							}
							{
							if ((LA(1)=='\'') && (LA(2)=='o')) {
								match("'o");
							}
							else if ((LA(1)=='\'') && (LA(2)=='O')) {
								match("'O");
							}
							else {
								throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
							}
							
							}
							}
						}
						catch (RecognitionException pe) {
							synPredMatched828 = false;
						}
						rewind(_m828);
						inputState.guessing--;
					}
					if ( synPredMatched828 ) {
						mSIZED_O_INT(false);
					}
					else if (((LA(1) >= '0' && LA(1) <= '9')) && (true) && (true)) {
						mD_INT(false);
					}
					else {
						throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
					}
					}}}
					if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
						_token = makeToken(_ttype);
						_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
					}
					_returnToken = _token;
				}
				
	public final void mCHAR_LITERAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = CHAR_LITERAL;
		int _saveIndex;
		
		match('0');
		{
		switch ( LA(1)) {
		case 'c':
		{
			match('c');
			break;
		}
		case 'C':
		{
			match('C');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		match("\"");
		matchNot(EOF_CHAR);
		match("\"");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSL_COMMENT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SL_COMMENT;
		int _saveIndex;
		
		switch ( LA(1)) {
		case '/':
		{
			{
			match("//");
			{
			_loop835:
			do {
				if ((_tokenSet_7.member(LA(1)))) {
					{
					match(_tokenSet_7);
					}
				}
				else {
					break _loop835;
				}
				
			} while (true);
			}
			}
			break;
		}
		case '-':
		{
			{
			match("--");
			{
			_loop839:
			do {
				if ((_tokenSet_7.member(LA(1)))) {
					{
					match(_tokenSet_7);
					}
				}
				else {
					break _loop839;
				}
				
			} while (true);
			}
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mDIRECTIVE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DIRECTIVE;
		int _saveIndex;
		
		match('#');
		{
		boolean synPredMatched845 = false;
		if (((LA(1)=='i') && (LA(2)=='f') && (LA(3)=='d'))) {
			int _m845 = mark();
			synPredMatched845 = true;
			inputState.guessing++;
			try {
				{
				match("ifdef");
				}
			}
			catch (RecognitionException pe) {
				synPredMatched845 = false;
			}
			rewind(_m845);
			inputState.guessing--;
		}
		if ( synPredMatched845 ) {
			match("ifdef");
		}
		else {
			boolean synPredMatched847 = false;
			if (((LA(1)=='i') && (LA(2)=='f') && (LA(3)=='n'))) {
				int _m847 = mark();
				synPredMatched847 = true;
				inputState.guessing++;
				try {
					{
					match("ifndef");
					}
				}
				catch (RecognitionException pe) {
					synPredMatched847 = false;
				}
				rewind(_m847);
				inputState.guessing--;
			}
			if ( synPredMatched847 ) {
				match("ifndef");
			}
			else {
				boolean synPredMatched843 = false;
				if (((LA(1)=='d'))) {
					int _m843 = mark();
					synPredMatched843 = true;
					inputState.guessing++;
					try {
						{
						match("define");
						}
					}
					catch (RecognitionException pe) {
						synPredMatched843 = false;
					}
					rewind(_m843);
					inputState.guessing--;
				}
				if ( synPredMatched843 ) {
					match("define");
				}
				else {
					throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
				}
				}}
				}
				if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
					_token = makeToken(_ttype);
					_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
				}
				_returnToken = _token;
			}
			
	public final void mSYSTASK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SYSTASK;
		int _saveIndex;
		
		match('$');
		{
		switch ( LA(1)) {
		case 'a':  case 'b':  case 'c':  case 'd':
		case 'e':  case 'f':  case 'g':  case 'h':
		case 'i':  case 'j':  case 'k':  case 'l':
		case 'm':  case 'n':  case 'o':  case 'p':
		case 'q':  case 'r':  case 's':  case 't':
		case 'u':  case 'v':  case 'w':  case 'x':
		case 'y':  case 'z':
		{
			matchRange('a','z');
			break;
		}
		case 'A':  case 'B':  case 'C':  case 'D':
		case 'E':  case 'F':  case 'G':  case 'H':
		case 'I':  case 'J':  case 'K':  case 'L':
		case 'M':  case 'N':  case 'O':  case 'P':
		case 'Q':  case 'R':  case 'S':  case 'T':
		case 'U':  case 'V':  case 'W':  case 'X':
		case 'Y':  case 'Z':
		{
			matchRange('A','Z');
			break;
		}
		case '_':
		{
			match('_');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		{
		_loop851:
		do {
			switch ( LA(1)) {
			case 'a':  case 'b':  case 'c':  case 'd':
			case 'e':  case 'f':  case 'g':  case 'h':
			case 'i':  case 'j':  case 'k':  case 'l':
			case 'm':  case 'n':  case 'o':  case 'p':
			case 'q':  case 'r':  case 's':  case 't':
			case 'u':  case 'v':  case 'w':  case 'x':
			case 'y':  case 'z':
			{
				matchRange('a','z');
				break;
			}
			case 'A':  case 'B':  case 'C':  case 'D':
			case 'E':  case 'F':  case 'G':  case 'H':
			case 'I':  case 'J':  case 'K':  case 'L':
			case 'M':  case 'N':  case 'O':  case 'P':
			case 'Q':  case 'R':  case 'S':  case 'T':
			case 'U':  case 'V':  case 'W':  case 'X':
			case 'Y':  case 'Z':
			{
				matchRange('A','Z');
				break;
			}
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			case '8':  case '9':
			{
				matchRange('0','9');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop851;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mMLC_OPEN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = MLC_OPEN;
		int _saveIndex;
		
		match("/*");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 0L, 72058693566333184L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = new long[8];
		data[0]=-17179869192L;
		data[1]=-268435457L;
		for (int i = 2; i<=3; i++) { data[i]=-1L; }
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 287949450930814976L, 0L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 287949450930814976L, 68719476752L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 287949450930814976L, 17179869188L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 287949450930814976L, 72058693566333184L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 287949450930814976L, 140737488388096L, 0L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = new long[8];
		data[0]=-9224L;
		for (int i = 1; i<=3; i++) { data[i]=-1L; }
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	
	}
