using System;
using System.Windows.Forms;
using System.Reflection;
using System.Collections;

using DDW.CSharp;
using DDW.CSharp.Dom;

namespace DDW.CSharpUI
{
	/// <summary>
	/// Summary description for IGraphNode.
	/// </summary>
	public class IGraphNode : TreeNode
	{
		private IGraph graph;
		private Type type;
		private static Hashtable iconIndex;

		public IGraphNode(IGraph ig)
		{
			graph = ig;
			type = graph.GetType();

			object o = IconIndex[type];
			int x = (int)o;
			ImageIndex = (int)IconIndex[type];
			// special icon cases
			if(graph is AccessorDecl)
			{
				AccessorModifiers am = ((AccessorDecl)graph).AccessorModifier;
				if(am == AccessorModifiers.Set || am == AccessorModifiers.Add) 
					ImageIndex = (int)CodeIcon.AccessorIn;
			}
			SelectedImageIndex = ImageIndex;

			if(graph is ICollection)
			{
				ICollection col = (ICollection)graph;
				int cnt = col.Count;
				foreach(object gr in col)
				{
					if(gr is IGraph)
					{
						IGraphNode ign = new IGraphNode((IGraph)gr);
						Nodes.Add(ign);
					}
				}
			}
			else
			{
				this.Text = graph.Text; //	graph.GetType().Name + ": "+
			}
			GetChildren();
		}

		private void GetChildren()
		{
			// don't get children for the following : typeref, primaryExpr...
			if(	graph is DDW.CSharp.Dom.TypeRef			||
				graph is DDW.CSharp.Dom.PrimitiveExpr	||
				graph is DDW.CSharp.Dom.UnknownReference||
				graph is DDW.CSharp.Dom.ArgumentRef		||
				graph is DDW.CSharp.Dom.LocalRef
				) return;
			else if(graph is DDW.CSharp.Dom.PrimitiveExpr) return;

			MemberInfo[] props = type.FindMembers(MemberTypes.Property,
				BindingFlags.Public | BindingFlags.Instance,
				new MemberFilter(MemberFilter),
				null);
			for(int i = 0; i < props.Length; i++)
			{
				object result = type.InvokeMember(
					props[i].Name, 
					BindingFlags.Public  | 
						BindingFlags.GetProperty | 
						BindingFlags.Instance, 
					null, 
					graph, 
					new object[]{} );

				// ignore the following
				if(	result == null			|| 
					result is LinePragma	||
					(props[i].Name == "DimensionCount" && (int)result == 0)
					) continue;

				if(result is IGraph)
				{
					if(result is ICollection)
					{	
						if( ((ICollection)result).Count == 0) continue;
						IGraphNode node = new IGraphNode((IGraph)result);
						node.Text = props[i].Name;
						Nodes.Add(node);
					}
					else
					{
						IGraphNode node = new IGraphNode((IGraph)result);
						Nodes.Add(node);
					}
				}
				else if(result != null)
				{
					bool addToTree = true;
					// literals etc.
					TreeNode node = 
						new TreeNode(props[i].Name +" : "+result.ToString());
					if(result is string)
					{
						node.ImageIndex = (int)CodeIcon.String;
						if( (string)result == "") addToTree = false; 
					}
					else if(result is int || result is long)
						node.ImageIndex = (int)CodeIcon.Integer;
					else if(result is float)
						node.ImageIndex = (int)CodeIcon.Real;
					else if(result is bool)
						node.ImageIndex = (int)CodeIcon.Bool;
					else if(result is Enum)
					{
						node.ImageIndex = (int)CodeIcon.EnumRef;
						if( Enum.GetName(result.GetType(), result) == "Empty")
							addToTree = false; 
					}

					node.SelectedImageIndex = node.ImageIndex;
					if(addToTree) Nodes.Insert(0,node);
				}
			}				
		}

		public IGraph Graph
		{
			get
			{
				return graph;
			}
		}
		public static bool MemberFilter(MemberInfo objMemberInfo, Object objSearch)
		{			
			if(objMemberInfo.Name == "LinePragma") return false;
			object[] oa = objMemberInfo.GetCustomAttributes(
				CSharpGraph.GetTypeFromString("DDW.CSharp.Dom.CodeElementAttribute"), true);
			if(oa.Length > 0)
			{
				return true;
			}
			return false;
		}

		private static Hashtable IconIndex
		{
			get
			{
				if(iconIndex != null) return iconIndex;
				iconIndex = new Hashtable(125);

				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.AccessorDecl"),			CodeIcon.AccessorOut );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ArgumentRef"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ArrayCreateExpr"),		CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ArrayElementRef"),		CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ArrayInitializer"),		CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.AssignExpr"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.AttachDelegateStmt"),	CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.BaseRef"),				CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.BinaryExpr"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.BooleanLiteral"),		CodeIcon.Bool );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.BreakStmt"),			CodeIcon.Break );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Case"),					CodeIcon.Case );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CaseCollection"),		CodeIcon.CaseCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CastExpr"),				CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Catch"),				CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CatchCollection"),		CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CharLiteral"),			CodeIcon.Char );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CheckedStmt"),			CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ClassDecl"),			CodeIcon.Class );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CodeCollectionAttribute"),CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CodeElementAttribute"),	CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Comment"),				CodeIcon.Comment );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CommentStmt"),			CodeIcon.Comment );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CommentStmtCollection"),CodeIcon.CommentCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CompileUnit"),			CodeIcon.CompileUnit );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CompileUnitCollection"),CodeIcon.CompileUnitCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ConstantDecl"),			CodeIcon.Constant );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ConstantDeclStmt"),		CodeIcon.Constant );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ConstructorDecl"),		CodeIcon.Constructor );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ContinueStmt"),			CodeIcon.Continue );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CreateDelegateExpr"),	CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CSharpGraph"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CustomAttribute"),		CodeIcon.Attribute );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.CustomAttributeCollection"),CodeIcon.Attributes );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.DelegateDecl"),			CodeIcon.Delegate );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.DestructorDecl"),		CodeIcon.Destructor );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.EnumDecl"),				CodeIcon.Enum );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.EnumMemberDecl"),		CodeIcon.EnumMember );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.EventDecl"),			CodeIcon.Event );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.EventRef"),				CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Expression"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ExpressionCollection"),	CodeIcon.ExprColl );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ExprStmt"),				CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.FieldDecl"),			CodeIcon.Field );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.FieldRef"),				CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ForEachStmt"),			CodeIcon.ForEach );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.GotoStmt"),				CodeIcon.Goto );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.IfStmt"),				CodeIcon.IfStmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Import"),				CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ImportCollection"),		CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.IndexerDecl"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.IndexerRef"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.IntegerLiteral"),		CodeIcon.Integer );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.InterfaceDecl"),		CodeIcon.Interface );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.DelegateInvokeExpr"),	CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.IterationStmt"),		CodeIcon.Iteration );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.LabeledStmt"),			CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.LinePragma"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.LocalRef"),				CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.LockStmt"),				CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MemberAccess"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MemberDecl"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MemberDeclCollection"),	CodeIcon.MemberCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MethodDecl"),			CodeIcon.Method );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MethodInvokeExpr"),		CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.MethodRef"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.NamespaceDecl"),		CodeIcon.Namespace );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.NamespaceDeclCollection"), CodeIcon.NamespaceCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.NullLiteral"),			CodeIcon.Null );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ObjectCreateExpr"),		CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.OperatorDecl"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ParamDecl"),			CodeIcon.Param );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ParamDeclCollection"),	CodeIcon.ParamCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Param"),				CodeIcon.Param );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ParamCollection"),		CodeIcon.ParamCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ParamDirection"),		CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.PostfixExpr"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.PrimitiveExpr"),		CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.PropertyDecl"),			CodeIcon.Property );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.PropertyRef"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.PropertySetValueRef"),	CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.RealLiteral"),			CodeIcon.Real );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.RemoveDelegateStmt"),	CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ReturnStmt"),			CodeIcon.Return );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Statement"),			CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.StatementCollection"),	CodeIcon.StmtColl );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.StringLiteral"),		CodeIcon.String );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.StructDecl"),			CodeIcon.Struct );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.SwitchStmt"),			CodeIcon.Switch );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ThisRef"),				CodeIcon.This );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.ThrowStmt"),			CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TryCatchFinallyStmt"),	CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TypeDecl"),				CodeIcon.TypeDecl );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TypeDeclCollection"),	CodeIcon.TypeDeclCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TypeOfExpr"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TypeRef"),				CodeIcon.TypeDecl );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TypeRefCollection"),	CodeIcon.TypeDeclCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.UnaryExpr"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.UncheckedStmt"),		CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.UnknownReference"),		CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.UsingStmt"),			CodeIcon.Stmt );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Reference"),			CodeIcon.Expr );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.VariableDecl"),			CodeIcon.Default );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.VariableDeclStmt"),		CodeIcon.Stmt );

				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.BuiltInType"),			CodeIcon.TypeDecl );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.Declarator"),			CodeIcon.Declarator );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.DeclaratorCollection"),	CodeIcon.DeclaratorCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.TernaryExpr"),			CodeIcon.Ternary );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.RankSpecifier"),		CodeIcon.RankSpecifier );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.RankSpecifierCollection"),	CodeIcon.RankCol );
				iconIndex.Add(CSharpGraph.GetTypeFromString(
					"DDW.CSharp.Dom.SubExpr"),				CodeIcon.SubExpr );

				return iconIndex;
			}
		}

	}
}
