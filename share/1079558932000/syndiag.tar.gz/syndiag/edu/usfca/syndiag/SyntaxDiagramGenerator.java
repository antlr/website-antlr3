package edu.usfca.syndiag;

import java.awt.*;
import javax.swing.*;

public interface SyntaxDiagramGenerator{
	public void drawArrow(int x1, int y1, int x2, int y2);
	public void drawDFConnLine(int x1, int y1, int x2, int y2);
	public void drawFUConnLine(int x1, int y1, int x2, int y2);
	public void drawDBConnLine(int x1, int y1, int x2, int y2);
	public void drawBUConnLine(int x1, int y1, int x2, int y2);
	public void drawBackConnLine(int x1, int y1, int x2, int y2, int h);
	public void drawForwardConnLine(int x1, int y1, int x2, int y2, int h);
	public void drawDotRect(int x, int y, int w, int h);
	public void drawLeftRangeRect(int x, int y, int w, int h);
	public void drawRightRangeRect(int x, int y, int w, int h);
	public void drawText(String str, Font f, int x, int y);
	public void drawRule(int x1, int y1, int x2, int y2, int w, int s);
	public void drawBlock(int[] connPoint1, int[] connPoint2, int[] leftConnPoint, int[] rightConnPoint, int i);
	public void drawOptional(int[] connPoint1, int[] connPoint2, int h);
	public void drawClosure(int[] connPoint1, int[] connPoint2, int h);
	public void drawPClosure(int[] connPoint1, int[] connPoint2, int h);
	public void drawRuleRef(int x, int y, int w, int h, String str, Font f);
	public void drawNot(int x, int y, int w, int h, String str, Font f);
	public void drawRange(int x, int y, int w, int h, String str, int pos);
	public void drawTokenRef(int x, int y, int w, int h, String str, Font f);
	public void drawL(int x, int y, int w, int h, String str, Font f);
}
