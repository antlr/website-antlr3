package org.antlr.java.crossref;
 

import java.io.IOException;
import java.util.*;

/** Scope representing a package
 */
public class PackageScope extends Scope {
	/**
	 * Field packages
	 */
	protected Hashtable packages = new Hashtable();
	/**
	 * Field classes
	 */
	protected Hashtable classes = new Hashtable(53);

	/**
	 * Constructor for PackageScope
	 * @param project CodeProject
	 * @param name String
	 * @param parent Scope
	 */
	public PackageScope(CodeProject project, String name, Scope parent) {
		super(project,name,parent);
		if ( parent!=null ) {
			parent.addScope(this); // double-link; parent knows subpackages
		}
	}

	/**
	 * Method resolveClass
	 * @param name String
	 * @return ClassScope
	 */
	public ClassScope resolveClass(String name) {
		if ( name==null ) {
			return null;
		}
		return (ClassScope)classes.get(name);
	}

	/**
	 * Method addScope
	 * @param s Scope
	 */
	public void addScope(Scope s) {
		if ( s==null ) {
			return;
		}

		// System.out.println("PackageScope:addScope " + "Add scope in PackageScope "+s);

		// can add either a package or class
		if ( s instanceof PackageScope ) {
			packages.put(s.getName(), s);
		}
		else if ( s instanceof ClassScope ) {
			project.setClassScope(s.getFullyQualifiedName(), (ClassScope)s);
			classes.put(s.getName(), s);
		}
	}

	/**
	 * Method getPackageScope
	 * @param name String
	 * @return PackageScope
	 */
	public PackageScope getPackageScope(String name) {
		return (PackageScope)packages.get(name);
	}

	// GETTER/SETTERS

	/**
	 * Method getPackages
	 * @return Hashtable
	 */
	public Hashtable getPackages() {
		return packages;
	}

	/**
	 * Method setPackages
	 * @param subpackages Hashtable
	 */
	public void setPackages(Hashtable subpackages) {
		this.packages = subpackages;
	}

	/**
	 * Method getClasses
	 * @return Hashtable
	 */
	public Hashtable getClasses() {
		return classes;
	}

	/**
	 * Method setClasses
	 * @param classes Hashtable
	 */
	public void setClasses(Hashtable classes) {
		this.classes = classes;
	}

	/**
	 * Method dump
	 */
	public void dump() {
		tab();
		System.out.println("PackageScope:dump " + "-"+getName());
		tabIndent++;
		Enumeration keys = packages.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			PackageScope ps = (PackageScope)packages.get(name);
			ps.dump();
		}
		keys = classes.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			ClassScope cs = (ClassScope)classes.get(name);
			cs.dump();
		}
		tabIndent--;
	}

	/**
	 * Method toString
	 * @return String
	 */
	public String toString() {
		StringBuffer s = new StringBuffer();
		s.append("Package ");
		s.append(getFullyQualifiedName());
		s.append("\n");
		// System.out.println("package: "+packages);
		// System.out.println("classes: "+classes);
		Enumeration keys = packages.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			PackageScope ps = (PackageScope)packages.get(name);
			s.append(ps);
		}
		keys = classes.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			ClassScope cs = (ClassScope)classes.get(name);
			s.append(cs);
			s.append("\n");
		}
		return s.toString();
	}

	/**
	 * @param xmlWriter
	 */
	public void xmlSerialize(XmlWriter xmlWriter) 
	{
	try {
		xmlWriter.xmlOpen("PackageScope name=\"" + getName()+ "\"");
		if(loc != null)
			loc.xmlSerialize(xmlWriter);
		Hashtable packages = getPackages();
		if (packages != null)
		{
			Enumeration keys = packages.keys();
			while (keys.hasMoreElements()) 
			{
				String name = (String)keys.nextElement();
				PackageScope ps = (PackageScope)packages.get(name);
				ps.xmlSerialize(xmlWriter);
			}
		}
		Hashtable classes = getClasses();
		if(classes != null)
		{
			Enumeration keys = classes.keys();
			while (keys.hasMoreElements()) 
			{
				String name = (String)keys.nextElement();
				ClassScope cs = (ClassScope)classes.get(name);
				cs.xmlSerialize(xmlWriter);
			}
		}
		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
		
		xmlWriter.xmlClose("PackageScope");

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	/**
	 * Method addScopeMember
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScopeMember(org.antlr.java.crossref.Scope)
	 */
	public void addScopeMember(Scope s) {
		return;		
	}
}
