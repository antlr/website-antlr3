/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef CLASS_HPP
#define CLASS_HPP

#include <vector>
#include <string>
#include <fstream>
#include "constantpool.hpp"

namespace ClassEncoder
{

class method_info;

//! This class represents one class file.
/*!
 * This class represents one class file and thus one java class object.
 * For all classes at least the special function <init> must be declared.
 */
class Class : public ClassWriterBase
{
public:
    Class( const std::string &className = "output" );
    ~Class();

    const std::string &getClassName() const { return ClassName; }
    void write( );
    method_info *addMethod( const std::string &name );

private:
    ConstantPool ConstantPoolEntries;
    std::vector<method_info*> Methods;
    std::string ClassName;
};

} // end namespace
#endif // CLASS_HPP
