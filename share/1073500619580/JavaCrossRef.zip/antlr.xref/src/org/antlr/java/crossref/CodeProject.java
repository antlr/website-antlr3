package org.antlr.java.crossref; 

import java.io.IOException;
import java.io.Writer;
import java.util.*;

/** The information repository for the JavaRecognizer.  
 *  User provides an OutputCrossRefInfo class that regulates output.
 *  Tree parsers define scopes using public methods.
 *  Tree parsers call public methods to resolve references to 
 *  classes, fields, and methods.
 *  XML serialize outputs hierarchical representation of Scopes.
 *  Warnings are xmlSerialized, as well.   
 */
public class CodeProject {
	/**
	 * Master switch for printing debug information. 
	 * There are local flags in other classes
	 */
	static final boolean printDebug = false;
	/**
	 * Should the XML for references be output?
	 */
	static final boolean saveReferences = true;

	/** What scopes (typically top-level package names
	 *  like java or javax or com or org)
	 *  embody this project.
	 */
	protected Hashtable scopes = new Hashtable();

	/** Name such as JDK-1.3.1, Resin-2.0.5 */
	protected String name = null;

	/** Map "java.io.File.java" to its FileScope */
	protected Hashtable qFileNameToScopeMap = new Hashtable(1001);

	/** Map "java.util" to its PackageScope */
	protected Hashtable qPackageNameToScopeMap = new Hashtable(101);

	/** Map "java.io.File" to its ClassScope */
	protected Hashtable qClassNameToScopeMap = new Hashtable(5001);

	/** Map "java.io.File.open" to its MethodScope */
	protected Hashtable qMethodNameToScopeMap = new Hashtable(15001);

	/**
	 * Currently, not used.  
	 * Pro: We know a null superclass means that java.lang.Object is 
	 * superclass. Gunks up XML output
	 * Con: We could create an Object class with toString() and other 
	 * "base" methods.  
	 */
	protected ClassScope classCalledObject = null;

	/**
	 * Field defaultPackage
	 */
	protected PackageScope defaultPackage = null;
	
	/**
	 * User provides class.  The refClass, refMethod and refElement 
	 * methods "fire" when parser resolves an item.
	 */
	protected OutputCrossRefInfo outputInfo = null;
	
	/**
	 * Place where filenot found and parser problems live.
	 */
	protected Vector warnings=new Vector();
	

	/**
	 * Constructor for CodeProject
	 */
	public CodeProject() {
		// Define default package
		mkPackageScopes("[default]");

		// Define default class superclass: Object
//		mkPackageScopes("java.lang");
//		classCalledObject =
//			new ClassScope(this,"Object",getPackageScope("java.lang"));
//		getPackageScope("java.lang").addScope(classCalledObject);
	}
	/**
	 * Project is parsed/loaded and references are resolved.  Write
	 * out all the information.
	 */
	public void outputStructure(){
		if(outputInfo != null)
			outputInfo.OutputProject(this);
	}

	/**
	 * A method reference has been resolved.  Do user routine.
	 * @param referencingScope Scope
	 * @param referencedMethod MethodScope
	 * @param code LocationAST
	 */
	public void refMethod(Scope referencingScope,
						  MethodScope referencedMethod,
							LocationAST code)
	{
		if(saveReferences)
		{
			referencingScope.addRefTo(referencedMethod, code);
			if(referencedMethod != null)
				referencedMethod.addRefdBy(referencingScope, code);
		}
		if(outputInfo != null)
			outputInfo.OutputRefMethod(referencingScope, referencedMethod, code);
	}

	/**
	 * A class reference has been resolved.  Do user routine.
	 * @param referencingMethod MethodScope
	 * @param referencedClass ClassScope
	 * @param code LocationAST
	 */
	public void refClass(MethodScope referencingMethod,
						  ClassScope referencedClass,
							LocationAST code)
	{
		if(saveReferences)
		{
			referencingMethod.addRefTo(referencedClass, code);
			if(referencedClass != null)
				referencedClass.addRefdBy(referencingMethod, code);
		}
		if(outputInfo != null)
			outputInfo.OutputRefClass(referencingMethod, referencedClass, code);
	}
	/**
	 * A generic element has been resolved.  Do user routine.
	 * @param referencingClassOrMethod Scope
	 * @param referencedClassOrVariable Scope
	 * @param code LocationAST
	 */
	public void refElement(Scope referencingClassOrMethod,
						  Scope referencedClassOrVariable,
							LocationAST code)
	{
		if(saveReferences)
		{
			referencingClassOrMethod.addRefTo(referencedClassOrVariable, code);
			if(referencedClassOrVariable != null)
				referencedClassOrVariable.addRefdBy(referencingClassOrMethod, code);
		}
		if(outputInfo != null)
			outputInfo.OutputRefElement(referencingClassOrMethod, referencedClassOrVariable, code);
	}

	/** Make sure that all packages from root downwards are defined.
	 *  For example, com.jguru.portal would make three PackageScope
	 *  objects linked via parent field and have "com" as the root.
	 *  "com" would be added to this.scopes list if not there.
	 * @param qualifiedPackageName String
	 */
	public void mkPackageScopes(String qualifiedPackageName) {
		Vector packages = splitQualifiedName(qualifiedPackageName);
		if ( packages==null ) {
			return;
		}
		StringBuffer qname = new StringBuffer(50);
		PackageScope parent = null;
		// PackageScope last = null;
		for (int i = 0; i < packages.size(); i++) {
			String name = (String)packages.elementAt(i);
			// check to see if package exists
			PackageScope p = null;
			if ( parent!=null ) {
				qname.append('.');
				qname.append(name);
				// check this subpackage for name
				p = parent.getPackageScope(name);
				if(CodeProject.printDebug)
					System.out.println("CodeProject:mkPackagesScopes " + name+" within scope="+p);
			}
			else {
				// at root, check for existing top level package
				qname.append(name);
				p = (PackageScope)scopes.get(name);
				if(CodeProject.printDebug)
				  System.out.println("CodeProject:mkPackagesScopes " + name+" at root="+p);
			}
			if ( p==null ) {
				// still can't find, have to create, hook in
				p = new PackageScope(this, name, parent);
				if(CodeProject.printDebug)
				  System.out.println("CodeProject:mkPackagesScopes " + "couldn't find, creating "+name+" in "+
								   (parent!=null?parent.getName():"root"));
			}
			if ( parent==null ) {
				// update outermost scope...add if wasn't there
				if ( scopes.get(name)==null ) {
					if(CodeProject.printDebug)
						System.out.println("CodeProject:mkPackagesScopes " + "Adding to outer most scope: "+name);
					scopes.put(name, p);
				}
			}
			// each package gets added to overall project package to
			// PackageScope mapping
			setPackageScope(qname.toString(), p);
			parent = p;
			// last = p;
		}
		// update map that translates java.awt to its package scope
		// setPackageScope(qualifiedPackageName, last);
	}

	// UTILITIES

	/**
	 * Method getFileScope
	 * @param qName String
	 * @return FileScope
	 */
	public FileScope getFileScope(String qName) {
		if(CodeProject.printDebug)
			System.out.println("CodeProject:getFileScope " + "looking up file "+qName+"="+qFileNameToScopeMap.get(qName));
		return (FileScope)qFileNameToScopeMap.get(qName);
	}

	/**
	 * Method setFileScope
	 * @param qName String
	 * @param scope FileScope
	 */
	public void setFileScope(String qName, FileScope scope) {
		qFileNameToScopeMap.put(qName, scope);
	}

	/** From a fully qualified package name, get the PackageScope.  Examples:
	 *  "java", "java.io", "com.jguru.portal.tool".
	 * @param qName String
	 * @return PackageScope
	 */
	public PackageScope getPackageScope(String qName) {
		if(CodeProject.printDebug)
			System.out.println("CodeProject:getPackagesScope " + "looking up package "+qName);
		return (PackageScope)qPackageNameToScopeMap.get(qName);
	}

	/**
	 * Method setPackageScope
	 * @param qName String
	 * @param scope PackageScope
	 */
	public void setPackageScope(String qName, PackageScope scope) {
		qPackageNameToScopeMap.put(qName, scope);
	}

	/** From a fully qualified class name, get the ClassScope.  Examples:
	 *  "java.io.File", "JavaRecognizer" (if in default package).
	 * @param qName String
	 * @return ClassScope
	 */
	public ClassScope getClassScope(String qName) {
		if(CodeProject.printDebug)
			System.out.println("CodeProject:getClassScope " + "looking up class "+qName+"="+qClassNameToScopeMap.get(qName));
		return (ClassScope)qClassNameToScopeMap.get(qName);
	}

	/** From a fully qualified class name, get the ClassScope.  Examples:
	 *  "java.io.File", "JavaRecognizer" (if in default package).
	 * @param qName String
	 * @return ClassScope
	 */
	public ClassScope getOrPredefClassScope(String qName) {
		if(CodeProject.printDebug)
			System.out.println("CodeProject:getOrPredefClassScope " + "looking up class "+qName+"="+qClassNameToScopeMap.get(qName));
		ClassScope sc = null;
		sc = (ClassScope) qClassNameToScopeMap.get(qName);

		if(sc == null)
		{//did not find it - pre-define
			String className = null;
			String packName = null;
			if(qName.indexOf('.') < 0)
			{
				className = qName;
				sc = new ClassScope(this, className, null);
			}
			else
			{ 
				className = qName.substring(qName.lastIndexOf('.') + 1);
				packName = qName.substring(0, qName.lastIndexOf('.'));
				mkPackageScopes(packName);
  				sc = new ClassScope(this, className, getPackageScope(packName));
				getPackageScope(packName).addScope(sc);
			}
				
			if(sc != null)
				setClassScope(qName, sc);	
		}				
		return sc;
	}

	/**
	 * Method setClassScope
	 * @param qName String
	 * @param scope ClassScope
	 */
	public void setClassScope(String qName, ClassScope scope) {
		qClassNameToScopeMap.put(qName, scope);
	}

	/**
	 * Method getMethodScope
	 * @param qName String
	 * @param signature String
	 * @return MethodScope
	 */
	public MethodScope getMethodScope(String qName, String signature) {
		Object value = qMethodNameToScopeMap.get(qName);
		MethodScope ms = null; 
		if(CodeProject.printDebug)
			System.out.println("CodeProject:getMethodScope " + "looking up method "+qName+"="+qMethodNameToScopeMap.get(qName));
		if(value == null || value instanceof MethodScope)
			ms = (MethodScope) value;
		else {
			for (Iterator iter = ((ArrayList)value).iterator(); iter.hasNext();) {
				MethodScope element = (MethodScope) iter.next();
				if(element.matchSignature(signature)){
					ms = element;
					break;
				}
			}
		}
		return ms;
	}

	/**
	 * Method setMethodScope
	 * @param qName String
	 * @param scope MethodScope
	 */
	public void setMethodScope(String qName, MethodScope scope) {
		Object value = qMethodNameToScopeMap.get(qName);
		if(value == null)
			qMethodNameToScopeMap.put(qName, scope);
		else if(value instanceof MethodScope){
			qMethodNameToScopeMap.remove(qName);
			ArrayList arrayList = new ArrayList();
			arrayList.add(value);
			arrayList.add(scope);
			qMethodNameToScopeMap.put(qName, arrayList);
		} else //value already an arraylist
			((ArrayList) value).add(scope);
			
			
//		qMethodNameToScopeMap.put(qName, scope);
	}

	/** When we see a "name.method()" in some context, we have to decide
	 *  what that name is.  Fortunately, we know that it is either a typename
	 *  or a fieldname/variable.  Deciding which is a pain in the ass given java's
	 *  overloading of the '.' operator, but the following algorithm should
	 *  be mostly right: if it's a simple ID, then resolve it as a variable
	 *  or field/variable.  If it fails, assume classname (look it up).  If
	 *  not a simple ID, then look for whole id as a qualified class name like
	 *  "com.jguru.portal.util.StringUtils.replace(...)".  If not class name,
	 *  try assuming last ID is a static field like "System.out" or
	 *  "java.lang.System.out".  Resolve the stuff to the left as a
	 *  classname.  If that fails, it must be series of field references
	 *  leading to either a class or field name.  Try to match stuff to left
	 *  of last ID as variableOrFieldOrClass.fieldOrClass...fieldOrClass.
	 *  You basically have to interpret the '.' dot operator.
	 *
	 *  Return the class scope or the type of the field.  Return null
	 *  for scalar type fields.
	 *
	 *  // com.jguru.test.Main.getName();  package.class access
		// a.foo();     field access
		// a.b.c.foo(); field access
		// Main.foo();  class method access
		// java.lang.System.out.println(); package.class.field access
		// var.Field.Class.Field.ClassOrField.foo();
	 * @param scopeOfReference Scope
	 * @param qname String
	 * @return Scope
	 */
	/*
	public ClassScope resolveTypeOrField(Scope scopeOfReference,
										 String qname) {
		if ( qname.indexOf('.')<0 ) {
			Variable v = scopeOfReference.resolveVariable(qname);
			if ( v!=null ) {
				System.out.print(qname+" resolved to ");
				v.dump();
				return v.getType();
			}
			// try class name
			ClassScope cs = scopeOfReference.resolveClass(qname);
			if ( cs!=null ) {
				System.out.print("Resolved to class "+cs.getFullyQualifiedName());
				return cs;
			}
			return null; // unresolved.
		}

		// is a qualified name

		// is the whole tamale a class name?
		ClassScope cs = getClassScope(qname);
		if ( cs!=null ) {
			System.out.print("Resolved to class "+cs.getFullyQualifiedName());
			return cs;
		}

		// is whole thing a static field like System.out?  Stuff to
		// left of last ID is class name then.
		else {
			String fieldName = qName.substring(lastDot,qName.length());
			String className = qName.substring(0,lastDot);
			ClassScope cs = getClassScope(className);
			if ( cs!=null ) {
				return cs.getField(fieldName);
			}
			// see if it's a qualified field
			FieldVariable fv = getField(qname);
			if ( fv!=null ) {
				System.out.print("Resolved to field ");
				fv.dump();
			}
			else {
				// see if it's a classname
				String t = scopeOfReference.resolveClass(qname);
				if ( t!=null ) {
					System.out.print("Resolved to class "+t.getFullyQualifiedName());
				}
			}
		}
	}
	*/

	/**
	 *  Starting on the left edge start resolving the symbols.  Assume
	 *  there is no ambiguity like somebody defines "int java=0;" and
	 *  then refers to "java.lang.String" in that scope.  That should get
	 *  us pretty far.
	 * Examples:
	   // com.jguru.test.Main.getName();  package.class access
	   // a.foo();     field access
	   // a.b.c.foo(); field access
	   // Main.foo();  class method access
	   // java.lang.System.out.println(); package.class.field access
	   // var.Field.Class.Field.ClassOrField.foo();
	*/
   public Scope resolveTypeOrField(Scope scopeOfReference,
										String qname) {
	   if ( qname.indexOf('.')<0 ) {
		   Variable v = scopeOfReference.resolveVariable(qname);
		   if ( v!=null ) {
			   if(CodeProject.printDebug){
			   		System.out.print("CodeProject:resolveTypeOrField " + qname+" resolved to ");
			   		v.dump();
			   }
//jfo: want variable, not just type 			   return v.getType();
			   return v;
		   }
		   // try class name
		   ClassScope cs = scopeOfReference.resolveClass(qname);
		   if ( cs!=null ) {
				if(CodeProject.printDebug)
					System.out.print("CodeProject:resolveTypeOrField " + "Resolved to class "+cs.getFullyQualifiedName());
			   return cs;
		   }
		   return null; // unresolved.
	   }

		// is a qualified name
		Vector ids = splitQualifiedName(qname);

		// peel off a package name on left edge?

		// first ID, scope is scope of reference
		Scope movingScope = scopeOfReference;
		for (int i = 0; i < (ids.size()-1); i++) {
			String name = (String)ids.elementAt(i);
			if(CodeProject.printDebug)
				System.out.println("CodeProject:resolveTypeOrField " +  "analyzing "+name);
			String nextName = (String)ids.elementAt(i+1);
			// VARIABLE OR FIELD?
			Variable v = movingScope.resolveVariable(name);
			if ( v!=null &&
				v.getType()!=null &&
				(v.getType().resolveField(nextName)!=null ||
				v.getType().resolveClass(nextName)!=null) )
			{
				// it's a var or field and next name is member
				if(CodeProject.printDebug)
					System.out.println("CodeProject:resolveTypeOrField " +  "it's a var/field: "+v.getFullyQualifiedName());
				movingScope=v.getType();
				continue;
			}

			// CLASSNAME?
			ClassScope cs = movingScope.resolveClass(name);
			if ( cs!=null &&
				 (cs.resolveField(nextName)!=null ||
				  cs.resolveClass(nextName)!=null) )
			{
				if(CodeProject.printDebug)
					System.out.println("CodeProject:resolveTypeOrField " +  "it's a class: "+cs.getFullyQualifiedName());
				movingScope = cs;
				continue;
			}

			// PACKAGE? (if first ID)
			PackageScope ps = getPackageScope(name);
			if ( i==0 && ps!=null ) {
				movingScope = ps;
				if(CodeProject.printDebug)
					System.out.println("CodeProject:resolveTypeOrField " +  "it's a package: "+movingScope.getFullyQualifiedName());
				continue;
			}
			else if ( i>0 && movingScope instanceof PackageScope ) {
				PackageScope thisps = (PackageScope)movingScope;
				ps = thisps.getPackageScope(name);
				if ( ps!=null ) {
					movingScope = ps;
					if(CodeProject.printDebug)
						System.out.println("CodeProject:resolveTypeOrField " +  "it's a package: "+ps.getFullyQualifiedName());
					continue;
				}
			}
			if(CodeProject.printDebug)
				System.out.println("CodeProject:resolveTypeOrField " +  "unresolved "+qname);
			return null; // I have no idea what the hell it is
		}

		// Ok, at this point we know what everything but the last ID
		// represents.  Could be a class or field.  Check it out
		String lastID = (String)ids.elementAt(ids.size()-1);
		if(CodeProject.printDebug)
			System.out.println("CodeProject:resolveTypeOrField " +  "resolving last ID "+lastID);
		Variable v = movingScope.resolveField(lastID);
		if ( v!=null ) {
			// it's a field
			if(CodeProject.printDebug)
				System.out.println("CodeProject:resolveTypeOrField " +  "it's a field of type: "+v.getType().getFullyQualifiedName());
//			jfo: want variable, not just type  return v.getType();
            return v;
		}
		ClassScope cs = movingScope.resolveClass(lastID);
		if ( cs!=null ) {
			// it's a class
			if(CodeProject.printDebug)
				System.out.println("CodeProject:resolveTypeOrField " +  "it's a class: "+cs.getFullyQualifiedName());
			return cs;
		}
		return null;
	}

	/** Return variable for field if qname=="<classname>.field"
	 * @param qname String
	 * @return Vector
	 */
	/*
	public FieldVariable getField(String qName) {
		int lastDot = qName.lastIndexOf(".");
		if ( lastDot<=0 ) {
			return null;
		}
		String fieldName = qName.substring(lastDot,qName.length());
		String className = qName.substring(0,lastDot);
		ClassScope cs = getClassScope(className);
		if ( cs!=null ) {
			return cs.getField(fieldName);
		}
		return null;
	}
*/

	public Vector splitQualifiedName(String qname) {
		if ( qname==null ) {
			return null;
		}
		Vector v = new Vector();
		StringTokenizer st = new StringTokenizer(qname, ".");
		while ( st.hasMoreTokens() ) {
			String n = st.nextToken();
			v.addElement(n);
		}
		return v;
	}

	// GETTERS/SETTERS

	/**
	 * Method getScopes
	 * @return Hashtable
	 */
	public Hashtable getScopes() {
		return scopes;
	}

	/**
	 * Method setScopes
	 * @param scopes Hashtable
	 */
	public void setScopes(Hashtable scopes) {
		this.scopes = scopes;
	}

	/**
	 * Method getName
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method setName
	 * @param name String
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method dump
	 */
	public void dump() {
		StringBuffer s = new StringBuffer();
		System.out.println("CodeProject:dump " + "Project "+getName());
		Enumeration keys = scopes.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			Scope sc = (PackageScope)scopes.get(name);
			sc.dump();
		}
	}

	/**
	 * Method toString
	 * @return String
	 */
	public String toString() {
		StringBuffer s = new StringBuffer();
		s.append("Project ");
		s.append(getName());
		s.append("\n");
		Enumeration keys = scopes.keys();
		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			Scope sc = (PackageScope)scopes.get(name);
			s.append(sc);
		}
		// s.append("Package map: "+qPackageNameToScopeMap.toString());
		// s.append("\nClass map: "+qClassNameToScopeMap.toString());
		return s.toString();
	}
	/**
	 * @param outputInfo
	 */
	public void setOutputInfo(OutputCrossRefInfo outputInfo) {
		this.outputInfo = outputInfo;
	}
	/**
	 * Method xmlSerialize
	 * @param out Writer
	 * @throws IOException
	 */
	public void xmlSerialize(Writer out) throws IOException
	{
		XmlWriter xmlWriter = new XmlWriter(out);
		xmlWriter.xmlOpen("Project name=\""+ getName() + "\"");

		Hashtable scopes = getScopes();
		Enumeration keys = scopes.keys();

		while (keys.hasMoreElements()) {
			String name = (String)keys.nextElement();
			PackageScope sc = (PackageScope)scopes.get(name);
			sc.xmlSerialize(xmlWriter);
//			xmlPackage(sc);
		}
		xmlWriter.xmlOpen("Warnings");
		Iterator iter = warnings.iterator();
		if(!iter.hasNext())
			xmlWriter.xmlNode("None");
			
		while(iter.hasNext()) 
		{
			Object object = iter.next();
			if(object instanceof Location)
				((Location)object).xmlSerialize(xmlWriter);
		}
		xmlWriter.xmlClose("Warnings");

		xmlWriter.xmlClose("Project");
		xmlWriter.flush();
		
	}
	

	/**
	 * @return Vector
	 */
	public Vector getWarnings() {
		return warnings;
	}

}
