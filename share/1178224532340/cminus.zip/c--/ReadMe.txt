Introduction
=========

This is an implementation of a simple language "C--" that implements a small subset of C. The following are supported:

  - If statements
  - Loops (while, do-while, for)
  - Integers
  - Many operators (tertiary and some others excluded)
  - Functions
  - Arrays (automatically passed by reference to functions)

It is a very simple language but could be useful for learning purposes.

This language has been implemented using an interperter and a compiler. The interperter is written using a ANTLR tree-grammar file.

The compiler targets LLVM's [http://LLVM.org] intermediate representation.

Three sample C-- programs are included in the test folder.

It is very limited and some features are implemented completely (ie. "i++" will work in the interperter but not the compiler). The project was developed for a course and an incomplete language specification is attached as a PDF.

Tested with ANTLR 3.0b7 and LLVM 1.9.

-Scott Fortmann-Roe

scottfr@gmail.com


Using the Interperter
=============

1) Run ANTLR on the grammar files in the interperter folder.

java org.antlr.Tool *.g

2) Compile the java code.

javac *.java

3) Run the code interperter on a C-- program

java Main ../test/bubble.c--

Using the Compiler
=============

1) Run ANTLR on the grammar files in the compiler folder.

java org.antlr.Tool *.g

2) Compile the java code.

javac *.java

3) Run the code compiler on a C-- program

java Main ../test/bubble.c-- > bubble.ll

4) Convert the LL file into bytecode using LLVM's llvm-as command (download these commands from http://LLVM.org)

llvm-as bubble.ll

5) Run the bytecode using LLVM's interperter or compile.

lli bubble.bc

or

llvmc bubble.bc -o bubble
./bubble