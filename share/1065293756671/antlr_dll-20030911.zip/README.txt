To use the dll from your project, you need to link against the corresponding
antlr.lib and define the following preprocessor macros

ANTLR_IMPORTS
ANTLR_CXX_SUPPORTS_NAMESPACE

and add drive:\<path-to-antlr>\lib\cpp to your include path. Note that the
ANTLR 2.7.2 distribution won't work, you need Ric's modified version, available
at http://wwwhome.cs.utwente.nl/~klaren/antlr/antlr-20030911.tar.gz.

If you want to build the dll yourself, here's how:

1. Create new "Win32 Project"
2. In the creation wizard, under "Application Settings", check DLL as
application type and "Empty project" in "Additional Options"
3. Insert all *.cpp files from lib/cpp/src and *.hpp from lib/cpp/antlr
to your project.
4. Make these changes in Project properties:
    - Configuration Properties
      - C/C++
        - General
          - Additinal Include Directories: drive:\path-to-antlr\lib\cpp
        - Preprocessor
          - Preprocessor Definitions:
		WIN32;_DEBUG;_WINDOWS;_USRDLL;ANTLR_EXPORTS;ANTLR_CXX_SUPPORTS_NAMESPACE
              ( change _DEBUG to NDEBUG in release build)
        - Code generation
          - Runtime Library: Multi-threaded Debug DLL  (Skip "debug" in
release build)
          - Enable Function-level Linking: Yes
        - Language
          - Default Char Unsigned: Yes
        - Create/Use Precompiled Header: Not using precompiled header
5. Compile

