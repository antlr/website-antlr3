#ifndef INC_CalcParserTokenTypes_hpp_
#define INC_CalcParserTokenTypes_hpp_

/* $ANTLR 2.7.5 (20050128): "calc.g" -> "CalcParserTokenTypes.hpp"$ */

#ifndef CUSTOM_API
# define CUSTOM_API
#endif

#ifdef __cplusplus
struct CUSTOM_API CalcParserTokenTypes {
#endif
	enum {
		EOF_ = 1,
		PLUS = 4,
		SEMI = 5,
		STAR = 6,
		INT = 7,
		WS_ = 8,
		LPAREN = 9,
		RPAREN = 10,
		DIGIT = 11,
		NULL_TREE_LOOKAHEAD = 3
	};
#ifdef __cplusplus
};
#endif
#endif /*INC_CalcParserTokenTypes_hpp_*/
