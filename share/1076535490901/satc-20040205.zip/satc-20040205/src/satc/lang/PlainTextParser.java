// $ANTLR 2.7.2: "plain.g" -> "PlainTextParser.java"$
 package satc.lang; 
import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;
import satc.antlr.DocParser;

public class PlainTextParser extends DocParser       implements PlainTextTokenTypes
 {

protected PlainTextParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public PlainTextParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected PlainTextParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public PlainTextParser(TokenStream lexer) {
  this(lexer,1);
}

public PlainTextParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void start() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST start_AST = null;
		
		try {      // for error handling
			{
			_loop8:
			do {
				if ((LA(1)==LINE)) {
					AST tmp1_AST = null;
					tmp1_AST = astFactory.create(LT(1));
					match(LINE);
				}
				else {
					break _loop8;
				}
				
			} while (true);
			}
			start_AST = (AST)currentAST.root;
			start_AST = astFactory.create(START,"START") ;
			currentAST.root = start_AST;
			currentAST.child = start_AST!=null &&start_AST.getFirstChild()!=null ?
				start_AST.getFirstChild() : start_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_0);
		}
		returnAST = start_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"LINE",
		"\"START\""
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	
	}
