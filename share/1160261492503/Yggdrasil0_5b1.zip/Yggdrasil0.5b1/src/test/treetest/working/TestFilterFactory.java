import org.antlr_yggdrasil.runtime.PayloadFactory;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.PayloadToken;
import java.util.HashMap;

public class TestFilterFactory implements PayloadFactory {
	public static final int SEPARATOR=5;
	public static final int EOF=-1;
	public static final int Tokens=7;
	public static final int CONTENT=4;
	public static final int NEWLINE=6;
	HashMap<String, Integer> typeMap = new HashMap<String, Integer>();

	public TestFilterFactory() {
		typeMap.put("SEPARATOR", new Integer(5));
		typeMap.put("EOF", new Integer(-1));
		typeMap.put("Tokens", new Integer(7));
		typeMap.put("CONTENT", new Integer(4));
		typeMap.put("NEWLINE", new Integer(6));
	}

	public Payload createNew(int tokenType) {
		return createNew(tokenType, "" + tokenType);
	}
	
	public Payload createNew(Payload typeID, Payload name) {
		Payload pay = createNew(typeID.getText(), name.getText());
		return pay;
	}
	
	public Payload createNew(String typeID, Payload text) {
		return createNew(typeID, text.getText());
	}
	
	public Payload createNew(Payload token, String text) {
		return createNew(token.getText(), text);
	}
		
	public Payload createNew (String typeID, String text) {
		int type = typeMap.get(typeID).intValue();
		
		return createNew(type, text);
	}

	public Payload createNew(int tokenType, String text) {
				return new PayloadToken(tokenType, text);

	}
}
