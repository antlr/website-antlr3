/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "errorhandler.hpp"
#include <iostream>
#include <fstream>

using namespace std;

int ErrorHandler::TotalErrors = 0;

//! Checker error handling function
/*!
 * Reports error and then returns normally. After 5 errors are encountered it quits.
 * \param lineNumber Line number where the error occured.
 * \param message Additional error msg
 */
void ErrorHandler::error ( int lineNumber, const string &message)
{
	cerr << lineNumber << ": " << message << endl;

	++TotalErrors;


	if (TotalErrors == 10)
	{
		cerr << endl <<  "Maximum errors exceeded, bailing out" << endl << endl;
		exit(-1);
	}
}

//! Parser error handling function
/*!
 * Reports error and then returns normally.
 * \param file Source file of the program that has an error.
 * \param line Line number where the error occured.
 * \param column Column where the error occured
 * \param msg Additional error msg
 */
void ErrorHandler::error (const string &file, const int &line, const int &column, const string &msg)
{
	char buf[80];
	ifstream fp(file.c_str());


	for (int i = 0; i < line; i++)
	{
		fp.getline (buf, 80);
	}

	cerr << msg << " at line " << line << endl;

	// The line that goes wrong.
	cerr << buf << endl;

	// The caret
	for (int i = 0; i < column - 1; i++)
	{
		cerr << ' ';
	}
	cerr << "^ error" << endl << endl;

	fp.close();
}
