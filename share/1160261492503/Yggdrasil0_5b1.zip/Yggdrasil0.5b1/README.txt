ANTLR Yggdrasil is an ANTLR variant built on the ANTLR 3 recognition engine and (for the near term) StringTemplate.  It has the following features:
 
1.) Strongly typed attributes:  Yggdrasil supports definition of attribute types and attribute variables and provides a very simple attribute algebra.  Attributes are first class syntactic elements of Yggdrasil:  that is, attribute manipulations are primarily done through the attribute algebra and rarely through actions.  Base attribute types include Carrier and Payload for tree manipulation; Payloads (Tokens) are passed intact from input to output tree. 

2.) Code generation for attribute types:  Yggdrasil generates code for user-defined attribute types, without hindering the user's ability to define classes in the target language.  Yggdrasil also generates a Payload factory to support heterogeneous tree construction. 

3.) Tree rewrite through attribute manipulations.  Any element in a tree can be assigned to an attribute variable and later instantiated in the tree by referencing the attribute variable.  Attributes--including the type field in payloads--can be set or referenced using Yggdrasil syntax.  This makes a difference for tree grammar generation--perhaps the commonest attribute manipulation in ANTLR 2 was to change the type field of an AST node in an action, where it was essentially invisible and the generated tree recognized the original type, not the modified one. 

4.) Predicated tree construction.  Construction predicates direct tree construction much the same way that (matching) semantic predicated direct recognition of semantic constructs. 

5.) Full model/view separation of grammar and target.  All actions (and semantic predicates) are templates; output can be retargeted by replacing the template definition files used by the grammar.  It should be possible to "develop in Java, deliver in C" once Yggdrasil supports a C target.

6.) Lexical editing (! on characters), keyword and string support (keywords have types, strings are matched by text to provide "keyword in context" support, heterogeneous ASTs (Payload types may vary).
 
Later versions will provide automatic tree grammar generation and "compiled" StringTemplates (to improve retargetability of Yggdrasil and reduce memory usage).

For more information, check out the manual in the doc directory.
 
Yggdrasil is an outgrowth of my experiences with ANTLR 2.8 and the concepts I presented at the last ANTLR workshop.  Some of those concepts--notably attribute variables and dynamic scoping--in turn grew out of the Oregon ANTLR Cabal discussions.  Thanks, Ter, Monty!
 
