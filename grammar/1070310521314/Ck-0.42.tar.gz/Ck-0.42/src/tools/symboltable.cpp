/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "symboltable.hpp"

using namespace std;
//! Constructor
/*!
 *  Default constructor
 */
template<class T>
SymbolTable<T>::SymbolTable<T>()
{
    CurrentLevel = 0;
    Scopes.push_back( new map<string, T*> );
}

//! Destructor
/*!
 *  Destroys the object and all the objects in de symbol table.
 */
template<class T>
SymbolTable<T>::~SymbolTable<T>()
{
    // typename tells the compiler that T is a type
    // loop through all scopes
    for( typename vector<map<string, T*>*>::const_iterator scope_it = Scopes.begin();
         scope_it != Scopes.end(); ++scope_it )
    {
        // loop through all entries in the scope
        for( typename map<string, T*>::const_iterator entry_it = (*scope_it)->begin();
                 entry_it != (*scope_it)->end(); ++entry_it )
        {
            delete entry_it->second;
        }
        delete (*scope_it);
    }
}

//! Open a new scope
template<class T>
void SymbolTable<T>::openScope()
{
    ++CurrentLevel;
    Scopes.push_back( new map<string, T*> );
}

//! Close current scope
/*!
 * All identifiers in the current scope level will be removed from the symbol table.
 * \throw SymbolTableException when trying to close scope 0.
 */
template<class T>
void SymbolTable<T>::closeScope()
{
    if( CurrentLevel == 0 )
        throw SymbolTableException();

    // delete all entries in current scope
            // loop through all entries in the scope
    for( typename map<string, T*>::const_iterator entry_it = Scopes[CurrentLevel]->begin();
         entry_it != Scopes[CurrentLevel]->begin(); ++entry_it )
    {
        delete entry_it->second;
    }

    delete Scopes[CurrentLevel];
    Scopes.pop_back();
    --CurrentLevel;
}

//! Check if an identifier is declared
/*!
 * \return The entry on the highest scope level if found. 0 if the identifier is not declared.
 */
template<class T>
T *SymbolTable<T>::retrieve( const string &id )
{
    for( int i = CurrentLevel; i >= 0; --i )
    {
        typename map<string, T*>::const_iterator entry_it = Scopes[i]->find( id );
        if( entry_it != Scopes[i]->end() ) return entry_it->second;
    }
    return 0;
}

//! Insert identifier into current scope
/*!
 * \param id Identifier to insert
 * \param newEntry The entry to add into the symbol table. It will be deleted when it goes out of scope
 * or when the symbol table is destroyed.
 * \throw SymbolTableException when
 * - the id is already declared in this scope.
 */
template<class T>
void SymbolTable<T>::enter( const string &id, T *newEntry )
{
    if( Scopes[CurrentLevel]->find( id ) != Scopes[CurrentLevel]->end() )
        throw SymbolTableException();
    else
        (*Scopes[CurrentLevel])[id] = newEntry;
}

// explicit initialization. Without this the template code is not generated
// an option is to put all the template code in de header of the symbol table class (this is what STL does)
template class SymbolTable<CheckerIdEntry>;
template class SymbolTable<CGIdEntry>;
template class SymbolTable<FunctionIdEntry>;
template class SymbolTable<CGFunctionEntry>;
