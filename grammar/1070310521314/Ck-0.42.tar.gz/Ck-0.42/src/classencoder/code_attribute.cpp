/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "code_attribute.hpp"
#include "class.hpp"

namespace ClassEncoder
{
using namespace std;

//! Standard constructor.
/*!
 * Creates the ByteCode entry initialises the other variables and sets our name to Code via attribute_info::setNameIndex.
 \param pool Pointer to the constant pool of the class this code_attribute belongs to.
 \sa attribute_info::setNameIndex
 */
code_attribute::code_attribute( ConstantPool *pool )
{
    Code = new ByteCode( pool );
    max_locals = 0;
    ConstantPoolEntries = pool;
    // add self description
    setNameIndex( pool->add( new Utf8_info( "Code" ) ) );
}

//! Default destructor
/*!
 * Delete the ByteCode entry located in the constructor.
 */
code_attribute::~code_attribute()
{
    if( Code ) delete Code;
}

//! Write contents to class stream
/*!
 * Writes the contents of this attribute to the class stream.
 * \param stream The class stream to write to.
 */
void code_attribute::write( ofstream &stream )
{
    attribute_info::write( stream );
// u2 max_stack;
    writeu2( stream, Code->maxStackSize() );
// u2 max_locals;
    writeu2( stream, max_locals );
// u4 code_length;
    writeu4( stream, Code->nextInstrAddr() );
// u1 code[code_length];
    Code->write( stream );

// u2 exception_table_length;
//   exception_table[exception_table_length];
    writeu2( stream, 0 );
// u2 attributes_count;
// attribute_info attributes[attribute_count];
    writeu2( stream, 0 );
}

//! Compute size
/*!
 * Computes the total number of bytes the elements of the code_attribute use.
 * This corresponds to 2 + 2 + 4 + the size of the code + 2 + 2.
 */
unsigned int code_attribute::size()
{
    return 2 + 2 + 4 + Code->nextInstrAddr() + 2 + 2;
}

} // end namespace
