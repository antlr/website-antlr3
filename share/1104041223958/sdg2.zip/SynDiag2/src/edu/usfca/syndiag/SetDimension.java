// $ANTLR 2.7.3rc3: "setDim.g" -> "SetDimension.java"$

	package edu.usfca.syndiag;
	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** A tree grammar set dimension of each node in the Grammar AST
 *
 *  Jia Zheng
 *  University of San Francisco
 *  Oct. 1, 2003
 */
public class SetDimension extends antlr.TreeParser       implements SetDimensionTokenTypes
 {

public static final int ELEMENT_FONT_SIZE = 14;
public static final int RULE_DEF_FONT_SIZE = 20;

public static int getStringWidth(String str, Font f){
	JFrame jframe = new JFrame();
	jframe.pack(); 
	Graphics g = jframe.getGraphics(); 
	g.setFont(f);
	FontMetrics fm = g.getFontMetrics();
	int w = fm.stringWidth(str);
	return w;
}

public SetDimension() {
	tokenNames = _tokenNames;
}

	public final void grammar(AST _t) throws RecognitionException {
		
		AST grammar_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		GrammarAST g = (GrammarAST)grammar_AST_in;
			 int w = 0;
			 int h = 0;
			 Dimension c;
			
		
		try {      // for error handling
			c=classDef(_t);
			_t = _retTree;
			((GrammarAST)g).setDim((int)c.getWidth(), (int)c.getHeight());
				 System.out.println("width = " + (int)c.getWidth() + ", height = " + (int)c.getHeight());
				
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final Dimension  classDef(AST _t) throws RecognitionException {
		Dimension d;
		
		AST classDef_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		GrammarAST c = (GrammarAST)classDef_AST_in;
			 int w = 0;
			 int h = 0;
			 d = new Dimension(w, h);
			 Dimension d1, d2, d3;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case PARSER:
			{
				AST __t3 = _t;
				AST tmp1_AST_in = (AST)_t;
				match(_t,PARSER);
				_t = _t.getFirstChild();
				d1=rules(_t);
				_t = _retTree;
				_t = __t3;
				_t = _t.getNextSibling();
				w = (int)d1.getWidth();
						 h = (int)d1.getHeight();
						 d = new Dimension(w+200, h+200);
						
				break;
			}
			case TREE_PARSER:
			{
				AST __t4 = _t;
				AST tmp2_AST_in = (AST)_t;
				match(_t,TREE_PARSER);
				_t = _t.getFirstChild();
				d2=rules(_t);
				_t = _retTree;
				_t = __t4;
				_t = _t.getNextSibling();
				w = (int)d2.getWidth();
						 h = (int)d2.getHeight();
						 d = new Dimension(w+200, h+200);    		 
						
				break;
			}
			case LEXER:
			{
				AST __t5 = _t;
				AST tmp3_AST_in = (AST)_t;
				match(_t,LEXER);
				_t = _t.getFirstChild();
				d3=rules(_t);
				_t = _retTree;
				_t = __t5;
				_t = _t.getNextSibling();
				w = (int)d3.getWidth();
						 h = (int)d3.getHeight();
						 d = new Dimension(w+200, h+200);    		 
						
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return d;
	}
	
	public final Dimension  rules(AST _t) throws RecognitionException {
		Dimension d;
		
		AST rules_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		int w = 0;
			 int h = 0;
			 int deltaY = 0;
			 d = new Dimension(w, h);
			
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					r = _t==ASTNULL ? null : (AST)_t;
					rule(_t);
					_t = _retTree;
					w = Math.max(w, ((GrammarAST)r).getWidth());
							 h += ((GrammarAST)r).getHeight() + deltaY;
							 deltaY = 60;
							
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt8++;
			} while (true);
			}
			d = new Dimension(w, h);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return d;
	}
	
	public final void rule(AST _t) throws RecognitionException {
		
		AST rule_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST b = null;
		GrammarAST rl = (GrammarAST)rule_AST_in;
			 int w = 0; 
			 int h = 0; 
			 Dimension d;
			
		
		try {      // for error handling
			AST __t10 = _t;
			AST tmp4_AST_in = (AST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			r = (AST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			w = getStringWidth(r.getText(), new Font("Monospaces", Font.BOLD, RULE_DEF_FONT_SIZE)) +  100;
						 ((GrammarAST)r).setDim(w, RULE_DEF_FONT_SIZE);
						
			AST __t11 = _t;
			AST tmp5_AST_in = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			b = _t==ASTNULL ? null : (AST)_t;
			d=block(_t);
			_t = _retTree;
			_t = __t11;
			_t = _t.getNextSibling();
			w += (int)d.getWidth(); 
			h += (int)d.getHeight();
					
			AST tmp6_AST_in = (AST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t10;
			_t = _t.getNextSibling();
			((GrammarAST)rl).setDim(w, h);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final Dimension  block(AST _t) throws RecognitionException {
		Dimension d;
		
		AST block_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		GrammarAST b = (GrammarAST)block_AST_in;
			 int w = 0; 
			 int h = 0; 
			 int deltaY = 0;
			 d = new Dimension(0,0);
			
		
		try {      // for error handling
			{
			int _cnt14=0;
			_loop14:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					a = _t==ASTNULL ? null : (AST)_t;
					alternative(_t);
					_t = _retTree;
					w = Math.max(w, ((GrammarAST)a).getWidth());
						 h += ((GrammarAST)a).getHeight() + deltaY;
						 //deltaY = 30; //jz
						 deltaY = 35; //mm. 35 gives more accurate output.
						
				}
				else {
					if ( _cnt14>=1 ) { break _loop14; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt14++;
			} while (true);
			}
			((GrammarAST)b).setBlockDim(w, h);
			d = new Dimension(w, h);
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
		return d;
	}
	
	public final void alternative(AST _t) throws RecognitionException {
		
		AST alternative_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST e = null;
		int w = 0;
			 int h = 0; 
			 int deltaX = 0;
			
		
		try {      // for error handling
			AST __t16 = _t;
			a = _t==ASTNULL ? null :(AST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			{
			int _cnt18=0;
			_loop18:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t);
					_t = _retTree;
					w += ((GrammarAST)e).getWidth() + deltaX;
							 h = Math.max(h, ((GrammarAST)e).getHeight());
							 deltaX = 50;
							
				}
				else {
					if ( _cnt18>=1 ) { break _loop18; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt18++;
			} while (true);
			}
			_t = __t16;
			_t = _t.getNextSibling();
			((GrammarAST)a).setDim(w, h);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t) throws RecognitionException {
		
		AST element_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST elt = null;
		AST tr = null;
		AST a1 = null;
		AST a2 = null;
		AST c1 = null;
		AST c2 = null;
		AST eb = null;
		AST t = null;
		GrammarAST e = (GrammarAST)element_AST_in;
			 Dimension b;
			 int w; 
			 int h;
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case RULE_REF:
			case WILD_CARD:
			{
				a = _t==ASTNULL ? null : (AST)_t;
				atom(_t);
				_t = _retTree;
				e.setDim(((GrammarAST)a).getWidth(), ((GrammarAST)a).getHeight());
				break;
			}
			case NOT:
			{
				AST __t20 = _t;
				AST tmp7_AST_in = (AST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				elt = _t==ASTNULL ? null : (AST)_t;
				element(_t);
				_t = _retTree;
				_t = __t20;
				_t = _t.getNextSibling();
				e.setDim(((GrammarAST)elt).getWidth(), ((GrammarAST)elt).getHeight());
				break;
			}
			case TOKEN_RANGE:
			{
				AST __t21 = _t;
				tr = _t==ASTNULL ? null :(AST)_t;
				match(_t,TOKEN_RANGE);
				_t = _t.getFirstChild();
				a1 = _t==ASTNULL ? null : (AST)_t;
				atom(_t);
				_t = _retTree;
				a2 = _t==ASTNULL ? null : (AST)_t;
				atom(_t);
				_t = _retTree;
				_t = __t21;
				_t = _t.getNextSibling();
				w = ((GrammarAST)a1).getWidth() + ((GrammarAST)a2).getWidth();
						 h = Math.max(((GrammarAST)a1).getHeight(), ((GrammarAST)a2).getHeight());
						 e.setDim(w, h);
						
				break;
			}
			case CHAR_RANGE:
			{
				AST __t22 = _t;
				AST tmp8_AST_in = (AST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				c1 = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				c2 = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				_t = __t22;
				_t = _t.getNextSibling();
				w = ((GrammarAST)c1).getWidth() + ((GrammarAST)c2).getWidth();
						 h = Math.max(((GrammarAST)c1).getHeight(), ((GrammarAST)c2).getHeight());
					  	 e.setDim(w, h);
					  	
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				eb = _t==ASTNULL ? null : (AST)_t;
				ebnf(_t);
				_t = _retTree;
				e.setDim(((GrammarAST)eb).getWidth(), ((GrammarAST)eb).getHeight());
				break;
			}
			case TREE_BEGIN:
			{
				t = _t==ASTNULL ? null : (AST)_t;
				tree(_t);
				_t = _retTree;
				e.setDim(((GrammarAST)t).getWidth(), ((GrammarAST)t).getHeight());
				break;
			}
			case SYNPRED:
			{
				AST __t23 = _t;
				AST tmp9_AST_in = (AST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				_t = __t23;
				_t = _t.getNextSibling();
				e.setDim((int)b.getWidth(), (int)b.getHeight());
				break;
			}
			case ACTION:
			{
				AST tmp10_AST_in = (AST)_t;
				match(_t,ACTION);
				_t = _t.getNextSibling();
				break;
			}
			case SEMPRED:
			{
				AST tmp11_AST_in = (AST)_t;
				match(_t,SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				AST tmp12_AST_in = (AST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t) throws RecognitionException {
		
		AST atom_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST t = null;
		AST c = null;
		AST s = null;
		AST wi = null;
		int w = 0; 
			 int h = 20;
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				r = (AST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				w = getStringWidth(r.getText(), new Font("Monospaces", Font.PLAIN, ELEMENT_FONT_SIZE)) + 30;
						  	 ((GrammarAST)r).setDim(w, h);
						 	
				break;
			}
			case TOKEN_REF:
			{
				t = (AST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				w = getStringWidth(t.getText(), new Font("Monospaces", Font.PLAIN, ELEMENT_FONT_SIZE)) + 30;
						 	 ((GrammarAST)t).setDim(w, h);
						 	
				break;
			}
			case CHAR_LITERAL:
			{
				c = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				w = getStringWidth(c.getText(), new Font("Monospaces", Font.PLAIN, ELEMENT_FONT_SIZE)) + 30;
						 	 ((GrammarAST)c).setDim(w, h);
						 	
				break;
			}
			case STRING_LITERAL:
			{
				s = (AST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				w = getStringWidth(s.getText(), new Font("Monospaces", Font.PLAIN, ELEMENT_FONT_SIZE)) + 30;
						 	 ((GrammarAST)s).setDim(w, h);
						 	
				break;
			}
			case WILD_CARD:
			{
				wi = (AST)_t;
				match(_t,WILD_CARD);
				_t = _t.getNextSibling();
				w = getStringWidth(wi.getText(), new Font("Monospaces", Font.PLAIN, ELEMENT_FONT_SIZE)) + 30;
						 	 ((GrammarAST)wi).setDim(w, h);
						 	
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t) throws RecognitionException {
		
		AST ebnf_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST bb = null;
		AST o = null;
		AST c = null;
		AST p = null;
		Dimension b;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				AST __t25 = _t;
				bb = _t==ASTNULL ? null :(AST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				_t = __t25;
				_t = _t.getNextSibling();
				((GrammarAST)bb).setDim((int)b.getWidth() + 30, (int)b.getHeight());
				break;
			}
			case OPTIONAL:
			{
				AST __t26 = _t;
				o = _t==ASTNULL ? null :(AST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				_t = __t26;
				_t = _t.getNextSibling();
				((GrammarAST)o).setDim((int)b.getWidth() + 30, (int)b.getHeight());
				break;
			}
			case CLOSURE:
			{
				AST __t27 = _t;
				c = _t==ASTNULL ? null :(AST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				_t = __t27;
				_t = _t.getNextSibling();
				((GrammarAST)c).setDim((int)b.getWidth()+30, (int)b.getHeight());
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t28 = _t;
				p = _t==ASTNULL ? null :(AST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				b=block(_t);
				_t = _retTree;
				_t = __t28;
				_t = _t.getNextSibling();
				((GrammarAST)p).setDim((int)b.getWidth()+30, (int)b.getHeight());
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tree(AST _t) throws RecognitionException {
		
		AST tree_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST t = null;
		AST a = null;
		AST e = null;
		
		try {      // for error handling
			AST __t30 = _t;
			t = _t==ASTNULL ? null :(AST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			a = _t==ASTNULL ? null : (AST)_t;
			atom(_t);
			_t = _retTree;
			int w = ((GrammarAST)a).getWidth();
										 int h = ((GrammarAST)a).getHeight();
										
			{
			_loop32:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t);
					_t = _retTree;
					w += ((GrammarAST)e).getWidth() + ((GrammarAST)e).deltaX;
											 	 h = Math.max(h, ((GrammarAST)e).getHeight());
											 	
				}
				else {
					break _loop32;
				}
				
			} while (true);
			}
			_t = __t30;
			_t = _t.getNextSibling();
			((GrammarAST)t).setDim(w, h);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"LEXER",
		"PARSER",
		"TREE_PARSER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"TOKEN_RANGE",
		"CHAR_RANGE",
		"NOT",
		"EPSILON",
		"ALT",
		"EOR",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LITERAL",
		"INT",
		"OR",
		"RANGE",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RULE_REF",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"WILD_CARD"
	};
	
	}
	
