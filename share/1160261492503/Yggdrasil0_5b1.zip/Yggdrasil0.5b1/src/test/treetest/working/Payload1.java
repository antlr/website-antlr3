// Yggdrasil generated type class
import org.antlr_yggdrasil.runtime.PayloadToken;

public class Payload1 extends PayloadToken {
	private Integer foo = null;
	
	public Payload1(int type, String txt) {
		super(type, txt);
	}

	public Integer getFoo() {
		return foo;
	}

	public void setFoo(Integer tmp_) {
		foo = (Integer) tmp_;
	}

}
