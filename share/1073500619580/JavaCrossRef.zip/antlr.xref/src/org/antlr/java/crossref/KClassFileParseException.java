package org.antlr.java.crossref;

import java.io.*;

/**
* Thrown if ClassFileReader encounters a corrupt class file.
* 
* @see KClassFileReader
*/
public class KClassFileParseException extends IOException {
	public KClassFileParseException(String msg) {
		super(msg);
	}
}