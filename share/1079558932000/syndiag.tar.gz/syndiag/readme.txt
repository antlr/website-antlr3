A Syntax Diagram Generator for ANTLR

Jia Zheng

Usage:

$ java edu.usfca.syndiag.Main [-wrap] < file.g

A Swing window will be displayed with your syntax diagram.

You can contact Jennifer Zheng (jzheng@cs.usfca.edu) with questions.
