/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

/** Idiot level CharSequence class to support editable token text
 * 
 * @author lgc
 *
 */
public class CharacterSequence implements CharSequence {

	char[] data = null;
	int first;
	public int last;
	public static int increment = 20000;
	
	public CharacterSequence(char[] data) {
		this.data = data;
		first = 0;
		last = 0;
	}
	
	public CharacterSequence(char[] data, int start, int end) {
		this.data = data;
		this.first = start;
		this.last = end;
	}

	public int length() {
		return last - first;
	}

	public char charAt(int arg0) {
		return data[first + arg0];
	}

	public CharSequence subSequence(int arg0, int arg1) {
		return new CharacterSequence(data, first+arg0, first+arg1);
	}
	
	public int addChars(char[] buf, int start, int end) {
		int len = end - start;
		int retval = last;
		
		if ((data.length < last + len) || first != 0) {
			char[] ndata = new char[last - first + increment];
			for (int i=0; i<last - first; i++)
				ndata[i] = data[first + i];
			
			data = ndata;
		}
		
		for (int i=0; i<len; i++) {
			data[last++] = buf[start + i];
		}
		
		return retval;
	}

	public char[] getData() {
		return data;
	}
	
	public String toString() {
		return new String(data, first, last - first + 1);
	}
}
