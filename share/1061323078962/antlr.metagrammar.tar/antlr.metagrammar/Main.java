import java.awt.event.*;
import java.io.StringReader;
import java.util.StringTokenizer;

import antlr.*;
import antlr.collections.*;
import antlr.debug.misc.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ANTLRLexer lexer = new ANTLRLexer(System.in);
        ANTLRParser parser = new ANTLRParser(lexer);
        parser.setASTNodeClass("GrammarAST");
        parser.grammar();
        AST grammarTree = parser.getAST();
        System.out.println(grammarTree.toStringList());

        print((GrammarAST)grammarTree);

        ASTFactory factory = new ASTFactory();
        AST r = factory.create(0,"AST ROOT");
        r.setFirstChild(grammarTree);
        final ASTFrame frame = new ASTFrame("ANTLR AST", r);
        frame.setVisible(true);
        frame.addWindowListener(
				new WindowAdapter() {
				    public void windowClosing (WindowEvent e) {
					frame.setVisible(false); // hide the Frame
					frame.dispose();
					System.exit(0);
				    }
				}
				);
    }

    public static void print(GrammarAST t) {
        System.out.println(toString(t));
    }

		public static String toString(GrammarAST t) {
        String s = null;
        try {
            s = new ANTLRTreePrinter().toString((AST)t);
        }
        catch (Exception e) {
            System.err.println("Problems printing tree: "+t);
            e.printStackTrace(System.err);
        }
        return s;
    }


}
