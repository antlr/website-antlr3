package org.antlr.test;

public class DebugTestAutoAST extends TestAutoAST {
	public DebugTestAutoAST() {debug=true;}
}
