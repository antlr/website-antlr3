 

import java.util.Vector;

/** Represents the definition of a field (class or instance).
 */
public class FieldVariable extends Variable {
    public FieldVariable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    public void dump() {
        tab();
        if ( type!=null ) {
            System.out.println("field "+type.getFullyQualifiedName()+" "+getName());
        }
        else {
            System.out.println("field "+getName());
        }
    }
}
