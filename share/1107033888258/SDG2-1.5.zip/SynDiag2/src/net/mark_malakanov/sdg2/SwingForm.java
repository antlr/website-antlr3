package net.mark_malakanov.sdg2;

/*
 * [The "BSD licence"]
 * Copyright (c) Mark Malakanov 2004
 * All rights reserved.
 *
 * $Header: d:\\cvsroot/SDG2/src/net/mark_malakanov/sdg2/SwingForm.java,v 1.9 2005/01/29 21:44:09 Mark Exp $
 *
 * Modification Log
 * $Log: SwingForm.java,v $
 * Revision 1.9  2005/01/29 21:44:09  Mark
 * added hourglass cursor in Save As file
 *
 * Revision 1.8  2005/01/25 08:00:03  Mark
 * save menu items grayed
 *
 * Revision 1.7  2005/01/25 07:41:41  Mark
 * dialogs centered
 *
 * Revision 1.6  2005/01/03 13:16:48  Mark
 * minor
 *
 * Revision 1.5  2004/12/30 01:53:28  Mark
 * resizing of width added
 *
 * Revision 1.4  2004/12/29 20:38:32  Mark
 * SdgBody separated with GUI. Multifile output command line params added.
 *
 * Revision 1.3  2004/12/28 07:47:47  Mark
 * CVS keywords added
 *
 *
 */
import antlr.*;

import antlr.collections.*;

import antlr.debug.misc.*;

import edu.usfca.syndiag.*;
import edu.usfca.syndiag.ANTLRLexer;
import edu.usfca.syndiag.ANTLRParser;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.*;

import java.io.*;

import java.util.*;

import javax.imageio.*;
import javax.imageio.spi.IIORegistry;
import javax.imageio.spi.ImageWriterSpi;

import javax.swing.*;
import javax.swing.plaf.basic.*;
import javax.swing.text.Element;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLWriter;


public class SwingForm implements ActionListener {
    AST ast;
    DrawDemo demo;
    JFrame frm;
    SdgBody sdgBody;
    JMenuItem menuItemSaveAs, menuItemSaveAsHTML, menuItemSetWidth, menuItemDiagStyle;
    

    public SwingForm(SdgBody sdgBody) {
        this.sdgBody = sdgBody;
    }

    public JMenuBar createMenuBar() {
        // Menu
        JMenuBar menuBar = new JMenuBar();

        JMenu menu = new JMenu("File");
        menu.setMnemonic(KeyEvent.VK_F);
        menu.getAccessibleContext().setAccessibleDescription("File functions");
        menuBar.add(menu);

        JMenuItem menuItem = new JMenuItem("Open", KeyEvent.VK_O);
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
                ActionEvent.CTRL_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Open ANTLR grammar file");
        menuItem.addActionListener(this);
        menu.add(menuItem);

        menuItem = new JMenuItem("Save As", KeyEvent.VK_S);
        menuItem.setEnabled(false);
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
                ActionEvent.CTRL_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Save image to file");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        menuItemSaveAs = menuItem;
        
        menuItem = new JMenuItem("Save As HTML and Multiple Files",
                KeyEvent.VK_S);
        menuItem.setEnabled(false);
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
                ActionEvent.CTRL_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Save every rule to a separate file");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        menuItemSaveAsHTML = menuItem;
        

        menu.addSeparator();
        menuItem = new JMenuItem("Exit", KeyEvent.VK_E);
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_4,
                ActionEvent.ALT_MASK));
        menuItem.addActionListener(this);
        menu.add(menuItem);

        JMenu optMenu = new JMenu("Options");
        optMenu.setMnemonic(KeyEvent.VK_O);
        optMenu.getAccessibleContext().setAccessibleDescription("Options");
        menuBar.add(optMenu);
        optMenu.addSeparator();
        menuItem = new JMenuItem("Set Width", KeyEvent.VK_W);
        menuItem.setEnabled(false);
        menuItem.addActionListener(this);
        optMenu.add(menuItem);
        menuItemSetWidth = menuItem;
        
        menuItem = new JMenuItem("Diagram Style", KeyEvent.VK_S);
        menuItem.setEnabled(false);
        menuItem.addActionListener(this);
        optMenu.add(menuItem);
        menuItemDiagStyle = menuItem;
        
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        helpMenu.getAccessibleContext().setAccessibleDescription("Help");
        menuBar.add(helpMenu);

        helpMenu.addSeparator();
        menuItem = new JMenuItem("About", KeyEvent.VK_A);
        menuItem.addActionListener(this);
        helpMenu.add(menuItem);

        return menuBar;
    }

    public void createForm() {
        if (frm != null) {
            return;
        }

        frm = new JFrame("ANTLR syntax diagram");

        frm.setJMenuBar(createMenuBar());

        demo = new DrawDemo();

        JScrollPane sp = new JScrollPane(demo);

        frm.setContentPane(sp);

        frm.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    frm.setVisible(false);
                    frm.dispose();
                    System.exit(0);
                }
            });

        frm.pack();
        frm.setSize(new Dimension(800, 600));
        frm.setVisible(!Main.isBlind);
    }

    public void draw(AST t) {
        this.ast = t;
        demo.init();
        demo.setDiagramStyle(sdgBody.diagramStyle);
        demo.setAST(ast);
        demo.repaint(demo.getVisibleRect());
    }

    public void actionPerformed(ActionEvent e) {
        String filename;
        JMenuItem source = (JMenuItem) (e.getSource());

        if (source.getText().equals("Save As")) {
            try {
                JFileChooser chooser = new JFileChooser(".");

                IIORegistry iior = IIORegistry.getDefaultInstance();
                Iterator spi = iior.getServiceProviders(ImageWriterSpi.class,
                        true);

                while (spi.hasNext()) {
                    ImageWriterSpi writerSpi = (ImageWriterSpi) spi.next();
                    String fn = writerSpi.getDescription(Locale.US);
                    String[] sfxs = writerSpi.getFileSuffixes();
                    UniversalFilter uf = new UniversalFilter(sfxs, fn);
                    chooser.addChoosableFileFilter(uf);
                }

                chooser.addChoosableFileFilter(new UniversalFilter("svg",
                        "SVG Vector Image"));

                int returnVal = chooser.showSaveDialog(null);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    frm.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    sdgBody.saveAsFile(ast,
                        chooser.getSelectedFile().getAbsolutePath());
                    frm.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            } catch (java.io.IOException x) {
                throw new RuntimeException(x);
            }
        } else if (source.getText().equals("Open")) {
            try {
                JFileChooser chooser = new JFileChooser(".");

                chooser.addChoosableFileFilter(new UniversalFilter("g",
                        "ANTLR grammar"));
                
                int returnVal = chooser.showOpenDialog(null);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    String[] s2 = chooser.getSelectedFile().getName().split("\\.");
                    Main.grammarName = s2[0];
                    frm.setTitle("SDG2: " + Main.grammarName);

                    frm.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                    sdgBody.load(new FileInputStream(chooser.getSelectedFile()
                                                            .getAbsolutePath()));
                    menuItemSaveAs.setEnabled(true);
                    menuItemSaveAsHTML.setEnabled(true);
                    menuItemSetWidth.setEnabled(true);
                    menuItemDiagStyle.setEnabled(true);
                    
                    draw(sdgBody.grammarTree);
                    
                    frm.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            } catch (Exception x) {
                throw new RuntimeException(x);
            }
        } else if (source.getText().equals("Exit")) {
            System.exit(0);
        } else if (source.getText().equals("Save As HTML and Multiple Files")) {
            SaveToMultipleFilesDialog smfd = new SaveToMultipleFilesDialog(frm,
                    "Save As HTML and Multiple Files", true);
            smfd.setUniformName(Main.grammarName);
            smfd.pack();
            //smfd.setLocationRelativeTo(frm);
            //smfd.setLocationRelativeTo(null);
            int x = frm.getWidth()/2 - 200 + frm.getX();
            int y = frm.getHeight()/2 - 200 + frm.getY();
            smfd.setLocation(x,y);
            smfd.setSize(400, 342);
            //smfd.setLocationByPlatform(true);
            smfd.setVisible(true);
            
            if (smfd.getResult().equals("OK")) {
                try {
                    HTMLandFilesBackGroundSaver t = new HTMLandFilesBackGroundSaver(sdgBody,
                            smfd.getHtmlDirName(), smfd.getHtmlFileName(),
                            smfd.getImgFormat(), smfd.getHtmlTitle(),
                            smfd.getHtmlHeader(), smfd.getHtmlImgBorder());
                    ProgressMonitor progressMonitor = new ProgressMonitor(frm,
                            "Saving multiple files", "", 0, 0);
                    progressMonitor.setMillisToDecideToPopup(10);
                    progressMonitor.setMillisToPopup(0);
                    t.setProgressMonitor(progressMonitor);
                    t.start();

                    //saveAsHTMLandFiles(smfd.getHtmlDirName(),smfd.getHtmlFileName(),smfd.getImgFormat(),
                    //smfd.getHtmlTitle(),smfd.getHtmlHeader(),smfd.getHtmlImgBorder(), progressMonitor);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        } else if (source.getText().equals("Set Width")) {
            WidthDialog wd = new WidthDialog(frm, "WidthDialog", true);
            wd.setDiagramWidth(sdgBody.diagramWidth);

            int x = frm.getWidth()/2 - wd.getWidth()/2 + frm.getX();
            int y = frm.getHeight()/2 - wd.getHeight()/2 + frm.getY();
            wd.setLocation(x,y);
            wd.setVisible(true);

            if (wd.resultValue.equals("OK")) {
                frm.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                sdgBody.calcLayout(wd.getDiagramWidth(),
                    sdgBody.diagramWidth - 300);
                draw(sdgBody.grammarTree);
                frm.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        } else if (source.getText().equals("Diagram Style")) {
            DiagramTypeDialog sd = new DiagramTypeDialog(frm, "DiagramTypeDialog", true);
            sd.setDiagramStyle(sdgBody.diagramStyle);

            int x = frm.getWidth()/2 - sd.getWidth()/2 + frm.getX();
            int y = frm.getHeight()/2 - sd.getHeight()/2 + frm.getY();
            sd.setLocation(x,y);
            sd.setVisible(true);

            if (sd.resultValue.equals("OK")) {
                frm.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                sdgBody.diagramStyle = sd.getDiagramStyle();
                draw(sdgBody.grammarTree);
                frm.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        } else if (source.getText().equals("About")) {
            JOptionPane.showMessageDialog(frm, new About(), "About",
                JOptionPane.PLAIN_MESSAGE);
        }
    }
}
