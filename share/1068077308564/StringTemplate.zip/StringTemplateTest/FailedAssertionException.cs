using System;

namespace StringTemplateTest {
	/// <summary>
	/// Summary description for FailedAssertionException.
	/// </summary>
	public class FailedAssertionException : Exception {
	}
}
