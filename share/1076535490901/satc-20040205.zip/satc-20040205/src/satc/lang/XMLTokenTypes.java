// $ANTLR : "XMLLexer.g" -> "XMLLexer.java"$

package satc.lang; 

public interface XMLTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int XF_WS = 4;
	int XF_ID = 5;
	int XC_CLOSE = 6;
	int XC_WS = 7;
	int XC_WORD = 8;
	int WS = 9;
	int TAG_START = 10;
	int TAG_END = 11;
	int ID = 12;
	int ASSIGN = 13;
	int STRING_LITERAL = 14;
	int XC_OPEN = 15;
}
