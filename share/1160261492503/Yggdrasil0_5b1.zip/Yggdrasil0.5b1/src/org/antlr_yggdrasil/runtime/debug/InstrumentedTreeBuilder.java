/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime.debug;

import java.util.ArrayList;

import org.antlr_yggdrasil.runtime.TreeBuilder;

import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.ReferenceCarrier;
import org.antlr_yggdrasil.runtime.TreeCodeBlock;

public class InstrumentedTreeBuilder extends TreeBuilder implements TreeInstrumentation {
	private CollectedMeasures measure;

	public InstrumentedTreeBuilder() {
		// TODO Auto-generated constructor stub
	}

	public InstrumentedTreeBuilder(int size) {
		super(size);
		// TODO Auto-generated constructor stub
	}

	public InstrumentedTreeBuilder(int size, int incr) {
		super(size, incr);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#setMeasure(org.antlr_yggdrasil.runtime.debug.CollectedMeasures)
	 */
	public void setMeasure(CollectedMeasures measure) {
		this.measure = measure;
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#getMeasure()
	 */
	public CollectedMeasures getMeasure() {
		return measure;
	}
	
	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#addPayload(int, org.antlr_yggdrasil.runtime.Payload)
	 */
	public void addPayload(int code, Payload item) {
		if (isDisabled())
			return;
		
		super.addPayload(code, item);
	}
	
	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#addCarrier(int, org.antlr_yggdrasil.runtime.Carrier)
	 */
	public void addCarrier(int code, Carrier item) {
		if (isDisabled())
			return;
		
		super.addCarrier(code, item);
	}
	
	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#add(java.util.Vector)
	 */
	public void add(ArrayList item) {
		if (isDisabled())
			return;
		
		super.add(item);
	}
	
	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#processFromMark()
	 */
	public void processFromMark() {
		if (isDisabled())
			return;
		
		super.processFromMark();
	}
	
	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#processList(java.util.Vector, int)
	 */
	public void processList(ArrayList v, int direction) {
		if (isDisabled())
			return;
		
		super.processList(v, direction);
	}

	/* (non-Javadoc)
	 * @see org.antlr_yggdrasil.runtime.debug.TreeInstrumentation#setNextDown(boolean)
	 */
	public void setNextDown(boolean nextIsDown) {
		if (isDisabled())
			return;
		
		super.setNextDown(nextIsDown);
	}

}
