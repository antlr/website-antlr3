/*
 [The "BSD licence"]
 Copyright (c) 2006 Loring Craymer
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr_yggdrasil.runtime;

import java.util.HashMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;

/**
 * @author lgc
 *
 */
public class TypeMap  {
	private HashMap<String, TypeInfo> typeInfo = new HashMap<String, TypeInfo>();
	private HashMap<String, String> varInfo = new HashMap<String, String>();
	private HashMap<String, String> aliases;
	
	
	private String genericType = "Object";

	/**
	 * 
	 */
	public TypeMap() {
	}
	
	public void addVariable(String name, String type) {
		if (varInfo.containsKey(name)) {
			;	// TODO:  throw exception here
		}
		varInfo.put(name, type);
	}
	
	public void addType(TypeInfo type) {
		typeInfo.put(type.getName(), type);
		type.setTypemap(this);
	}
	
	public void addType(String name, TypeInfo type) {
		typeInfo.put(name, type);
		type.setTypemap(this);
	}
	
	public boolean itemIsAType(String item_, String type) {
		String item = item_.replace('.', '/');
		String fields[] = item.split("/");
		String name = fields[0];
		String ctype = null;
		name = fields[0];
		
		TypeInfo info = getInfo(varInfo.get(name));
		
		for (int i = 1; i<fields.length; i++) {
			name = fields[i];
			ctype = info.getTypeOf(name);		
			info = (TypeInfo) getTypeInfo().get(ctype);
		}
		return (info.isa(type));
	}
	
	public TypeInfo getInfo(String key) {
		return (TypeInfo) getTypeInfo().get(key);
	}
	
	public void setInfo(TypeInfo info) {
		getTypeInfo().put(info.getName(), info);
	}
	
	public void relateTypes() {
		Iterator iter = getTypeInfo().keySet().iterator();
		String key = null;
		
		while (iter.hasNext()) {
			key = (String) iter.next();
			setAncestors(key);
		}
	}
	
	void setAncestors(String key) {
		HashSet ancestors = new HashSet();
		String nextKey = key;
		String alias = null;
		TypeInfo info = (TypeInfo) getTypeInfo().get(key);
		TypeInfo baseInfo = info;
		
		if (genericType != null) {
			while (!info.getParent().equals(genericType)) {
				nextKey = info.getParent();
				alias = typeInfo.get(nextKey).getName();
				ancestors.add(alias);
				info = (TypeInfo) getTypeInfo().get(nextKey);
			}
		
			ancestors.add(genericType);
		}
		else {
			while (info != null) {
				nextKey = info.getParent();
				alias = typeInfo.get(nextKey).getName();
				ancestors.add(alias);
				info = (TypeInfo) getTypeInfo().get(nextKey);				
			}
		}
		alias = typeInfo.get(nextKey).getName();
		baseInfo.setBaseType(alias);
		
		baseInfo.setAncestors(ancestors);
	}

	/**
	 * @param varInfo The varInfo to set.
	 */
	public void setVarInfo(HashMap varInfo) {
		this.varInfo = varInfo;
	}

	/**
	 * @return Returns the varInfo.
	 */
	public HashMap getVarInfo() {
		return varInfo;
	}
	
	public String getTypeOf(String var) {
		return (varInfo.get(var));
	}

	public void setTypeInfo(HashMap typeInfo) {
		this.typeInfo = typeInfo;
	}

	public HashMap getTypeInfo() {
		return typeInfo;
	}

	public void setGenericType(String genericType) {
		this.genericType = genericType;
	}

	public String getGenericType() {
		return genericType;
	}

	public void addAlias(String name, String type) {
		if (aliases == null)
			aliases = new HashMap<String, String>();
		
		aliases.put(name, type);
	}
	
	public String getAlias(String name) {
		return aliases.get(name);
	}
	
	public String addGenericType(String base, ArrayList<String> types) {
		String name = specializedName(base, types);
		if (name == null)
			return name;
		
		TypeInfo baseInfo = typeInfo.get(base);
		TypeInfo copy = getInfo(name);
		if (copy != null)	// already present
			return name;
		
		copy = baseInfo.clone();		
		copy.resolveTypeTemplates(types);
		copy.setName(name);
		copy.setParent(base);
		addType(copy);
		
		return name;
	}

	public String specializedName(String base, ArrayList<String> types) {
		String name = aliases.get(base);
		if (name == null)
			name = base;
		
		name += "<";
		
		Iterator<String> iter = types.iterator();
		if (!iter.hasNext())
			return null;
		
		name += iter.next();
		while (iter.hasNext()) {
			name += ", " + iter.next();
		}
		name += ">";
		return name;
	}
	
	public TypeInfo getSpecialization(String base, ArrayList<String> types) {
		String name = specializedName(base, types);
		if (name == null)
			name = base;
		
		return getInfo(name);
	}
}
