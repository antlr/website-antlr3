package org.antlr.java.crossref;

import java.util.Vector;


/**
* A common base class for KClassInfo, KMethodInfo, and KFieldInfo.
*
* @see KClassInfo
* @see KMethodInfo
* @see KFieldInfo
*/
public class KCommonInfo {
	short accessFlags = 0;
	Vector attributes = new Vector();
	String name;

	/**
	* Set the name of this class/method/field.
	*/
	public void setName(String name) {
		this.name = name;
	}

	/**
	* Get the name of this class/method/field.
	*/
	public String getName() {
		return name;
	}

	/**
	* Set the access flags of the class.
	* 
	* @see KAccessFlags
	*/
	public void setAccessFlags(short accessFlags) {
		this.accessFlags = accessFlags;
	}

	/**
	* Get the access flags of the class.
	* 
	* @see KAccessFlags
	*/
	public short getAccessFlags() {
		return accessFlags;
	}

	/**
	* Add a <i>non-standard</i> attribute.  This does not include the Code 
	* attribute for methods, the SourceFile attribute for classes, or the 
	* ConstantValue attribute for fields.
	*/
	public void addAttribute(KAttributeInfo attributeInfo) {
		attributes.addElement(attributeInfo);
	}

	/**
	* Get all <i>non-standard</i> attributes.  This does not include the Code 
	* attribute for methods, the SourceFile attribute for classes, or the 
	* ConstantValue attribute for fields.
	*/
	public KAttributeInfo[] getAttributes() {
		KAttributeInfo[] list = new KAttributeInfo[attributes.size()];
		attributes.copyInto(list);
		return list;
	}
}