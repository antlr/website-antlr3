package org.antlr.java.crossref;

import java.io.*;

/**
* A class for storing information about line numbers.
* This class represents one row in the LineNumberTable.
*
* @see KCodeInfo#setLineNumberTable(KLineNumberInfo[])
*/
public class KLineNumberInfo {
	public short startPC, lineNumber;

	public KLineNumberInfo(short startPC, short lineNumber) {
		this.startPC = startPC;
		this.lineNumber = lineNumber;
	}
}
