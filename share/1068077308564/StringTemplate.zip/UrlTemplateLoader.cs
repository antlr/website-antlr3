using System;
using System.Net;
using System.IO;
using System.Text;

namespace Antlr.StringTemplate {
	/// <summary>
	/// Summary description for UrlTemplateLoader.
	/// </summary>
	public class UrlTemplateLoader : IStringTemplateLoader {
		private Uri baseUrl;

		public UrlTemplateLoader() : this(null) {
		}

		public UrlTemplateLoader(String baseUrlString) {
			this.Base = baseUrlString;
		}

		/// <summary>
		/// Convert a filename relativePath/name.st to relativePath/name.
		/// </summary>
		/// <param name="relativePath">Relative template path.</param>
		/// <returns>The template name.</returns>
		public String DeriveTemplateNameFromLocation(String location) {
			return Path.ChangeExtension(location, null);
		}

		/// <summary>
		/// Derive a template path from a name.
		/// </summary>
		/// <param name="templateName">Template name.</param>
		/// <returns>The template path.</returns>
		public String DeriveLocationFromTemplateName(String templateName) {
			return templateName + ".st";
		}

		public String LoadTemplate(String name, String location) {
			Uri uri = new Uri(this.baseUrl + "/" + location);
			WebClient client = new WebClient();			
			client.Credentials = CredentialCache.DefaultCredentials;
			byte[] data = client.DownloadData(uri.ToString());

			String respEncoding = client.ResponseHeaders["Content-Encoding"];
			Encoding enc = Encoding.UTF8;

			if (respEncoding != null) {
				enc = Encoding.GetEncoding(respEncoding);
			}

			String templateSource = enc.GetString(data);

			if ( templateSource == null || templateSource.Length == 0 ) {
				throw new Exception("No text in template '" + name + "'");
			}

			// strip newlines etc.. from front/back since filesystem
			// may add newlines etc...
			return templateSource.Trim();
		}

		public String Base { 
			get {
				return this.baseUrl.ToString();
			}
			set{
				if (value == null) {
					UriBuilder ub = new UriBuilder("file", null, 0, 
						AppDomain.CurrentDomain.BaseDirectory);
					this.baseUrl = ub.Uri;
				}
				else {
					this.baseUrl = new Uri(value);
				}
			}
		}
	}
}
