package org.antlr.java.crossref;


import java.util.*;

/** A File scope represents a compilation unit: a package, some
 *  imports, and one or more type definitions.
 */
public class FileScope extends Scope {
	/**
	 * Field printDebug
	 */
	static final boolean printDebug = true;
	/**
	 * Field thisPackage
	 */
	protected PackageScope thisPackage = null;

	/** List of imported scopes; used for symbol resolution.  This list
	 *  contains both packages and class scopes.
	 */
	protected Vector imports = new Vector();

	/**
	 * Constructor for FileScope
	 * @param project CodeProject
	 * @param name String
	 * @param parent Scope
	 */
	public FileScope(CodeProject project, String name, Scope parent) {
		super(project,name,parent);
		if ( parent!=null ) {
			parent.addScope(this); // double-link; parent knows subpackages
		}
	}

	/** If fully qualified, just look it up else look up the name in
	 *  the current package or in one of the imports.
	 * @param name String
	 * @return ClassScope
	 */
	public ClassScope resolveClass(String name) {
		if ( name==null ) {
			return null;
		}
		if(FileScope.printDebug && CodeProject.printDebug)
			System.out.println("FileScope:resolveClass " + "Resolve Class "+name);
		if ( name.indexOf('.')>0 ) { // fully qualified?
			return project.getClassScope(name);
		}
		// is it in one of the packages / classes listed in imports?
		for (int i = 0; i < imports.size(); i++) {
			Scope scope = (Scope)imports.elementAt(i);
			if ( scope==null ) {
				if(FileScope.printDebug && CodeProject.printDebug )
					System.out.println("FileScope:resolveClass " + "# import scope "+i+" is null!");
				continue;
			}
			if(FileScope.printDebug && CodeProject.printDebug)
				System.out.println("FileScope:resolveClass " + "Checking scope "+scope.getName());
			if((scope instanceof ClassScope) && name.equalsIgnoreCase(scope.getName()))
			{
				if(FileScope.printDebug && CodeProject.printDebug)
					System.out.println("FileScope:resolveClass " + "Resolving to "+scope.getFullyQualifiedName());
				return (ClassScope) scope;
			}
		}
		// is it in current package?
		ClassScope scope = thisPackage.resolveClass(name);
		if ( scope!=null ) {
			if(FileScope.printDebug && CodeProject.printDebug)
				System.out.println("FileScope:resolveClass " + "resolved to current package "+thisPackage.getFullyQualifiedName());
			return scope;
		}
		if(FileScope.printDebug && CodeProject.printDebug)
			System.out.println("FileScope:resolveClass " + "unresolved");
		return null;
	}

	/**
	 * Method addImport
	 * @param scope Scope
	 */
	public void addImport(Scope scope) {
		if ( scope==null ) {
			return;
		}
		imports.addElement(scope);
	}

	/**
	 * Method addScope
	 * @param s Scope
	 */
	public void addScope(Scope s) {
		if ( thisPackage!=null ) {
			thisPackage.addScope(s);
		}
	}

	// GETTER/SETTERS
	/**
	 * Method getPackageScope
	 * @return PackageScope
	 */
	public PackageScope getPackageScope() {
		return thisPackage;
	}

	/**
	 * Method setPackageScope
	 * @param thisPackage PackageScope
	 */
	public void setPackageScope(PackageScope thisPackage) {
		this.thisPackage = thisPackage;
	}

	/**
	 * Method toString
	 * @return String
	 */
	public String toString() {
		StringBuffer s = new StringBuffer();
		s.append("File ");
		s.append(getName());
		s.append("\n");
		if ( getPackageScope()!=null ) {
			s.append("package "+getPackageScope().getFullyQualifiedName()+"\n");
		}
		if ( imports!=null && imports.size()>0 ) {
			s.append("imports ");
		}
		for (int i = 0; i<imports.size(); i++) {
			s.append("\n\timports "+
			((Scope)imports.elementAt(i)).getFullyQualifiedName()+"\n");
		}
		return s.toString();
	}

	/**
	 * Method getName
	 * @return String
	 */
	public String getName() {
		return "["+super.getName()+"]";
	}

	/**
	 * Method getFullyQualifiedName
	 * @return String
	 */
	public String getFullyQualifiedName() {
		if ( getPackageScope()==null ) {
			return "[default]";
		}
		return getPackageScope().getFullyQualifiedName();
	}

	/**
	 * Method dump
	 * @see org.antlr.java.crossref.Scope#dump()
	 */
	public void dump() {
//		handled elsewhere
//    if(parent != null)
//			parent.dump();
		return;
	}

	/**
	 * Method addScopeMember
	 * @param s Scope
	 * @see org.antlr.java.crossref.Scope#addScopeMember(org.antlr.java.crossref.Scope)
	 */
	public void addScopeMember(Scope s) {
		return;
	}

}
