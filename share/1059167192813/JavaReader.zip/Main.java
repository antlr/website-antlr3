import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.sax.*;
import org.xml.sax.*;
import javax.xml.transform.stream.StreamResult;

class Main {

    public static void main(String[] args) {
		// Use a try/catch block for parser exceptions
		try {
			if (args.length > 1 ) {
        JavaReader jr = new JavaReader();
        jr.setContentHandler(getHandler(new FileOutputStream(args[1]),"UTF-8"));
        jr.parse(args[0]);
      }
			else
				System.out.println("Usage: java Main <directory or file name> <destination>");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

  public static ContentHandler getHandler(OutputStream out, String encoding) throws Exception {

      TransformerFactory factory = TransformerFactory.newInstance();

      if (!(factory.getFeature(SAXSource.FEATURE) || factory.getFeature(SAXResult.FEATURE))) {
        throw new Exception("Der xsl-Parser ist nicht TrAX konform");
      }

    SAXTransformerFactory saxFactory = ((SAXTransformerFactory) factory);

    TransformerHandler handler;

    handler = saxFactory.newTransformerHandler();
    handler.setResult(new StreamResult(new OutputStreamWriter(out, encoding)));
    return handler;
  }


}

