 

import java.util.*;

public class PackageScope extends Scope {
    protected Hashtable packages = new Hashtable();
    protected Hashtable classes = new Hashtable(53);

    public PackageScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
        if ( parent!=null ) {
            parent.addScope(this); // double-link; parent knows subpackages
        }
    }

    public ClassScope resolveClass(String name) {
        if ( name==null ) {
            return null;
        }
        return (ClassScope)classes.get(name);
    }

    public void addScope(Scope s) {
        if ( s==null ) {
            return;
        }

        // System.out.println("Add scope in PackageScope "+s);

        // can add either a package or class
        if ( s instanceof PackageScope ) {
            packages.put(s.getName(), s);
        }
        else if ( s instanceof ClassScope ) {
            project.setClassScope(s.getFullyQualifiedName(), (ClassScope)s);
            classes.put(s.getName(), s);
        }
    }

    public PackageScope getPackageScope(String name) {
        return (PackageScope)packages.get(name);
    }

    // GETTER/SETTERS

    public Hashtable getPackages() {
        return packages;
    }

    public void setPackages(Hashtable subpackages) {
        this.packages = subpackages;
    }

    public Hashtable getClasses() {
        return classes;
    }

    public void setClasses(Hashtable classes) {
        this.classes = classes;
    }

    public void dump() {
        tab();
        System.out.println("-"+getName());
        tabIndent++;
        Enumeration keys = packages.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            PackageScope ps = (PackageScope)packages.get(name);
            ps.dump();
        }
        keys = classes.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            ClassScope cs = (ClassScope)classes.get(name);
            cs.dump();
        }
        tabIndent--;
    }

    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("Package ");
        s.append(getFullyQualifiedName());
        s.append("\n");
        // System.out.println("package: "+packages);
        // System.out.println("classes: "+classes);
        Enumeration keys = packages.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            PackageScope ps = (PackageScope)packages.get(name);
            s.append(ps);
        }
        keys = classes.keys();
        while (keys.hasMoreElements()) {
            String name = (String)keys.nextElement();
            ClassScope cs = (ClassScope)classes.get(name);
            s.append(cs);
            s.append("\n");
        }
        return s.toString();
    }
}
