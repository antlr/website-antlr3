package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;

public class DefaultPayloadTest extends TestCase {

	public static void main(String[] args) {
		junit.textui.TestRunner.run(DefaultPayloadTest.class);
	}

	public DefaultPayloadTest(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/*
	 * Class under test for void DefaultPayload()
	 */
	public void testDefaultPayload() {
	}

	/*
	 * Class under test for void DefaultPayload(int, String)
	 */
	public void testDefaultPayloadintString() {
	}

	/*
	 * Class under test for void DefaultPayload(DefaultPayload)
	 */
	public void testDefaultPayloadDefaultPayload() {
	}

	public void testGetText() {
	}

	public void testGetType() {
	}

	public void testSetText() {
	}

	public void testSetType() {
	}

	public void testWrap() {
	}

}
