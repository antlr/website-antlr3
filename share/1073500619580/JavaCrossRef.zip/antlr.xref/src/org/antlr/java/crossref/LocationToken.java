package org.antlr.java.crossref;

import antlr.Token;
/** ANTLR token including location
 */
public class LocationToken extends antlr.CommonToken
{
	/**
	 * Field filename
	 */
	private String filename = null;
	
    /**
     * Constructor for LocationToken
     */
    public LocationToken()
    {
    	super();	
    }
    
    /**
     * Constructor for LocationToken
     * @param type int
     * @param text String
     */
    public LocationToken(int type, String text)
    {
    	super(type, text);
    }
    
    /**
     * Constructor for LocationToken
     * @param t Token
     */
    public LocationToken(Token t) 
    {
		super(t.getType(), t.getText());
		setFilename(t.getFilename());
		setLine(t.getLine());
		setColumn(t.getColumn());
    }

	/**
	 * @return String
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

}