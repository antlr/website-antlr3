class Test {
	void Main() {
		int value;
		if (value < 1) {}
		if (value < 1 + 2) {}
	}
}
