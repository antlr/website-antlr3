package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.Queue;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.DefaultPayload;

public class QueueTest extends TestCase {
	Queue q = new Queue();

	public static void main(String[] args) {
		junit.textui.TestRunner.run(QueueTest.class);
	}

	public QueueTest(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		q.clear();
	}

	public void testGetFirst() {
		Payload p = new DefaultPayload();
		
		q.setFirst(p);
		Payload p2 = new DefaultPayload();
		q.setLast(p2);
		assertTrue(q.getFirst() == p);
		assertTrue(q.getFirst() == p2);
		
		assertTrue(q.size() == 0);
		
		q.setFirst(p);
		q.setFirst(p2);
		Payload p3 = new DefaultPayload();
		q.setLast(p3);
		
		assertTrue(q.getFirst() == p2);
		assertTrue(q.getFirst() == p);
		assertTrue(q.getFirst() == p3);
		assertTrue(q.size() == 0);
	}

	public void testGetLast() {
		Payload p = new DefaultPayload();
		Payload p1 = new DefaultPayload();
		Payload p2 = new DefaultPayload();
		
		q.setFirst(p);
		assertTrue(q.getLast() == p);
		
		q.setLast(p);
		q.setLast(p1);
		q.setFirst(p2);
		
		assertTrue(q.getLast() == p1);
		assertTrue(q.getLast() == p);
		assertTrue(q.getLast() == p2); 
	}

}
