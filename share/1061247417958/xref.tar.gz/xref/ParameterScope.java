 

import java.util.*;

/** Represents a group of parameters  */
public class ParameterScope extends CodeBlockScope {
    public ParameterScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    public void addScopeMember(Scope s) {
        if ( variables==null ) {
            variables=new Hashtable();
        }
        System.out.println("Add parameter scope member "+s);
        variables.put(s.getName(),s);
    }
}
