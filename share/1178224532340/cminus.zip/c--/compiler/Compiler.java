// $ANTLR 3.0b7 Compiler.g 2007-05-03 14:07:35

	import java.util.HashMap;
	import java.util.Vector;
	import java.util.Map;
    	import java.util.List;
	import java.io.*;
	import org.antlr.stringtemplate.*;
	import org.antlr.stringtemplate.language.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.stringtemplate.*;
import org.antlr.stringtemplate.language.*;
import java.util.HashMap;
public class Compiler extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "POS", "NEG", "POSTFIX", "PREFIX", "NOP", "PROGRAM", "FUNCTION", "VARDEF", "ARRDEF", "VARPAR", "ARRPAR", "BLOCK", "ASSIGN", "EXPR", "EXPRLIST", "CALL", "INDEX", "NOT", "NEGATE", "FUNCTIONS", "VARIABLES", "PARAMATERS", "STMTS", "NUM", "VAR", "TYPE", "ID", "INT", "RETURN", "READ", "WRITE", "WRITELN", "BREAK", "WHILE", "IF", "SCHAR", "SQUOTE", "CHAR", "LCHAR", "DIGIT", "LC", "UC", "NEWLINE", "WS", "COMMENT", "LINECOMMENT", "';'", "'['", "']'", "'('", "')'", "','", "'{'", "'}'", "'do'", "'for'", "'else'", "'unless'", "'='", "'or'", "'||'", "'and'", "'&&'", "'=='", "'!='", "'<>'", "'>'", "'<'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'!'", "'not'", "'++'", "'--'"
    };
    public static final int INDEX=20;
    public static final int TYPE=29;
    public static final int EXPR=17;
    public static final int VARPAR=13;
    public static final int PARAMATERS=25;
    public static final int ARRPAR=14;
    public static final int NEGATE=22;
    public static final int VARIABLES=24;
    public static final int SQUOTE=40;
    public static final int VARDEF=11;
    public static final int STMTS=26;
    public static final int PROGRAM=9;
    public static final int NEWLINE=46;
    public static final int FUNCTIONS=23;
    public static final int BLOCK=15;
    public static final int PREFIX=7;
    public static final int FUNCTION=10;
    public static final int INT=31;
    public static final int SCHAR=39;
    public static final int ASSIGN=16;
    public static final int POS=4;
    public static final int POSTFIX=6;
    public static final int DIGIT=43;
    public static final int EXPRLIST=18;
    public static final int LCHAR=42;
    public static final int ID=30;
    public static final int WHILE=37;
    public static final int WS=47;
    public static final int CHAR=41;
    public static final int WRITE=34;
    public static final int LC=44;
    public static final int COMMENT=48;
    public static final int LINECOMMENT=49;
    public static final int VAR=28;
    public static final int RETURN=32;
    public static final int IF=38;
    public static final int EOF=-1;
    public static final int NOP=8;
    public static final int BREAK=36;
    public static final int NUM=27;
    public static final int CALL=19;
    public static final int UC=45;
    public static final int NEG=5;
    public static final int NOT=21;
    public static final int WRITELN=35;
    public static final int READ=33;
    public static final int ARRDEF=12;

        public Compiler(TreeNodeStream input) {
            super(input);
        }
        
    protected StringTemplateGroup templateLib =
      new StringTemplateGroup("CompilerTemplates", AngleBracketTemplateLexer.class);

    public void setTemplateLib(StringTemplateGroup templateLib) {
      this.templateLib = templateLib;
    }
    public StringTemplateGroup getTemplateLib() {
      return templateLib;
    }
    /** allows convenient multi-value initialization:
     *  "new STAttrMap().put(...).put(...)"
     */
    public static class STAttrMap extends HashMap {
      public STAttrMap put(String attrName, Object value) {
        super.put(attrName, value);
        return this;
      }
      public STAttrMap put(String attrName, int value) {
        super.put(attrName, new Integer(value));
        return this;
      }
    }

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "Compiler.g"; }


    	CommonTreeNodeStream stream = (CommonTreeNodeStream)input;
    	Boolean global=true;
    	
    	int next_power_of_two(int v){
    		//FIXME Currently arrays are set to 2^16, and this function isn't used
    		double t=(double)v;
    		double nv=Math.log(t)/Math.log(2);
    		int res=(int)Math.ceil(nv);
    		return (int)Math.pow(2,res);
    	}

    	StringTemplateGroup mtemplates;



    public static class program_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start program
    // Compiler.g:35:1: program : ^( PROGRAM ^( VARIABLES (vars+= varDecl )* ) ^( FUNCTIONS (funs+= funDecl )* ) . ) EOF -> wrapper(globals=$varsfunctions=$funs);
    public final program_return program() throws RecognitionException {
        program_return retval = new program_return();
        retval.start = input.LT(1);

        List list_vars=null;
        List list_funs=null;
        RuleReturnScope vars = null;
        RuleReturnScope funs = null;
        List list_funDecl=new ArrayList();
        List list_varDecl=new ArrayList();

        	Main.symbols.reset_globals();

        try {
            // Compiler.g:40:3: ( ^( PROGRAM ^( VARIABLES (vars+= varDecl )* ) ^( FUNCTIONS (funs+= funDecl )* ) . ) EOF -> wrapper(globals=$varsfunctions=$funs))
            // Compiler.g:40:3: ^( PROGRAM ^( VARIABLES (vars+= varDecl )* ) ^( FUNCTIONS (funs+= funDecl )* ) . ) EOF
            {
            match(input,PROGRAM,FOLLOW_PROGRAM_in_program59); 

            match(input, Token.DOWN, null); 
            match(input,VARIABLES,FOLLOW_VARIABLES_in_program62); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:40:25: (vars+= varDecl )*
                loop1:
                do {
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( ((LA1_0>=VARDEF && LA1_0<=ARRDEF)) ) {
                        alt1=1;
                    }


                    switch (alt1) {
                	case 1 :
                	    // Compiler.g:40:26: vars+= varDecl
                	    {
                	    pushFollow(FOLLOW_varDecl_in_program67);
                	    vars=varDecl();
                	    _fsp--;

                	    if (list_vars==null) list_vars=new ArrayList();
                	    list_vars.add(vars.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop1;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            match(input,FUNCTIONS,FOLLOW_FUNCTIONS_in_program73); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:40:55: (funs+= funDecl )*
                loop2:
                do {
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==FUNCTION) ) {
                        alt2=1;
                    }


                    switch (alt2) {
                	case 1 :
                	    // Compiler.g:40:56: funs+= funDecl
                	    {
                	    pushFollow(FOLLOW_funDecl_in_program78);
                	    funs=funDecl();
                	    _fsp--;

                	    if (list_funs==null) list_funs=new ArrayList();
                	    list_funs.add(funs.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop2;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            matchAny(input); 

            match(input, Token.UP, null); 
            match(input,EOF,FOLLOW_EOF_in_program86); 

            // TEMPLATE REWRITE
            // 40:80: -> wrapper(globals=$varsfunctions=$funs)
            {
                retval.st = templateLib.getInstanceOf("wrapper",
              new STAttrMap().put("globals", list_vars).put("functions", list_funs));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end program

    public static class funDecl_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start funDecl
    // Compiler.g:43:1: funDecl : ^( FUNCTION TYPE name= ID ^( PARAMATERS (params+= paramDecl )* ) b+= block ) -> function(name=$nameparams=$paramscontent=$b);
    public final funDecl_return funDecl() throws RecognitionException {
        funDecl_return retval = new funDecl_return();
        retval.start = input.LT(1);

        CommonTree name=null;
        List list_params=null;
        List list_b=null;
        RuleReturnScope params = null;
        RuleReturnScope b = null;
        List list_paramDecl=new ArrayList();
        List list_block=new ArrayList();

        	global=false;
        	Main.symbols.enter_frame();

        try {
            // Compiler.g:52:3: ( ^( FUNCTION TYPE name= ID ^( PARAMATERS (params+= paramDecl )* ) b+= block ) -> function(name=$nameparams=$paramscontent=$b))
            // Compiler.g:52:3: ^( FUNCTION TYPE name= ID ^( PARAMATERS (params+= paramDecl )* ) b+= block )
            {
            match(input,FUNCTION,FOLLOW_FUNCTION_in_funDecl119); 

            match(input, Token.DOWN, null); 
            match(input,TYPE,FOLLOW_TYPE_in_funDecl121); 
            name=(CommonTree)input.LT(1);
            match(input,ID,FOLLOW_ID_in_funDecl125); 
            match(input,PARAMATERS,FOLLOW_PARAMATERS_in_funDecl128); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:52:40: (params+= paramDecl )*
                loop3:
                do {
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( ((LA3_0>=VARPAR && LA3_0<=ARRPAR)) ) {
                        alt3=1;
                    }


                    switch (alt3) {
                	case 1 :
                	    // Compiler.g:52:41: params+= paramDecl
                	    {
                	    pushFollow(FOLLOW_paramDecl_in_funDecl133);
                	    params=paramDecl();
                	    _fsp--;

                	    if (list_params==null) list_params=new ArrayList();
                	    list_params.add(params.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop3;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            pushFollow(FOLLOW_block_in_funDecl140);
            b=block();
            _fsp--;

            if (list_b==null) list_b=new ArrayList();
            list_b.add(b.getTemplate());


            match(input, Token.UP, null); 

            // TEMPLATE REWRITE
            // 52:72: -> function(name=$nameparams=$paramscontent=$b)
            {
                retval.st = templateLib.getInstanceOf("function",
              new STAttrMap().put("name", name).put("params", list_params).put("content", list_b));
            }



            }


            	global=true;
            	Main.symbols.exit_frame();

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end funDecl

    public static class paramDecl_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start paramDecl
    // Compiler.g:55:1: paramDecl : ( ^( VARPAR TYPE ID ) -> param(name=Main.symbols.get_variable($ID.text).num) | ^( ARRPAR TYPE name= ID ) -> array_param(name=Main.symbols.get_variable($ID.text).num));
    public final paramDecl_return paramDecl() throws RecognitionException {
        paramDecl_return retval = new paramDecl_return();
        retval.start = input.LT(1);

        CommonTree name=null;
        CommonTree ID1=null;
        CommonTree TYPE2=null;
        CommonTree TYPE3=null;

        try {
            // Compiler.g:55:13: ( ^( VARPAR TYPE ID ) -> param(name=Main.symbols.get_variable($ID.text).num) | ^( ARRPAR TYPE name= ID ) -> array_param(name=Main.symbols.get_variable($ID.text).num))
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==VARPAR) ) {
                alt4=1;
            }
            else if ( (LA4_0==ARRPAR) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("55:1: paramDecl : ( ^( VARPAR TYPE ID ) -> param(name=Main.symbols.get_variable($ID.text).num) | ^( ARRPAR TYPE name= ID ) -> array_param(name=Main.symbols.get_variable($ID.text).num));", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // Compiler.g:55:13: ^( VARPAR TYPE ID )
                    {
                    match(input,VARPAR,FOLLOW_VARPAR_in_paramDecl170); 

                    match(input, Token.DOWN, null); 
                    TYPE2=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_paramDecl172); 
                    ID1=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_paramDecl174); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_variable(ID1.getText(),TYPE2.getText(), true);

                    // TEMPLATE REWRITE
                    // 55:92: -> param(name=Main.symbols.get_variable($ID.text).num)
                    {
                        retval.st = templateLib.getInstanceOf("param",
                      new STAttrMap().put("name", Main.symbols.get_variable(ID1.getText()).num));
                    }



                    }
                    break;
                case 2 :
                    // Compiler.g:56:12: ^( ARRPAR TYPE name= ID )
                    {
                    match(input,ARRPAR,FOLLOW_ARRPAR_in_paramDecl201); 

                    match(input, Token.DOWN, null); 
                    TYPE3=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_paramDecl203); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_paramDecl207); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_array(name.getText(),TYPE3.getText(),65536);

                    // TEMPLATE REWRITE
                    // 57:20: -> array_param(name=Main.symbols.get_variable($ID.text).num)
                    {
                        retval.st = templateLib.getInstanceOf("array_param",
                      new STAttrMap().put("name", Main.symbols.get_variable(name.getText()).num));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end paramDecl

    public static class varDecl_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start varDecl
    // Compiler.g:60:1: varDecl : ( ^( VARDEF TYPE name= ID ) -> {global}? declare_global(r=Main.symbols.get_variable($ID.text).num) -> declare(r=Main.symbols.get_variable($ID.text).num) | ^( ARRDEF TYPE name= ID size= INT ) -> {global}? declare_global_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length) -> declare_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length));
    public final varDecl_return varDecl() throws RecognitionException {
        varDecl_return retval = new varDecl_return();
        retval.start = input.LT(1);

        CommonTree name=null;
        CommonTree size=null;
        CommonTree TYPE4=null;
        CommonTree TYPE5=null;

        try {
            // Compiler.g:60:11: ( ^( VARDEF TYPE name= ID ) -> {global}? declare_global(r=Main.symbols.get_variable($ID.text).num) -> declare(r=Main.symbols.get_variable($ID.text).num) | ^( ARRDEF TYPE name= ID size= INT ) -> {global}? declare_global_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length) -> declare_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length))
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==VARDEF) ) {
                alt5=1;
            }
            else if ( (LA5_0==ARRDEF) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("60:1: varDecl : ( ^( VARDEF TYPE name= ID ) -> {global}? declare_global(r=Main.symbols.get_variable($ID.text).num) -> declare(r=Main.symbols.get_variable($ID.text).num) | ^( ARRDEF TYPE name= ID size= INT ) -> {global}? declare_global_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length) -> declare_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length));", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // Compiler.g:60:11: ^( VARDEF TYPE name= ID )
                    {
                    match(input,VARDEF,FOLLOW_VARDEF_in_varDecl250); 

                    match(input, Token.DOWN, null); 
                    TYPE4=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_varDecl252); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_varDecl256); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_variable(name.getText(),TYPE4.getText(),false);

                    // TEMPLATE REWRITE
                    // 60:96: -> {global}? declare_global(r=Main.symbols.get_variable($ID.text).num)
                    if (global) {
                        retval.st = templateLib.getInstanceOf("declare_global",
                      new STAttrMap().put("r", Main.symbols.get_variable(name.getText()).num));
                    }
                    else // 61:14: -> declare(r=Main.symbols.get_variable($ID.text).num)
                    {
                        retval.st = templateLib.getInstanceOf("declare",
                      new STAttrMap().put("r", Main.symbols.get_variable(name.getText()).num));
                    }



                    }
                    break;
                case 2 :
                    // Compiler.g:62:8: ^( ARRDEF TYPE name= ID size= INT )
                    {
                    match(input,ARRDEF,FOLLOW_ARRDEF_in_varDecl302); 

                    match(input, Token.DOWN, null); 
                    TYPE5=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_varDecl304); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_varDecl308); 
                    size=(CommonTree)input.LT(1);
                    match(input,INT,FOLLOW_INT_in_varDecl312); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_array(name.getText(),TYPE5.getText(),65536);

                    // TEMPLATE REWRITE
                    // 63:18: -> {global}? declare_global_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length)
                    if (global) {
                        retval.st = templateLib.getInstanceOf("declare_global_array",
                      new STAttrMap().put("ref", Main.symbols.get_variable(name.getText()).num).put("size", Main.symbols.get_variable(name.getText()).length));
                    }
                    else // 64:14: -> declare_array(ref=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).length)
                    {
                        retval.st = templateLib.getInstanceOf("declare_array",
                      new STAttrMap().put("ref", Main.symbols.get_variable(name.getText()).num).put("size", Main.symbols.get_variable(name.getText()).length));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end varDecl

    public static class block_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start block
    // Compiler.g:67:1: block : ^( BLOCK ^( VARIABLES (vars+= varDecl )* ) ^( STMTS (stmts+= stmt )* ) ) -> block(vars=$varsstmts=$stmts);
    public final block_return block() throws RecognitionException {
        block_return retval = new block_return();
        retval.start = input.LT(1);

        List list_vars=null;
        List list_stmts=null;
        RuleReturnScope vars = null;
        RuleReturnScope stmts = null;
        List list_stmt=new ArrayList();
        List list_varDecl=new ArrayList();

        	Main.symbols.enter_block();

        try {
            // Compiler.g:74:4: ( ^( BLOCK ^( VARIABLES (vars+= varDecl )* ) ^( STMTS (stmts+= stmt )* ) ) -> block(vars=$varsstmts=$stmts))
            // Compiler.g:74:4: ^( BLOCK ^( VARIABLES (vars+= varDecl )* ) ^( STMTS (stmts+= stmt )* ) )
            {
            match(input,BLOCK,FOLLOW_BLOCK_in_block398); 

            match(input, Token.DOWN, null); 
            match(input,VARIABLES,FOLLOW_VARIABLES_in_block401); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:74:24: (vars+= varDecl )*
                loop6:
                do {
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=VARDEF && LA6_0<=ARRDEF)) ) {
                        alt6=1;
                    }


                    switch (alt6) {
                	case 1 :
                	    // Compiler.g:74:25: vars+= varDecl
                	    {
                	    pushFollow(FOLLOW_varDecl_in_block406);
                	    vars=varDecl();
                	    _fsp--;

                	    if (list_vars==null) list_vars=new ArrayList();
                	    list_vars.add(vars.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop6;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            match(input,STMTS,FOLLOW_STMTS_in_block412); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:74:50: (stmts+= stmt )*
                loop7:
                do {
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==NOP||(LA7_0>=BLOCK && LA7_0<=ASSIGN)||(LA7_0>=CALL && LA7_0<=NEGATE)||(LA7_0>=NUM && LA7_0<=VAR)||(LA7_0>=RETURN && LA7_0<=IF)||(LA7_0>=63 && LA7_0<=77)) ) {
                        alt7=1;
                    }


                    switch (alt7) {
                	case 1 :
                	    // Compiler.g:74:51: stmts+= stmt
                	    {
                	    pushFollow(FOLLOW_stmt_in_block417);
                	    stmts=stmt();
                	    _fsp--;

                	    if (list_stmts==null) list_stmts=new ArrayList();
                	    list_stmts.add(stmts.getTemplate());


                	    }
                	    break;

                	default :
                	    break loop7;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }

            match(input, Token.UP, null); 

            // TEMPLATE REWRITE
            // 74:67: -> block(vars=$varsstmts=$stmts)
            {
                retval.st = templateLib.getInstanceOf("block",
              new STAttrMap().put("vars", list_vars).put("stmts", list_stmts));
            }



            }


            	Main.symbols.exit_block();

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end block

    public static class stmt_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start stmt
    // Compiler.g:77:1: stmt : (a= expr -> item(st=$a.sts=\"Start Expression\"e=\"End Expression\") | ^( RETURN expr ) -> return(expr=$expr.stref=$expr.ref) | ^( READ ID ) -> read(ret=Main.symbols.get_variable($ID.text).numtmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()tmp3=Main.symbols.next_var()tmp4=Main.symbols.next_var()tmp5=Main.symbols.next_var()) | ^( WRITE expr ) -> write(expr=$expr.stref=$expr.refv1=Main.symbols.next_var()v2=Main.symbols.next_var()) | WRITELN -> writeln(v=Main.symbols.next_var()) | BREAK -> break(lab=$whileStmt::breaked) | ifStmt -> item(st=$ifStmt.sts=\"Start If Statement\"e=\"End If Statement\") | whileStmt -> item(st=$whileStmt.sts=\"Start While Statement\"e=\"End While Statement\") | block -> item(st=$block.sts=\"Start Block\"e=\"End Block\") | NOP ->);
    public final stmt_return stmt() throws RecognitionException {
        stmt_return retval = new stmt_return();
        retval.start = input.LT(1);

        CommonTree ID7=null;
        expr_return a = null;

        expr_return expr6 = null;

        expr_return expr8 = null;

        ifStmt_return ifStmt9 = null;

        whileStmt_return whileStmt10 = null;

        block_return block11 = null;

        List list_ifStmt=new ArrayList();
        List list_expr=new ArrayList();
        List list_whileStmt=new ArrayList();
        List list_block=new ArrayList();
        try {
            // Compiler.g:77:8: (a= expr -> item(st=$a.sts=\"Start Expression\"e=\"End Expression\") | ^( RETURN expr ) -> return(expr=$expr.stref=$expr.ref) | ^( READ ID ) -> read(ret=Main.symbols.get_variable($ID.text).numtmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()tmp3=Main.symbols.next_var()tmp4=Main.symbols.next_var()tmp5=Main.symbols.next_var()) | ^( WRITE expr ) -> write(expr=$expr.stref=$expr.refv1=Main.symbols.next_var()v2=Main.symbols.next_var()) | WRITELN -> writeln(v=Main.symbols.next_var()) | BREAK -> break(lab=$whileStmt::breaked) | ifStmt -> item(st=$ifStmt.sts=\"Start If Statement\"e=\"End If Statement\") | whileStmt -> item(st=$whileStmt.sts=\"Start While Statement\"e=\"End While Statement\") | block -> item(st=$block.sts=\"Start Block\"e=\"End Block\") | NOP ->)
            int alt8=10;
            switch ( input.LA(1) ) {
            case ASSIGN:
            case CALL:
            case INDEX:
            case NOT:
            case NEGATE:
            case NUM:
            case VAR:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
                {
                alt8=1;
                }
                break;
            case RETURN:
                {
                alt8=2;
                }
                break;
            case READ:
                {
                alt8=3;
                }
                break;
            case WRITE:
                {
                alt8=4;
                }
                break;
            case WRITELN:
                {
                alt8=5;
                }
                break;
            case BREAK:
                {
                alt8=6;
                }
                break;
            case IF:
                {
                alt8=7;
                }
                break;
            case WHILE:
                {
                alt8=8;
                }
                break;
            case BLOCK:
                {
                alt8=9;
                }
                break;
            case NOP:
                {
                alt8=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("77:1: stmt : (a= expr -> item(st=$a.sts=\"Start Expression\"e=\"End Expression\") | ^( RETURN expr ) -> return(expr=$expr.stref=$expr.ref) | ^( READ ID ) -> read(ret=Main.symbols.get_variable($ID.text).numtmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()tmp3=Main.symbols.next_var()tmp4=Main.symbols.next_var()tmp5=Main.symbols.next_var()) | ^( WRITE expr ) -> write(expr=$expr.stref=$expr.refv1=Main.symbols.next_var()v2=Main.symbols.next_var()) | WRITELN -> writeln(v=Main.symbols.next_var()) | BREAK -> break(lab=$whileStmt::breaked) | ifStmt -> item(st=$ifStmt.sts=\"Start If Statement\"e=\"End If Statement\") | whileStmt -> item(st=$whileStmt.sts=\"Start While Statement\"e=\"End While Statement\") | block -> item(st=$block.sts=\"Start Block\"e=\"End Block\") | NOP ->);", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // Compiler.g:77:8: a= expr
                    {
                    pushFollow(FOLLOW_expr_in_stmt448);
                    a=expr();
                    _fsp--;


                    // TEMPLATE REWRITE
                    // 77:17: -> item(st=$a.sts=\"Start Expression\"e=\"End Expression\")
                    {
                        retval.st = templateLib.getInstanceOf("item",
                      new STAttrMap().put("st", a.st).put("s", "Start Expression").put("e", "End Expression"));
                    }



                    }
                    break;
                case 2 :
                    // Compiler.g:78:5: ^( RETURN expr )
                    {
                    match(input,RETURN,FOLLOW_RETURN_in_stmt474); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_stmt476);
                    expr6=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 78:20: -> return(expr=$expr.stref=$expr.ref)
                    {
                        retval.st = templateLib.getInstanceOf("return",
                      new STAttrMap().put("expr", expr6.st).put("ref", expr6.ref));
                    }



                    }
                    break;
                case 3 :
                    // Compiler.g:79:5: ^( READ ID )
                    {
                    match(input,READ,FOLLOW_READ_in_stmt500); 

                    match(input, Token.DOWN, null); 
                    ID7=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_stmt502); 

                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 79:17: -> read(ret=Main.symbols.get_variable($ID.text).numtmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()tmp3=Main.symbols.next_var()tmp4=Main.symbols.next_var()tmp5=Main.symbols.next_var())
                    {
                        retval.st = templateLib.getInstanceOf("read",
                      new STAttrMap().put("ret", Main.symbols.get_variable(ID7.getText()).num).put("tmp1", Main.symbols.next_var()).put("tmp2", Main.symbols.next_var()).put("tmp3", Main.symbols.next_var()).put("tmp4", Main.symbols.next_var()).put("tmp5", Main.symbols.next_var()));
                    }



                    }
                    break;
                case 4 :
                    // Compiler.g:80:5: ^( WRITE expr )
                    {
                    match(input,WRITE,FOLLOW_WRITE_in_stmt555); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_stmt557);
                    expr8=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 80:20: -> write(expr=$expr.stref=$expr.refv1=Main.symbols.next_var()v2=Main.symbols.next_var())
                    {
                        retval.st = templateLib.getInstanceOf("write",
                      new STAttrMap().put("expr", expr8.st).put("ref", expr8.ref).put("v1", Main.symbols.next_var()).put("v2", Main.symbols.next_var()));
                    }



                    }
                    break;
                case 5 :
                    // Compiler.g:81:5: WRITELN
                    {
                    match(input,WRITELN,FOLLOW_WRITELN_in_stmt596); 

                    // TEMPLATE REWRITE
                    // 81:14: -> writeln(v=Main.symbols.next_var())
                    {
                        retval.st = templateLib.getInstanceOf("writeln",
                      new STAttrMap().put("v", Main.symbols.next_var()));
                    }



                    }
                    break;
                case 6 :
                    // Compiler.g:82:5: BREAK
                    {
                    match(input,BREAK,FOLLOW_BREAK_in_stmt614); 

                    // TEMPLATE REWRITE
                    // 82:13: -> break(lab=$whileStmt::breaked)
                    {
                        retval.st = templateLib.getInstanceOf("break",
                      new STAttrMap().put("lab", ((whileStmt_scope)whileStmt_stack.peek()).breaked));
                    }



                    }
                    break;
                case 7 :
                    // Compiler.g:83:5: ifStmt
                    {
                    pushFollow(FOLLOW_ifStmt_in_stmt631);
                    ifStmt9=ifStmt();
                    _fsp--;


                    // TEMPLATE REWRITE
                    // 83:13: -> item(st=$ifStmt.sts=\"Start If Statement\"e=\"End If Statement\")
                    {
                        retval.st = templateLib.getInstanceOf("item",
                      new STAttrMap().put("st", ifStmt9.st).put("s", "Start If Statement").put("e", "End If Statement"));
                    }



                    }
                    break;
                case 8 :
                    // Compiler.g:84:5: whileStmt
                    {
                    pushFollow(FOLLOW_whileStmt_in_stmt655);
                    whileStmt10=whileStmt();
                    _fsp--;


                    // TEMPLATE REWRITE
                    // 84:16: -> item(st=$whileStmt.sts=\"Start While Statement\"e=\"End While Statement\")
                    {
                        retval.st = templateLib.getInstanceOf("item",
                      new STAttrMap().put("st", whileStmt10.st).put("s", "Start While Statement").put("e", "End While Statement"));
                    }



                    }
                    break;
                case 9 :
                    // Compiler.g:85:5: block
                    {
                    pushFollow(FOLLOW_block_in_stmt679);
                    block11=block();
                    _fsp--;


                    // TEMPLATE REWRITE
                    // 85:13: -> item(st=$block.sts=\"Start Block\"e=\"End Block\")
                    {
                        retval.st = templateLib.getInstanceOf("item",
                      new STAttrMap().put("st", block11.st).put("s", "Start Block").put("e", "End Block"));
                    }



                    }
                    break;
                case 10 :
                    // Compiler.g:86:5: NOP
                    {
                    match(input,NOP,FOLLOW_NOP_in_stmt704); 

                    // TEMPLATE REWRITE
                    // 86:11: ->
                    {
                        retval.st = null;;
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end stmt

    protected static class whileStmt_scope {
        int breaked;
    }
    protected Stack whileStmt_stack = new Stack();

    public static class whileStmt_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start whileStmt
    // Compiler.g:89:1: whileStmt : ^( WHILE expr stmt ) -> while(expr=$expr.stref=$expr.refstmt=$stmt.sttmp1=Main.symbols.next_var()start=Main.symbols.next_label()block_begin=Main.symbols.next_label()end=$whileStmt::breaked);
    public final whileStmt_return whileStmt() throws RecognitionException {
        whileStmt_stack.push(new whileStmt_scope());
        whileStmt_return retval = new whileStmt_return();
        retval.start = input.LT(1);

        expr_return expr12 = null;

        stmt_return stmt13 = null;

        List list_expr=new ArrayList();
        List list_stmt=new ArrayList();

        	((whileStmt_scope)whileStmt_stack.peek()).breaked =Main.symbols.next_label();

        try {
            // Compiler.g:97:4: ( ^( WHILE expr stmt ) -> while(expr=$expr.stref=$expr.refstmt=$stmt.sttmp1=Main.symbols.next_var()start=Main.symbols.next_label()block_begin=Main.symbols.next_label()end=$whileStmt::breaked))
            // Compiler.g:97:4: ^( WHILE expr stmt )
            {
            match(input,WHILE,FOLLOW_WHILE_in_whileStmt729); 

            match(input, Token.DOWN, null); 
            pushFollow(FOLLOW_expr_in_whileStmt731);
            expr12=expr();
            _fsp--;

            pushFollow(FOLLOW_stmt_in_whileStmt733);
            stmt13=stmt();
            _fsp--;


            match(input, Token.UP, null); 

            // TEMPLATE REWRITE
            // 97:24: -> while(expr=$expr.stref=$expr.refstmt=$stmt.sttmp1=Main.symbols.next_var()start=Main.symbols.next_label()block_begin=Main.symbols.next_label()end=$whileStmt::breaked)
            {
                retval.st = templateLib.getInstanceOf("while",
              new STAttrMap().put("expr", expr12.st).put("ref", expr12.ref).put("stmt", stmt13.st).put("tmp1", Main.symbols.next_var()).put("start", Main.symbols.next_label()).put("block_begin", Main.symbols.next_label()).put("end", ((whileStmt_scope)whileStmt_stack.peek()).breaked));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            whileStmt_stack.pop();
        }
        return retval;
    }
    // $ANTLR end whileStmt

    public static class ifStmt_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start ifStmt
    // Compiler.g:100:1: ifStmt : ^( IF ^( EXPR expr ) t= stmt f= stmt ) -> if(expr=$expr.stref=$expr.reftrue=$t.stfalse=$f.sttmp1=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label());
    public final ifStmt_return ifStmt() throws RecognitionException {
        ifStmt_return retval = new ifStmt_return();
        retval.start = input.LT(1);

        stmt_return t = null;

        stmt_return f = null;

        expr_return expr14 = null;

        List list_expr=new ArrayList();
        List list_stmt=new ArrayList();
        try {
            // Compiler.g:100:12: ( ^( IF ^( EXPR expr ) t= stmt f= stmt ) -> if(expr=$expr.stref=$expr.reftrue=$t.stfalse=$f.sttmp1=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()))
            // Compiler.g:100:12: ^( IF ^( EXPR expr ) t= stmt f= stmt )
            {
            match(input,IF,FOLLOW_IF_in_ifStmt784); 

            match(input, Token.DOWN, null); 
            match(input,EXPR,FOLLOW_EXPR_in_ifStmt787); 

            match(input, Token.DOWN, null); 
            pushFollow(FOLLOW_expr_in_ifStmt789);
            expr14=expr();
            _fsp--;


            match(input, Token.UP, null); 
            pushFollow(FOLLOW_stmt_in_ifStmt794);
            t=stmt();
            _fsp--;

            pushFollow(FOLLOW_stmt_in_ifStmt798);
            f=stmt();
            _fsp--;


            match(input, Token.UP, null); 

            // TEMPLATE REWRITE
            // 100:45: -> if(expr=$expr.stref=$expr.reftrue=$t.stfalse=$f.sttmp1=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label())
            {
                retval.st = templateLib.getInstanceOf("if",
              new STAttrMap().put("expr", expr14.st).put("ref", expr14.ref).put("true", t.st).put("false", f.st).put("tmp1", Main.symbols.next_var()).put("lab1", Main.symbols.next_label()).put("lab2", Main.symbols.next_label()).put("lab3", Main.symbols.next_label()));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end ifStmt

    public static class expr_return extends TreeRuleReturnScope {
        public int ref;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start expr
    // Compiler.g:104:1: expr returns [int ref] : ( ^( ( 'or' | '||' ) a= expr b= expr ) -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( ( 'and' | '&&' ) a= expr b= expr ) -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( '==' a= expr b= expr ) -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( ( '!=' | '<>' ) a= expr b= expr ) -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>' a= expr b= expr ) -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<' a= expr b= expr ) -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>=' a= expr b= expr ) -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<=' a= expr b= expr ) -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '+' a= expr b= expr ) -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '-' a= expr b= expr ) -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '*' a= expr b= expr ) -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '/' a= expr b= expr ) -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( NEGATE a= expr ) -> negate(expr=$a.str=$refval=$a.ref) | ^( NOT a= expr ) -> not(expr=$a.stret=$refref=$a.ref) | ^( NUM INT ) -> create(r=$refval=$INT) | ^( VAR ID ) -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num) -> | ^( INDEX name= ID i= expr ) -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length) | call[$ref] -> {$call.st} | ^( ASSIGN name= ID a= expr ) -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref) | ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr ) -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var()));
    public final expr_return expr() throws RecognitionException {
        expr_return retval = new expr_return();
        retval.start = input.LT(1);

        CommonTree name=null;
        CommonTree INT15=null;
        CommonTree ID16=null;
        expr_return a = null;

        expr_return b = null;

        expr_return i = null;

        call_return call17 = null;

        List list_call=new ArrayList();
        List list_expr=new ArrayList();

        	retval.ref =Main.symbols.next_var();

        try {
            // Compiler.g:108:4: ( ^( ( 'or' | '||' ) a= expr b= expr ) -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( ( 'and' | '&&' ) a= expr b= expr ) -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( '==' a= expr b= expr ) -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( ( '!=' | '<>' ) a= expr b= expr ) -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>' a= expr b= expr ) -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<' a= expr b= expr ) -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>=' a= expr b= expr ) -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<=' a= expr b= expr ) -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '+' a= expr b= expr ) -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '-' a= expr b= expr ) -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '*' a= expr b= expr ) -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '/' a= expr b= expr ) -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( NEGATE a= expr ) -> negate(expr=$a.str=$refval=$a.ref) | ^( NOT a= expr ) -> not(expr=$a.stret=$refref=$a.ref) | ^( NUM INT ) -> create(r=$refval=$INT) | ^( VAR ID ) -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num) -> | ^( INDEX name= ID i= expr ) -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length) | call[$ref] -> {$call.st} | ^( ASSIGN name= ID a= expr ) -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref) | ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr ) -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var()))
            int alt12=20;
            switch ( input.LA(1) ) {
            case 63:
            case 64:
                {
                alt12=1;
                }
                break;
            case 65:
            case 66:
                {
                alt12=2;
                }
                break;
            case 67:
                {
                alt12=3;
                }
                break;
            case 68:
            case 69:
                {
                alt12=4;
                }
                break;
            case 70:
                {
                alt12=5;
                }
                break;
            case 71:
                {
                alt12=6;
                }
                break;
            case 73:
                {
                alt12=7;
                }
                break;
            case 72:
                {
                alt12=8;
                }
                break;
            case 74:
                {
                alt12=9;
                }
                break;
            case 75:
                {
                alt12=10;
                }
                break;
            case 76:
                {
                alt12=11;
                }
                break;
            case 77:
                {
                alt12=12;
                }
                break;
            case NEGATE:
                {
                alt12=13;
                }
                break;
            case NOT:
                {
                alt12=14;
                }
                break;
            case NUM:
                {
                alt12=15;
                }
                break;
            case VAR:
                {
                alt12=16;
                }
                break;
            case INDEX:
                {
                alt12=17;
                }
                break;
            case CALL:
                {
                alt12=18;
                }
                break;
            case ASSIGN:
                {
                int LA12_19 = input.LA(2);

                if ( (LA12_19==DOWN) ) {
                    int LA12_20 = input.LA(3);

                    if ( (LA12_20==INDEX) ) {
                        alt12=20;
                    }
                    else if ( (LA12_20==ID) ) {
                        alt12=19;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("104:1: expr returns [int ref] : ( ^( ( 'or' | '||' ) a= expr b= expr ) -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( ( 'and' | '&&' ) a= expr b= expr ) -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( '==' a= expr b= expr ) -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( ( '!=' | '<>' ) a= expr b= expr ) -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>' a= expr b= expr ) -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<' a= expr b= expr ) -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>=' a= expr b= expr ) -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<=' a= expr b= expr ) -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '+' a= expr b= expr ) -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '-' a= expr b= expr ) -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '*' a= expr b= expr ) -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '/' a= expr b= expr ) -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( NEGATE a= expr ) -> negate(expr=$a.str=$refval=$a.ref) | ^( NOT a= expr ) -> not(expr=$a.stret=$refref=$a.ref) | ^( NUM INT ) -> create(r=$refval=$INT) | ^( VAR ID ) -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num) -> | ^( INDEX name= ID i= expr ) -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length) | call[$ref] -> {$call.st} | ^( ASSIGN name= ID a= expr ) -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref) | ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr ) -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var()));", 12, 20, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("104:1: expr returns [int ref] : ( ^( ( 'or' | '||' ) a= expr b= expr ) -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( ( 'and' | '&&' ) a= expr b= expr ) -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( '==' a= expr b= expr ) -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( ( '!=' | '<>' ) a= expr b= expr ) -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>' a= expr b= expr ) -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<' a= expr b= expr ) -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>=' a= expr b= expr ) -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<=' a= expr b= expr ) -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '+' a= expr b= expr ) -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '-' a= expr b= expr ) -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '*' a= expr b= expr ) -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '/' a= expr b= expr ) -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( NEGATE a= expr ) -> negate(expr=$a.str=$refval=$a.ref) | ^( NOT a= expr ) -> not(expr=$a.stret=$refref=$a.ref) | ^( NUM INT ) -> create(r=$refval=$INT) | ^( VAR ID ) -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num) -> | ^( INDEX name= ID i= expr ) -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length) | call[$ref] -> {$call.st} | ^( ASSIGN name= ID a= expr ) -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref) | ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr ) -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var()));", 12, 19, input);

                    throw nvae;
                }
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("104:1: expr returns [int ref] : ( ^( ( 'or' | '||' ) a= expr b= expr ) -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( ( 'and' | '&&' ) a= expr b= expr ) -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label()) | ^( '==' a= expr b= expr ) -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( ( '!=' | '<>' ) a= expr b= expr ) -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>' a= expr b= expr ) -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<' a= expr b= expr ) -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '>=' a= expr b= expr ) -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '<=' a= expr b= expr ) -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref) | ^( '+' a= expr b= expr ) -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '-' a= expr b= expr ) -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '*' a= expr b= expr ) -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( '/' a= expr b= expr ) -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref) | ^( NEGATE a= expr ) -> negate(expr=$a.str=$refval=$a.ref) | ^( NOT a= expr ) -> not(expr=$a.stret=$refref=$a.ref) | ^( NUM INT ) -> create(r=$refval=$INT) | ^( VAR ID ) -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num) -> | ^( INDEX name= ID i= expr ) -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length) | call[$ref] -> {$call.st} | ^( ASSIGN name= ID a= expr ) -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref) | ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr ) -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var()));", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // Compiler.g:108:4: ^( ( 'or' | '||' ) a= expr b= expr )
                    {
                    // Compiler.g:108:6: ( 'or' | '||' )
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==63) ) {
                        alt9=1;
                    }
                    else if ( (LA9_0==64) ) {
                        alt9=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("108:6: ( 'or' | '||' )", 9, 0, input);

                        throw nvae;
                    }
                    switch (alt9) {
                        case 1 :
                            // Compiler.g:108:7: 'or'
                            {
                            match(input,63,FOLLOW_63_in_expr862); 

                            }
                            break;
                        case 2 :
                            // Compiler.g:108:12: '||'
                            {
                            match(input,64,FOLLOW_64_in_expr864); 

                            }
                            break;

                    }


                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr869);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr873);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 108:34: -> or(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label())
                    {
                        retval.st = templateLib.getInstanceOf("or",
                      new STAttrMap().put("ret", retval.ref).put("expr1", a.st).put("expr2", b.st).put("ref1", a.ref).put("ref2", b.ref).put("tmp1", Main.symbols.next_var()).put("tmp2", Main.symbols.next_var()).put("lab1", Main.symbols.next_label()).put("lab2", Main.symbols.next_label()).put("lab3", Main.symbols.next_label()).put("lab4", Main.symbols.next_label()));
                    }



                    }
                    break;
                case 2 :
                    // Compiler.g:109:5: ^( ( 'and' | '&&' ) a= expr b= expr )
                    {
                    // Compiler.g:109:7: ( 'and' | '&&' )
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==65) ) {
                        alt10=1;
                    }
                    else if ( (LA10_0==66) ) {
                        alt10=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("109:7: ( 'and' | '&&' )", 10, 0, input);

                        throw nvae;
                    }
                    switch (alt10) {
                        case 1 :
                            // Compiler.g:109:8: 'and'
                            {
                            match(input,65,FOLLOW_65_in_expr932); 

                            }
                            break;
                        case 2 :
                            // Compiler.g:109:14: '&&'
                            {
                            match(input,66,FOLLOW_66_in_expr934); 

                            }
                            break;

                    }


                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr939);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr943);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 109:36: -> and(ret=$refexpr1=$a.stexpr2=$b.stref1=$a.refref2=$b.reftmp1=Main.symbols.next_var()tmp2=Main.symbols.next_var()lab1=Main.symbols.next_label()lab2=Main.symbols.next_label()lab3=Main.symbols.next_label()lab4=Main.symbols.next_label())
                    {
                        retval.st = templateLib.getInstanceOf("and",
                      new STAttrMap().put("ret", retval.ref).put("expr1", a.st).put("expr2", b.st).put("ref1", a.ref).put("ref2", b.ref).put("tmp1", Main.symbols.next_var()).put("tmp2", Main.symbols.next_var()).put("lab1", Main.symbols.next_label()).put("lab2", Main.symbols.next_label()).put("lab3", Main.symbols.next_label()).put("lab4", Main.symbols.next_label()));
                    }



                    }
                    break;
                case 3 :
                    // Compiler.g:110:5: ^( '==' a= expr b= expr )
                    {
                    match(input,67,FOLLOW_67_in_expr1001); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1005);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1009);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 110:29: -> comparison(type=\"eq\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "eq").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 4 :
                    // Compiler.g:111:5: ^( ( '!=' | '<>' ) a= expr b= expr )
                    {
                    // Compiler.g:111:7: ( '!=' | '<>' )
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==68) ) {
                        alt11=1;
                    }
                    else if ( (LA11_0==69) ) {
                        alt11=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("111:7: ( '!=' | '<>' )", 11, 0, input);

                        throw nvae;
                    }
                    switch (alt11) {
                        case 1 :
                            // Compiler.g:111:8: '!='
                            {
                            match(input,68,FOLLOW_68_in_expr1053); 

                            }
                            break;
                        case 2 :
                            // Compiler.g:111:13: '<>'
                            {
                            match(input,69,FOLLOW_69_in_expr1055); 

                            }
                            break;

                    }


                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1060);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1064);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 111:35: -> comparison(type=\"ne\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "ne").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 5 :
                    // Compiler.g:112:5: ^( '>' a= expr b= expr )
                    {
                    match(input,70,FOLLOW_70_in_expr1106); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1110);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1114);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 112:28: -> comparison(type=\"gt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "gt").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 6 :
                    // Compiler.g:113:5: ^( '<' a= expr b= expr )
                    {
                    match(input,71,FOLLOW_71_in_expr1157); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1161);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1165);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 113:28: -> comparison(type=\"lt\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "lt").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 7 :
                    // Compiler.g:114:5: ^( '>=' a= expr b= expr )
                    {
                    match(input,73,FOLLOW_73_in_expr1208); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1212);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1216);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 114:29: -> comparison(type=\"ge\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "ge").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 8 :
                    // Compiler.g:115:5: ^( '<=' a= expr b= expr )
                    {
                    match(input,72,FOLLOW_72_in_expr1259); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1263);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1267);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 115:29: -> comparison(type=\"le\"expr1=$a.stexpr2=$b.stret=$refref1=$a.refref2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("comparison",
                      new STAttrMap().put("type", "le").put("expr1", a.st).put("expr2", b.st).put("ret", retval.ref).put("ref1", a.ref).put("ref2", b.ref));
                    }



                    }
                    break;
                case 9 :
                    // Compiler.g:116:5: ^( '+' a= expr b= expr )
                    {
                    match(input,74,FOLLOW_74_in_expr1310); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1314);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1318);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 116:29: -> add(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("add",
                      new STAttrMap().put("ea", a.st).put("eb", b.st).put("r", retval.ref).put("v1", a.ref).put("v2", b.ref));
                    }



                    }
                    break;
                case 10 :
                    // Compiler.g:117:5: ^( '-' a= expr b= expr )
                    {
                    match(input,75,FOLLOW_75_in_expr1356); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1360);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1364);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 117:29: -> subtract(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("subtract",
                      new STAttrMap().put("ea", a.st).put("eb", b.st).put("r", retval.ref).put("v1", a.ref).put("v2", b.ref));
                    }



                    }
                    break;
                case 11 :
                    // Compiler.g:118:5: ^( '*' a= expr b= expr )
                    {
                    match(input,76,FOLLOW_76_in_expr1402); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1406);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1410);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 118:29: -> multiply(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("multiply",
                      new STAttrMap().put("ea", a.st).put("eb", b.st).put("r", retval.ref).put("v1", a.ref).put("v2", b.ref));
                    }



                    }
                    break;
                case 12 :
                    // Compiler.g:119:5: ^( '/' a= expr b= expr )
                    {
                    match(input,77,FOLLOW_77_in_expr1448); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1452);
                    a=expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr1456);
                    b=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 119:29: -> divide(ea=$a.steb=$b.str=$refv1=$a.refv2=$b.ref)
                    {
                        retval.st = templateLib.getInstanceOf("divide",
                      new STAttrMap().put("ea", a.st).put("eb", b.st).put("r", retval.ref).put("v1", a.ref).put("v2", b.ref));
                    }



                    }
                    break;
                case 13 :
                    // Compiler.g:120:5: ^( NEGATE a= expr )
                    {
                    match(input,NEGATE,FOLLOW_NEGATE_in_expr1494); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1498);
                    a=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 120:24: -> negate(expr=$a.str=$refval=$a.ref)
                    {
                        retval.st = templateLib.getInstanceOf("negate",
                      new STAttrMap().put("expr", a.st).put("r", retval.ref).put("val", a.ref));
                    }



                    }
                    break;
                case 14 :
                    // Compiler.g:121:5: ^( NOT a= expr )
                    {
                    match(input,NOT,FOLLOW_NOT_in_expr1527); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1531);
                    a=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 121:22: -> not(expr=$a.stret=$refref=$a.ref)
                    {
                        retval.st = templateLib.getInstanceOf("not",
                      new STAttrMap().put("expr", a.st).put("ret", retval.ref).put("ref", a.ref));
                    }



                    }
                    break;
                case 15 :
                    // Compiler.g:122:5: ^( NUM INT )
                    {
                    match(input,NUM,FOLLOW_NUM_in_expr1561); 

                    match(input, Token.DOWN, null); 
                    INT15=(CommonTree)input.LT(1);
                    match(input,INT,FOLLOW_INT_in_expr1563); 

                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 122:19: -> create(r=$refval=$INT)
                    {
                        retval.st = templateLib.getInstanceOf("create",
                      new STAttrMap().put("r", retval.ref).put("val", INT15));
                    }



                    }
                    break;
                case 16 :
                    // Compiler.g:123:5: ^( VAR ID )
                    {
                    match(input,VAR,FOLLOW_VAR_in_expr1588); 

                    match(input, Token.DOWN, null); 
                    ID16=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr1590); 

                    match(input, Token.UP, null); 
                    if(Main.symbols.get_variable(ID16.getText()).read_only || Main.symbols.get_variable(ID16.getText()).mode=="array") retval.ref =Main.symbols.get_variable(ID16.getText()).num;

                    // TEMPLATE REWRITE
                    // 123:169: -> {(! Main.symbols.get_variable($ID.text).read_only) && Main.symbols.get_variable($ID.text).mode==\"scalar\"}? access(target=$refsource=Main.symbols.get_variable($ID.text).num)
                    if ((! Main.symbols.get_variable(ID16.getText()).read_only) && Main.symbols.get_variable(ID16.getText()).mode=="scalar") {
                        retval.st = templateLib.getInstanceOf("access",
                      new STAttrMap().put("target", retval.ref).put("source", Main.symbols.get_variable(ID16.getText()).num));
                    }
                    else // 124:8: ->
                    {
                        retval.st = null;;
                    }



                    }
                    break;
                case 17 :
                    // Compiler.g:127:5: ^( INDEX name= ID i= expr )
                    {
                    match(input,INDEX,FOLLOW_INDEX_in_expr1633); 

                    match(input, Token.DOWN, null); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr1637); 
                    pushFollow(FOLLOW_expr_in_expr1641);
                    i=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 127:30: -> access_array(ret=$refname=Main.symbols.get_variable($name.text).numindex_expr=$i.stindex_ref=i.reftmp1=Main.symbols.next_var()size=Main.symbols.get_variable($name.text).length)
                    {
                        retval.st = templateLib.getInstanceOf("access_array",
                      new STAttrMap().put("ret", retval.ref).put("name", Main.symbols.get_variable(name.getText()).num).put("index_expr", i.st).put("index_ref", i.ref).put("tmp1", Main.symbols.next_var()).put("size", Main.symbols.get_variable(name.getText()).length));
                    }



                    }
                    break;
                case 18 :
                    // Compiler.g:128:5: call[$ref]
                    {
                    pushFollow(FOLLOW_call_in_expr1680);
                    call17=call(retval.ref);
                    _fsp--;


                    // TEMPLATE REWRITE
                    // 128:19: -> {$call.st}
                    {
                        retval.st = call17.st;
                    }



                    }
                    break;
                case 19 :
                    // Compiler.g:129:5: ^( ASSIGN name= ID a= expr )
                    {
                    match(input,ASSIGN,FOLLOW_ASSIGN_in_expr1694); 

                    match(input, Token.DOWN, null); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr1698); 
                    pushFollow(FOLLOW_expr_in_expr1702);
                    a=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 129:31: -> var_assign(ret=$refexpr=$a.stvar=Main.symbols.get_variable($name.text).numref=$a.ref)
                    {
                        retval.st = templateLib.getInstanceOf("var_assign",
                      new STAttrMap().put("ret", retval.ref).put("expr", a.st).put("var", Main.symbols.get_variable(name.getText()).num).put("ref", a.ref));
                    }



                    }
                    break;
                case 20 :
                    // Compiler.g:130:5: ^( ASSIGN ^( INDEX name= ID i= expr ) a= expr )
                    {
                    match(input,ASSIGN,FOLLOW_ASSIGN_in_expr1735); 

                    match(input, Token.DOWN, null); 
                    match(input,INDEX,FOLLOW_INDEX_in_expr1738); 

                    match(input, Token.DOWN, null); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr1742); 
                    pushFollow(FOLLOW_expr_in_expr1746);
                    i=expr();
                    _fsp--;


                    match(input, Token.UP, null); 
                    pushFollow(FOLLOW_expr_in_expr1751);
                    a=expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    // TEMPLATE REWRITE
                    // 130:46: -> array_assign(ret=$refval_expr=$a.stval_ref=$a.refindex_expr=$i.stindex_ref=i.refvar=Main.symbols.get_variable($name.text).numsize=Main.symbols.get_variable($name.text).values.lengthtmp1=Main.symbols.next_var())
                    {
                        retval.st = templateLib.getInstanceOf("array_assign",
                      new STAttrMap().put("ret", retval.ref).put("val_expr", a.st).put("val_ref", a.ref).put("index_expr", i.st).put("index_ref", i.ref).put("var", Main.symbols.get_variable(name.getText()).num).put("size", Main.symbols.get_variable(name.getText()).values.length).put("tmp1", Main.symbols.next_var()));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end expr

    public static class call_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start call
    // Compiler.g:133:1: call[int ref] : ^( CALL ID ^( EXPRLIST (p= expr )* ) ) -> call(ret=$refname=$ID.textparam_expr=exprsparams=prefs);
    public final call_return call(int ref) throws RecognitionException {
        call_return retval = new call_return();
        retval.start = input.LT(1);

        CommonTree ID18=null;
        expr_return p = null;

        List list_expr=new ArrayList();

        	int p_i=0;
        	Function fcn;
        	ArrayList prefs=new ArrayList();
        	ArrayList exprs=new ArrayList();

        try {
            // Compiler.g:141:2: ( ^( CALL ID ^( EXPRLIST (p= expr )* ) ) -> call(ret=$refname=$ID.textparam_expr=exprsparams=prefs))
            // Compiler.g:141:2: ^( CALL ID ^( EXPRLIST (p= expr )* ) )
            {
            match(input,CALL,FOLLOW_CALL_in_call1815); 

            match(input, Token.DOWN, null); 
            ID18=(CommonTree)input.LT(1);
            match(input,ID,FOLLOW_ID_in_call1817); 
            fcn=Main.symbols.get_function(ID18.getText());
            match(input,EXPRLIST,FOLLOW_EXPRLIST_in_call1822); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Compiler.g:141:66: (p= expr )*
                loop13:
                do {
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==ASSIGN||(LA13_0>=CALL && LA13_0<=NEGATE)||(LA13_0>=NUM && LA13_0<=VAR)||(LA13_0>=63 && LA13_0<=77)) ) {
                        alt13=1;
                    }


                    switch (alt13) {
                	case 1 :
                	    // Compiler.g:141:67: p= expr
                	    {
                	    pushFollow(FOLLOW_expr_in_call1827);
                	    p=expr();
                	    _fsp--;

                	    	
                	    		StringTemplate code;
                	    		if(((FunctionParam)fcn.params.get(p_i)).mode=="array"){
                	    			code=mtemplates.getInstanceOf("array_var");
                	    		}else{
                	    			code=mtemplates.getInstanceOf("int_var");
                	    		}
                	                	code.setAttribute("num", p.ref);
                	    		prefs.add(code);
                	    		exprs.add(p.st);
                	    		p_i++;
                	    	

                	    }
                	    break;

                	default :
                	    break loop13;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }

            match(input, Token.UP, null); 

            // TEMPLATE REWRITE
            // 154:2: -> call(ret=$refname=$ID.textparam_expr=exprsparams=prefs)
            {
                retval.st = templateLib.getInstanceOf("call",
              new STAttrMap().put("ret", ref).put("name", ID18.getText()).put("param_expr", exprs).put("params", prefs));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end call


 

    public static final BitSet FOLLOW_PROGRAM_in_program59 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VARIABLES_in_program62 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_varDecl_in_program67 = new BitSet(new long[]{0x0000000000001808L});
    public static final BitSet FOLLOW_FUNCTIONS_in_program73 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_funDecl_in_program78 = new BitSet(new long[]{0x0000000000000408L});
    public static final BitSet FOLLOW_EOF_in_program86 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_funDecl119 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_funDecl121 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_funDecl125 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_PARAMATERS_in_funDecl128 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramDecl_in_funDecl133 = new BitSet(new long[]{0x0000000000006008L});
    public static final BitSet FOLLOW_block_in_funDecl140 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VARPAR_in_paramDecl170 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_paramDecl172 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_paramDecl174 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRPAR_in_paramDecl201 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_paramDecl203 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_paramDecl207 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VARDEF_in_varDecl250 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_varDecl252 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_varDecl256 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRDEF_in_varDecl302 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_varDecl304 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_varDecl308 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_INT_in_varDecl312 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block398 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VARIABLES_in_block401 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_varDecl_in_block406 = new BitSet(new long[]{0x0000000000001808L});
    public static final BitSet FOLLOW_STMTS_in_block412 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_stmt_in_block417 = new BitSet(new long[]{0x8000007F18798108L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_stmt448 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_in_stmt474 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_stmt476 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_READ_in_stmt500 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_stmt502 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WRITE_in_stmt555 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_stmt557 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WRITELN_in_stmt596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BREAK_in_stmt614 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ifStmt_in_stmt631 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStmt_in_stmt655 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_stmt679 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOP_in_stmt704 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_whileStmt729 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_whileStmt731 = new BitSet(new long[]{0x8000007F18798100L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_stmt_in_whileStmt733 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_in_ifStmt784 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_EXPR_in_ifStmt787 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_ifStmt789 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_stmt_in_ifStmt794 = new BitSet(new long[]{0x8000007F18798100L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_stmt_in_ifStmt798 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_63_in_expr862 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_64_in_expr864 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr869 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr873 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_65_in_expr932 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_66_in_expr934 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr939 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr943 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_67_in_expr1001 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1005 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1009 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_68_in_expr1053 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_69_in_expr1055 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1060 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1064 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_70_in_expr1106 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1110 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1114 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_71_in_expr1157 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1161 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1165 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_73_in_expr1208 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1212 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1216 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_72_in_expr1259 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1263 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1267 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_74_in_expr1310 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1314 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1318 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_75_in_expr1356 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1360 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1364 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_76_in_expr1402 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1406 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1410 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_77_in_expr1448 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1452 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1456 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEGATE_in_expr1494 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1498 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_in_expr1527 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1531 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NUM_in_expr1561 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INT_in_expr1563 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_expr1588 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr1590 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INDEX_in_expr1633 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr1637 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1641 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_call_in_expr1680 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ASSIGN_in_expr1694 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr1698 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1702 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ASSIGN_in_expr1735 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INDEX_in_expr1738 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr1742 = new BitSet(new long[]{0x8000000018790000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr1746 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expr_in_expr1751 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_call1815 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_call1817 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_EXPRLIST_in_call1822 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_call1827 = new BitSet(new long[]{0x8000000018790008L,0x0000000000003FFFL});

}