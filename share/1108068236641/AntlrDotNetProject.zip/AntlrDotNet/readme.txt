Microsoft Visual J# 7.1 Project to compile antlr.exe tool.


Usage:


a) Copy the AntlrDotNet directory and all files inside to the antlr-2.7.5\antlr 
   directory

b) Start Microsoft Visual Studio 7.1 and open the solution Antlr.sln

c) Compile the Debug or Release version of antlr.exe

d) The executable will be placed in the AntlrDotNet\bin\Debug or 
   AntlrDotNet\bin\Release directory


AntlrDotNet compiles with Visual Studio 2005 Beta too, it should
also compile with the free available Visual Studio J# Express compiler,
but this has not been explicitly tested.
