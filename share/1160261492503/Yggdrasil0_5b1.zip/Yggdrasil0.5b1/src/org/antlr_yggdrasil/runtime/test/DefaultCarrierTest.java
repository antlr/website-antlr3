package org.antlr_yggdrasil.runtime.test;

import junit.framework.TestCase;
import org.antlr_yggdrasil.runtime.DefaultCarrier;
import org.antlr_yggdrasil.runtime.DefaultPayload;
import org.antlr_yggdrasil.runtime.Carrier;
import org.antlr_yggdrasil.runtime.Payload;
import org.antlr_yggdrasil.runtime.ReferenceCarrier;

public class DefaultCarrierTest extends TestCase {
	Carrier carrier = null;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(DefaultCarrierTest.class);
	}

	public DefaultCarrierTest(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
		carrier = new DefaultCarrier();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		carrier = null;
	}

	public void testGetAttributes() {
		Payload pay = new DefaultPayload(5, "testGet");
		assertTrue(carrier.getAttributes() == null);
		
		carrier.setAttributes(pay);
		Payload res = carrier.getAttributes();
		assertTrue(res == pay);
	}


	public void testGetFirstChild() {
		Carrier child = new DefaultCarrier();
		assertTrue(carrier.getFirstChild() == null);
		
		carrier.setFirstChild(child);
		Carrier res = carrier.getFirstChild();
		assertTrue(res == child);
	}

	public void testGetLastSibling() {
		Carrier sib = new DefaultCarrier();
		Carrier test = null;
		
		assertTrue(carrier == carrier.getLastSibling());
		
		carrier.setNextSibling(sib);
		test = carrier.getLastSibling();
		assertTrue(test == sib);
		
		sib = new DefaultCarrier();
		test.setNextSibling(sib);
		test = carrier.getLastSibling();
		assertTrue(test == sib);
		
		sib = new DefaultCarrier();
		test.setNextSibling(sib);
		test = carrier.getLastSibling();
		assertTrue(test == sib);
		
		sib = new DefaultCarrier();
		test.setNextSibling(sib);
		test = carrier.getLastSibling();
		assertTrue(test == sib);
	}

	
	public void testGetNextSibling() {
		assertTrue(carrier.getNextSibling() == null);
		
		Carrier sib = new DefaultCarrier();
		carrier.setNextSibling(sib);
		assertTrue(carrier.getNextSibling() == sib);
	}


	/*
	 * Class under test for Object clone()
	 */
	public void testClone() {
		Carrier dup = (Carrier) carrier.clone();
		assertTrue(carrier.equals(dup));
		
		carrier.setNextSibling(dup);
		dup = (Carrier) carrier.clone();
		assertFalse(carrier.equals(dup));
	}

	public void testCopy() {
		carrier.setNextSibling(new DefaultCarrier());
		carrier.setFirstChild(new DefaultCarrier());
		
		Carrier test = carrier.copy();
		assertTrue(carrier.equals(test));
	}

	/*
	 * Class under test for void DefaultCarrier(Payload)
	 */
	public void testDefaultCarrierPayload() {
		Payload p = new DefaultPayload();
		Carrier c = new DefaultCarrier(p);
		
		assertTrue(c.getAttributes() == p);
	}

	public void testGetText() {
		Payload p = new DefaultPayload(-1, "testGetText");
		carrier.setAttributes(p);
		
		assertTrue(carrier.getText().equals("testGetText"));
	}

	public void testGetType() {
		Payload p = new DefaultPayload(3, "testGetType");
		carrier.setAttributes(p);
		
		assertTrue(carrier.getType()== 3);
	}

	public void testSetText() {
		Payload p = new DefaultPayload(3, "testGetType");
		carrier.setAttributes(p);
		
		carrier.setText("TestSetText");
		
		assertTrue(p.getText().equals("TestSetText"));
	}

	public void testSetType() {
		Payload p = new DefaultPayload(4, "testSetType");
		carrier.setAttributes(p);
		
		carrier.setType(5);
		
		assertTrue(carrier.getType() == 5);
		assertTrue(p.getType() == 5);
	}

	public void testWrap() {
		Payload p = new DefaultPayload();
		
		Carrier test = carrier.wrap();
		assertTrue((test instanceof ReferenceCarrier) && (((ReferenceCarrier) test).getCarrier() == carrier));
		
		carrier.setAttributes(p);
		test = carrier.wrap();
		assertTrue((test != carrier) && carrier.equals(test));
	}

}
