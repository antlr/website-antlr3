package satc.antlr;

import java.util.logging.Logger;

import satc.ListToken;
import antlr.CommonAST;
import antlr.Token;
import antlr.collections.AST;

public class DocAST extends CommonAST  
{

	private DocAST parentPN;

	public DocAST() {
		super();
	}

	public DocAST( Token token) {
		super( token);
	}

	public int getLine() {
		return line;
	}

	public DocAST getParentPN() {
		return parentPN;
	}
	
	public void setParentPN( DocAST parentPN) {
		this.parentPN = parentPN;
	}

    public void initialize( DocAST t) {
		log.finest("-->initialize( DocAST t)");
        super.initialize( t);
		line = t.line;
		column = t.column;
		startLine = t.startLine;
		startColumn = t.startColumn;
		endLine = t.endLine;
		endColumn = t.endColumn;
    }

    public void initialize( Token tok) {
    	log.finest("-->initialize( Token tok)");
        super.initialize( tok);
		line = tok.getLine();
		column = tok.getColumn();
//		((ListToken)tok).setAST(this);
    }


    /** Is node t equal to this in terms of token type and text? */
    public boolean equals(Object o) {
		try {
			AST t = (AST) o;
        if (t == null) return false;
        return this.getText().equals(t.getText()) &&
            this.getType() == t.getType();
		} catch (Exception e) {
			return false;
		}
    }

	/**
	 * @return
	 */
	public ListToken getFirstToken() {
		return firstToken;
	}

	/**
	 * @return
	 */
	public ListToken getLastToken() {
		return lastToken;
	}

	/**
	 * @param token
	 */
	public void setFirstToken(ListToken token) {
		firstToken = token;
	}

	/**
	 * @param token
	 */
	public void setLastToken(ListToken token) {
		lastToken = token;
	}

	/**
	 * @return
	 */
	public boolean isDamaged() {
		return damaged;
	}

	/**
	 * @param b
	 */
	public void setDamaged(boolean b) {
		log.fine("-->setDamaged(" + b + ") in " + this);
		damaged = b;
		if (getParentPN() != null && b) 
			((DocAST)getParentPN()).setDamaged(true);
	}

	private ListToken token;
	private DocAST previous;
	public int line;
	public int column;
	public int startLine = -1;
	public int startColumn = -1;
	public int endLine = -1;
	public int endColumn = -1;
	
	private ListToken firstToken;
	private ListToken lastToken;

	private boolean damaged;
	private boolean isParseNode;
	
	
	
	/**
	 * @param startAST
	 */
	public void setPreviousSibling( DocAST ast) {
		previous = ast;
	}
	
	public DocAST getPreviousSibling() {
		return previous;
	}

	/**
	 * 
	 */
	public DocAST setDamagedAfter() {
		log.fine("-->setDamagedAfter() in " + this);
		DocAST parent = (DocAST) getParentPN();
		if (parent != null) {
			if (parent.getLastToken() != this.getLastToken())
				parent.setDamaged( true);
			else
				return parent.setDamagedAfter();
		}
		return parent;
	}

	/**
	 * 
	 */
	public DocAST setDamagedBefore() {
		log.fine("-->setDamagedBefore() in " + this);
		DocAST parent = (DocAST) getParentPN();
		if (parent != null) {
			if (parent.getFirstToken() != this.getFirstToken())
				parent.setDamaged( true);
			else
				return parent.setDamagedBefore();
		}
		return parent;
	}

	/**
	 * @return
	 */
	public ListToken getToken() {
		if (token == null) { 
			token = new ListToken( this.getType(), this.getText());
			token.setAST(this);
			token.setPN(this);
		}
		return token;
	}

	/**
	 * @return
	 */
	public boolean isParseNode() {
		return isParseNode;
	}

	/**
	 * @param b
	 */
	public void setParseNode( boolean b) {
		isParseNode = b;
	}

	private static Logger log = Logger.getLogger("satc.antlr.DocAST");

}

