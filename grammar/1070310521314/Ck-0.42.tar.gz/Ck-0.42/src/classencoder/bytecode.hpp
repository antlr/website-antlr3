/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef BYTECODE_HPP
#define BYTECODE_HPP

#include <fstream>
#include <vector>

#include "defs.hpp"
#include "classwriterbase.hpp"

namespace ClassEncoder
{

class ConstantPool;

//! This class is used to handle and create java bytecode.
/*!
 * This is done through the emit_xxx... functions representing java assembly commands.
 * The java assembly codes are not documented in detail, however detailed information about what they do can be found here: http://mrl.nyu.edu/~meyer/jvmref/
 * This class consists of quite a lot of duplicated or very similar code. This was a design decision to keep things simple. Smart and short functions would be error prone and hard to maintain.
 */
class ByteCode : public ClassWriterBase
{
public:
    ByteCode( ConstantPool *pool );
    virtual ~ByteCode();

    //! Get the maximum stack size during execution
    /*!
     * \return Maximum stack size during execution. Note that this value may be wrong if jumps are used in the code.
     */
    unsigned int maxStackSize() const { return MaxStackSize; }
    //! Get the address of the next instruction
    /*!
     * \return Next instruction address.
     */
    unsigned int nextInstrAddr() const { return Code.size(); }

    void write( std::ofstream &stream ) const;

    // EMIT FUNCTIONS
    // Only the fuctions we need are implemented here..
    // see http://www.comnets.rwth-aachen.de/doc/java/vmspec/vmspec-12.html#HEADING12-0 for complete listings of all functions in each category
    // PUSH CONSTANTS ONTO THE STACK
    unsigned int emit_iconst( int number );
    unsigned int emit_bipush( u1 num );
    unsigned int emit_sipush( u2 num );
    unsigned int emit_ldc( u1 index );
    unsigned int emit_ldc2( u2 index );

    // LOADING LOCALS ON THE STACK
    unsigned int emit_iload( u1 vindex );
    unsigned int emit_lload( u1 vindex );
    unsigned int emit_fload( u1 vindex );
    unsigned int emit_dload( u1 vindex );
    unsigned int emit_aload( u1 vindex );

    // STORING STACK TO LOCALS
    unsigned int emit_istore( u1 vindex );
    unsigned int emit_lstore( u1 vindex );
    unsigned int emit_fstore( u1 vindex );
    unsigned int emit_dstore( u1 vindex );
    unsigned int emit_astore( u1 vindex );
    unsigned int emit_iinc( u1 vindex, u1 value ); // increment integer var at vindex with value

    // ARRAY FUNCTIONS
    unsigned int emit_newarray( _basic_data_types type );
    unsigned int emit_multianewarray( u2 index, u1 dimensions );
    unsigned int emit_multianewarray( const std::string classType, u1 dimensions );

    unsigned int emit_iastore();
    unsigned int emit_lastore();
    unsigned int emit_fastore();
    unsigned int emit_dastore();
    unsigned int emit_aastore();
    unsigned int emit_bastore();
    unsigned int emit_castore();
    unsigned int emit_sastore();

    unsigned int emit_iaload();
    unsigned int emit_laload();
    unsigned int emit_faload();
    unsigned int emit_daload();
    unsigned int emit_aaload();
    unsigned int emit_baload();
    unsigned int emit_caload();
    unsigned int emit_saload();

    // STACK INSTRUCTIONS
    unsigned int emit_pop();
    unsigned int emit_pop2();
    unsigned int emit_dup();
    unsigned int emit_dup2();
    unsigned int emit_dup_x1();
    unsigned int emit_dup_x2();
    unsigned int emit_swap();

    // ARITHMETIC INSTRUCTIONS
private:
    unsigned int emit_arithmetic( _opcode code, unsigned int popVal = 1 );
public:
    unsigned int emit_iadd(); // add
    unsigned int emit_ladd();
    unsigned int emit_fadd();
    unsigned int emit_dadd();
    unsigned int emit_isub(); // sub
    unsigned int emit_lsub();
    unsigned int emit_fsub();
    unsigned int emit_dsub();
    unsigned int emit_imul(); // mul
    unsigned int emit_lmul();
    unsigned int emit_fmul();
    unsigned int emit_dmul();
    unsigned int emit_idiv(); // div
    unsigned int emit_ldiv();
    unsigned int emit_fdiv();
    unsigned int emit_ddiv();
    unsigned int emit_irem(); // mod
    unsigned int emit_lrem();
    unsigned int emit_frem();
    unsigned int emit_drem();
    unsigned int emit_ineg(); // invert
    unsigned int emit_lneg();
    unsigned int emit_fneg();
    unsigned int emit_dneg();

    // LOGICAL INSTRUCTIONS
    unsigned int emit_iand();
    unsigned int emit_ior();
    unsigned int emit_ixor();

    // CONVERSION OPERATIONS

    // CONTROL TRANSFER
private:
    unsigned int emit_transfer( _opcode code, u2 jump, unsigned int popVal = 1 );
public:
    // patch jump
    void patch( unsigned int instrAddr, u2 jump );

    unsigned int emit_ifeq( u2 jump );
    unsigned int emit_ifnull( u2 jump );
    unsigned int emit_iflt( u2 jump ); // less than
    unsigned int emit_ifle( u2 jump ); // less or equal
    unsigned int emit_ifne( u2 jump ); // not equal
    unsigned int emit_ifnonnull( u2 jump );
    unsigned int emit_ifgt( u2 jump ); // greater than
    unsigned int emit_ifge( u2 jump ); // greater or equal
    unsigned int emit_if_icmpeq( u2 jump ); // top two stack integers equal
    unsigned int emit_if_icmpne( u2 jump ); // top two stack integers not equal
    unsigned int emit_if_icmplt( u2 jump ); // integer stack 2 less than stack 1
    unsigned int emit_if_icmpgt( u2 jump ); // integer stack 2 greater than stack 1
    unsigned int emit_if_icmple( u2 jump ); // stack2 less or equal stack 1
    unsigned int emit_if_icmpge( u2 jump ); // stack 2 greater or equal stack 1
    unsigned int emit_goto( u2 jump );
    unsigned int emit_jsr( u2 jump ); // jump subroutine (ret on stack)
    unsigned int emit_ret( u1 vindex );

    // MANIPULATING OBJECT FIELDS
    unsigned int emit_getstatic( u2 index );
    unsigned int emit_getstatic( const std::string &className, const std::string &fieldName,
                                 const std::string &fieldType );

    // TABLE JUMPING (for switch)

    // METHOD INVOCATION
    /* TODO: Add num params, so we can pop correctly */
    unsigned int emit_invokevirtual( u2 index );
    unsigned int emit_invokespecial( u2 index );
    unsigned int emit_invokestatic( u2 index );
    unsigned int emit_invokeinterface( u2 index, u1 nargs );

    unsigned int emit_invokestatic( const std::string &classType, const std::string &function,
                                    const std::string &footprint );
    unsigned int emit_invokevirtual( const std::string &classType, const std::string &function,
                                     const std::string &footprint );
    unsigned int emit_invokespecial( const std::string &object, const std::string &function,
                                     const std::string &footprint );
    unsigned int emit_invokeinterface( const std::string &objectType, const std::string &function,
                                       const std::string &footprint, u1 nargs );
    // MISC OBJECT FUNCTIONS
    unsigned int emit_new( u2 index );
    unsigned int emit_new( const std::string &className );

    // FUNCTION RETURN
    unsigned int emit_ireturn();
    unsigned int emit_lreturn();
    unsigned int emit_freturn();
    unsigned int emit_dreturn();
    unsigned int emit_return();

private:
    void push( int num = 1 );
    void pop( int num = 1 );

private:
    unsigned int MaxStackSize;
    unsigned int StackSize;
    std::vector<u1> Code;

    ConstantPool *ConstantPoolEntries;
};

} // end of namespace
#endif // BYTECODE_HPP
