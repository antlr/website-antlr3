// $ANTLR : "VerilogTreeParser.g" -> "VerilogTreeParser.java"$

package satc.lang; 

public interface VerilogTreeParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int START = 4;
	int LITERAL_module = 5;
	int ID = 6;
	int PORT_LIST = 7;
	int LITERAL_parameter = 8;
	int ASSIGN = 9;
	int LITERAL_input = 10;
	int LITERAL_output = 11;
	int LITERAL_inout = 12;
	int RANGE = 13;
	int SL = 14;
	int SR = 15;
	int PLUS = 16;
	int MINUS = 17;
	int STAR = 18;
	int DIV = 19;
	int MOD = 20;
	int UNARY_PLUS = 21;
	int UNARY_MINUS = 22;
	int NUMBER = 23;
	int IDENTIFIER = 24;
	int ESCAPED_IDENTIFIER = 25;
	int NIL6 = 26;
	int NIL7 = 27;
	int NIL4 = 28;
	int NIL5 = 29;
	int NIL3 = 30;
	int NIL = 31;
	int NIL2 = 32;
}
