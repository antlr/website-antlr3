// $ANTLR 3.0b7 Validator.g 2007-05-03 14:07:36

	import java.util.HashMap;
	import java.util.Vector;
	import java.util.Map;
	import java.io.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class Validator extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "POS", "NEG", "POSTFIX", "PREFIX", "NOP", "PROGRAM", "FUNCTION", "VARDEF", "ARRDEF", "VARPAR", "ARRPAR", "BLOCK", "ASSIGN", "EXPR", "EXPRLIST", "CALL", "INDEX", "NOT", "NEGATE", "FUNCTIONS", "VARIABLES", "PARAMATERS", "STMTS", "NUM", "VAR", "TYPE", "ID", "INT", "RETURN", "READ", "WRITE", "WRITELN", "BREAK", "WHILE", "IF", "SCHAR", "SQUOTE", "CHAR", "LCHAR", "DIGIT", "LC", "UC", "NEWLINE", "WS", "COMMENT", "LINECOMMENT", "';'", "'['", "']'", "'('", "')'", "','", "'{'", "'}'", "'do'", "'for'", "'else'", "'unless'", "'='", "'or'", "'||'", "'and'", "'&&'", "'=='", "'!='", "'<>'", "'>'", "'<'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'!'", "'not'", "'++'", "'--'"
    };
    public static final int INDEX=20;
    public static final int TYPE=29;
    public static final int EXPR=17;
    public static final int VARPAR=13;
    public static final int PARAMATERS=25;
    public static final int ARRPAR=14;
    public static final int NEGATE=22;
    public static final int VARIABLES=24;
    public static final int SQUOTE=40;
    public static final int VARDEF=11;
    public static final int STMTS=26;
    public static final int PROGRAM=9;
    public static final int NEWLINE=46;
    public static final int FUNCTIONS=23;
    public static final int BLOCK=15;
    public static final int PREFIX=7;
    public static final int FUNCTION=10;
    public static final int INT=31;
    public static final int SCHAR=39;
    public static final int ASSIGN=16;
    public static final int POS=4;
    public static final int POSTFIX=6;
    public static final int DIGIT=43;
    public static final int EXPRLIST=18;
    public static final int LCHAR=42;
    public static final int ID=30;
    public static final int WHILE=37;
    public static final int WS=47;
    public static final int CHAR=41;
    public static final int WRITE=34;
    public static final int LC=44;
    public static final int COMMENT=48;
    public static final int LINECOMMENT=49;
    public static final int VAR=28;
    public static final int RETURN=32;
    public static final int IF=38;
    public static final int EOF=-1;
    public static final int NOP=8;
    public static final int BREAK=36;
    public static final int NUM=27;
    public static final int CALL=19;
    public static final int UC=45;
    public static final int NEG=5;
    public static final int NOT=21;
    public static final int WRITELN=35;
    public static final int READ=33;
    public static final int ARRDEF=12;

        public Validator(TreeNodeStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "Validator.g"; }


    	



    // $ANTLR start program
    // Validator.g:19:1: program : ^( PROGRAM ^( VARIABLES ( varDecl )* ) ^( FUNCTIONS ( funDecl )* ) call ) EOF ;
    public final void program() throws RecognitionException {

        	Main.symbols.reset_globals();

        try {
            // Validator.g:24:3: ( ^( PROGRAM ^( VARIABLES ( varDecl )* ) ^( FUNCTIONS ( funDecl )* ) call ) EOF )
            // Validator.g:24:3: ^( PROGRAM ^( VARIABLES ( varDecl )* ) ^( FUNCTIONS ( funDecl )* ) call ) EOF
            {
            match(input,PROGRAM,FOLLOW_PROGRAM_in_program51); 

            match(input, Token.DOWN, null); 
            match(input,VARIABLES,FOLLOW_VARIABLES_in_program54); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:24:25: ( varDecl )*
                loop1:
                do {
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( ((LA1_0>=VARDEF && LA1_0<=ARRDEF)) ) {
                        alt1=1;
                    }


                    switch (alt1) {
                	case 1 :
                	    // Validator.g:24:25: varDecl
                	    {
                	    pushFollow(FOLLOW_varDecl_in_program56);
                	    varDecl();
                	    _fsp--;


                	    }
                	    break;

                	default :
                	    break loop1;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            match(input,FUNCTIONS,FOLLOW_FUNCTIONS_in_program61); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:24:47: ( funDecl )*
                loop2:
                do {
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==FUNCTION) ) {
                        alt2=1;
                    }


                    switch (alt2) {
                	case 1 :
                	    // Validator.g:24:47: funDecl
                	    {
                	    pushFollow(FOLLOW_funDecl_in_program63);
                	    funDecl();
                	    _fsp--;


                	    }
                	    break;

                	default :
                	    break loop2;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            pushFollow(FOLLOW_call_in_program67);
            call();
            _fsp--;


            match(input, Token.UP, null); 
            match(input,EOF,FOLLOW_EOF_in_program70); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end program


    // $ANTLR start funDecl
    // Validator.g:27:1: funDecl : ^( FUNCTION type= TYPE name= ID ^( PARAMATERS ( . )* ) block ) ;
    public final void funDecl() throws RecognitionException {
        CommonTree type=null;
        CommonTree name=null;

        try {
            // Validator.g:28:4: ( ^( FUNCTION type= TYPE name= ID ^( PARAMATERS ( . )* ) block ) )
            // Validator.g:28:4: ^( FUNCTION type= TYPE name= ID ^( PARAMATERS ( . )* ) block )
            {
            match(input,FUNCTION,FOLLOW_FUNCTION_in_funDecl82); 

            match(input, Token.DOWN, null); 
            type=(CommonTree)input.LT(1);
            match(input,TYPE,FOLLOW_TYPE_in_funDecl86); 
            name=(CommonTree)input.LT(1);
            match(input,ID,FOLLOW_ID_in_funDecl90); 
            match(input,PARAMATERS,FOLLOW_PARAMATERS_in_funDecl93); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:28:46: ( . )*
                loop3:
                do {
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==UP) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_0>=POS && LA3_0<=81)) ) {
                        alt3=1;
                    }


                    switch (alt3) {
                	case 1 :
                	    // Validator.g:28:46: .
                	    {
                	    matchAny(input); 

                	    }
                	    break;

                	default :
                	    break loop3;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            Main.symbols.enter_frame(name.getText());
            pushFollow(FOLLOW_block_in_funDecl101);
            block();
            _fsp--;

            Main.symbols.exit_frame();

            match(input, Token.UP, null); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end funDecl


    // $ANTLR start varDecl
    // Validator.g:31:1: varDecl : ( ^( VARDEF TYPE name= ID ) | ^( ARRDEF TYPE name= ID size= INT ) );
    public final void varDecl() throws RecognitionException {
        CommonTree name=null;
        CommonTree size=null;
        CommonTree TYPE1=null;
        CommonTree TYPE2=null;

        try {
            // Validator.g:31:11: ( ^( VARDEF TYPE name= ID ) | ^( ARRDEF TYPE name= ID size= INT ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==VARDEF) ) {
                alt4=1;
            }
            else if ( (LA4_0==ARRDEF) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("31:1: varDecl : ( ^( VARDEF TYPE name= ID ) | ^( ARRDEF TYPE name= ID size= INT ) );", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // Validator.g:31:11: ^( VARDEF TYPE name= ID )
                    {
                    match(input,VARDEF,FOLLOW_VARDEF_in_varDecl116); 

                    match(input, Token.DOWN, null); 
                    TYPE1=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_varDecl118); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_varDecl122); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_variable(name.getText(),TYPE1.getText());

                    }
                    break;
                case 2 :
                    // Validator.g:32:4: ^( ARRDEF TYPE name= ID size= INT )
                    {
                    match(input,ARRDEF,FOLLOW_ARRDEF_in_varDecl133); 

                    match(input, Token.DOWN, null); 
                    TYPE2=(CommonTree)input.LT(1);
                    match(input,TYPE,FOLLOW_TYPE_in_varDecl135); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_varDecl139); 
                    size=(CommonTree)input.LT(1);
                    match(input,INT,FOLLOW_INT_in_varDecl143); 

                    match(input, Token.UP, null); 
                    Main.symbols.declare_array(name.getText(),TYPE2.getText(),Integer.parseInt(size.getText()));

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end varDecl


    // $ANTLR start block
    // Validator.g:35:1: block : ^( BLOCK ^( VARIABLES ( varDecl )* ) ^( STMTS ( stmt )* ) ) ;
    public final void block() throws RecognitionException {

        	Main.symbols.enter_block();

        try {
            // Validator.g:42:4: ( ^( BLOCK ^( VARIABLES ( varDecl )* ) ^( STMTS ( stmt )* ) ) )
            // Validator.g:42:4: ^( BLOCK ^( VARIABLES ( varDecl )* ) ^( STMTS ( stmt )* ) )
            {
            match(input,BLOCK,FOLLOW_BLOCK_in_block167); 

            match(input, Token.DOWN, null); 
            match(input,VARIABLES,FOLLOW_VARIABLES_in_block170); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:42:24: ( varDecl )*
                loop5:
                do {
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( ((LA5_0>=VARDEF && LA5_0<=ARRDEF)) ) {
                        alt5=1;
                    }


                    switch (alt5) {
                	case 1 :
                	    // Validator.g:42:24: varDecl
                	    {
                	    pushFollow(FOLLOW_varDecl_in_block172);
                	    varDecl();
                	    _fsp--;


                	    }
                	    break;

                	default :
                	    break loop5;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }
            match(input,STMTS,FOLLOW_STMTS_in_block177); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:42:42: ( stmt )*
                loop6:
                do {
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=POSTFIX && LA6_0<=NOP)||(LA6_0>=BLOCK && LA6_0<=ASSIGN)||(LA6_0>=CALL && LA6_0<=NEGATE)||(LA6_0>=NUM && LA6_0<=VAR)||(LA6_0>=RETURN && LA6_0<=IF)||(LA6_0>=63 && LA6_0<=77)) ) {
                        alt6=1;
                    }


                    switch (alt6) {
                	case 1 :
                	    // Validator.g:42:42: stmt
                	    {
                	    pushFollow(FOLLOW_stmt_in_block179);
                	    stmt();
                	    _fsp--;


                	    }
                	    break;

                	default :
                	    break loop6;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }

            match(input, Token.UP, null); 

            }


            	Main.symbols.exit_block();

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end block


    // $ANTLR start stmt
    // Validator.g:45:1: stmt : ( expr | ^( RETURN expr ) | ^( READ name= ID ) | ^( WRITE expr ) | WRITELN | BREAK | ifStmt | whileStmt | block | NOP );
    public final void stmt() throws RecognitionException {
        CommonTree name=null;

        try {
            // Validator.g:46:4: ( expr | ^( RETURN expr ) | ^( READ name= ID ) | ^( WRITE expr ) | WRITELN | BREAK | ifStmt | whileStmt | block | NOP )
            int alt7=10;
            switch ( input.LA(1) ) {
            case POSTFIX:
            case PREFIX:
            case ASSIGN:
            case CALL:
            case INDEX:
            case NOT:
            case NEGATE:
            case NUM:
            case VAR:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
            case 73:
            case 74:
            case 75:
            case 76:
            case 77:
                {
                alt7=1;
                }
                break;
            case RETURN:
                {
                alt7=2;
                }
                break;
            case READ:
                {
                alt7=3;
                }
                break;
            case WRITE:
                {
                alt7=4;
                }
                break;
            case WRITELN:
                {
                alt7=5;
                }
                break;
            case BREAK:
                {
                alt7=6;
                }
                break;
            case IF:
                {
                alt7=7;
                }
                break;
            case WHILE:
                {
                alt7=8;
                }
                break;
            case BLOCK:
                {
                alt7=9;
                }
                break;
            case NOP:
                {
                alt7=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("45:1: stmt : ( expr | ^( RETURN expr ) | ^( READ name= ID ) | ^( WRITE expr ) | WRITELN | BREAK | ifStmt | whileStmt | block | NOP );", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // Validator.g:46:4: expr
                    {
                    pushFollow(FOLLOW_expr_in_stmt195);
                    expr();
                    _fsp--;


                    }
                    break;
                case 2 :
                    // Validator.g:47:5: ^( RETURN expr )
                    {
                    match(input,RETURN,FOLLOW_RETURN_in_stmt202); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_stmt204);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 3 :
                    // Validator.g:48:5: ^( READ name= ID )
                    {
                    match(input,READ,FOLLOW_READ_in_stmt213); 

                    match(input, Token.DOWN, null); 
                    name=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_stmt217); 

                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(name.getText());

                    }
                    break;
                case 4 :
                    // Validator.g:49:5: ^( WRITE expr )
                    {
                    match(input,WRITE,FOLLOW_WRITE_in_stmt227); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_stmt229);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 5 :
                    // Validator.g:50:5: WRITELN
                    {
                    match(input,WRITELN,FOLLOW_WRITELN_in_stmt238); 

                    }
                    break;
                case 6 :
                    // Validator.g:51:5: BREAK
                    {
                    match(input,BREAK,FOLLOW_BREAK_in_stmt246); 

                    }
                    break;
                case 7 :
                    // Validator.g:52:5: ifStmt
                    {
                    pushFollow(FOLLOW_ifStmt_in_stmt255);
                    ifStmt();
                    _fsp--;


                    }
                    break;
                case 8 :
                    // Validator.g:53:5: whileStmt
                    {
                    pushFollow(FOLLOW_whileStmt_in_stmt261);
                    whileStmt();
                    _fsp--;


                    }
                    break;
                case 9 :
                    // Validator.g:54:5: block
                    {
                    pushFollow(FOLLOW_block_in_stmt267);
                    block();
                    _fsp--;


                    }
                    break;
                case 10 :
                    // Validator.g:55:5: NOP
                    {
                    match(input,NOP,FOLLOW_NOP_in_stmt273); 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end stmt


    // $ANTLR start whileStmt
    // Validator.g:58:1: whileStmt : ^( WHILE expr stmt ) ;
    public final void whileStmt() throws RecognitionException {
        try {
            // Validator.g:59:4: ( ^( WHILE expr stmt ) )
            // Validator.g:59:4: ^( WHILE expr stmt )
            {
            match(input,WHILE,FOLLOW_WHILE_in_whileStmt286); 

            match(input, Token.DOWN, null); 
            pushFollow(FOLLOW_expr_in_whileStmt288);
            expr();
            _fsp--;

            pushFollow(FOLLOW_stmt_in_whileStmt290);
            stmt();
            _fsp--;


            match(input, Token.UP, null); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end whileStmt


    // $ANTLR start ifStmt
    // Validator.g:61:1: ifStmt : ^( IF ^( EXPR expr ) stmt stmt ) ;
    public final void ifStmt() throws RecognitionException {
        try {
            // Validator.g:62:5: ( ^( IF ^( EXPR expr ) stmt stmt ) )
            // Validator.g:62:5: ^( IF ^( EXPR expr ) stmt stmt )
            {
            match(input,IF,FOLLOW_IF_in_ifStmt303); 

            match(input, Token.DOWN, null); 
            match(input,EXPR,FOLLOW_EXPR_in_ifStmt306); 

            match(input, Token.DOWN, null); 
            pushFollow(FOLLOW_expr_in_ifStmt308);
            expr();
            _fsp--;


            match(input, Token.UP, null); 
            pushFollow(FOLLOW_stmt_in_ifStmt311);
            stmt();
            _fsp--;

            pushFollow(FOLLOW_stmt_in_ifStmt313);
            stmt();
            _fsp--;


            match(input, Token.UP, null); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end ifStmt


    // $ANTLR start expr
    // Validator.g:66:1: expr : ( ^( ( 'or' | '||' ) expr expr ) | ^( ( 'and' | '&&' ) expr expr ) | ^( '==' expr expr ) | ^( '!=' expr expr ) | ^( '>' expr expr ) | ^( '<' expr expr ) | ^( '>=' expr expr ) | ^( '<=' expr expr ) | ^( '<>' expr expr ) | ^( '+' expr expr ) | ^( '-' expr expr ) | ^( '*' expr expr ) | ^( '/' expr expr ) | ^( NEGATE expr ) | ^( NOT expr ) | ^( NUM INT ) | ^( VAR ID ) | ^( INDEX ID expr ) | ^( PREFIX ^( VAR ID ) ^( NUM INT ) ) | ^( POSTFIX ^( VAR ID ) ^( NUM INT ) ) | call | ^( ASSIGN ID expr ) | ^( ASSIGN ^( INDEX ID expr ) expr ) );
    public final void expr() throws RecognitionException {
        CommonTree ID3=null;
        CommonTree ID4=null;
        CommonTree ID5=null;
        CommonTree ID6=null;
        CommonTree ID7=null;
        CommonTree ID8=null;

        try {
            // Validator.g:67:4: ( ^( ( 'or' | '||' ) expr expr ) | ^( ( 'and' | '&&' ) expr expr ) | ^( '==' expr expr ) | ^( '!=' expr expr ) | ^( '>' expr expr ) | ^( '<' expr expr ) | ^( '>=' expr expr ) | ^( '<=' expr expr ) | ^( '<>' expr expr ) | ^( '+' expr expr ) | ^( '-' expr expr ) | ^( '*' expr expr ) | ^( '/' expr expr ) | ^( NEGATE expr ) | ^( NOT expr ) | ^( NUM INT ) | ^( VAR ID ) | ^( INDEX ID expr ) | ^( PREFIX ^( VAR ID ) ^( NUM INT ) ) | ^( POSTFIX ^( VAR ID ) ^( NUM INT ) ) | call | ^( ASSIGN ID expr ) | ^( ASSIGN ^( INDEX ID expr ) expr ) )
            int alt8=23;
            switch ( input.LA(1) ) {
            case 63:
            case 64:
                {
                alt8=1;
                }
                break;
            case 65:
            case 66:
                {
                alt8=2;
                }
                break;
            case 67:
                {
                alt8=3;
                }
                break;
            case 68:
                {
                alt8=4;
                }
                break;
            case 70:
                {
                alt8=5;
                }
                break;
            case 71:
                {
                alt8=6;
                }
                break;
            case 73:
                {
                alt8=7;
                }
                break;
            case 72:
                {
                alt8=8;
                }
                break;
            case 69:
                {
                alt8=9;
                }
                break;
            case 74:
                {
                alt8=10;
                }
                break;
            case 75:
                {
                alt8=11;
                }
                break;
            case 76:
                {
                alt8=12;
                }
                break;
            case 77:
                {
                alt8=13;
                }
                break;
            case NEGATE:
                {
                alt8=14;
                }
                break;
            case NOT:
                {
                alt8=15;
                }
                break;
            case NUM:
                {
                alt8=16;
                }
                break;
            case VAR:
                {
                alt8=17;
                }
                break;
            case INDEX:
                {
                alt8=18;
                }
                break;
            case PREFIX:
                {
                alt8=19;
                }
                break;
            case POSTFIX:
                {
                alt8=20;
                }
                break;
            case CALL:
                {
                alt8=21;
                }
                break;
            case ASSIGN:
                {
                int LA8_22 = input.LA(2);

                if ( (LA8_22==DOWN) ) {
                    int LA8_23 = input.LA(3);

                    if ( (LA8_23==ID) ) {
                        alt8=22;
                    }
                    else if ( (LA8_23==INDEX) ) {
                        alt8=23;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("66:1: expr : ( ^( ( 'or' | '||' ) expr expr ) | ^( ( 'and' | '&&' ) expr expr ) | ^( '==' expr expr ) | ^( '!=' expr expr ) | ^( '>' expr expr ) | ^( '<' expr expr ) | ^( '>=' expr expr ) | ^( '<=' expr expr ) | ^( '<>' expr expr ) | ^( '+' expr expr ) | ^( '-' expr expr ) | ^( '*' expr expr ) | ^( '/' expr expr ) | ^( NEGATE expr ) | ^( NOT expr ) | ^( NUM INT ) | ^( VAR ID ) | ^( INDEX ID expr ) | ^( PREFIX ^( VAR ID ) ^( NUM INT ) ) | ^( POSTFIX ^( VAR ID ) ^( NUM INT ) ) | call | ^( ASSIGN ID expr ) | ^( ASSIGN ^( INDEX ID expr ) expr ) );", 8, 23, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("66:1: expr : ( ^( ( 'or' | '||' ) expr expr ) | ^( ( 'and' | '&&' ) expr expr ) | ^( '==' expr expr ) | ^( '!=' expr expr ) | ^( '>' expr expr ) | ^( '<' expr expr ) | ^( '>=' expr expr ) | ^( '<=' expr expr ) | ^( '<>' expr expr ) | ^( '+' expr expr ) | ^( '-' expr expr ) | ^( '*' expr expr ) | ^( '/' expr expr ) | ^( NEGATE expr ) | ^( NOT expr ) | ^( NUM INT ) | ^( VAR ID ) | ^( INDEX ID expr ) | ^( PREFIX ^( VAR ID ) ^( NUM INT ) ) | ^( POSTFIX ^( VAR ID ) ^( NUM INT ) ) | call | ^( ASSIGN ID expr ) | ^( ASSIGN ^( INDEX ID expr ) expr ) );", 8, 22, input);

                    throw nvae;
                }
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("66:1: expr : ( ^( ( 'or' | '||' ) expr expr ) | ^( ( 'and' | '&&' ) expr expr ) | ^( '==' expr expr ) | ^( '!=' expr expr ) | ^( '>' expr expr ) | ^( '<' expr expr ) | ^( '>=' expr expr ) | ^( '<=' expr expr ) | ^( '<>' expr expr ) | ^( '+' expr expr ) | ^( '-' expr expr ) | ^( '*' expr expr ) | ^( '/' expr expr ) | ^( NEGATE expr ) | ^( NOT expr ) | ^( NUM INT ) | ^( VAR ID ) | ^( INDEX ID expr ) | ^( PREFIX ^( VAR ID ) ^( NUM INT ) ) | ^( POSTFIX ^( VAR ID ) ^( NUM INT ) ) | call | ^( ASSIGN ID expr ) | ^( ASSIGN ^( INDEX ID expr ) expr ) );", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // Validator.g:67:4: ^( ( 'or' | '||' ) expr expr )
                    {
                    if ( (input.LA(1)>=63 && input.LA(1)<=64) ) {
                        input.consume();
                        errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_expr329);    throw mse;
                    }


                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr335);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr337);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 2 :
                    // Validator.g:68:5: ^( ( 'and' | '&&' ) expr expr )
                    {
                    if ( (input.LA(1)>=65 && input.LA(1)<=66) ) {
                        input.consume();
                        errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_expr347);    throw mse;
                    }


                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr353);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr355);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 3 :
                    // Validator.g:69:5: ^( '==' expr expr )
                    {
                    match(input,67,FOLLOW_67_in_expr365); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr367);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr369);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 4 :
                    // Validator.g:70:5: ^( '!=' expr expr )
                    {
                    match(input,68,FOLLOW_68_in_expr380); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr382);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr384);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 5 :
                    // Validator.g:71:5: ^( '>' expr expr )
                    {
                    match(input,70,FOLLOW_70_in_expr395); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr397);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr399);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 6 :
                    // Validator.g:72:5: ^( '<' expr expr )
                    {
                    match(input,71,FOLLOW_71_in_expr410); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr412);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr414);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 7 :
                    // Validator.g:73:5: ^( '>=' expr expr )
                    {
                    match(input,73,FOLLOW_73_in_expr425); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr427);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr429);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 8 :
                    // Validator.g:74:5: ^( '<=' expr expr )
                    {
                    match(input,72,FOLLOW_72_in_expr440); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr442);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr444);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 9 :
                    // Validator.g:75:5: ^( '<>' expr expr )
                    {
                    match(input,69,FOLLOW_69_in_expr455); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr457);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr459);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 10 :
                    // Validator.g:76:5: ^( '+' expr expr )
                    {
                    match(input,74,FOLLOW_74_in_expr470); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr472);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr474);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 11 :
                    // Validator.g:77:5: ^( '-' expr expr )
                    {
                    match(input,75,FOLLOW_75_in_expr486); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr488);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr490);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 12 :
                    // Validator.g:78:5: ^( '*' expr expr )
                    {
                    match(input,76,FOLLOW_76_in_expr502); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr504);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr506);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 13 :
                    // Validator.g:79:5: ^( '/' expr expr )
                    {
                    match(input,77,FOLLOW_77_in_expr518); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr520);
                    expr();
                    _fsp--;

                    pushFollow(FOLLOW_expr_in_expr522);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 14 :
                    // Validator.g:80:5: ^( NEGATE expr )
                    {
                    match(input,NEGATE,FOLLOW_NEGATE_in_expr534); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr536);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 15 :
                    // Validator.g:81:5: ^( NOT expr )
                    {
                    match(input,NOT,FOLLOW_NOT_in_expr547); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr549);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 

                    }
                    break;
                case 16 :
                    // Validator.g:82:5: ^( NUM INT )
                    {
                    match(input,NUM,FOLLOW_NUM_in_expr561); 

                    match(input, Token.DOWN, null); 
                    match(input,INT,FOLLOW_INT_in_expr563); 

                    match(input, Token.UP, null); 

                    }
                    break;
                case 17 :
                    // Validator.g:83:5: ^( VAR ID )
                    {
                    match(input,VAR,FOLLOW_VAR_in_expr575); 

                    match(input, Token.DOWN, null); 
                    ID3=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr577); 

                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID3.getText());

                    }
                    break;
                case 18 :
                    // Validator.g:84:5: ^( INDEX ID expr )
                    {
                    match(input,INDEX,FOLLOW_INDEX_in_expr590); 

                    match(input, Token.DOWN, null); 
                    ID4=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr592); 
                    pushFollow(FOLLOW_expr_in_expr594);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID4.getText());

                    }
                    break;
                case 19 :
                    // Validator.g:85:5: ^( PREFIX ^( VAR ID ) ^( NUM INT ) )
                    {
                    match(input,PREFIX,FOLLOW_PREFIX_in_expr606); 

                    match(input, Token.DOWN, null); 
                    match(input,VAR,FOLLOW_VAR_in_expr609); 

                    match(input, Token.DOWN, null); 
                    ID5=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr611); 

                    match(input, Token.UP, null); 
                    match(input,NUM,FOLLOW_NUM_in_expr615); 

                    match(input, Token.DOWN, null); 
                    match(input,INT,FOLLOW_INT_in_expr617); 

                    match(input, Token.UP, null); 

                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID5.getText());

                    }
                    break;
                case 20 :
                    // Validator.g:86:5: ^( POSTFIX ^( VAR ID ) ^( NUM INT ) )
                    {
                    match(input,POSTFIX,FOLLOW_POSTFIX_in_expr628); 

                    match(input, Token.DOWN, null); 
                    match(input,VAR,FOLLOW_VAR_in_expr631); 

                    match(input, Token.DOWN, null); 
                    ID6=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr633); 

                    match(input, Token.UP, null); 
                    match(input,NUM,FOLLOW_NUM_in_expr637); 

                    match(input, Token.DOWN, null); 
                    match(input,INT,FOLLOW_INT_in_expr639); 

                    match(input, Token.UP, null); 

                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID6.getText());

                    }
                    break;
                case 21 :
                    // Validator.g:87:5: call
                    {
                    pushFollow(FOLLOW_call_in_expr649);
                    call();
                    _fsp--;


                    }
                    break;
                case 22 :
                    // Validator.g:88:5: ^( ASSIGN ID expr )
                    {
                    match(input,ASSIGN,FOLLOW_ASSIGN_in_expr661); 

                    match(input, Token.DOWN, null); 
                    ID7=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr663); 
                    pushFollow(FOLLOW_expr_in_expr665);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID7.getText());Main.symbols.test_assign(ID7.getText());

                    }
                    break;
                case 23 :
                    // Validator.g:89:5: ^( ASSIGN ^( INDEX ID expr ) expr )
                    {
                    match(input,ASSIGN,FOLLOW_ASSIGN_in_expr677); 

                    match(input, Token.DOWN, null); 
                    match(input,INDEX,FOLLOW_INDEX_in_expr680); 

                    match(input, Token.DOWN, null); 
                    ID8=(CommonTree)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_expr682); 
                    pushFollow(FOLLOW_expr_in_expr684);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 
                    pushFollow(FOLLOW_expr_in_expr687);
                    expr();
                    _fsp--;


                    match(input, Token.UP, null); 
                    Main.symbols.test_declared(ID8.getText());Main.symbols.test_assign(ID8.getText());

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end expr


    // $ANTLR start call
    // Validator.g:93:1: call : ^( CALL ID ^( EXPRLIST ( expr )* ) ) ;
    public final void call() throws RecognitionException {
        CommonTree ID9=null;


        	int arg_count=0;

        try {
            // Validator.g:97:4: ( ^( CALL ID ^( EXPRLIST ( expr )* ) ) )
            // Validator.g:97:4: ^( CALL ID ^( EXPRLIST ( expr )* ) )
            {
            match(input,CALL,FOLLOW_CALL_in_call709); 

            match(input, Token.DOWN, null); 
            ID9=(CommonTree)input.LT(1);
            match(input,ID,FOLLOW_ID_in_call711); 
            match(input,EXPRLIST,FOLLOW_EXPRLIST_in_call714); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // Validator.g:97:25: ( expr )*
                loop9:
                do {
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( ((LA9_0>=POSTFIX && LA9_0<=PREFIX)||LA9_0==ASSIGN||(LA9_0>=CALL && LA9_0<=NEGATE)||(LA9_0>=NUM && LA9_0<=VAR)||(LA9_0>=63 && LA9_0<=77)) ) {
                        alt9=1;
                    }


                    switch (alt9) {
                	case 1 :
                	    // Validator.g:97:26: expr
                	    {
                	    pushFollow(FOLLOW_expr_in_call717);
                	    expr();
                	    _fsp--;

                	    arg_count++;

                	    }
                	    break;

                	default :
                	    break loop9;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }

            match(input, Token.UP, null); 

            		Function fcn=Main.symbols.get_function(ID9.getText());
            		if(fcn.params.size()!=arg_count){
            			Main.print_err("Invalid number of arguments to function '"+fcn.name+"'");
            		}
            	

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end call


 

    public static final BitSet FOLLOW_PROGRAM_in_program51 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VARIABLES_in_program54 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_varDecl_in_program56 = new BitSet(new long[]{0x0000000000001808L});
    public static final BitSet FOLLOW_FUNCTIONS_in_program61 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_funDecl_in_program63 = new BitSet(new long[]{0x0000000000000408L});
    public static final BitSet FOLLOW_call_in_program67 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EOF_in_program70 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_funDecl82 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_funDecl86 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_funDecl90 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_PARAMATERS_in_funDecl93 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_block_in_funDecl101 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VARDEF_in_varDecl116 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_varDecl118 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_varDecl122 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRDEF_in_varDecl133 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_varDecl135 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ID_in_varDecl139 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_INT_in_varDecl143 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block167 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VARIABLES_in_block170 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_varDecl_in_block172 = new BitSet(new long[]{0x0000000000001808L});
    public static final BitSet FOLLOW_STMTS_in_block177 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_stmt_in_block179 = new BitSet(new long[]{0x8000007F187981C8L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_stmt195 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_in_stmt202 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_stmt204 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_READ_in_stmt213 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_stmt217 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WRITE_in_stmt227 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_stmt229 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WRITELN_in_stmt238 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BREAK_in_stmt246 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ifStmt_in_stmt255 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStmt_in_stmt261 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_stmt267 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOP_in_stmt273 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_whileStmt286 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_whileStmt288 = new BitSet(new long[]{0x8000007F187981C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_stmt_in_whileStmt290 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_in_ifStmt303 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_EXPR_in_ifStmt306 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_ifStmt308 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_stmt_in_ifStmt311 = new BitSet(new long[]{0x8000007F187981C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_stmt_in_ifStmt313 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_expr329 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr335 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr337 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_expr347 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr353 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr355 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_67_in_expr365 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr367 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr369 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_68_in_expr380 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr382 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr384 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_70_in_expr395 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr397 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr399 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_71_in_expr410 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr412 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr414 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_73_in_expr425 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr427 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr429 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_72_in_expr440 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr442 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr444 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_69_in_expr455 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr457 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr459 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_74_in_expr470 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr472 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr474 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_75_in_expr486 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr488 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr490 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_76_in_expr502 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr504 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr506 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_77_in_expr518 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr520 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr522 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEGATE_in_expr534 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr536 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_in_expr547 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr549 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NUM_in_expr561 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INT_in_expr563 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_expr575 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr577 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INDEX_in_expr590 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr592 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr594 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PREFIX_in_expr606 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VAR_in_expr609 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr611 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NUM_in_expr615 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INT_in_expr617 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POSTFIX_in_expr628 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_VAR_in_expr631 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr633 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NUM_in_expr637 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INT_in_expr639 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_call_in_expr649 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ASSIGN_in_expr661 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr663 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr665 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ASSIGN_in_expr677 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INDEX_in_expr680 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr682 = new BitSet(new long[]{0x80000000187900C0L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expr_in_expr684 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expr_in_expr687 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_call709 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_call711 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_EXPRLIST_in_call714 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_call717 = new BitSet(new long[]{0x80000000187900C8L,0x0000000000003FFFL});

}