// $ANTLR : "XMLTagNameLexer.g" -> "XMLTagNameLexer.java"$

package satc.lang; 

public interface XMLTagNameTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int XF_WS = 4;
	int XF_ID = 5;
}
