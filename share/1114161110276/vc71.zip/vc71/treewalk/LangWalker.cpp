/* $ANTLR 2.7.5 (20050128): "treewalk.g" -> "LangWalker.cpp"$ */
#include "LangWalker.hpp"
#include <antlr/Token.hpp>
#include <antlr/AST.hpp>
#include <antlr/NoViableAltException.hpp>
#include <antlr/MismatchedTokenException.hpp>
#include <antlr/SemanticException.hpp>
#include <antlr/BitSet.hpp>
#line 54 "treewalk.g"

#include <iostream>

void LangWalker::printAST( RefMyAST ast )
{
	ANTLR_USE_NAMESPACE(std)cout << "Found " << getTokenName(ast->getType())
		<< " '" << ast->getText()
		<< "' at line " << ast->getLine()
		<< ANTLR_USE_NAMESPACE(std)endl;
}


#line 23 "LangWalker.cpp"
LangWalker::LangWalker()
	: ANTLR_USE_NAMESPACE(antlr)TreeParser() {
}

void LangWalker::block(RefMyAST _t) {
	RefMyAST block_AST_in = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
	
	try {      // for error handling
		RefMyAST __t17 = _t;
		RefMyAST tmp1_AST_in = _t;
		match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),LCURLY);
		_t = _t->getFirstChild();
		{ // ( ... )+
		int _cnt19=0;
		for (;;) {
			if (_t == RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
				_t = ASTNULL;
			if ((_tokenSet_0.member(_t->getType()))) {
				stat(_t);
				_t = _retTree;
			}
			else {
				if ( _cnt19>=1 ) { goto _loop19; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(ANTLR_USE_NAMESPACE(antlr)RefAST(_t));}
			}
			
			_cnt19++;
		}
		_loop19:;
		}  // ( ... )+
		_t = __t17;
		_t = _t->getNextSibling();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if ( _t != RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
			_t = _t->getNextSibling();
	}
	_retTree = _t;
}

void LangWalker::stat(RefMyAST _t) {
	RefMyAST stat_AST_in = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
	
	try {      // for error handling
		if (_t == RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
			_t = ASTNULL;
		switch ( _t->getType()) {
		case LITERAL_if:
		{
			RefMyAST __t21 = _t;
			RefMyAST tmp2_AST_in = _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),LITERAL_if);
			_t = _t->getFirstChild();
			expr(_t);
			_t = _retTree;
			stat(_t);
			_t = _retTree;
			{
			if (_t == RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
				_t = ASTNULL;
			switch ( _t->getType()) {
			case LCURLY:
			case LITERAL_if:
			case LITERAL_while:
			case ASSIGN:
			case PLUS:
			case STAR:
			case ID:
			case INT:
			{
				stat(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(ANTLR_USE_NAMESPACE(antlr)RefAST(_t));
			}
			}
			}
			_t = __t21;
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_while:
		{
			RefMyAST __t23 = _t;
			RefMyAST tmp3_AST_in = _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),LITERAL_while);
			_t = _t->getFirstChild();
			expr(_t);
			_t = _retTree;
			stat(_t);
			_t = _retTree;
			_t = __t23;
			_t = _t->getNextSibling();
			break;
		}
		case ASSIGN:
		case PLUS:
		case STAR:
		case ID:
		case INT:
		{
			expr(_t);
			_t = _retTree;
			break;
		}
		case LCURLY:
		{
			block(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(ANTLR_USE_NAMESPACE(antlr)RefAST(_t));
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if ( _t != RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
			_t = _t->getNextSibling();
	}
	_retTree = _t;
}

void LangWalker::expr(RefMyAST _t) {
	RefMyAST expr_AST_in = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
	RefMyAST asgn = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	RefMyAST plus = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	RefMyAST star = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	RefMyAST a = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	RefMyAST b = RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST);
	
	try {      // for error handling
		if (_t == RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
			_t = ASTNULL;
		switch ( _t->getType()) {
		case ASSIGN:
		{
			RefMyAST __t25 = _t;
			asgn = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),ASSIGN);
			_t = _t->getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t25;
			_t = _t->getNextSibling();
#line 84 "treewalk.g"
			printAST(asgn);
#line 182 "LangWalker.cpp"
			break;
		}
		case PLUS:
		{
			RefMyAST __t26 = _t;
			plus = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),PLUS);
			_t = _t->getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t26;
			_t = _t->getNextSibling();
#line 85 "treewalk.g"
			printAST(plus);
#line 199 "LangWalker.cpp"
			break;
		}
		case STAR:
		{
			RefMyAST __t27 = _t;
			star = (_t == ASTNULL) ? RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) : _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),STAR);
			_t = _t->getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t27;
			_t = _t->getNextSibling();
#line 86 "treewalk.g"
			printAST(star);
#line 216 "LangWalker.cpp"
			break;
		}
		case ID:
		{
			a = _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),ID);
			_t = _t->getNextSibling();
#line 87 "treewalk.g"
			printAST(a);
#line 226 "LangWalker.cpp"
			break;
		}
		case INT:
		{
			b = _t;
			match(ANTLR_USE_NAMESPACE(antlr)RefAST(_t),INT);
			_t = _t->getNextSibling();
#line 88 "treewalk.g"
			printAST(b);
#line 236 "LangWalker.cpp"
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(ANTLR_USE_NAMESPACE(antlr)RefAST(_t));
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if ( _t != RefMyAST(ANTLR_USE_NAMESPACE(antlr)nullAST) )
			_t = _t->getNextSibling();
	}
	_retTree = _t;
}

void LangWalker::initializeASTFactory( ANTLR_USE_NAMESPACE(antlr)ASTFactory& )
{
}
const char* LangWalker::tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"LCURLY",
	"RCURLY",
	"SEMI",
	"\"if\"",
	"LPAREN",
	"RPAREN",
	"\"else\"",
	"\"while\"",
	"ASSIGN",
	"PLUS",
	"STAR",
	"ID",
	"INT",
	"WS_",
	"COMMA",
	"ESC",
	"DIGIT",
	0
};

const unsigned long LangWalker::_tokenSet_0_data_[] = { 129168UL, 0UL, 0UL, 0UL };
// LCURLY "if" "while" ASSIGN PLUS STAR ID INT 
const ANTLR_USE_NAMESPACE(antlr)BitSet LangWalker::_tokenSet_0(_tokenSet_0_data_,4);


