 

/** Manage the various code projects such as JDK, Resin, Lucene,
 *  Tomcat, etc... and definitions/references within them.
 */
public class CodeRepositoryManager {
}
