package util.unicode;

public class UnknownDatatypeException extends RuntimeException {

	private static final long	serialVersionUID	= 4395476105914018790L;

	public UnknownDatatypeException(final String message) {
		super(message);
	}
}
