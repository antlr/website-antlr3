
package org.antlr.java.crossref;

import antlr.Token;
import antlr.collections.AST;
/** ANTLR AST including location
 */
public class LocationAST extends antlr.CommonAST
{
	/**
	 * Field filename
	 */
	private String filename = null;
	/**
	 * Field line
	 */
	private int line        = -1;
	/**
	 * Field column
	 */
	private int column      = -1;
	
    /**
     * Constructor for LocationAST
     */
    public LocationAST() 
    {
    	super();	
    }
    
    /**
     * Constructor for LocationAST
     * @param tok Token
     */
    public LocationAST(Token tok) 
    {
		initialize(tok);
    }
    
    /**
     * Constructor for LocationAST
     * @param type int
     * @param text String
     */
    public LocationAST(int type, String text)
    {
		initialize(type, text);
    }
    
    /**
     * Constructor for LocationAST
     * @param ast AST
     */
    public LocationAST(AST ast) 
    {
		initialize(ast);
    }

	/**
	 * Method initialize
	 * @param ast AST
	 * @see antlr.collections.AST#initialize(AST)
	 */
	public void initialize(AST ast)
	{
		super.initialize(ast);

		if(ast instanceof LocationAST)
		{
			this.copyLocationInfo((LocationAST)ast);
		}
	}

	/**
	 * Method initialize
	 * @param t Token
	 * @see antlr.collections.AST#initialize(Token)
	 */
	public void initialize(Token t)
	{
		super.initialize(t);

		setFilename(t.getFilename());
		setLine(t.getLine());
		setColumn(t.getColumn());
	}
	
    /**
     * Method copyLocationInfo
     * @param locationAST LocationAST
     */
    public void copyLocationInfo(LocationAST locationAST)
    {
    	if(locationAST!=null)
    	{
    		this.filename = locationAST.getFilename();
    		this.line = locationAST.getLine();
    		this.column = locationAST.getColumn();
    	}
    }
	/**
	 * @return int
	 */
	public int getColumn() {
		return column;
	}

	/**
	 * @param column
	 */
	public void setColumn(int column) {
		this.column = column;
	}

	/**
	 * @return String
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return int
	 */
	public int getLine() {
		return line;
	}

	/**
	 * @param line
	 */
	public void setLine(int line) {
		this.line = line;
	}

}