/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.filechooser.FileFilter;

/**
 *  This class contains general information about syntax modes. Each  
 *  syntax mode has a syntaxInfo structure associated.
 */
public final class SyntaxInfo extends FileFilter {
    
    private String type;
    private String name;
    private String[] extensions;
    private String description;
    
    /**
     *  The constructor.
     */
    public SyntaxInfo( String name, String type, List exts, String description) {
        this.name = name;
        this.type = type;
        this.extensions = (String[])exts.toArray( new String[0] );
        this.description = description;
    }

    /**
     *  Returns the MIME type.
     */ 
    public String getType() {
        return type;
    }

    /**
     *  Returns the internal name for this syntax mode. This name is used by 
     *  SATC to retrieve the appropriate classes for a certain syntax mode.
     *  All classes related to a syntax mode are prefixed with this name.
     */ 
    public String getName() {
        return name;
    }

    /**
     *  Returns the default extension for this syntax mode.
     */
    public String getDefaultExtension() {
        return extensions[0];
    }

    /**
     *  Returns a textual description of this syntax mode.
     */
    public String getDescription() {
        return description;
    }

    /**
     *  FileFilter method.
     */
    public boolean accept( File f ) {
        if( f.isDirectory()) return true;
        String fileName = f.getName();
        for( int i=0; i<extensions.length; i++) {
            if( fileName.endsWith( extensions[i])) return true;
        }
        return false;
    }

    /**
     *  Documents with unknown syntax are opened as plain text.
     */ 
    public static SyntaxInfo getDefaultSyntaxInfo() {
        ArrayList extensionList = new ArrayList();
        extensionList.add( "*.*");
        return new SyntaxInfo( 
            "PlainText",
            "text/plain",
            extensionList,
            "Default syntax mode: plain text"
        );
    }
}


