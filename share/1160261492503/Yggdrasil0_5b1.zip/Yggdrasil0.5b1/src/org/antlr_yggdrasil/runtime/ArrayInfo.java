package org.antlr_yggdrasil.runtime;

public class ArrayInfo extends CollectionInfo {

	private String indexedType = null;
	public ArrayInfo(String type_) {
		super(type_);
		// TODO Auto-generated constructor stub
	}

	public ArrayInfo(String type_, TypeInfo base) {
		super(type_, base);
		// TODO Auto-generated constructor stub
	}

	public void setIndexedType(String indexType) {
		this.indexedType = indexType;
	}

	public String getIndexedType() {
		return indexedType;
	}

	
}
