/* Main class for translating bison Grammars to ANTLR 

 [The "BSD licence"]
 Copyright (c) 2005 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */


import java.io.*;
import antlr.collections.AST;
import antlr.collections.impl.*;
import antlr.debug.misc.*;
import antlr.*;
import java.awt.event.*;

class BisonReader {

	public static void main(String[] args) {
		String path;
		File file;
	    
		// Use a try/catch block for parser exceptions
		try {
			// if we have at least one command-line argument
			if (args.length > 0 ) {
				System.err.println("Parsing...");
				// for each directory/file specified on the command line
				for(int i=0; i< args.length;i++) {
					if ( args[i].equals("-o") ) {
						i++;
						path = args[i];
					}
					else { // file name
						file = new File(args[i]));
					}
				}
				doFile(file, path);
			}
			else {
				System.err.println("Usage: java BisonReader"
					" [-o directory] " +
					"<file name>");
			}
			catch(Exception e) {
				System.err.println("exception: "+e);
				e.printStackTrace(System.err);   // so we can get stack trace
			}
		}
	}

	// This method decides what action to take based on the type of
	//   file we are looking at
	public static void doFile(File f, String path)
							  throws Exception {
		System.err.println("   "+f.getAbsolutePath());
		// parseFile(f.getName(), new FileInputStream(f));
		parseFile(f.getName(), new BufferedReader(new FileReader(f)));
	}

	// Here's where we do the real work...
	public static void parseFile(String f, Reader r)
			throws Exception {
		try {
			// Create a scanner that reads from the input stream passed to us
			BisonLexer lexer = new BisonLexer(r);
			lexer.setFilename(f);

			// Create a parser that reads from the scanner
			BisonParser parser = new BisonParser(lexer);
			parser.setFilename(f);

			// start parsing at the compilationUnit rule
			parser.grammar();
			
			// do something with the tree
			doTreeAction(f, parser.getAST(), path);
		}
		catch (Exception e) {
			System.err.println("parser exception: "+e);
			e.printStackTrace();   // so we can get stack trace		
		}
	}
	
	public static void doTreeAction(String f, AST t, String path) {
		if ( t==null )
			return;
		
		BisonParserTree tparse = new BisonParserTree();
		tparse.setFilename(f);
		tparse.setPath(path);
		try {
			tparse.grammar(t);
		}
		catch (RecognitionException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

	}
}

