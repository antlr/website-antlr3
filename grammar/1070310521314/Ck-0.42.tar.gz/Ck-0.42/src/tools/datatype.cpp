/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#include "datatype.hpp"
#include "exception.hpp"

#include <sstream>

using namespace std;

//! Default constructor
CkDataType::CkDataType()
{
    commontInit();
}

//! type constructor
/*
 * Initializes this type to a non array type of the basic type given
 * \param type The basic type of this type
 */
CkDataType::CkDataType( Types type )
{
    commontInit();
    Type = type;
}

//! Single dimension array constructor
/*
 * Initializes this type to a single dimension array of the basic type given
 * \param type The basic type of this type
 * \param dim the Size of the dimension
 */
CkDataType::CkDataType( Types type, int dim )
{
    commontInit();
    Type = type;
    Dimensions[0] = dim;
}

//! double dimension array constructor
/*
 * Initializes this type to a double dimension array of the basic type given
 * \param type The basic type of this type
 * \param dim1 the Size of the first dimension
 * \param dim2 the Size of the second dimension
 */
CkDataType::CkDataType( Types type, int dim1, int dim2 )
{
    commontInit();
    Type = type;
    Dimensions[0] = dim1;
    Dimensions[1] = dim2;
}

//! Copy constructor
CkDataType::CkDataType( const CkDataType &other )
{
    commontInit();
    *this = other;
}

//! Initializes all variables of this class. Common for all constructors
void CkDataType::commontInit()
{
    Dimensions[0] = Dimensions[1] = 0;
    Type = Undefined;
}

//! Expand type with one dimension
/*!
 * The new dimension is added in front.
 * \param dim Size of new dimension
 */
void CkDataType::expandDimension( int dim )
{
    Dimensions[1] = Dimensions[0];
    Dimensions[0] = dim;
}


//! Get the number of dimensions for this variable. 0 means that it is not an array.
unsigned int CkDataType::getNumDimensions() const
{
    if( Dimensions[0] != 0 && Dimensions[1] != 0 )
        return 2;
    else if( Dimensions[0] != 0 )
        return 1;
    else
        return 0;
}

//! Convert DataTypes to string information.
/*!
 * \param type The type you want to convert
 * \return The string representation of the type.
 */
string CkDataType::dataTypeToString( Types type )
{
    string result = "undefined";
    switch( type )
    {
        case Undefined: result = "undefined"; break;
        case PrimVoid: result = "void"; break;
        case PrimBool: result = "bool"; break;
        case PrimChar: result = "char"; break;
        case PrimInt: result = "int"; break;
        case Custom:  result = "custom"; break;
    }
    return result;
}

//! Convert this datatype to a string representation
/*!
 * This function converts the datatype to a literal representation:
 * e.g An non array integer type is represented as "int".
 * A multidimensional integer array with dimensions 2 and 4 is represted as "int[2][4]"
 */
string CkDataType::toString() const
{
    stringstream array;
    if( Dimensions[0] > 0)
        array << "["  << Dimensions[0] << "]";
    if( Dimensions[0] == -1)
        array << "[]";

    if( Dimensions[1] > 0)
        array << "["  << Dimensions[1] << "]";
    if( Dimensions[1] == -1)
        array << "[]";

    return dataTypeToString( Type ) + array.str();
}

//! Converts this datatype to a JVM identification string
/*!
 * \return the JVM id string.
 */
string CkDataType::toJVMString() const
{
    string retString;
    if( Dimensions[0] != 0 )
        retString = "[";
    if( Dimensions[1] != 0 )
        retString += "[";

    switch( Type )
    {
        case PrimVoid: retString = "V"; break; // = is intentional
        case PrimBool:
        case PrimInt: retString += "I"; break;
        case PrimChar: retString += "C"; break;
        default: break; // make gcc happy
    }
    return retString;
}

//! Compare datatype to basic datatype
/*
 * \return Returns true if this datatype is a non dimensional variable with the same type. Otherwise false is returned.
 */
bool CkDataType::operator==( Types type ) const
{
    if( getNumDimensions() == 0 && Type == type ) return true;
    return false;
}

//! Compare datatype to basic datatype
/*
 * \return Returns false if this datatype is a non dimensional variable with the same type. Otherwise true is returned.
 */
bool CkDataType::operator!=( Types type ) const
{
    if( getNumDimensions() == 0 && Type != type ) return true;
    return false;
}

//! Compare two datatypes
/*
 * \return Returns true if the datatypes have the same basic type and the same dimensions. Or one 
 * of the basic types has an undefined size. 
 * 
 * Otherwise false is returned.
 */
bool CkDataType::operator==( const CkDataType &other ) const
{
    if( Type == other.Type && 
			((Dimensions[0] == other.Dimensions[0] && Dimensions[1] == other.Dimensions[1]) || 
			 (Dimensions[1] == -1 && other.Dimensions[1] != 0) || 
			 (other.Dimensions[1] == -1 && Dimensions[1] != 0)) ||

			 ((Dimensions[0] == -1 && other.Dimensions[0] != 0 || 
			   Dimensions[0] != 0 && other.Dimensions[0] == -1)&&
			  (Dimensions[1] == other.Dimensions[1] ||
			   Dimensions[1] == -1 && other.Dimensions[1] != 0 ||
			   Dimensions[1] != 0 && other.Dimensions[1] == -1)))
        return true;
    return false;
}

//! Compare two datatypes
/*
 * \return Returns false if the datatypes have the same basic type and the same dimensions. Otherwise true is returned.
 */
bool CkDataType::operator!=( const CkDataType &other ) const
{
    return !(*this == other);
}

//! Return this datatype converted around the given dimensions
/*!
 *
 * e.g this datatype is int[2][5];
 * converting 1 dimensions returns a datatype that is int[5]
 * converting 2 dimensions return a datatype that is int
 */
CkDataType CkDataType::reduceDimensions( unsigned int varDimensions ) const
{
    if( varDimensions < 1 || varDimensions > getNumDimensions() )
        throw Exception( "invalid types for array subscript" );

    CkDataType newType = Type;
    if( getNumDimensions() == 2 )
    {
        // reduce from int[10][2] -> int[2]
        if( varDimensions == 1 ) newType.setDimensions( Dimensions[1], 0 );
        // if varDimensions == 2 .. there is nothing to do int[10][2] -> int
    }
    // if our dimension size == 1, then varDimensions also was 1.. nothing to do
    return newType;
}
