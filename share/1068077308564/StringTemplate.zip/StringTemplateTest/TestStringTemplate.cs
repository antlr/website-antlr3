using System;
using System.IO;
using System.Collections;
using System.Text;
using System.Net;

using Antlr.StringTemplate;
using Antlr.StringTemplate.Language;

namespace StringTemplateTest {
	/// <summary>
	/// Summary description for TestStringTemplate.
	/// </summary>

	public class TestStringTemplate : TestSuite {

		public TestStringTemplate() {
		}

		public override void runTests() {
			runTest("testFindTemplateInManifest");
			runTest("testApplyingTemplateFromUrlWithPrecompiledIF");
			runTest("testSimpleInheritance");
			runTest("testOverrideInheritance");
			runTest("testMultiLevelInheritance");
			runTest("testExprInParens");
			runTest("testMultipleAdditions");
			runTest("testCollectionAttributes");
			runTest("testParenthesizedExpression");
			/* (foo)() breaks encapsulation
			runTest("testApplyTemplateNameExpression");
			runTest("testTemplateNameExpression");
			*/
			runTest("testMissingEndDelimiter");
			runTest("testSetButNotRefd");
			runTest("testNullTemplateToMultiValuedApplication");
			runTest("testNullTemplateApplication");
			runTest("testChangingAttrValueTemplateApplicationToVector");
			runTest("testChangingAttrValueRepeatedTemplateApplicationToVector");
			runTest("testTemplateApplicationAsRHSOfAssignment");
			runTest("testAlternatingTemplateApplication");
			runTest("testParameterAndAttributeScoping");
			runTest("testExpressionAsRHSOfAssignment");
			runTest("testComplicatedSeparatorExpr");
			runTest("testApplyRepeatedAnonymousTemplateWithForeignTemplateRefToMultiValuedAttribute");
			runTest("testAttributeRefButtedUpAgainstEndifAndWhitespace");
			runTest("testApplyAnonymousTemplateToMultiValuedAttribute");
			runTest("testStringCatenationOnSingleValuedAttribute");
			runTest("testMultiValuedAttributeWithSeparator");
			runTest("testApplyingTemplateFromDiskWithPrecompiledIF");
			runTest("testSingleValuedAttributes");
			runTest("testIFTemplate");
			runTest("testNestedIFTemplate");
			runTest("testApplyTemplateToSingleValuedAttribute");
			runTest("testApplyTemplateToSingleValuedAttributeWithDefaultAttribute");
			runTest("testApplyAnonymousTemplateToSingleValuedAttribute");
			runTest("testRepeatedApplicationOfTemplateToSingleValuedAttribute");
			runTest("testRepeatedApplicationOfTemplateToMultiValuedAttributeWithSeparator");
			runTest("testFindTemplateInCLASSPATH");
			runTest("testMultiValuedAttributeWithAnonymousTemplateUsingIndexVariableI");
			runTest("testStringLiteralAsAttribute");
			runTest("testObjectPropertyReference");
			runTest("testRecursion");
		}

		class ErrorBuffer : IStringTemplateErrorListener {
			StringBuilder errorOutput = new StringBuilder(500);

			public void Error(String msg, Exception e) {
				if ( e!=null ) {
					errorOutput.Append(msg+e);
				}
				else {
					errorOutput.Append(msg);
				}
			}
			
			public void Warning(String msg) {
				errorOutput.Append(msg);
			}
			
			public void Debug(String msg) {
				errorOutput.Append(msg);
			}

			public override String ToString() {
				return errorOutput.ToString();
			}
		}

		public void testSimpleInheritance() {
			// make a bold template in the super group that you can inherit from sub
			StringTemplateGroup supergroup = new StringTemplateGroup("super");
			StringTemplateGroup subgroup = new StringTemplateGroup("sub");
			StringTemplate bold = supergroup.DefineTemplate("bold", "<b>$attr$</b>");
			subgroup.SuperGroup  = supergroup;
			IStringTemplateErrorListener errors = new ErrorBuffer();
			subgroup.ErrorListener = errors;
			supergroup.ErrorListener = errors;
			StringTemplate duh = new StringTemplate(subgroup, "$name:bold()$");
			duh.SetAttribute("name", "Terence");
			String expecting = "<b>Terence</b>";
			assertTrue(duh.ToString().Equals(expecting));
		}

		public void testOverrideInheritance() {
			// make a bold template in the super group and one in sub group
			StringTemplateGroup supergroup = new StringTemplateGroup("super");
			StringTemplateGroup subgroup = new StringTemplateGroup("sub");
			supergroup.DefineTemplate("bold", "<b>$attr$</b>");
			subgroup.DefineTemplate("bold", "<strong>$attr$</strong>");
			subgroup.SuperGroup = supergroup;
			IStringTemplateErrorListener errors = new ErrorBuffer();
			subgroup.ErrorListener = errors;
			supergroup.ErrorListener = errors;
			StringTemplate duh = new StringTemplate(subgroup, "$name:bold()$");
			duh.SetAttribute("name", "Terence");
			String expecting = "<strong>Terence</strong>";
			assertTrue(duh.ToString().Equals(expecting));
		}

		public void testMultiLevelInheritance() {
			// must loop up two levels to find bold()
			StringTemplateGroup rootgroup = new StringTemplateGroup("root");
			StringTemplateGroup level1 = new StringTemplateGroup("level1");
			StringTemplateGroup level2 = new StringTemplateGroup("level2");
			rootgroup.DefineTemplate("bold", "<b>$attr$</b>");
			level1.SuperGroup = rootgroup;
			level2.SuperGroup = level1;
			IStringTemplateErrorListener errors = new ErrorBuffer();
			rootgroup.ErrorListener = errors;
			level1.ErrorListener = errors;
			level2.ErrorListener = errors;
			StringTemplate duh = new StringTemplate(level2, "$name:bold()$");
			duh.SetAttribute("name", "Terence");
			String expecting = "<b>Terence</b>";
			assertTrue(duh.ToString().Equals(expecting));
		}

		public void testExprInParens() {
			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate duh = new StringTemplate(group, "$(\"blort: \"+(list)):bold()$");
			duh.SetAttribute("list", "a");
			duh.SetAttribute("list", "b");
			duh.SetAttribute("list", "c");
			// System.out.println(duh);
			String expecting = "<b>blort: abc</b>";
			assertTrue(duh.ToString().Equals(expecting));
		}

		public void testMultipleAdditions() {
			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			group.DefineTemplate("link", "<a href=\"$url$\"><b>$title$</b></a>");
			StringTemplate duh =
				new StringTemplate(group,
				"$link(url=\"/member/view?ID=\"+ID+\"&x=y\"+foo, title=\"the title\")$");
			duh.SetAttribute("ID", "3321");
			duh.SetAttribute("foo", "fubar");
			String expecting = "<a href=\"/member/view?ID=3321&x=yfubar\"><b>the title</b></a>";
			assertTrue(duh.ToString().Equals(expecting));
		}

		public void testCollectionAttributes() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate t =
				new StringTemplate(group, "$data$, $data:bold()$, "+
				"$list:bold():bold()$, $array$, $a2$, $a3$, $a4$");
			ArrayList v = new ArrayList();
			v.Add("1");
			v.Add("2");
			v.Add("3");
			IList list = new ArrayList();
			list.Add("a");
			list.Add("b");
			list.Add("c");
			t.SetAttribute("data", v);
			t.SetAttribute("list", list);
			t.SetAttribute("array", new String[] {"x","y"});
			t.SetAttribute("a2", new int[] {10,20});
			t.SetAttribute("a3", new float[] {1.2f,1.3f});
			t.SetAttribute("a4", new double[] {8.7,9.2});
			//System.out.println(t);
			String expecting="123, <b>1</b><b>2</b><b>3</b>, "+
				"<b><b>a</b></b><b><b>b</b></b><b><b>c</b></b>, xy, 1020, 1.21.3, 8.79.2";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testParenthesizedExpression() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate t = new StringTemplate(group, "$(first+last):bold()$");
			t.SetAttribute("first", "Joe");
			t.SetAttribute("last", "Schmoe");
			//System.out.println(t);
			String expecting="<b>JoeSchmoe</b>";
			assertTrue(t.ToString().Equals(expecting));
		}

		/*
		public void testApplyTemplateNameExpression() {
			StringTemplateGroup group =
					new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("foobar", "foo$attr$bar");
			StringTemplate t = new StringTemplate(group, "$data:(name+\"bar\")()$");
			t.SetAttribute("data", "Ter");
			t.SetAttribute("data", "Tom");
			t.SetAttribute("name", "foo");
			//System.out.println(t);
			String expecting="fooTerbarfooTombar";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testTemplateNameExpression() {
			StringTemplateGroup group =
					new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("foo", "hi there!");
			StringTemplate t = new StringTemplate(group, "$(name)()$");
			t.SetAttribute("name", "foo");
			//System.out.println(t);
			String expecting="hi there!";
			assertTrue(t.ToString().Equals(expecting));
		}
		*/

		public void testMissingEndDelimiter() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			IStringTemplateErrorListener errors = new ErrorBuffer();
			group.ErrorListener = errors;
			StringTemplate t = new StringTemplate(group, "stuff $a then more junk etc...");
			String expectingError="end delimiter '$' not found in template for delimiter starting at index 30";
			//System.out.println("error: '"+errorOutput+"'");
			//System.out.println("expecting: '"+expectingError+"'");
			assertTrue(errors.ToString().Equals(expectingError));
		}

		public void testSetButNotRefd() {
			StringTemplate.InLintMode = true;
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate t = new StringTemplate(group, "$a$ then $b$ and $c$ refs.");
			t.SetAttribute("a", "Terence");
			t.SetAttribute("b", "Terence");
			t.SetAttribute("cc", "Terence"); // oops...should be 'c'
			String newline = Environment.NewLine;
			IStringTemplateErrorListener errors = new ErrorBuffer();
			group.ErrorListener = errors;
			String expectingError="anonymous: set but not used: cc";
			String result = t.ToString();    // result is irrelevant
			//System.out.println("error: '"+errorOutput+"'"); // filled after t.ToString()
			//System.out.println("expecting: '"+expectingError+"'");
			StringTemplate.InLintMode = false;
			assertTrue(errors.ToString().Equals(expectingError));
		}

		public void testNullTemplateApplication() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			IStringTemplateErrorListener errors = new ErrorBuffer();
			group.ErrorListener = errors;
			StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
			t.SetAttribute("names", "Terence");
			//System.out.println(t);
			String expecting=""; // bold not found...empty string
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testNullTemplateToMultiValuedApplication() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			IStringTemplateErrorListener errors = new ErrorBuffer();
			group.ErrorListener = errors;
			StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
			t.SetAttribute("names", "Terence");
			t.SetAttribute("names", "Tom");
			//System.out.println(t);
			String expecting=""; // bold not found...empty string
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testChangingAttrValueTemplateApplicationToVector() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate italics = group.DefineTemplate("italics", "<i>$x$</i>");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$x$</b>");
			StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
			t.SetAttribute("names", "Terence");
			t.SetAttribute("names", "Tom");
			//System.out.println(t);
			String expecting="<b>Terence</b><b>Tom</b>";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testChangingAttrValueRepeatedTemplateApplicationToVector() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$item$</b>");
			StringTemplate italics = group.DefineTemplate("italics", "<i>$it$</i>");
			StringTemplate members =
				new StringTemplate(group, "$members:bold(item=attr):italics(it=attr)$");
			members.SetAttribute("members", "Jim");
			members.SetAttribute("members", "Mike");
			members.SetAttribute("members", "Ashar");
			//System.out.println("members="+members);
			String expecting = "<i><b>Jim</b></i><i><b>Mike</b></i><i><b>Ashar</b></i>";
			assertTrue(members.ToString().Equals(expecting));
		}

		public void testAlternatingTemplateApplication() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate listItem = group.DefineTemplate("listItem", "<li>$attr$</li>");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate italics = group.DefineTemplate("italics", "<i>$attr$</i>");
			StringTemplate item =
				new StringTemplate(group, "$item:bold(),italics():listItem()$");
			item.SetAttribute("item", "Jim");
			item.SetAttribute("item", "Mike");
			item.SetAttribute("item", "Ashar");
			//System.out.println("ITEM="+item);
			String expecting = "<li><b>Jim</b></li><li><i>Mike</i></li><li><b>Ashar</b></li>";
			assertTrue(item.ToString().Equals(expecting));
		}

		public void testExpressionAsRHSOfAssignment() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate hostname = group.DefineTemplate("hostname", "$machine$.jguru.com");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$x$</b>");
			StringTemplate t = new StringTemplate(group, "$bold(x=hostname(machine=\"www\"))$");
			String expecting="<b>www.jguru.com</b>";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testTemplateApplicationAsRHSOfAssignment() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate hostname = group.DefineTemplate("hostname", "$machine$.jguru.com");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$x$</b>");
			StringTemplate italics = group.DefineTemplate("italics", "<i>$attr$</i>");
			StringTemplate t = new StringTemplate(group, "$bold(x=hostname(machine=\"www\"):italics())$");
			String expecting="<b><i>www.jguru.com</i></b>";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testParameterAndAttributeScoping() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate italics = group.DefineTemplate("italics", "<i>$x$</i>");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$x$</b>");
			StringTemplate t = new StringTemplate(group, "$bold(x=italics(x=name))$");
			t.SetAttribute("name", "Terence");
			//System.out.println(t);
			String expecting="<b><i>Terence</i></b>";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testComplicatedSeparatorExpr() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bulletSeparator", "</li>$foo$<li>");
			// make separator a complicated expression with args passed to included template
			StringTemplate t =
				new StringTemplate(group,
				"<ul>$name; separator=bulletSeparator(foo=\" \")+\"&nbsp;\"$</ul>");
			t.SetAttribute("name", "Ter");
			t.SetAttribute("name", "Tom");
			t.SetAttribute("name", "Mel");
			//System.out.println(t);
			String expecting = "<ul>Ter</li> <li>&nbsp;Tom</li> <li>&nbsp;Mel</ul>";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testAttributeRefButtedUpAgainstEndifAndWhitespace() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate a = new StringTemplate(group,
				"$if (!firstName)$$email$$endif$");
			a.SetAttribute("email", "parrt@jguru.com");
			String expecting = "parrt@jguru.com";
			assertTrue(a.ToString().Equals(expecting));
		}

		public void testStringCatenationOnSingleValuedAttribute() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate a = new StringTemplate(group, "$name+\" Parr\":bold()$");
			StringTemplate b = new StringTemplate(group, "$bold(attr=name+\" Parr\")$");
			a.SetAttribute("name", "Terence");
			b.SetAttribute("name", "Terence");
			String expecting = "<b>Terence Parr</b>";
			assertTrue(a.ToString().Equals(expecting) && b.ToString().Equals(expecting));
		}

		public void testApplyingTemplateFromDiskWithPrecompiledIF() {
			String newline = Environment.NewLine;
			// write the template files first to /temp
			StreamWriter fw = new StreamWriter("/temp/page.st");
			fw.Write("<html><head>"+newline);
			//fw.Write("  <title>PeerScope: $title$</title>"+newline);
			fw.Write("</head>"+newline);
			fw.Write("<body>"+newline);
			fw.Write("$if(member)$User: $member:terse()$$endif$"+newline);
			fw.Write("</body>"+newline);
			fw.Write("</head>"+newline);
			fw.Close();

			fw = new StreamWriter("/temp/terse.st");
			fw.Write("$attr.FirstName$ $attr.LastName$ (<tt>$attr.Email$</tt>)"+newline);
			fw.Close();

			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			group.Loader.Base = "/temp";

			StringTemplate a = group.GetInstanceOf("page");
			a.SetAttribute("member", new Connector());
			String expecting = "<html><head>"+newline+
				"</head>"+newline+
				"<body>"+newline+
				"User: Terence Parr (<tt>parrt@jguru.com</tt>)"+newline+
				"</body>"+newline+
				"</head>";
			//System.out.println(a);
			assertTrue(a.ToString().Equals(expecting));
		}

		public void testMultiValuedAttributeWithAnonymousTemplateUsingIndexVariableI() {
			String newline = Environment.NewLine;
			StringTemplateGroup tgroup =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate t =
				new StringTemplate(tgroup,
				"List:"+newline+
				"$names:{<br>$i+1$. $attr$"+newline+
				"}$");
			t.SetAttribute("names", "Terence");
			t.SetAttribute("names", "Jim");
			t.SetAttribute("names", "Sriram");
			//System.out.println(t);
			String expecting =
				"List:"+newline+
				"<br>1. Terence"+newline+
				"<br>2. Jim"+newline+
				"<br>3. Sriram"+newline;
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testFindTemplateInCLASSPATH() {
			// Look for templates in CLASSPATH as resources
			StringTemplateGroup mgroup =
				new StringTemplateGroup("method stuff", "<", ">");
			StringTemplate m = mgroup.GetInstanceOf("method");
			// "method.st" references body() so "body.st" will be loaded too
			m.SetAttribute("visibility", "public");
			m.SetAttribute("name", "foobar");
			m.SetAttribute("returnType", "void");
			m.SetAttribute("statements", "i=1;"); // body inherits these from method
			m.SetAttribute("statements", "x=i;");
			String newline = Environment.NewLine;
			String expecting =
				"public void foobar() {\n"+
				"\t// start of a body\n"+
				"\ti=1; x=i;\n"+
				"\t// end of a body\n"+
				"}";
			//System.out.println(m);
			assertTrue(m.ToString().Equals(expecting));
		}

		public void testApplyTemplateToSingleValuedAttribute() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$x$</b>");
			StringTemplate name = new StringTemplate(group, "$name:bold(x=name)$");
			name.SetAttribute("name", "Terence");
			assertTrue(name.ToString().Equals("<b>Terence</b>"));
		}

		public void testStringLiteralAsAttribute() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate name = new StringTemplate(group, "$\"Terence\":bold()$");
			assertTrue(name.ToString().Equals("<b>Terence</b>"));
		}

		public void testApplyTemplateToSingleValuedAttributeWithDefaultAttribute() {
			StringTemplateGroup group =
				new StringTemplateGroup("test", "$", "$");
			StringTemplate bold = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate name = new StringTemplate(group, "$name:bold()$");
			name.SetAttribute("name", "Terence");
			assertTrue(name.ToString().Equals("<b>Terence</b>"));
		}

		public void testApplyAnonymousTemplateToSingleValuedAttribute() {
			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate item =
				new StringTemplate(group, "$item:{<li>$attr$</li>}$");
			item.SetAttribute("item", "Terence");
			assertTrue(item.ToString().Equals("<li>Terence</li>"));
		}

		public void testApplyAnonymousTemplateToMultiValuedAttribute() {
			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate list =
				new StringTemplate(group, "<ul>$items$</ul>");
			// demonstrate setting arg to anonymous subtemplate
			StringTemplate item =
				new StringTemplate(group, "$item:{<li>$attr$</li>}; separator=\",\"$");
			item.SetAttribute("item", "Terence");
			item.SetAttribute("item", "Jim");
			item.SetAttribute("item", "John");
			list.SetAttribute("items", item); // nested template
			assertTrue(list.ToString().Equals("<ul><li>Terence</li>,<li>Jim</li>,<li>John</li></ul>"));
		}

		public void testRepeatedApplicationOfTemplateToSingleValuedAttribute() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate search = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate item =
				new StringTemplate(group, "$item:bold():bold()$");
			item.SetAttribute("item", "Jim");
			assertTrue(item.ToString().Equals("<b><b>Jim</b></b>"));
		}

		public void testRepeatedApplicationOfTemplateToMultiValuedAttributeWithSeparator() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			StringTemplate search = group.DefineTemplate("bold", "<b>$attr$</b>");
			StringTemplate item =
				new StringTemplate(group, "$item:bold():bold(); separator=\",\"$");
			item.SetAttribute("item", "Jim");
			item.SetAttribute("item", "Mike");
			item.SetAttribute("item", "Ashar");
			// first application of template must yield another vector!
			//System.out.println("ITEM="+item);
			assertTrue(item.ToString().Equals("<b><b>Jim</b></b>,<b><b>Mike</b></b>,<b><b>Ashar</b></b>"));
		}

		// ### NEED A TEST OF ATTR ASSIGNED TO ARG?
		// ### NEED A TEST OF SEPARATOR AS TEMPLATE?

		public void testMultiValuedAttributeWithSeparator() {
			StringTemplate query;

			// if column can be multi-valued, specify a separator
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "<", ">");
			query = new StringTemplate(group, "SELECT <distinct> <column; separator=\", \"> FROM <table>;");
			query.SetAttribute("column", "name");
			query.SetAttribute("column", "email");
			query.SetAttribute("table", "User");
			// uncomment next line to make "DISTINCT" appear in output
			// query.SetAttribute("distince", "DISTINCT");
			// System.out.println(query);
			assertTrue(query.ToString().Equals("SELECT  name, email FROM User;"));
		}

		public void testSingleValuedAttributes() {
			// all attributes are single-valued:
			StringTemplate query =
				new StringTemplate("SELECT $column$ FROM $table$;");
			query.SetAttribute("column", "name");
			query.SetAttribute("table", "User");
			// System.out.println(query);
			assertTrue(query.ToString().Equals("SELECT name FROM User;"));
		}

		public void testIFTemplate() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "<", ">");
			StringTemplate t =
				new StringTemplate(group,
				"SELECT <column> FROM PERSON "+
				"<if(cond)>WHERE ID=<id><endif>;");
			t.SetAttribute("column", "name");
			t.SetAttribute("cond", "true");
			t.SetAttribute("id", "231");
			assertTrue(t.ToString().Equals("SELECT name FROM PERSON WHERE ID=231;"));
		}

		public void testNestedIFTemplate() {
			String newline = Environment.NewLine;
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "<", ">");
			StringTemplate t =
				new StringTemplate(group,
				"ack<if(a)>"+newline+
				"foo"+newline+
				"<if(!b)>stuff<endif>"+newline+
				"<if(b)>no<endif>"+newline+
				"junk"+newline+
				"<endif>"
				);
			t.SetAttribute("a", "blort");
			// leave b as null
			//System.out.println("t="+t);
			String expecting =
				"ack"+newline+
				"foo"+newline+
				"stuff"+newline+
				""+newline+
				"junk\r";
			assertTrue(t.ToString().Equals(expecting));
		}

		public class Connector {
			public int ID { get {return 1;} }
			public String FirstName { get {return "Terence";} }
			public String LastName { get {return "Parr";} }
			public String Email { get {return "parrt@jguru.com";} }
			public String Bio { get {return "Superhero by night...";} }
			public bool CanEdit { get {return false;} }
		}

		public class Connector2 {
			public int ID { get {return 2;} }
			public String FirstName { get {return "Tom";} }
			public String LastName { get {return "Burns";} }
			public String Email { get {return "tombu@jguru.com";} }
			public String Bio { get {return "Superhero by day...";} }
			public bool CanEdit { get {return true;} }
		}

		public void testObjectPropertyReference() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			String newline = Environment.NewLine;
			StringTemplate t =
				new StringTemplate(
				group,
				"<b>Name: $p.FirstName$ $p.LastName$</b><br>"+newline+
				"<b>Email: $p.Email$</b><br>"+newline+
				"$p.Bio$"
				);
			t.SetAttribute("p", new Connector());
			//System.out.println("t is "+t.ToString());
			String expecting =
				"<b>Name: Terence Parr</b><br>"+newline+
				"<b>Email: parrt@jguru.com</b><br>"+newline+
				"Superhero by night...";
			assertTrue(t.ToString().Equals(expecting));
		}

		public void testApplyRepeatedAnonymousTemplateWithForeignTemplateRefToMultiValuedAttribute() {
			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			String newline = Environment.NewLine;
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			group.DefineTemplate("link", "<a href=\"$url$\"><b>$title$</b></a>");
			StringTemplate duh =
				new StringTemplate(group,
				"start|$p:{$link(url=\"/member/view?ID=\"+attr.ID, title=attr.FirstName)$ $if(attr.CanEdit)$canEdit$endif$}:"+
				"{$attr$<br>" + newline + "}$|end");
			duh.SetAttribute("p", new Connector());
			duh.SetAttribute("p", new Connector2());
			//System.out.println(duh);
			String expecting = "start|<a href=\"/member/view?ID=1\"><b>Terence</b></a> <br>"+newline+
				"<a href=\"/member/view?ID=2\"><b>Tom</b></a> canEdit<br>"+newline+
				"|end";
			String result = duh.ToString();
			assertTrue(duh.ToString().Equals(expecting));
		}

		public class Tree {
			protected IList children = new ArrayList();
			protected String text;
			public Tree(String t) {
				text = t;
			}

			public String Text {
				get {
					return text;
				}
			}

			public void addChild(Tree c) {
				children.Add(c);
			}

			public Tree FirstChild {
				get {
					if ( children.Count==0 ) {
						return null;
					}

					return (Tree)children[0];
				}
			}

			public IList Children {
				get {
					return children;
				}
			}
		}

		public void testRecursion() {
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "<", ">");
			group.DefineTemplate("tree",
				"<if(attr.FirstChild)>"+
				"( <attr.Text> <attr.Children:tree(); separator=\" \"> )" +
				"<endif>"+
				"<if(!attr.FirstChild)>" +
				"<attr.Text>" +
				"<endif>");
			StringTemplate tree = group.GetInstanceOf("tree");
			// build ( a b (c d) e )
			Tree root = new Tree("a");
			root.addChild(new Tree("b"));
			Tree subtree = new Tree("c");
			subtree.addChild(new Tree("d"));
			root.addChild(subtree);
			root.addChild(new Tree("e"));
			tree.SetAttribute("attr", root);
			String expecting = "( a b ( c d ) e )";
			assertTrue(tree.ToString().Equals(expecting));
		}

		public void testApplyingTemplateFromUrlWithPrecompiledIF() {
			String newline = Environment.NewLine;
			// write the template files first to /temp
			/*
			MemoryStream ms = new MemoryStream();
			StreamWriter fw = new StreamWriter(ms);
			fw.Write("<html><head>"+newline);
			//fw.Write("  <title>PeerScope: $title$</title>"+newline);
			fw.Write("</head>"+newline);
			fw.Write("<body>"+newline);
			fw.Write("$if(member)$User: $member:terse()$$endif$"+newline);
			fw.Write("</body>"+newline);
			fw.Write("</head>"+newline);
			fw.Close();

			String baseUrl = "http://localhost";
			WebClient wc = new WebClient();
			wc.UploadData(baseUrl + "/ealg/page.st", "POST",  ms.GetBuffer());

			ms = new MemoryStream();
			fw = new StreamWriter(ms);
			fw.Write("$attr.FirstName$ $attr.LastName$ (<tt>$attr.Email$</tt>)"+newline);
			fw.Close();

			wc.UploadData(baseUrl + "/ealg/terse.st", "POST", ms.GetBuffer());
			*/

			// specify a template to apply to an attribute
			// Use a template group so we can specify the start/stop chars
			StringTemplateGroup group =
				new StringTemplateGroup("dummy", "$", "$");
			group.Loader = new UrlTemplateLoader("http://localhost/ealg");

			StringTemplate a = group.GetInstanceOf("page");
			a.SetAttribute("member", new Connector());
			String expecting = "<html><head>"+newline+
				"</head>"+newline+
				"<body>"+newline+
				"User: Terence Parr (<tt>parrt@jguru.com</tt>)"+newline+
				"</body>"+newline+
				"</head>";
			//System.out.println(a);
			assertTrue(a.ToString().Equals(expecting));
		}

		public void testFindTemplateInManifest() {
			// Look for templates in CLASSPATH as resources
			StringTemplateGroup mgroup =
				new StringTemplateGroup("method stuff", "<", ">");
			mgroup.Loader = new AssemblyTemplateLoader(
				this.GetType().Assembly, this.GetType().Namespace);
			StringTemplate m = mgroup.GetInstanceOf("method");
			// "method.st" references body() so "body.st" will be loaded too
			m.SetAttribute("visibility", "public");
			m.SetAttribute("name", "foobar");
			m.SetAttribute("returnType", "void");
			m.SetAttribute("statements", "i=1;"); // body inherits these from method
			m.SetAttribute("statements", "x=i;");
			String newline = Environment.NewLine;
			String expecting =
				"public void foobar() {\n"+
				"\t// start of a body\n"+
				"\ti=1; x=i;\n"+
				"\t// end of a body\n"+
				"}";
			//System.out.println(m);
			assertTrue(m.ToString().Equals(expecting));
		}
	}
}
