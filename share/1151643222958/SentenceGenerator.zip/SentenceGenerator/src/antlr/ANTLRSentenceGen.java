package antlr;

import antlr.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/*
 * Generate sentances for a antler defined grammer
 */
public class ANTLRSentenceGen 
{
  AntlrGrammarGraph antlrGrammarGraph = new AntlrGrammarGraph();
  public ANTLRSentenceGen()
  {
  }
  //----------------------------------------------------------------------------
  private void printSentencesForRule(String ruleName, OutputStream out)
  {
    int    noOfSentences = 0;
    String lastSentence;  
    
    antlr.collections.AST ast = (antlr.collections.AST)(AntlrGrammarGraph.parserRules.get(ruleName));
    if (ast != null)
    {
      try
      {
        antlrGrammarGraph.createSentenceOfGrammarForNodeWithBacktracking(ast);
        lastSentence = new String(antlrGrammarGraph.sentence + "\n");
        System.out.println(antlrGrammarGraph.sentence);
        //System.out.println("NUMBER OF BACKTRACK POINTS " + antlrGrammarGraph.getNumberOfBackTrackPoints());
        noOfSentences++;
        while (antlrGrammarGraph.thereAreMoreSentences()) {     
          antlrGrammarGraph.createSentenceOfGrammarForNodeWithBacktracking(ast);
          if (antlrGrammarGraph.sentence != null) 
          {
            System.out.println(antlrGrammarGraph.sentence);
            //System.out.println("NUMBER OF BACKTRACK POINTS " + antlrGrammarGraph.getNumberOfBackTrackPoints());
            //lastSentence = new String(antlrGrammarGraph.sentence + "\n");
            // write to string to file
            if (out != null) 
            { 
              //byte[] buffer = lastSentence.getBytes();
              //out.write(buffer);  
            }
            if(noOfSentences % 10000 == 0) 
            {
              System.out.println("number of backtract points : " + 
                                antlrGrammarGraph.getNumberOfBackTrackPoints() + 
                                " sentence count up to now is : " +  
                                noOfSentences);
            }
            noOfSentences++;
          }
        }
      }
      catch (Exception e)
      {
        System.out.println("error " + e);        
        e.printStackTrace();
      }
        
    }
    System.out.println("number of sentences : " + noOfSentences);
    antlrGrammarGraph.showRulesCalledCount();
    antlrGrammarGraph.clearRulesCountMap();
  }
  //----------------------------------------------------------------------------
  public void parseGrammerAndGenSentencesTest1(String fileName, OutputStream out)
  {
    ANTLRLexer lex = new ANTLRLexer ((FileInputStream)null);
    try{
        DumpASTVisitor visitor = new DumpASTVisitor();    
        InputStream inputStream = new FileInputStream(new File(fileName)); // needs to be instanated
        lex = new ANTLRLexer (inputStream);
        // construct the parser
        ANTLRParser par = new ANTLRParser (lex);
        // parse the file
        par.grammar();
        // prep the rules
        antlrGrammarGraph.prepareRulesForForSentenceGeneration();
        antlrGrammarGraph.connectRulesIntoAnANFAGraph();
        // test
        System.out.println("---------------------------------------------TEST1");
        printSentencesForRule("test1",out);
        System.out.println("---------------------------------------------TEST2");
        printSentencesForRule("test2",out);
        System.out.println("---------------------------------------------TEST3");
        //antlrGrammarGraph.traceIsOn = true;
        printSentencesForRule("test3",out);
        //antlrGrammarGraph.traceIsOn = false;
        System.out.println("---------------------------------------------TEST4");
        printSentencesForRule("test4",out);
        System.out.println("---------------------------------------------TEST5");
        printSentencesForRule("test5",out);
        System.out.println("---------------------------------------------TEST6");
        printSentencesForRule("test6",out);
        System.out.println("---------------------------------------------TEST7");
        printSentencesForRule("test7",out);
        System.out.println("---------------------------------------------TEST8");
        printSentencesForRule("test8",out);
        System.out.println("---------------------------------------------TEST9");
        printSentencesForRule("test9",out);
        System.out.println("---------------------------------------------TEST10");
        printSentencesForRule("test10",out);
        System.out.println("---------------------------------------------TEST11");
        printSentencesForRule("test11",out);
        System.out.println("---------------------------------------------TEST12");
        printSentencesForRule("test12",out);
        System.out.println("---------------------------------------------TEST13");
        printSentencesForRule("test13",out);
        System.out.println("---------------------------------------------TEST14");
        printSentencesForRule("test14",out);
        System.out.println("---------------------------------------------TEST15");
        printSentencesForRule("test15",out);
        System.out.println("---------------------------------------------TEST16");
        printSentencesForRule("test16",out);
        System.out.println("---------------------------------------------TEST17");
        //antlrGrammarGraph.traceIsOn = true;
        //visitor.visit((antlr.collections.AST)(antlrGrammarGraph.parserRules.get("test17")));
        printSentencesForRule("test17",out);
        System.out.println("---------------------------------------------TEST18");
        printSentencesForRule("test18",out);
        System.out.println("---------------------------------------------TEST19");
        printSentencesForRule("test19",out);
        System.out.println("---------------------------------------------TEST20");
        //antlrGrammarGraph.traceIsOn = true;
        //visitor.visit((antlr.collections.AST)(antlrGrammarGraph.parserRules.get("test20")));
        printSentencesForRule("test20",out);
        System.out.println("---------------------------------------------TEST21");
        //antlrGrammarGraph.traceIsOn = true;
        //visitor.visit((antlr.collections.AST)(antlrGrammarGraph.parserRules.get("test21")));
        printSentencesForRule("test21",out);
        System.out.println("---------------------------------------------TEST22");
        //antlrGrammarGraph.traceIsOn = true;
        //visitor.visit((antlr.collections.AST)(antlrGrammarGraph.parserRules.get("test22")));
        printSentencesForRule("test22",out);
        System.out.println("---------------------------------------------TEST23");
        antlrGrammarGraph.traceIsOn = true;
        visitor.visit((antlr.collections.AST)(antlrGrammarGraph.parserRules.get("test23")));
        printSentencesForRule("test23",out);
        
    }
    catch(Exception e)
    {
      System.out.println("EXCEPTION : " + e.getMessage());
        // get line an col position of the lexer.
        System.out.println("LINE : " + lex.inputState.line + " COL : " + lex.inputState.column); 
    }
  }
  //----------------------------------------------------------------------------
  public void parseGrammerAndGenSentencesTest(String fileName, String startRule, OutputStream out)
  {
    ANTLRLexer lex = new ANTLRLexer ((FileInputStream)null);
    try{
        InputStream inputStream = new FileInputStream(new File(fileName)); // needs to be instanated
        lex = new ANTLRLexer (inputStream);
        // construct the parser
        ANTLRParser par = new ANTLRParser (lex);
        // parse the file
        par.grammar();
        // prep the rules
        antlrGrammarGraph.prepareRulesForForSentenceGeneration();
        antlrGrammarGraph.connectRulesIntoAnANFAGraph();
        // test
        System.out.println("---------------------------------------------");
        printSentencesForRule(startRule,out);
        
    }
    catch(Exception e)
    {
      System.out.println("EXCEPTION : " + e.getMessage());
      // get line an col position of the lexer.
      System.out.println("LINE : " + lex.inputState.line + " COL : " + lex.inputState.column); 
    }
  }
  
  //----------------------------------------------------------------------------
    public static void main(String[] args)
  {
    int runTest = 0;
    ANTLRSentenceGen antlrSentenceGen = new ANTLRSentenceGen();
    if (runTest == 0)
    {
      antlrSentenceGen.parseGrammerAndGenSentencesTest1("C:\\Documents and Settings\\myburg_g\\My Documents\\antlr\\antlr-sentence\\TEST.g", null);      
    }
    else
    if (runTest == 1)
    {
    try{
      antlrSentenceGen.parseGrammerAndGenSentencesTest(
        "C:\\Documents and Settings\\myburg_g\\My Documents\\antlr\\antlr-sentence\\antlr.g",
        "grammar",
        new FileOutputStream("C:\\Documents and Settings\\myburg_g\\My Documents\\antlr\\DmlSQL2-GRAMMAR\\sentences"));
    }
    catch (Exception e)
    {
      System.out.println(e);  
    }
    }
    else if (runTest == 2)
    {
    //
    try{
      AntlrGrammarGraph.tokenRef.put("REGULAR_ID","id ");
      AntlrGrammarGraph.tokenRef.put("MINUS_SIGN","- ");
      AntlrGrammarGraph.tokenRef.put("LEFT_PAREN","( ");
      AntlrGrammarGraph.tokenRef.put("RIGHT_PAREN",") ");
      AntlrGrammarGraph.tokenRef.put("UNSIGNED_INTEGER","1234 ");
      AntlrGrammarGraph.tokenRef.put("PERIOD",". ");
      AntlrGrammarGraph.tokenRef.put("SOLIDUS","/ ");
      AntlrGrammarGraph.tokenRef.put("CONCATENATION_OP","|| ");
      AntlrGrammarGraph.tokenRef.put("COMMA",", ");
      AntlrGrammarGraph.tokenRef.put("INTRODUCER","_");
      AntlrGrammarGraph.tokenRef.put("PLUS_SIGN","+ ");
      AntlrGrammarGraph.tokenRef.put("ASTERISK","* ");
      AntlrGrammarGraph.tokenRef.put("COLON",": ");
      AntlrGrammarGraph.tokenRef.put("EQUALS_OP","= ");
      AntlrGrammarGraph.tokenRef.put("CHAR_STRING","\"str\" ");
      AntlrGrammarGraph.tokenRef.put("EXACT_NUM_LIT","123 ");
      AntlrGrammarGraph.tokenRef.put("APPROXIMATE_NUM_LIT","321 ");
      AntlrGrammarGraph.tokenRef.put("DELIMITED_ID","dId ");
      AntlrGrammarGraph.tokenRef.put("","");
      
      AntlrGrammarGraph.ruleRef.put("non_reserved_word","ada ");
      //
      antlrSentenceGen.parseGrammerAndGenSentencesTest(
        "C:\\Documents and Settings\\myburg_g\\My Documents\\antlr\\DmlSQL2-GRAMMAR\\sql.g",
        "value_exp",
        new FileOutputStream("C:\\Documents and Settings\\myburg_g\\My Documents\\antlr\\DmlSQL2-GRAMMAR\\sentences"));
    }
    catch (Exception e)
    {
      System.out.println(e);  
    }
    }
  }
}
