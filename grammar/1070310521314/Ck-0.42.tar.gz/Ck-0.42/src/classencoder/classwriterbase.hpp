/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef CLASSWRITERBASE_HPP
#define CLASSWRITERBASE_HPP

#include <fstream>
#include "defs.hpp"

namespace ClassEncoder
{

//! Base class for all functions writing to the class stream.
/*!
 * This class contains functionality for writing u1, u2 and u4 values as defined by SUN to the class stream.
 * Note that this class assumes that the code is run on a little endian machine as it converts everything to big endian as defined by SUN. If you want to port this code to a big endian architecture this class must be adapted accordingly.
 */
class ClassWriterBase
{
public:
    ClassWriterBase();
    virtual ~ClassWriterBase();

    void writeu1Array( std::ofstream &stream, const char *data, unsigned int length ) const;
    void writeu1( std::ofstream &stream, const u1 &num ) const;
    void writeu2( std::ofstream &stream, const u2 &num ) const;
    void writeu4( std::ofstream &stream, const u4 &num ) const;

private:
    u2 u2ToBigEndian( u2 num ) const;
    u4 u4ToBigEndian( u4 num ) const;
};

} // end namespace

#endif // CLASSWRITERBASE_HPP
