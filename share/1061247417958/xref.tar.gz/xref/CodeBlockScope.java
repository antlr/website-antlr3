 

import java.util.*;

/** Represents the definition of a field (class or instance).
 */
public class CodeBlockScope extends Scope {
    protected Hashtable variables = null;

    public CodeBlockScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    public void addScopeMember(Scope s) {
        if ( variables==null ) {
            variables=new Hashtable();
        }
        System.out.println("Add local scope member "+s);
        variables.put(s.getName(),s);
    }

    public Variable resolveVariable(String name) {
        if ( variables!=null && variables.get(name)!=null ) {
            return (Variable)variables.get(name);
        }
        if ( parent!=null ) {
            return parent.resolveVariable(name);
        }
        return null;
    }

    public void dump() {
        if ( variables!=null ) {
            Enumeration p = variables.elements();
            while (p.hasMoreElements()) {
                LocalVariable variable = (LocalVariable)p.nextElement();
                if ( variable.getType()!=null ) {
                    System.out.print(" "+variable.getType().getFullyQualifiedName());
                }
                System.out.print(" "+variable.getName());
            }
        }
    }
}
