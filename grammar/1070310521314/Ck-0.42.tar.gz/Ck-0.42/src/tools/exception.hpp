/*
 * Copyright (c) 2003, Raymond Bosman
 * Copyright (c) 2003, Frederik Holljen
 * All Rights Reserved.
 *
 * See COPYING for licensing.
 */


#ifndef EXCEPTION_HPP
#define EXCEPTION_HPP

#include <string>

//! Exception class used by many Ck classes
/*!
 * This very simple exception class can only hold an error message which
 * can be used to give at least partially useful output to the user.
 */
class Exception
{
public:
    Exception( const std::string &error );
    Exception( const char *file, int line, const std::string &error );
    virtual ~Exception();

    //! Get the error message associated with this exception..
    const std::string &getError() const { return ErrorMsg; }

private:
    std::string ErrorMsg;
};


#endif // EXCEPTION_HPP
