package org.antlr.java.crossref;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

import org.antlr.java.crossref.ClassScope;
import org.antlr.java.crossref.CodeProject;
import org.antlr.java.crossref.FileScope;
import org.antlr.java.crossref.MethodScope;
import org.antlr.java.crossref.OutputCrossRefInfo;
import org.antlr.java.crossref.Scope;


/**
 * Class to control output of the JavaRecognizer
 */
public class MyOutput implements OutputCrossRefInfo {

	/**
	 * Field OUTPUTDIR
	 */
	final static String OUTPUTDIR = "./";
	/**
	 * Use project.xmlSerialize to write a file in OUTPUTDIR of <project name>.xml
	 * @param project CodeProject
	 * @see org.antlr.java.crossref.OutputCrossRefInfo#OutputProject(CodeProject)
	 */
	public void OutputProject(CodeProject project)
	{
	String filename = OUTPUTDIR + project.getName() + ".xml";

		try {
			FileWriter writer = new FileWriter(filename);
			project.xmlSerialize(writer);
		} catch (IOException e) 
		{
		// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/** 
	 * Parser calls OutputRefClass when a Class reference is resolved
	 * @param refMethod MethodScope
	 * @param defClass ClassScope
	 * @param code LocationAST
	 * @see org.antlr.java.crossref.OutputCrossRefInfo#OutputRefClass(MethodScope, ClassScope, LocationAST)
	 */
	public void OutputRefClass(
		MethodScope refMethod,
		ClassScope defClass,
		LocationAST code) {
			if(defClass == null)
				System.err.println(code.toStringList()+" in "+ refMethod.getFullyQualifiedName() + " unresolved");

			outputBreakdown("Ref ", refMethod, code);
			outputBreakdown("Def ", defClass);
			System.out.println();
			
	}

	/**
	 * Parser calls OutputRefElement when an item reference is resolved
	 * @param refClassOrMethod Scope
	 * @param defClassOrVariable Scope
	 * @param code LocationAST
	 * @see org.antlr.java.crossref.OutputCrossRefInfo#OutputRefElement(Scope, Scope, LocationAST)
	 */
	public void OutputRefElement(
		Scope refClassOrMethod,
		Scope defClassOrVariable,
		LocationAST code) {
			
			if(defClassOrVariable == null)
				System.err.println(code.toStringList()+" in "+ refClassOrMethod.getFullyQualifiedName() + " unresolved");
			outputBreakdown("Ref :", refClassOrMethod, code);
			outputBreakdown("Def :", defClassOrVariable);
			System.out.println();
	}

	/**
	 * Parser calls OutputRefMethod when a Method reference is resolved
	 * @param refScope Scope
	 * @param defMethod MethodScope
	 * @param code LocationAST
	 * @see org.antlr.java.crossref.OutputCrossRefInfo#OutputRefMethod(Scope, MethodScope, LocationAST)
	 */
	public void OutputRefMethod(
		Scope refScope,
		MethodScope defMethod,
		LocationAST code) {

			outputBreakdown("Ref ", refScope, code);
			outputBreakdown("Def ", defMethod);
			System.out.println();
	}
	/**
	 * Helper function
	 * @param str String
	 * @param scope Scope
	 */
	void outputBreakdown(String str, Scope scope)
	{
		outputBreakdown(str, scope, null);
	}
	/**
	 * Helper function
	 * @param str String
	 * @param scope Scope
	 * @param code LocationAST
	 */
	void outputBreakdown(String str, Scope scope, LocationAST code)
	{
		
		if(scope == null)
			return;
		StringBuffer pack = new StringBuffer();
		StringBuffer klaess = new StringBuffer();
		StringBuffer method = new StringBuffer();
		StringBuffer item = new StringBuffer();

		LinkedList ll = new LinkedList();
		
		gatherScopes(scope, ll);
		
		for (Iterator iter = ll.iterator(); iter.hasNext();) {
			Scope element = (Scope) iter.next();
			//this will not work for class or jar files without FileScope, 
			//is this ok?
			if(element.getClass().equals(FileScope.class))
				pack.append(((FileScope) element).getPackageScope().getFullyQualifiedName());
			else if(element.getClass().equals(ClassScope.class))
			{
				if(klaess.length() != 0)
					klaess.append('.');
				klaess.append(element.getName());
			} else if(element.getClass().equals(MethodScope.class))
			{
				method.append(element.getName());
			}// else if(element.getClass().equals(Variable.class))
			//{
			//	item.append(element.getName());
			//}

 
		}

		System.out.print(str);
		System.out.print("Package - :" + pack +
							": Class - :" + klaess +
							": Method - :" + method +
							": Item - :" + item + ":");
		if(code == null)
			System.out.println(" " + scope.getFilename() + " loc=" + scope.getLine() + "," + scope.getColumn());
		else							
			System.out.println(" " + code.getFilename() + " loc=" + code.getLine() + "," + code.getColumn());

		return;
	}
	/**
	 * Out the info
	 * @param str String
	 * @throws IOException
	 */
	void output(String str) throws IOException{
			System.out.print(str);
	}

	/**
	 * Method gatherScopes
	 * @param sc Scope
	 * @param ll LinkedList
	 */
	void gatherScopes(Scope sc, LinkedList ll)
	{
		while(sc != null)
		{
			ll.addFirst(sc);
			sc = sc.getParent();
		}
	}

}
