package org.antlr.java.crossref;
 

import java.io.IOException;
import java.util.*;

/** Represents a group of parameters  * @author Jim O 'Connor
 * @version $Revision: 1.8 $
 */
public class ParameterScope extends CodeBlockScope {
	/** Should debug information be printed?
     * @see CodeProject.printDebug
	 */
	static final boolean printDebug = true;
    /**
     * Constructor for ParameterScope
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public ParameterScope(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }

    /**
     * Add codeBlock or fields to this scope
     * @param s Scope
     */
    public void addScopeMember(Scope s) {
		if(ParameterScope.printDebug && CodeProject.printDebug)
			System.out.println("ParameterScope:addScopeMember " + "Add parameter scope member "+s);
		if(s instanceof CodeBlockScope)
		{
			if(codeBlocks == null)
				codeBlocks = new ArrayList();
			codeBlocks.add(s);
		}
		else
		{
	        if ( variables==null ) 
    	        variables=new Hashtable();
        	variables.put(s.getName(),s);
		}
    }

	/** XML dump
     *
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		if ( variables!=null || codeBlocks != null) 
			xmlWriter.xmlOpen("Parameters");
		if(variables != null)
		{
			Enumeration p = variables.elements();
			while (p.hasMoreElements()) {
				LocalVariable variable = (LocalVariable)p.nextElement();
				variable.xmlSerialize(xmlWriter);
			}
		}
		if(codeBlocks != null)
			xmlSerializeCodeBlocks(xmlWriter);
		if ( variables!=null || codeBlocks != null) 
			xmlWriter.xmlClose("Parameters");
		return;
	}
}
