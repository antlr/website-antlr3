#include <mario.h>

mario::mario()
{
    std::cout << "I am mario, created in: " << __FUNCTION__ << std::endl;
}

mario::~mario()
{
    std::cout << "I am mario, and game is over in: " << __FUNCTION__ << std::endl;
}

mario* mario::pipe_a(int par)
{
    std::cout << "I am running in " << __FUNCTION__ << std::endl;
    this->data = par;
    std::cout << "data: " << data << std::endl;    
    return this;
}

mario* mario::pipe_b()
{
    std::cout << "I am running in " << __FUNCTION__ << std::endl;
    return this;
}

mario* mario::pipe_c()
{
    std::cout << "I am running in " << __FUNCTION__ << std::endl;
    return this;
}
