/* ====================================================================
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is SATC.
 *
 * The Initial Developer of the Original Code is Bogdan Mitu.
 *
 * Copyright (C) 2001-2002 Bogdan Mitu.
 *
 * ====================================================================
 */

package satc.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Logger;

import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.PlainView;
import javax.swing.text.Segment;
import javax.swing.text.Utilities;

import satc.AbstractLexerCallback;
import satc.MultiStateLexer;
import satc.TokenContext;
import antlr.Token;



/**
*  A View for simple multi-line text with support for syntax highlight.
*  When a line is to be rendered, the document lexer is called to break
*  the line into tokens, and each token is rendered according to its type.
*/
public class SyntaxView extends PlainView {
    
    public SyntaxView( Element elem) {
        super( elem);
    }

    protected int getTabSize() { return 4; }

    /**
    *  Draw a new line with syntax highlighting. A token rendering
    *  action is registered with the document lexer and the lexer
    *  is called to break the line into tokens.
    */
    public void drawLine( int lineIndex, Graphics g, int x, int y) {
		log.fine("----------------------------------");
		log.fine("drawing line " + lineIndex + " ...");
		log.fine("----------------------------------");
        Document doc = getDocument();
        Element line = doc.getDefaultRootElement().getElement( lineIndex);
        if( line == null) return;
        try{
            doc.getText( line.getStartOffset(), line.getEndOffset()-line.getStartOffset(), lineSegment);
        } catch( Exception e) {
        	log.severe("Error in drawLine()");
//            e.printStackTrace();
    
        }
//if(lineIndex == 17) {
//	log.fine("......");
	log.fine(lineSegment.toString());
	log.fine("...................................");
//}

        drawLineAction.init( g, x, y, lineSegment, line.getStartOffset());
        MultiStateLexer lexer = (MultiStateLexer) doc.getProperty("lexer");
        LexerDocumentListener listener = (LexerDocumentListener) doc.getProperty("lexerDocumentListener");
        if( listener == null) 
            log.warning("listener = null");
        listener.xcanLine( doc, lineIndex, lexer, drawLineAction);               
    }

    //TODO: consider the selection
    public int drawSegment( Segment segment, Graphics g, int x, int y, int docOffset) throws BadLocationException {
        return drawUnselectedSegment( segment, g, x, y, docOffset);
    }
    protected int drawUnselectedSegment(Segment segment, Graphics g, int x, int y, int docOffset) throws BadLocationException {
        return Utilities.drawTabbedText(segment, x, y, g, this, docOffset);
    }

    /**
    *  Lexer callback action for drawing a new token.
    */
    class DrawLineAction extends AbstractLexerCallback {
        Graphics g;
        int x; 
        int y;
        int docOffset;

        public void init( Graphics g, int x, int y, Segment lineSegment, int startOffset) {
            this.g = g;
            this.x = x;
            this.y = y;
            tokenSegment = lineSegment;
            docOffset = startOffset;
        }

        public void action( Token token) {
			log.finest("-->DrawLineAction.action(" + token + ")");
        	//TODO: why token can be null in drawLine?
        	if (token == null) return;
            try {
                this.g.setColor( tokenContext.getColor( token));
            } catch( Exception exc) {
                this.g.setColor( Color.black);
            }
            try {
				log.finest( "drawing token --" + token.getText() + "...");
				if (token.getText() != null) {                
	                tokenSegment.count = token.getText().length();
					log.finest( "tokenSegment = " + tokenSegment);
					if (false == token.getText().equals(tokenSegment.toString())) {
						log.severe("token = :" + token.getText() + ": segment = :" + tokenSegment.toString() + ":");
					}
	                x = drawSegment( tokenSegment, this.g, this.x, this.y, docOffset);
	                docOffset += tokenSegment.count;
	                tokenSegment.offset += tokenSegment.count;
				}
				log.finest("<--DrawLineAction.action()");
            } catch (Exception exc) {
				log.severe("Error in DrawLineAction.action()");
//                exc.printStackTrace();
            } 
        } 
    }

    /**
    *  Token rendering action passed as a callback to the lexer.
    */
    private DrawLineAction drawLineAction = new DrawLineAction();

    /**
    *  Sets the token rendering context (colors, fonts ...).
    */
    public void setTokenContext( TokenContext tokenContext) {
        this.tokenContext = tokenContext;
    }

    /*
     *  Make this global to avoid creating a new one for each line parsed.
     */
    private Segment tokenSegment = new Segment();
    private Segment lineSegment = new Segment();
    private TokenContext tokenContext;
    
	private static Logger log = Logger.getLogger("satc.swing.SyntaxView");
    
}



