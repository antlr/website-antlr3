package org.antlr.java.crossref;
 

import java.io.IOException;
import java.util.Vector;

/** Represents the definition of a field (class or instance).
 */
public class LocalVariable extends Variable {
    /**
     * Constructor for LocalVariable
     * @param project CodeProject
     * @param name String
     * @param parent Scope
     */
    public LocalVariable(CodeProject project, String name, Scope parent) {
        super(project,name,parent);
    }
    /**
     * Method dump
     */
    public void dump() {
        tab();
		if ( type!=null ) {
			System.out.println("LocalVariable:dump " + "local "+type.getFullyQualifiedName()+" "+getName());
		}
		else {
			System.out.println("LocalVariable:dump " + "local "+getName());
		}
    }
	/** XML dump()
	 * @param xmlWriter
	 * @throws IOException
	 */
	public void xmlSerialize(XmlWriter xmlWriter) throws IOException {
		if ( type !=null ) 
			xmlWriter.xmlOpen("LocalVariable name=\"" + getName() + "\"" 
					  + " type=\"" + type.getFullyQualifiedName() + "\"");
		else
			xmlWriter.xmlOpen("LocalVariable name=\"" + getName() + "\""); 
		if(loc != null)
			loc.xmlSerialize(xmlWriter);
		if(refTo != null)
			super.xmlSerializeTo(xmlWriter);
		if(refBy != null)
			super.xmlSerializeBy(xmlWriter);
			
		xmlWriter.xmlClose("LocalVariable");
	}
    
}
