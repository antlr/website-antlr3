package net.mark_malakanov.sdg2;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class WidthDialog extends JDialog {
    private JLabel jLabel1 = new JLabel();
    private JSpinner diagramWidth = new JSpinner();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    String resultValue;

    public WidthDialog() {
        this(null, "", false);
    }

    /**
     *
     * @param parent
     * @param title
     * @param modal
     */
    public WidthDialog(Frame parent, String title, boolean modal) {
        super(parent, title, modal);

        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setSize(new Dimension(300, 159));
        this.getContentPane().setLayout(null);
        this.setTitle("Set Diagram Width");
        this.setModal(true);
        this.setVisible(false);
        jLabel1.setText("Diagram Width");
        jLabel1.setBounds(new Rectangle(25, 25, 120, 15));
        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
        diagramWidth.setBounds(new Rectangle(155, 20, 70, 20));
    diagramWidth.setPreferredSize(new Dimension(70, 20));
        jButton1.setText("OK");
        jButton1.setBounds(new Rectangle(65, 90, 75, 23));
        jButton1.setActionCommand("OK");
        jButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jButton2.setText("Cancel");
        jButton2.setBounds(new Rectangle(165, 90, 75, 23));
        jButton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton2_actionPerformed(e);
                }
            });
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(diagramWidth, null);
    this.getContentPane().add(jLabel1, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        resultValue = e.getActionCommand();
        setVisible(false);
    }

    private void jButton2_actionPerformed(ActionEvent e) {
        resultValue = e.getActionCommand();
        setVisible(false);
    }

    public int getDiagramWidth() {
        return ((Integer) diagramWidth.getValue()).intValue();
    }

    public void setDiagramWidth(int w) {
        diagramWidth.setValue(new Integer(w));
    }
}
