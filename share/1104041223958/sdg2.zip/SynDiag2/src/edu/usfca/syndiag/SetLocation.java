// $ANTLR 2.7.3rc3: "setLoc.g" -> "SetLocation.java"$

	package edu.usfca.syndiag;
	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


/** A tree grammar set locaiton of each node in the Grammar AST
 *
 *  Jia Zheng
 *  University of San Francisco
 *  Oct. 5, 2003
 */
public class SetLocation extends antlr.TreeParser       implements SetLocationTokenTypes
 {
public SetLocation() {
	tokenNames = _tokenNames;
}

	public final void grammar(AST _t) throws RecognitionException {
		
		AST grammar_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			classDef(_t);
			_t = _retTree;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void classDef(AST _t) throws RecognitionException {
		
		AST classDef_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case PARSER:
			{
				AST __t3 = _t;
				AST tmp1_AST_in = (AST)_t;
				match(_t,PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t3;
				_t = _t.getNextSibling();
				break;
			}
			case TREE_PARSER:
			{
				AST __t4 = _t;
				AST tmp2_AST_in = (AST)_t;
				match(_t,TREE_PARSER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t4;
				_t = _t.getNextSibling();
				break;
			}
			case LEXER:
			{
				AST __t5 = _t;
				AST tmp3_AST_in = (AST)_t;
				match(_t,LEXER);
				_t = _t.getFirstChild();
				rules(_t);
				_t = _retTree;
				_t = __t5;
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rules(AST _t) throws RecognitionException {
		
		AST rules_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		int x = 50;
			 int y = 50;
			 
			
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==RULE)) {
					r = _t==ASTNULL ? null : (AST)_t;
					rule(_t,x, y);
					_t = _retTree;
					y += ((GrammarAST)r).getHeight() + ((GrammarAST)r).deltaY;
							
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt8++;
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void rule(AST _t,
		int x, int y
	) throws RecognitionException {
		
		AST rule_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST b = null;
		GrammarAST rl = (GrammarAST)rule_AST_in;
			 ((GrammarAST)rl).setLoc(x, y);
			 x += 40;
			 rl.deltaY = 60;
			
		
		try {      // for error handling
			AST __t10 = _t;
			AST tmp4_AST_in = (AST)_t;
			match(_t,RULE);
			_t = _t.getFirstChild();
			r = (AST)_t;
			match(_t,RULE_REF);
			_t = _t.getNextSibling();
			((GrammarAST)r).setLoc(x, y);
							 int w = ((GrammarAST)r).getWidth();
							 x += w;
							
			AST __t11 = _t;
			AST tmp5_AST_in = (AST)_t;
			match(_t,BLOCK);
			_t = _t.getFirstChild();
			b = _t==ASTNULL ? null : (AST)_t;
			block(_t,x, y, BLOCK, RULE);
			_t = _retTree;
			_t = __t11;
			_t = _t.getNextSibling();
			AST tmp6_AST_in = (AST)_t;
			match(_t,EOR);
			_t = _t.getNextSibling();
			_t = __t10;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void block(AST _t,
		int x, int y, int type, int from
	) throws RecognitionException {
		
		AST block_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		GrammarAST b = (GrammarAST)block_AST_in;
			 int w = ((GrammarAST)b).getBlockWidth();
			 int connY = y;
			 int d;
			 //d=40;
			 if ((type == BLOCK) && (from == RULE))
				{d = 40;}
				else
				{d = 20;}
			 ((GrammarAST)b).setLoc(x, y);
			 ((GrammarAST)b).setBlockLeftConnPoint(x-d, y+10);
			
		
		try {      // for error handling
			{
			int _cnt14=0;
			_loop14:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==ALT)) {
					a = _t==ASTNULL ? null : (AST)_t;
					alternative(_t,x, y, w);
					_t = _retTree;
					y += ((GrammarAST)a).getHeight() + ((GrammarAST)a).deltaY;
							
				}
				else {
					if ( _cnt14>=1 ) { break _loop14; } else {throw new NoViableAltException(_t);}
				}
				
				_cnt14++;
			} while (true);
			}
			x = x + w + d;
			y = connY + 10;
		  
			((GrammarAST)b).setBlockRightConnPoint(x, y);
				
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void alternative(AST _t,
		int x, int y, int w
	) throws RecognitionException {
		
		AST alternative_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST e = null;
		int i = 0;
		
		try {      // for error handling
			AST __t16 = _t;
			a = _t==ASTNULL ? null :(AST)_t;
			match(_t,ALT);
			_t = _t.getFirstChild();
			x += w/2 - (((GrammarAST)a).getWidth())/2;
					     ((GrammarAST)a).setLoc(x, y);
					
			{
			_loop18:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t,x, y);
					_t = _retTree;
					i++;
									 if (i == 1){
										((GrammarAST)a).setLeftConnPoint(((GrammarAST)e).getLeftConnPoint()[0],
														 ((GrammarAST)e).getLeftConnPoint()[1]);
									 }
									    x += ((GrammarAST)e).getWidth() + ((GrammarAST)e).deltaX;
							
				}
				else {
					break _loop18;
				}
				
			} while (true);
			}
			((GrammarAST)a).setRightConnPoint(((GrammarAST)e).getRightConnPoint()[0],
										   ((GrammarAST)e).getRightConnPoint()[1]);
				
			_t = __t16;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void element(AST _t,
		int x, int y
	) throws RecognitionException {
		
		AST element_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST a = null;
		AST elt = null;
		AST a1 = null;
		AST a2 = null;
		AST eb = null;
		AST t = null;
		AST s = null;
		AST b = null;
		GrammarAST e = (GrammarAST)element_AST_in;
			 e.setLoc(x, y);
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case STRING_LITERAL:
			case CHAR_LITERAL:
			case TOKEN_REF:
			case RULE_REF:
			case WILD_CARD:
			{
				a = _t==ASTNULL ? null : (AST)_t;
				atom(_t,x, y);
				_t = _retTree;
				e.setLeftConnPoint(((GrammarAST)a).getLeftConnPoint()[0],
								    ((GrammarAST)a).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)a).getRightConnPoint()[0],
								     ((GrammarAST)a).getRightConnPoint()[1]);
						
				break;
			}
			case NOT:
			{
				AST __t20 = _t;
				AST tmp7_AST_in = (AST)_t;
				match(_t,NOT);
				_t = _t.getFirstChild();
				elt = _t==ASTNULL ? null : (AST)_t;
				element(_t,x, y);
				_t = _retTree;
				_t = __t20;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)elt).getLeftConnPoint()[0],
								    ((GrammarAST)elt).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)elt).getRightConnPoint()[0],
								     ((GrammarAST)elt).getRightConnPoint()[1]);
						
				break;
			}
			case TOKEN_RANGE:
			{
				AST __t21 = _t;
				AST tmp8_AST_in = (AST)_t;
				match(_t,TOKEN_RANGE);
				_t = _t.getFirstChild();
				a1 = _t==ASTNULL ? null : (AST)_t;
				atom(_t,x, y);
				_t = _retTree;
				x += ((GrammarAST)a1).getWidth();
				a2 = _t==ASTNULL ? null : (AST)_t;
				atom(_t,x, y);
				_t = _retTree;
				_t = __t21;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)a1).getLeftConnPoint()[0],
								    ((GrammarAST)a1).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)a2).getRightConnPoint()[0],
								     ((GrammarAST)a2).getRightConnPoint()[1]);
						
				break;
			}
			case CHAR_RANGE:
			{
				AST __t22 = _t;
				AST tmp9_AST_in = (AST)_t;
				match(_t,CHAR_RANGE);
				_t = _t.getFirstChild();
				AST tmp10_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				AST tmp11_AST_in = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				_t = __t22;
				_t = _t.getNextSibling();
				break;
			}
			case BLOCK:
			case OPTIONAL:
			case CLOSURE:
			case POSITIVE_CLOSURE:
			{
				eb = _t==ASTNULL ? null : (AST)_t;
				ebnf(_t,x, y);
				_t = _retTree;
				e.setLeftConnPoint(((GrammarAST)eb).getLeftConnPoint()[0],
								    ((GrammarAST)eb).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)eb).getRightConnPoint()[0],
								     ((GrammarAST)eb).getRightConnPoint()[1]);
						
				break;
			}
			case TREE_BEGIN:
			{
				t = _t==ASTNULL ? null : (AST)_t;
				tree(_t,x, y);
				_t = _retTree;
				e.setLeftConnPoint(((GrammarAST)t).getLeftConnPoint()[0],
								    ((GrammarAST)t).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)t).getRightConnPoint()[0],
								     ((GrammarAST)t).getRightConnPoint()[1]);
						
				break;
			}
			case SYNPRED:
			{
				AST __t23 = _t;
				s = _t==ASTNULL ? null :(AST)_t;
				match(_t,SYNPRED);
				_t = _t.getFirstChild();
				b = _t==ASTNULL ? null : (AST)_t;
				block(_t,x, y, SYNPRED, SYNPRED);
				_t = _retTree;
				_t = __t23;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)b).getBlockLeftConnPoint()[0],
								    ((GrammarAST)b).getBlockLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)b).getBlockRightConnPoint()[0],
								     ((GrammarAST)b).getBlockRightConnPoint()[1]);
						
				break;
			}
			case ACTION:
			{
				AST tmp12_AST_in = (AST)_t;
				match(_t,ACTION);
				_t = _t.getNextSibling();
				break;
			}
			case SEMPRED:
			{
				AST tmp13_AST_in = (AST)_t;
				match(_t,SEMPRED);
				_t = _t.getNextSibling();
				break;
			}
			case EPSILON:
			{
				AST tmp14_AST_in = (AST)_t;
				match(_t,EPSILON);
				_t = _t.getNextSibling();
				e.setLeftConnPoint(x, y+10);
							 e.setRightConnPoint(x, y+10);
							
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void atom(AST _t,
		int x, int y
	) throws RecognitionException {
		
		AST atom_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST t = null;
		AST c = null;
		AST s = null;
		AST wi = null;
		GrammarAST a = (GrammarAST)atom_AST_in;
			 a.setLoc(x, y);
			 int w = a.getWidth();
			 int h = a.getHeight();
			 a.setLeftConnPoint(x, y + h/2);
			 a.setRightConnPoint(x + w, y + h/2);
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case RULE_REF:
			{
				r = (AST)_t;
				match(_t,RULE_REF);
				_t = _t.getNextSibling();
				break;
			}
			case TOKEN_REF:
			{
				t = (AST)_t;
				match(_t,TOKEN_REF);
				_t = _t.getNextSibling();
				break;
			}
			case CHAR_LITERAL:
			{
				c = (AST)_t;
				match(_t,CHAR_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case STRING_LITERAL:
			{
				s = (AST)_t;
				match(_t,STRING_LITERAL);
				_t = _t.getNextSibling();
				break;
			}
			case WILD_CARD:
			{
				wi = (AST)_t;
				match(_t,WILD_CARD);
				_t = _t.getNextSibling();
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void ebnf(AST _t,
		int x, int y
	) throws RecognitionException {
		
		AST ebnf_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST b1 = null;
		AST b2 = null;
		AST b3 = null;
		AST b4 = null;
		GrammarAST e = (GrammarAST)ebnf_AST_in;
			 e.setLoc(x, y);
			
		
		try {      // for error handling
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BLOCK:
			{
				AST __t25 = _t;
				AST tmp15_AST_in = (AST)_t;
				match(_t,BLOCK);
				_t = _t.getFirstChild();
				b1 = _t==ASTNULL ? null : (AST)_t;
				block(_t,x, y, BLOCK, BLOCK);
				_t = _retTree;
				_t = __t25;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)b1).getLeftConnPoint()[0],
								    ((GrammarAST)b1).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)b1).getRightConnPoint()[0],
								     ((GrammarAST)b1).getRightConnPoint()[1]);
						
				break;
			}
			case OPTIONAL:
			{
				AST __t26 = _t;
				AST tmp16_AST_in = (AST)_t;
				match(_t,OPTIONAL);
				_t = _t.getFirstChild();
				b2 = _t==ASTNULL ? null : (AST)_t;
				block(_t,x, y, OPTIONAL, OPTIONAL);
				_t = _retTree;
				_t = __t26;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)b2).getLeftConnPoint()[0],
								    ((GrammarAST)b2).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)b2).getRightConnPoint()[0],
								     ((GrammarAST)b2).getRightConnPoint()[1]);
						
				break;
			}
			case CLOSURE:
			{
				AST __t27 = _t;
				AST tmp17_AST_in = (AST)_t;
				match(_t,CLOSURE);
				_t = _t.getFirstChild();
				b3 = _t==ASTNULL ? null : (AST)_t;
				block(_t,x, y, CLOSURE, CLOSURE);
				_t = _retTree;
				_t = __t27;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)b3).getLeftConnPoint()[0],
								    ((GrammarAST)b3).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)b3).getRightConnPoint()[0],
								     ((GrammarAST)b3).getRightConnPoint()[1]);
						
				break;
			}
			case POSITIVE_CLOSURE:
			{
				AST __t28 = _t;
				AST tmp18_AST_in = (AST)_t;
				match(_t,POSITIVE_CLOSURE);
				_t = _t.getFirstChild();
				b4 = _t==ASTNULL ? null : (AST)_t;
				block(_t,x, y, POSITIVE_CLOSURE, POSITIVE_CLOSURE);
				_t = _retTree;
				_t = __t28;
				_t = _t.getNextSibling();
				e.setLeftConnPoint(((GrammarAST)b4).getLeftConnPoint()[0],
								    ((GrammarAST)b4).getLeftConnPoint()[1]);
						 e.setRightConnPoint(((GrammarAST)b4).getRightConnPoint()[0],
								     ((GrammarAST)b4).getRightConnPoint()[1]);
						
				break;
			}
			default:
			{
				throw new NoViableAltException(_t);
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	public final void tree(AST _t,
		int x, int y
	) throws RecognitionException {
		
		AST tree_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST t = null;
		AST a = null;
		AST e = null;
		
		try {      // for error handling
			AST __t30 = _t;
			t = _t==ASTNULL ? null :(AST)_t;
			match(_t,TREE_BEGIN);
			_t = _t.getFirstChild();
			((GrammarAST)t).setLoc(x, y);
			a = _t==ASTNULL ? null : (AST)_t;
			atom(_t,x, y);
			_t = _retTree;
			x += ((GrammarAST)a).getWidth() + ((GrammarAST)a).deltaX;
							 ((GrammarAST)t).setLeftConnPoint(((GrammarAST)a).getLeftConnPoint()[0],
											  ((GrammarAST)a).getLeftConnPoint()[1]);
							
			{
			_loop32:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==BLOCK||_t.getType()==OPTIONAL||_t.getType()==CLOSURE||_t.getType()==POSITIVE_CLOSURE||_t.getType()==SYNPRED||_t.getType()==TOKEN_RANGE||_t.getType()==CHAR_RANGE||_t.getType()==NOT||_t.getType()==EPSILON||_t.getType()==STRING_LITERAL||_t.getType()==ACTION||_t.getType()==CHAR_LITERAL||_t.getType()==TOKEN_REF||_t.getType()==RULE_REF||_t.getType()==SEMPRED||_t.getType()==TREE_BEGIN||_t.getType()==WILD_CARD)) {
					e = _t==ASTNULL ? null : (AST)_t;
					element(_t,x, y);
					_t = _retTree;
					x += ((GrammarAST)e).getWidth() + ((GrammarAST)e).deltaX;
										
				}
				else {
					break _loop32;
				}
				
			} while (true);
			}
			((GrammarAST)t).setRightConnPoint(((GrammarAST)e).getRightConnPoint()[0],
											   ((GrammarAST)e).getRightConnPoint()[1]);
			_t = __t30;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"tokens\"",
		"LEXER",
		"PARSER",
		"TREE_PARSER",
		"RULE",
		"BLOCK",
		"OPTIONAL",
		"CLOSURE",
		"POSITIVE_CLOSURE",
		"SYNPRED",
		"TOKEN_RANGE",
		"CHAR_RANGE",
		"NOT",
		"EPSILON",
		"ALT",
		"EOR",
		"\"header\"",
		"STRING_LITERAL",
		"ACTION",
		"DOC_COMMENT",
		"\"lexclass\"",
		"\"class\"",
		"\"extends\"",
		"\"Lexer\"",
		"\"TreeParser\"",
		"OPTIONS",
		"ASSIGN",
		"SEMI",
		"RCURLY",
		"\"charVocabulary\"",
		"CHAR_LITERAL",
		"INT",
		"OR",
		"RANGE",
		"TOKENS",
		"TOKEN_REF",
		"OPEN_ELEMENT_OPTION",
		"CLOSE_ELEMENT_OPTION",
		"LPAREN",
		"RULE_REF",
		"RPAREN",
		"\"Parser\"",
		"\"protected\"",
		"\"public\"",
		"\"private\"",
		"BANG",
		"ARG_ACTION",
		"\"returns\"",
		"COLON",
		"\"throws\"",
		"COMMA",
		"\"exception\"",
		"\"catch\"",
		"NOT_OP",
		"SEMPRED",
		"TREE_BEGIN",
		"QUESTION",
		"STAR",
		"PLUS",
		"IMPLIES",
		"CARET",
		"WILDCARD",
		"\"options\"",
		"WS",
		"COMMENT",
		"SL_COMMENT",
		"ML_COMMENT",
		"ESC",
		"DIGIT",
		"XDIGIT",
		"NESTED_ARG_ACTION",
		"NESTED_ACTION",
		"WS_LOOP",
		"INTERNAL_RULE_REF",
		"WS_OPT",
		"WILD_CARD"
	};
	
	}
	
