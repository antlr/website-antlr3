/* $ANTLR 2.7.5 (20050128): "idl.g" -> "IDLParser.cpp"$ */
#include "IDLParser.hpp"
#include <antlr/NoViableAltException.hpp>
#include <antlr/SemanticException.hpp>
#include <antlr/ASTFactory.hpp>
#line 1 "idl.g"
#line 8 "IDLParser.cpp"
IDLParser::IDLParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,k)
{
}

IDLParser::IDLParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,1)
{
}

IDLParser::IDLParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,k)
{
}

IDLParser::IDLParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,1)
{
}

IDLParser::IDLParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(state,1)
{
}

void IDLParser::specification() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt3=0;
		for (;;) {
			if ((_tokenSet_0.member(LA(1)))) {
				definition();
			}
			else {
				if ( _cnt3>=1 ) { goto _loop3; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt3++;
		}
		_loop3:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_1);
	}
}

void IDLParser::definition() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case SEMI:
		case LITERAL_typedef:
		case LITERAL_native:
		case LITERAL_struct:
		case LITERAL_union:
		case LITERAL_enum:
		{
			type_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_const:
		{
			const_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_exception:
		{
			except_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_interface:
		{
			interf();
			match(SEMI);
			break;
		}
		case LITERAL_module:
		{
			module();
			match(SEMI);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_2);
	}
}

void IDLParser::type_dcl() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_typedef:
		{
			match(LITERAL_typedef);
			type_declarator();
			break;
		}
		case LITERAL_struct:
		{
			struct_type();
			break;
		}
		case LITERAL_union:
		{
			union_type();
			break;
		}
		case LITERAL_enum:
		{
			enum_type();
			break;
		}
		case SEMI:
		{
			break;
		}
		case LITERAL_native:
		{
			match(LITERAL_native);
			simple_declarator();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::const_dcl() {
	
	try {      // for error handling
		match(LITERAL_const);
		const_type();
		identifier();
		match(ASSIGN);
		const_exp();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::except_dcl() {
	
	try {      // for error handling
		match(LITERAL_exception);
		identifier();
		match(LCURLY);
		opt_member_list();
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::interf() {
	
	try {      // for error handling
		match(LITERAL_interface);
		identifier();
		inheritance_spec();
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			interface_body();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::module() {
	
	try {      // for error handling
		match(LITERAL_module);
		identifier();
		match(LCURLY);
		definition_list();
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::identifier() {
	
	try {      // for error handling
		match(IDENT);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_4);
	}
}

void IDLParser::definition_list() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt9=0;
		for (;;) {
			if ((_tokenSet_0.member(LA(1)))) {
				definition();
			}
			else {
				if ( _cnt9>=1 ) { goto _loop9; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt9++;
		}
		_loop9:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::inheritance_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case COLON:
		{
			match(COLON);
			scoped_name_list();
			break;
		}
		case SEMI:
		case LCURLY:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_6);
	}
}

void IDLParser::interface_body() {
	
	try {      // for error handling
		match(LCURLY);
		{ // ( ... )*
		for (;;) {
			if ((_tokenSet_7.member(LA(1)))) {
				export_spec();
			}
			else {
				goto _loop14;
			}
			
		}
		_loop14:;
		} // ( ... )*
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::export_spec() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case SEMI:
		case LITERAL_typedef:
		case LITERAL_native:
		case LITERAL_struct:
		case LITERAL_union:
		case LITERAL_enum:
		{
			type_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_const:
		{
			const_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_exception:
		{
			except_dcl();
			match(SEMI);
			break;
		}
		case LITERAL_readonly:
		case LITERAL_attribute:
		{
			attr_dcl();
			match(SEMI);
			break;
		}
		case SCOPEOP:
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		case LITERAL_string:
		case LITERAL_oneway:
		case LITERAL_void:
		case IDENT:
		{
			op_dcl();
			match(SEMI);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_8);
	}
}

void IDLParser::attr_dcl() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case LITERAL_readonly:
		{
			match(LITERAL_readonly);
			break;
		}
		case LITERAL_attribute:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(LITERAL_attribute);
		param_type_spec();
		simple_declarator_list();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::op_dcl() {
	
	try {      // for error handling
		op_attribute();
		op_type_spec();
		identifier();
		parameter_dcls();
		opt_raises_expr();
		opt_context_expr();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::scoped_name_list() {
	
	try {      // for error handling
		scoped_name();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				scoped_name();
			}
			else {
				goto _loop20;
			}
			
		}
		_loop20:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_9);
	}
}

void IDLParser::scoped_name() {
	
	try {      // for error handling
		opt_scope_op();
		identifier();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == SCOPEOP)) {
				match(SCOPEOP);
				identifier();
			}
			else {
				goto _loop23;
			}
			
		}
		_loop23:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_10);
	}
}

void IDLParser::opt_scope_op() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case SCOPEOP:
		{
			match(SCOPEOP);
			break;
		}
		case IDENT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::const_type() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		{
			integer_type();
			break;
		}
		case LITERAL_char:
		{
			char_type();
			break;
		}
		case LITERAL_boolean:
		{
			boolean_type();
			break;
		}
		case LITERAL_float:
		case LITERAL_double:
		{
			floating_pt_type();
			break;
		}
		case LITERAL_string:
		{
			string_type();
			break;
		}
		case SCOPEOP:
		case IDENT:
		{
			scoped_name();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::const_exp() {
	
	try {      // for error handling
		or_expr();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_12);
	}
}

void IDLParser::integer_type() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case LITERAL_unsigned:
		{
			match(LITERAL_unsigned);
			break;
		}
		case LITERAL_short:
		case LITERAL_long:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_short:
		{
			match(LITERAL_short);
			break;
		}
		case LITERAL_long:
		{
			match(LITERAL_long);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_13);
	}
}

void IDLParser::char_type() {
	
	try {      // for error handling
		match(LITERAL_char);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_13);
	}
}

void IDLParser::boolean_type() {
	
	try {      // for error handling
		match(LITERAL_boolean);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_13);
	}
}

void IDLParser::floating_pt_type() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_float:
		{
			match(LITERAL_float);
			break;
		}
		case LITERAL_double:
		{
			match(LITERAL_double);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::string_type() {
	
	try {      // for error handling
		match(LITERAL_string);
		opt_pos_int_br();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::or_expr() {
	
	try {      // for error handling
		xor_expr();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == OR)) {
				or_op();
				xor_expr();
			}
			else {
				goto _loop30;
			}
			
		}
		_loop30:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_12);
	}
}

void IDLParser::xor_expr() {
	
	try {      // for error handling
		and_expr();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == XOR)) {
				xor_op();
				and_expr();
			}
			else {
				goto _loop34;
			}
			
		}
		_loop34:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_15);
	}
}

void IDLParser::or_op() {
	
	try {      // for error handling
		match(OR);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::and_expr() {
	
	try {      // for error handling
		shift_expr();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == AND)) {
				and_op();
				shift_expr();
			}
			else {
				goto _loop38;
			}
			
		}
		_loop38:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_17);
	}
}

void IDLParser::xor_op() {
	
	try {      // for error handling
		match(XOR);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::shift_expr() {
	
	try {      // for error handling
		add_expr();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == LSHIFT || LA(1) == RSHIFT)) {
				shift_op();
				add_expr();
			}
			else {
				goto _loop42;
			}
			
		}
		_loop42:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_18);
	}
}

void IDLParser::and_op() {
	
	try {      // for error handling
		match(AND);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::add_expr() {
	
	try {      // for error handling
		mult_expr();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == PLUS || LA(1) == MINUS)) {
				add_op();
				mult_expr();
			}
			else {
				goto _loop46;
			}
			
		}
		_loop46:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_19);
	}
}

void IDLParser::shift_op() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LSHIFT:
		{
			match(LSHIFT);
			break;
		}
		case RSHIFT:
		{
			match(RSHIFT);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::mult_expr() {
	
	try {      // for error handling
		unary_expr();
		{ // ( ... )*
		for (;;) {
			if (((LA(1) >= STAR && LA(1) <= MOD))) {
				mult_op();
				unary_expr();
			}
			else {
				goto _loop50;
			}
			
		}
		_loop50:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_20);
	}
}

void IDLParser::add_op() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case PLUS:
		{
			match(PLUS);
			break;
		}
		case MINUS:
		{
			match(MINUS);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::unary_expr() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case PLUS:
		case MINUS:
		case TILDE:
		{
			unary_operator();
			primary_expr();
			break;
		}
		case SCOPEOP:
		case LPAREN:
		case LITERAL_TRUE:
		case LITERAL_FALSE:
		case INT:
		case OCTAL:
		case HEX:
		case STRING_LITERAL:
		case CHAR_LITERAL:
		case FLOAT:
		case IDENT:
		{
			primary_expr();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::mult_op() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case STAR:
		{
			match(STAR);
			break;
		}
		case DIV:
		{
			match(DIV);
			break;
		}
		case MOD:
		{
			match(MOD);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_16);
	}
}

void IDLParser::unary_operator() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case MINUS:
		{
			match(MINUS);
			break;
		}
		case PLUS:
		{
			match(PLUS);
			break;
		}
		case TILDE:
		{
			match(TILDE);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_22);
	}
}

void IDLParser::primary_expr() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case SCOPEOP:
		case IDENT:
		{
			scoped_name();
			break;
		}
		case LITERAL_TRUE:
		case LITERAL_FALSE:
		case INT:
		case OCTAL:
		case HEX:
		case STRING_LITERAL:
		case CHAR_LITERAL:
		case FLOAT:
		{
			literal();
			break;
		}
		case LPAREN:
		{
			match(LPAREN);
			const_exp();
			match(RPAREN);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::literal() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case INT:
		case OCTAL:
		case HEX:
		{
			integer_literal();
			break;
		}
		case STRING_LITERAL:
		{
			string_literal();
			break;
		}
		case CHAR_LITERAL:
		{
			character_literal();
			break;
		}
		case FLOAT:
		{
			floating_pt_literal();
			break;
		}
		case LITERAL_TRUE:
		case LITERAL_FALSE:
		{
			boolean_literal();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::integer_literal() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case INT:
		{
			match(INT);
			break;
		}
		case OCTAL:
		{
			match(OCTAL);
			break;
		}
		case HEX:
		{
			match(HEX);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::string_literal() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt140=0;
		for (;;) {
			if ((LA(1) == STRING_LITERAL)) {
				match(STRING_LITERAL);
			}
			else {
				if ( _cnt140>=1 ) { goto _loop140; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt140++;
		}
		_loop140:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_23);
	}
}

void IDLParser::character_literal() {
	
	try {      // for error handling
		match(CHAR_LITERAL);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::floating_pt_literal() {
	ANTLR_USE_NAMESPACE(antlr)RefToken  f = ANTLR_USE_NAMESPACE(antlr)nullToken;
	
	try {      // for error handling
		f = LT(1);
		match(FLOAT);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::boolean_literal() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_TRUE:
		{
			match(LITERAL_TRUE);
			break;
		}
		case LITERAL_FALSE:
		{
			match(LITERAL_FALSE);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_21);
	}
}

void IDLParser::positive_int_const() {
	
	try {      // for error handling
		const_exp();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_24);
	}
}

void IDLParser::type_declarator() {
	
	try {      // for error handling
		type_spec();
		declarators();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::struct_type() {
	
	try {      // for error handling
		match(LITERAL_struct);
		identifier();
		match(LCURLY);
		member_list();
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_25);
	}
}

void IDLParser::union_type() {
	
	try {      // for error handling
		match(LITERAL_union);
		identifier();
		match(LITERAL_switch);
		match(LPAREN);
		switch_type_spec();
		match(RPAREN);
		match(LCURLY);
		switch_body();
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_25);
	}
}

void IDLParser::enum_type() {
	
	try {      // for error handling
		match(LITERAL_enum);
		identifier();
		match(LCURLY);
		enumerator_list();
		match(RCURLY);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_26);
	}
}

void IDLParser::simple_declarator() {
	
	try {      // for error handling
		identifier();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_27);
	}
}

void IDLParser::type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case SCOPEOP:
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		case LITERAL_sequence:
		case LITERAL_string:
		case IDENT:
		{
			simple_type_spec();
			break;
		}
		case LITERAL_struct:
		case LITERAL_union:
		case LITERAL_enum:
		{
			constr_type_spec();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::declarators() {
	
	try {      // for error handling
		declarator();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				declarator();
			}
			else {
				goto _loop73;
			}
			
		}
		_loop73:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::simple_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		{
			base_type_spec();
			break;
		}
		case LITERAL_sequence:
		case LITERAL_string:
		{
			template_type_spec();
			break;
		}
		case SCOPEOP:
		case IDENT:
		{
			scoped_name();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::constr_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_struct:
		{
			struct_type();
			break;
		}
		case LITERAL_union:
		{
			union_type();
			break;
		}
		case LITERAL_enum:
		{
			enum_type();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::base_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		{
			integer_type();
			break;
		}
		case LITERAL_char:
		{
			char_type();
			break;
		}
		case LITERAL_boolean:
		{
			boolean_type();
			break;
		}
		case LITERAL_float:
		case LITERAL_double:
		{
			floating_pt_type();
			break;
		}
		case LITERAL_octet:
		{
			match(LITERAL_octet);
			break;
		}
		case LITERAL_any:
		{
			match(LITERAL_any);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::template_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_sequence:
		{
			sequence_type();
			break;
		}
		case LITERAL_string:
		{
			string_type();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::sequence_type() {
	
	try {      // for error handling
		match(LITERAL_sequence);
		match(LT_);
		simple_type_spec();
		opt_pos_int();
		match(GT);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::declarator() {
	
	try {      // for error handling
		identifier();
		opt_fixed_array_size();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_28);
	}
}

void IDLParser::opt_fixed_array_size() {
	
	try {      // for error handling
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == LBRACK)) {
				fixed_array_size();
			}
			else {
				goto _loop77;
			}
			
		}
		_loop77:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_28);
	}
}

void IDLParser::fixed_array_size() {
	
	try {      // for error handling
		match(LBRACK);
		positive_int_const();
		match(RBRACK);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_29);
	}
}

void IDLParser::member_list() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt82=0;
		for (;;) {
			if ((_tokenSet_30.member(LA(1)))) {
				member();
			}
			else {
				if ( _cnt82>=1 ) { goto _loop82; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt82++;
		}
		_loop82:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::member() {
	
	try {      // for error handling
		type_spec();
		declarators();
		match(SEMI);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_31);
	}
}

void IDLParser::switch_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		{
			integer_type();
			break;
		}
		case LITERAL_char:
		{
			char_type();
			break;
		}
		case LITERAL_boolean:
		{
			boolean_type();
			break;
		}
		case LITERAL_enum:
		{
			enum_type();
			break;
		}
		case SCOPEOP:
		case IDENT:
		{
			scoped_name();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_32);
	}
}

void IDLParser::switch_body() {
	
	try {      // for error handling
		case_stmt_list();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::case_stmt_list() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt89=0;
		for (;;) {
			if ((LA(1) == LITERAL_case || LA(1) == LITERAL_default)) {
				case_stmt();
			}
			else {
				if ( _cnt89>=1 ) { goto _loop89; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt89++;
		}
		_loop89:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::case_stmt() {
	
	try {      // for error handling
		case_label_list();
		element_spec();
		match(SEMI);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_33);
	}
}

void IDLParser::case_label_list() {
	
	try {      // for error handling
		{ // ( ... )+
		int _cnt93=0;
		for (;;) {
			if ((LA(1) == LITERAL_case || LA(1) == LITERAL_default)) {
				case_label();
			}
			else {
				if ( _cnt93>=1 ) { goto _loop93; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt93++;
		}
		_loop93:;
		}  // ( ... )+
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_30);
	}
}

void IDLParser::element_spec() {
	
	try {      // for error handling
		type_spec();
		declarator();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::case_label() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_case:
		{
			match(LITERAL_case);
			const_exp();
			match(COLON);
			break;
		}
		case LITERAL_default:
		{
			match(LITERAL_default);
			match(COLON);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_34);
	}
}

void IDLParser::enumerator_list() {
	
	try {      // for error handling
		enumerator();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				enumerator();
			}
			else {
				goto _loop99;
			}
			
		}
		_loop99:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::enumerator() {
	
	try {      // for error handling
		identifier();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_35);
	}
}

void IDLParser::opt_pos_int() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case COMMA:
		{
			match(COMMA);
			positive_int_const();
			break;
		}
		case GT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_36);
	}
}

void IDLParser::opt_pos_int_br() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case LT_:
		{
			match(LT_);
			positive_int_const();
			match(GT);
			break;
		}
		case COMMA:
		case GT:
		case IDENT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_14);
	}
}

void IDLParser::param_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		{
			base_type_spec();
			break;
		}
		case LITERAL_string:
		{
			string_type();
			break;
		}
		case SCOPEOP:
		case IDENT:
		{
			scoped_name();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::simple_declarator_list() {
	
	try {      // for error handling
		simple_declarator();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				simple_declarator();
			}
			else {
				goto _loop112;
			}
			
		}
		_loop112:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::opt_member_list() {
	
	try {      // for error handling
		{ // ( ... )*
		for (;;) {
			if ((_tokenSet_30.member(LA(1)))) {
				member();
			}
			else {
				goto _loop116;
			}
			
		}
		_loop116:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_5);
	}
}

void IDLParser::op_attribute() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_oneway:
		{
			match(LITERAL_oneway);
			break;
		}
		case SCOPEOP:
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		case LITERAL_string:
		case LITERAL_void:
		case IDENT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_37);
	}
}

void IDLParser::op_type_spec() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case SCOPEOP:
		case LITERAL_octet:
		case LITERAL_any:
		case LITERAL_unsigned:
		case LITERAL_short:
		case LITERAL_long:
		case LITERAL_char:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_boolean:
		case LITERAL_string:
		case IDENT:
		{
			param_type_spec();
			break;
		}
		case LITERAL_void:
		{
			match(LITERAL_void);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_11);
	}
}

void IDLParser::parameter_dcls() {
	
	try {      // for error handling
		match(LPAREN);
		{
		switch ( LA(1)) {
		case LITERAL_in:
		case LITERAL_out:
		case LITERAL_inout:
		{
			param_dcl_list();
			break;
		}
		case RPAREN:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RPAREN);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_38);
	}
}

void IDLParser::opt_raises_expr() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case LITERAL_raises:
		{
			raises_expr();
			break;
		}
		case SEMI:
		case LITERAL_context:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_39);
	}
}

void IDLParser::opt_context_expr() {
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case LITERAL_context:
		{
			context_expr();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::raises_expr() {
	
	try {      // for error handling
		match(LITERAL_raises);
		match(LPAREN);
		scoped_name_list();
		match(RPAREN);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_39);
	}
}

void IDLParser::context_expr() {
	
	try {      // for error handling
		match(LITERAL_context);
		match(LPAREN);
		string_literal_list();
		match(RPAREN);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_3);
	}
}

void IDLParser::param_dcl_list() {
	
	try {      // for error handling
		param_dcl();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				param_dcl();
			}
			else {
				goto _loop128;
			}
			
		}
		_loop128:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_32);
	}
}

void IDLParser::param_dcl() {
	
	try {      // for error handling
		param_attribute();
		param_type_spec();
		simple_declarator();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_40);
	}
}

void IDLParser::param_attribute() {
	
	try {      // for error handling
		switch ( LA(1)) {
		case LITERAL_in:
		{
			match(LITERAL_in);
			break;
		}
		case LITERAL_out:
		{
			match(LITERAL_out);
			break;
		}
		case LITERAL_inout:
		{
			match(LITERAL_inout);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_41);
	}
}

void IDLParser::string_literal_list() {
	
	try {      // for error handling
		string_literal();
		{ // ( ... )*
		for (;;) {
			if ((LA(1) == COMMA)) {
				match(COMMA);
				string_literal();
			}
			else {
				goto _loop135;
			}
			
		}
		_loop135:;
		} // ( ... )*
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		recover(ex,_tokenSet_32);
	}
}

void IDLParser::initializeASTFactory( ANTLR_USE_NAMESPACE(antlr)ASTFactory& )
{
}
const char* IDLParser::tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	";",
	"\"module\"",
	"{",
	"}",
	"\"interface\"",
	":",
	",",
	"::",
	"\"const\"",
	"=",
	"|",
	"^",
	"&",
	"<<",
	">>",
	"+",
	"-",
	"*",
	"/",
	"%",
	"~",
	"(",
	")",
	"\"TRUE\"",
	"\"FALSE\"",
	"\"typedef\"",
	"\"native\"",
	"\"octet\"",
	"\"any\"",
	"\"unsigned\"",
	"\"short\"",
	"\"long\"",
	"\"char\"",
	"\"float\"",
	"\"double\"",
	"\"boolean\"",
	"\"struct\"",
	"\"union\"",
	"\"switch\"",
	"\"case\"",
	"\"default\"",
	"\"enum\"",
	"\"sequence\"",
	"<",
	">",
	"\"string\"",
	"[",
	"]",
	"\"readonly\"",
	"\"attribute\"",
	"\"exception\"",
	"\"oneway\"",
	"\"void\"",
	"\"in\"",
	"\"out\"",
	"\"inout\"",
	"\"raises\"",
	"\"context\"",
	"an integer value",
	"OCTAL",
	"a hexadecimal value value",
	"a string literal",
	"a character literal",
	"an floating point value",
	"an identifer",
	"?",
	".",
	"!",
	"white space",
	"a preprocessor directive",
	"a comment",
	"a comment",
	"an escape sequence",
	"an escaped character value",
	"a digit",
	"an octal digit",
	"a hexadecimal digit",
	0
};

const unsigned long IDLParser::_tokenSet_0_data_[] = { 1610617136UL, 4203264UL, 0UL, 0UL };
// SEMI "module" "interface" "const" "typedef" "native" "struct" "union" 
// "enum" "exception" 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long IDLParser::_tokenSet_1_data_[] = { 2UL, 0UL, 0UL, 0UL };
// EOF 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_1(_tokenSet_1_data_,4);
const unsigned long IDLParser::_tokenSet_2_data_[] = { 1610617266UL, 4203264UL, 0UL, 0UL };
// EOF SEMI "module" RCURLY "interface" "const" "typedef" "native" "struct" 
// "union" "enum" "exception" 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_2(_tokenSet_2_data_,4);
const unsigned long IDLParser::_tokenSet_3_data_[] = { 16UL, 0UL, 0UL, 0UL };
// SEMI 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_3(_tokenSet_3_data_,4);
const unsigned long IDLParser::_tokenSet_4_data_[] = { 117436112UL, 852992UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI LCURLY RCURLY COLON COMMA SCOPEOP ASSIGN OR XOR AND LSHIFT RSHIFT 
// PLUS MINUS STAR DIV MOD LPAREN RPAREN "switch" GT LBRACK RBRACK IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_4(_tokenSet_4_data_,8);
const unsigned long IDLParser::_tokenSet_5_data_[] = { 128UL, 0UL, 0UL, 0UL };
// RCURLY 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_5(_tokenSet_5_data_,4);
const unsigned long IDLParser::_tokenSet_6_data_[] = { 80UL, 0UL, 0UL, 0UL };
// SEMI LCURLY 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_6(_tokenSet_6_data_,4);
const unsigned long IDLParser::_tokenSet_7_data_[] = { 3758102544UL, 32646143UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI SCOPEOP "const" "typedef" "native" "octet" "any" "unsigned" "short" 
// "long" "char" "float" "double" "boolean" "struct" "union" "enum" "string" 
// "readonly" "attribute" "exception" "oneway" "void" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_7(_tokenSet_7_data_,8);
const unsigned long IDLParser::_tokenSet_8_data_[] = { 3758102672UL, 32646143UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI RCURLY SCOPEOP "const" "typedef" "native" "octet" "any" "unsigned" 
// "short" "long" "char" "float" "double" "boolean" "struct" "union" "enum" 
// "string" "readonly" "attribute" "exception" "oneway" "void" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_8(_tokenSet_8_data_,8);
const unsigned long IDLParser::_tokenSet_9_data_[] = { 67108944UL, 0UL, 0UL, 0UL };
// SEMI LCURLY RPAREN 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_9(_tokenSet_9_data_,4);
const unsigned long IDLParser::_tokenSet_10_data_[] = { 83871312UL, 589824UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI LCURLY COLON COMMA OR XOR AND LSHIFT RSHIFT PLUS MINUS STAR DIV 
// MOD RPAREN GT RBRACK IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_10(_tokenSet_10_data_,8);
const unsigned long IDLParser::_tokenSet_11_data_[] = { 0UL, 0UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_11(_tokenSet_11_data_,8);
const unsigned long IDLParser::_tokenSet_12_data_[] = { 67109392UL, 589824UL, 0UL, 0UL };
// SEMI COLON RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_12(_tokenSet_12_data_,4);
const unsigned long IDLParser::_tokenSet_13_data_[] = { 67109888UL, 65536UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// COMMA RPAREN GT IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_13(_tokenSet_13_data_,8);
const unsigned long IDLParser::_tokenSet_14_data_[] = { 1024UL, 65536UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// COMMA GT IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_14(_tokenSet_14_data_,8);
const unsigned long IDLParser::_tokenSet_15_data_[] = { 67125776UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_15(_tokenSet_15_data_,4);
const unsigned long IDLParser::_tokenSet_16_data_[] = { 454559744UL, 3221225472UL, 31UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP PLUS MINUS TILDE LPAREN "TRUE" "FALSE" INT OCTAL HEX STRING_LITERAL 
// CHAR_LITERAL FLOAT IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_16(_tokenSet_16_data_,8);
const unsigned long IDLParser::_tokenSet_17_data_[] = { 67158544UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR XOR RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_17(_tokenSet_17_data_,4);
const unsigned long IDLParser::_tokenSet_18_data_[] = { 67224080UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR XOR AND RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_18(_tokenSet_18_data_,4);
const unsigned long IDLParser::_tokenSet_19_data_[] = { 67617296UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR XOR AND LSHIFT RSHIFT RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_19(_tokenSet_19_data_,4);
const unsigned long IDLParser::_tokenSet_20_data_[] = { 69190160UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR XOR AND LSHIFT RSHIFT PLUS MINUS RPAREN GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_20(_tokenSet_20_data_,4);
const unsigned long IDLParser::_tokenSet_21_data_[] = { 83870224UL, 589824UL, 0UL, 0UL };
// SEMI COLON OR XOR AND LSHIFT RSHIFT PLUS MINUS STAR DIV MOD RPAREN GT 
// RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_21(_tokenSet_21_data_,4);
const unsigned long IDLParser::_tokenSet_22_data_[] = { 436209664UL, 3221225472UL, 31UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP LPAREN "TRUE" "FALSE" INT OCTAL HEX STRING_LITERAL CHAR_LITERAL 
// FLOAT IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_22(_tokenSet_22_data_,8);
const unsigned long IDLParser::_tokenSet_23_data_[] = { 83871248UL, 589824UL, 0UL, 0UL };
// SEMI COLON COMMA OR XOR AND LSHIFT RSHIFT PLUS MINUS STAR DIV MOD RPAREN 
// GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_23(_tokenSet_23_data_,4);
const unsigned long IDLParser::_tokenSet_24_data_[] = { 0UL, 589824UL, 0UL, 0UL };
// GT RBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_24(_tokenSet_24_data_,4);
const unsigned long IDLParser::_tokenSet_25_data_[] = { 16UL, 0UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_25(_tokenSet_25_data_,8);
const unsigned long IDLParser::_tokenSet_26_data_[] = { 67108880UL, 0UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SEMI RPAREN IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_26(_tokenSet_26_data_,8);
const unsigned long IDLParser::_tokenSet_27_data_[] = { 67109904UL, 0UL, 0UL, 0UL };
// SEMI COMMA RPAREN 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_27(_tokenSet_27_data_,4);
const unsigned long IDLParser::_tokenSet_28_data_[] = { 1040UL, 0UL, 0UL, 0UL };
// SEMI COMMA 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_28(_tokenSet_28_data_,4);
const unsigned long IDLParser::_tokenSet_29_data_[] = { 1040UL, 262144UL, 0UL, 0UL };
// SEMI COMMA LBRACK 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_29(_tokenSet_29_data_,4);
const unsigned long IDLParser::_tokenSet_30_data_[] = { 2147485696UL, 156671UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP "octet" "any" "unsigned" "short" "long" "char" "float" "double" 
// "boolean" "struct" "union" "enum" "sequence" "string" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_30(_tokenSet_30_data_,8);
const unsigned long IDLParser::_tokenSet_31_data_[] = { 2147485824UL, 156671UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// RCURLY SCOPEOP "octet" "any" "unsigned" "short" "long" "char" "float" 
// "double" "boolean" "struct" "union" "enum" "sequence" "string" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_31(_tokenSet_31_data_,8);
const unsigned long IDLParser::_tokenSet_32_data_[] = { 67108864UL, 0UL, 0UL, 0UL };
// RPAREN 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_32(_tokenSet_32_data_,4);
const unsigned long IDLParser::_tokenSet_33_data_[] = { 128UL, 6144UL, 0UL, 0UL };
// RCURLY "case" "default" 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_33(_tokenSet_33_data_,4);
const unsigned long IDLParser::_tokenSet_34_data_[] = { 2147485696UL, 162815UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP "octet" "any" "unsigned" "short" "long" "char" "float" "double" 
// "boolean" "struct" "union" "case" "default" "enum" "sequence" "string" 
// IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_34(_tokenSet_34_data_,8);
const unsigned long IDLParser::_tokenSet_35_data_[] = { 1152UL, 0UL, 0UL, 0UL };
// RCURLY COMMA 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_35(_tokenSet_35_data_,4);
const unsigned long IDLParser::_tokenSet_36_data_[] = { 0UL, 65536UL, 0UL, 0UL };
// GT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_36(_tokenSet_36_data_,4);
const unsigned long IDLParser::_tokenSet_37_data_[] = { 2147485696UL, 16908543UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP "octet" "any" "unsigned" "short" "long" "char" "float" "double" 
// "boolean" "string" "void" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_37(_tokenSet_37_data_,8);
const unsigned long IDLParser::_tokenSet_38_data_[] = { 16UL, 805306368UL, 0UL, 0UL };
// SEMI "raises" "context" 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_38(_tokenSet_38_data_,4);
const unsigned long IDLParser::_tokenSet_39_data_[] = { 16UL, 536870912UL, 0UL, 0UL };
// SEMI "context" 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_39(_tokenSet_39_data_,4);
const unsigned long IDLParser::_tokenSet_40_data_[] = { 67109888UL, 0UL, 0UL, 0UL };
// COMMA RPAREN 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_40(_tokenSet_40_data_,4);
const unsigned long IDLParser::_tokenSet_41_data_[] = { 2147485696UL, 131327UL, 16UL, 0UL, 0UL, 0UL, 0UL, 0UL };
// SCOPEOP "octet" "any" "unsigned" "short" "long" "char" "float" "double" 
// "boolean" "string" IDENT 
const ANTLR_USE_NAMESPACE(antlr)BitSet IDLParser::_tokenSet_41(_tokenSet_41_data_,8);


