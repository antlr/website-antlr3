package org.antlr.java.crossref;

import java.util.Vector;

/**
* A class for storing information about the code of a method.
*
* @see KMethodInfo#setCodeInfo(KCodeInfo)
*/
public class KCodeInfo {
	private short maxStack, maxLocals;
	private byte[] bytecode;
	private KExceptionInfo[] exceptionTable;
	private KLineNumberInfo[] lineNumberTable;
	private KLocalVariableInfo[] localVariableTable;
	private Vector attributes = new Vector();

	public KCodeInfo(short maxStack, short maxLocals, byte[] bytecode, 
		KExceptionInfo[] exceptionTable) 
	{
		setMaxStack(maxStack);
		setMaxLocals(maxLocals);
		setBytecode(bytecode);
		setExceptionTable(exceptionTable);
	}

	public void setMaxStack(short maxStack) {
		this.maxStack = maxStack;
	}

	public short getMaxStack() {
		return maxStack;
	}

	public void setMaxLocals(short maxLocals) {
		this.maxLocals = maxLocals;
	}

	public short getMaxLocals() {
		return maxLocals;
	}

	public void setBytecode(byte[] bytecode) {
		this.bytecode = bytecode;
	}

	public byte[] getBytecode() {
		return bytecode;
	}

	public void setExceptionTable(KExceptionInfo[] exceptionTable) {
		this.exceptionTable = exceptionTable;
	}

	public KExceptionInfo[] getExceptionTable() {
		return exceptionTable;
	}

	public void setLineNumberTable(KLineNumberInfo[] lineNumberTable) {
		this.lineNumberTable = lineNumberTable;
	}

	public KLineNumberInfo[] getLineNumberTable() {
		return lineNumberTable;
	}

	public void setLocalVariableTable(KLocalVariableInfo[] localVariableTable) {
		this.localVariableTable = localVariableTable;
	}

	public KLocalVariableInfo[] getLocalVariableTable() {
		return localVariableTable;
	}

	public void addAttribute(KAttributeInfo attributeInfo) {
		attributes.addElement(attributeInfo);
	}

	public KAttributeInfo[] getAttributes() {
		KAttributeInfo[] list = new KAttributeInfo[attributes.size()];
		attributes.copyInto(list);
		return list;
	}
}